import React, { useState, useEffect } from "react";
import { Selector } from "components";
import { Row, Col, Input, message } from 'antd';
import useDebounce from "../../../hook/useDebounce"
import { orArray, orNull } from 'utils/Selector';
import { ProductCategories as ProductCategoriesAPI } from "api";

function Search(props) {
  const { filter, setFilter, searchValueCustom } = props
  const [searchValue, setSearchValue] = useState("")
  const [categories, setCategories] = useState([])
  const [categoryValue, setCategoryValue] = useState("all")
  const inputDebounce = useDebounce(searchValue, 300)

  useEffect(()=>{
    if(searchValueCustom != ""){
      setSearchValue(searchValueCustom)
    }
  },[searchValueCustom])

  useEffect(()=>{
    if (inputDebounce) {
      setFilter(prevState => ({
        ...prevState,
        q: searchValue
      }))
      return
    }
  },[inputDebounce])

  async function onGetListCategories(params) {
    try {
        const response = await ProductCategoriesAPI.getListProductCategoriesParent(params);
        const { data, status } = response;
        if (status === 200) {
            const defaultOptions = [
                { 
                    value: "all",
                    label: "Tất cả"
                }
            ]
            const result = data.data.map((item)=>({ value: item.id, label: item.name }))
            setCategories(defaultOptions.concat(result))
        }
    } catch (error) {
        message.error('Đã xảy ra lỗi trong quá trình lấy danh mục sản phẩm');
    }
}

useEffect(() => {
    onGetListCategories({})
}, [])


  useEffect(()=>{
    if(searchValue === "" && filter.q){
      delete filter.q;
      setFilter({...filter})
    }

  },[searchValue, filter])


  const onChangeSearchValue = (e) =>{
    setSearchValue(e.target.value)
  }

  const onChangeCategory = (value) =>{
    if(value === "all"){
        delete filter.category;
        setFilter({...filter})
        return
    }
    setCategoryValue(value)
    setFilter(prevState => ({
        ...prevState,
        category: value,
    }))
  }


  return (
    <div style={{ marginBottom: 15 }}>
      <Row gutter={24}>
        <Col span={6}>
            <Selector 
                placeholder="Lựa chọn danh mục sản phẩm" 
                value={categoryValue} 
                options={categories}
                onChange={onChangeCategory}
            />
        </Col>
        <Col span={18}>
          <Input value={searchValue} onChange={onChangeSearchValue} allowClear placeholder="Tìm kiếm theo tên sản phẩm ..."/>
        </Col>
      </Row>
    </div>
  );
}

export default Search;
