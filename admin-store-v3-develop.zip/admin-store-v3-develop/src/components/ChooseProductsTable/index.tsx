import React, { useState, useEffect } from 'react'
import "./styled.scss"
import { Modal, message, Spin, Button } from 'antd';
import { Product as ProductAPI } from "api";
import Search from "./Search"
import Table from './Table';

function ChooseProductsTable(props) {
    const {
        isVariant = false,
        visible,
        handleConfirm,
        handleCancel,
        listItemChoose,
        itemDisable,
        searchValueCustom = "",
        itemReject,
        allowInactive = false,
        isGroupProduct = false
    } = props
    const [products, setProducts] = useState({
        isLoading: false,
        data: [],
        meta: null
    })
    const [filter, setFilter] = useState({
        isActive: allowInactive ? null : true,
        page: 1,
        excludes: itemReject ? itemReject.join(",") : null,
        pageSize: 15
    });
    const [selectProducts, setSelectProducts] = useState([])

    useEffect(() => {
        if (listItemChoose) {
            setSelectProducts(listItemChoose)
        }
    }, [listItemChoose])

    useEffect(() => {
        if (itemDisable) {
            setSelectProducts(itemDisable.map(item => ({ ...item.product })))
        }
    }, [itemDisable])

    async function onGetListProduct(params) {
        try {
            setProducts({ ...products, isLoading: true })
            const response = await ProductAPI.getListProduct(params);
            const { data, status } = response;
            if (status === 200) {
                setProducts({
                    isLoading: false,
                    data: data.data.datas,
                    meta: {
                        page: data.data.page,
                        pageSize: data.data.pageSize,
                        total: data.data.total
                    }
                })
            }
        } catch (error) {
            message.error('Đã xảy ra lỗi trong quá trình lấy danh sách sản phẩm');
            setProducts({
                ...products,
                isLoading: false,
                data: [],
            })
        }
    }

    useEffect(() => {
        onGetListProduct(filter)
    }, [filter])


    function onClickConfirm() {
        handleConfirm(isGroupProduct ? selectProducts.filter(item => item.key) : selectProducts)
    }

    const ModalHeader = React.useCallback(() => {
        return (
            <div className="modal-header">
                <Button disabled={isGroupProduct && selectProducts.filter(item => item.key).length === 0 ? true : false} className="button-confirm" key="submit" type="primary" onClick={onClickConfirm}>
                    {selectProducts.length ? `Chọn ${selectProducts.length} sản phẩm` : "Xác nhận"}
                </Button>
                <Button key="back" onClick={handleCancel}>
                    Huỷ
                </Button>
            </div>
        )
    }, [selectProducts])

    function onChangePage(page) {
        setProducts(prevState => ({
            ...prevState,
            meta: {
                ...prevState.meta,
                page: page
            }
        }));

        setFilter({ ...filter, page: page });
    }

    return (
        <Modal
            title="Chọn sản phẩm"
            visible={visible}
            width={1000}
            onCancel={handleCancel}
            footer={false}
            bodyStyle={{ maxHeight: 700, overflow: "auto" }}
        >
            <Spin spinning={products.isLoading}>
                <ModalHeader />
                <Search filter={filter} setFilter={setFilter} searchValueCustom={searchValueCustom} />
                <Table
                    isVariant={isVariant}
                    itemDisable={itemDisable}
                    products={products}
                    onChangePage={onChangePage}
                    selectProducts={selectProducts}
                    setSelectProducts={setSelectProducts}
                />
            </Spin>
        </Modal>
    );
}


export default ChooseProductsTable
