import React, { useState, useEffect } from "react";
import { Table as AntTable, Avatar, Tag, Typography } from "antd";
import { orArray, orEmpty, orNull, orNumber } from "utils/Selector";
import { Helpers } from "utils";

const { Text } = Typography;

function Table(props) {
  const {
    isVariant,
    itemDisable,
    products,
    onChangePage,
    selectProducts,
    setSelectProducts,
  } = props;
  const [columnsTable, setColumnsTable] = useState([]);
  const [dataTable, setDataTable] = useState([]);

  const renderStatusProduct = (isOutOfStock, isActive) => {
    if (!isActive) {
      return (
        <Tag color="error">
          <span>Ngừng bán</span>
        </Tag>
      );
    }
    if (isOutOfStock) {
      return (
        <Tag color="error">
          <span>Hết hàng</span>
        </Tag>
      );
    }
    return null;
  };

  const onUpdateColumns = () => {
    if (isVariant) {
      const columns = [
        {
          title: "Tên Sản phẩm",
          dataIndex: "name",
          key: "name",
          render(value, record) {
            return {
              children: (
                <div
                  style={{
                    cursor: "pointer",
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  {orNull("image", record) ? (
                    <Avatar
                      style={{ marginRight: 10 }}
                      shape="square"
                      size={36}
                      src={orEmpty("image", record)}
                    />
                  ) : null}
                  {value}
                </div>
              ),
            };
          },
          width: "40%",
        },
        {
          title: "Tồn kho",
          dataIndex: "inventoryProduct",
          key: "inventoryProduct",
          render: (_, record) => {
            return (
              <div>
                {orArray("inventoryProduct", record).map((item) => (
                  <div style={{ display: "flex" }}>
                    <Text strong>- {orEmpty("inventory.name", item)}:</Text>
                    <div style={{ marginLeft: 5 }}>
                      Tồn: {orNumber("onhand", item)} | Có thể bán:{" "}
                      {orNumber("available", item)}
                    </div>
                  </div>
                ))}
              </div>
            );
          },
        },
        // {
        //     title: 'Trạng thái',
        //     dataIndex: 'isOutOfStock',
        //     key: 'isOutOfStock',
        //     render: (value, record) => !value || record.isActive && renderStatusProduct(value, record.isActive),
        //     width: '15%',
        // },
        {
          title: "Giá sản phẩm",
          dataIndex: "price",
          key: "price",
          render: (value) => (
            <div>{value ? Helpers.currencyFormatVND(value) : null}</div>
          ),
          width: "15%",
        },
      ];
      setColumnsTable(columns);
      return;
    }
    const columns = [
      {
        title: "",
        dataIndex: "image",
        key: "image",
        render: (value) => {
          return (
            <Avatar
              style={{ marginRight: 10 }}
              shape="square"
              size={48}
              src={value}
            />
          );
        },
      },
      {
        title: "Sản phẩm",
        dataIndex: "name",
        key: "name",
        render(value, record) {
          return {
            props: {
              style: { padding: "0" },
            },
            children: <div style={{ cursor: "pointer" }}>{value}</div>,
          };
        },
      },
      {
        title: "Trạng thái",
        dataIndex: "isActive",
        render: (value) =>
          value ? <Tag color="#108ee9">Hiển thị</Tag> : <Tag>Tạm khóa</Tag>,
        width: "15%",
      },
    ];
    setColumnsTable(columns);
  };

  const checkEnabledProduct = (item) => {
    const stringListItemDisable =
      itemDisable && itemDisable.map((item) => JSON.stringify(item.product.id));
    if (stringListItemDisable) {
      return;
    }
    return item.isOutOfStock;
  };

  const onUpdateData = () => {
    const stringListItemDisable =
      itemDisable && itemDisable.map((item) => JSON.stringify(item.product.id));
    const listProduct = orArray("data", products);
    if (listProduct && isVariant) {
      const result = listProduct.map((item) => ({
        key: item.id,
        image: item.featuredImage.url,
        name: item.name,
        isParent: true,
        enabled: checkEnabledProduct(item),
        children: item.variants.map((variant) => ({
          ...variant,
          key: variant.id,
          id: variant.id,
          name: variant.name,
          price: variant.price,
          quantity: 1,
          totalMoney: variant.price,
          isActive: variant.isActive,
          enabled: variant.isOutOfStock,
          product: {
            id: item.id,
            name: item.name,
            image: item.featuredImage.url,
          },
        })),
      }));
      setDataTable(result);
    } else if (listProduct && !isVariant) {
      const result = listProduct.map((item) => ({
        key: item.id,
        image: item.featuredImage.url,
        enabled:
          stringListItemDisable &&
          stringListItemDisable.includes(JSON.stringify(item.id)),
        price:
          item.staticPrice.minPrice === item.staticPrice.maxPrice
            ? Helpers.currencyFormatVND(item.staticPrice.maxPrice)
            : `${Helpers.currencyFormatVND(
                item.staticPrice.minPrice
              )} - ${Helpers.currencyFormatVND(item.staticPrice.maxPrice)}`,
        category: item.category.name,
        ...item,
      }));
      setDataTable(result);
    }
  };

  const addSelected = (record) => {
    if (record.isParent) {
      const r = selectProducts.slice();
      const newArray = r.concat(
        record.children.filter((item) => !item.enabled)
      );
      setSelectProducts(newArray);
      return;
    }
    const r = selectProducts.slice();
    r.push(record);
    setSelectProducts(r);
    return;
  };

  const removeSelected = (record) => {
    if (record.isParent) {
      const childrenId = record.children.map((item) => item.id);
      setSelectProducts((prevState) =>
        prevState.filter((item) => !childrenId.includes(item.id))
      );
      return;
    }
    setSelectProducts((prevState) =>
      prevState.filter((item) => item.id != record.id)
    );
  };

  const selectedAll = (selectedRows) => {
    if (isVariant) {
      const r = selectProducts.slice();
      setSelectProducts(
        r.concat(selectedRows).filter((item) => !item.isParent)
      );
    } else {
      const r = selectProducts.slice();
      setSelectProducts(r.concat(selectedRows).filter((item) => item));
    }
  };

  const removeAll = (record) => {
    const r = selectProducts.slice();
    const data = [];
    r.forEach((e) => {
      const result = record.find((item) => item.key === e.key);
      if (!result) {
        data.push(e);
        return;
      }
    });
    setSelectProducts(data);
  };

  const rowSelection = {
    selectedRowKeys: selectProducts.map((item) => orEmpty("id", item)),
    getCheckboxProps: (record) => ({
      disabled: record.enabled,
      key: record.key,
    }),
    onSelect: (record, selected) => {
      if (selected) {
        addSelected(record);
      } else {
        removeSelected(record);
      }
    },
    onSelectRow: (record) => {
      if (record.isParent) {
        const data = [];
        orArray("children", record).forEach((e) => {
          const result = selectProducts.find((item) => item.id === e.id);
          if (!result) {
            data.push(e);
            return;
          }
        });
        if (data.length === 0) {
          removeAll(orArray("children", record));
          return;
        }
        selectedAll(data.filter((item) => !item.enabled));
        return;
      }
      const isSelected = selectProducts.find((item) => item.id === record.id);
      if (!isSelected) {
        addSelected(record);
        return;
      }
      removeSelected(record);
    },
    onSelectAll: (selected, selectedRows, changeRows) => {
      if (selected) {
        selectedAll(selectedRows);
      } else {
        removeAll(changeRows);
      }
    },
  };

  useEffect(onUpdateData, [orArray("data", products), isVariant]);
  useEffect(onUpdateColumns, [isVariant]);

  const TableComponent = React.useCallback(() => {
    return (
      <AntTable
        className="product-table-wrapper"
        columns={columnsTable}
        rowKey="key"
        size={"small"}
        onRow={(record) => {
          return {
            onClick: () => {
              !record.isOutOfStock && rowSelection.onSelectRow(record);
            },
          };
        }}
        rowSelection={{ ...rowSelection, checkStrictly: false }}
        dataSource={dataTable}
        expandable={{
          defaultExpandAllRows: true,
          expandIcon: () => <div></div>,
        }}
        pagination={{
          defaultPageSize: orNumber("meta.pageSize", products),
          defaultCurrent: orNumber("meta.page", products),
          total: orNumber("meta.total", products),
          onChange: onChangePage,
          showSizeChanger: false,
        }}
      />
    );
  }, [columnsTable, dataTable, selectProducts, products.meta]);

  return <TableComponent />;
}

export default Table;
