import React from "react";
import { Mocks } from "../../utils";
import { Badge, Typography } from 'antd';
import "./styled.scss";

const { Text, Link } = Typography;

const FulfillmentStatus = ({ value }) => {
  const isProcessing = "READY_TO_PICK" === value;
  const isCancelled = ["CANCELLED", "REFUNDED"] === value;
  const isPicking = "PICKING" === value
  const isCompleted = "DELIVERED" === value;
  const isRefund = ["REFUNDING"].includes(value);
  const textType = isProcessing ? "warning" : isRefund ? "danger" : isCompleted ? "success" : isCancelled ? "secondary" : null;

  return (
    <div className={"status-badge"}>
      {
        isPicking
          ?
          <Link strong>{Mocks.TRANSPORTS.getFulfillmentStatus(value)}</Link>
          :
          <Text strong type={textType}>{Mocks.TRANSPORTS.getFulfillmentStatus(value)}</Text>
      }
    </div>
  )
};


export default FulfillmentStatus;