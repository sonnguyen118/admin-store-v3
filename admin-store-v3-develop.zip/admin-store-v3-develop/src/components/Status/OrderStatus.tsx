import React from "react";
import { Mocks } from "../../utils";
import { Badge, Typography } from 'antd';
import "./styled.scss";

const { Text, Link } = Typography;

const OrderStatus = ({ value }) => {
  const isProcessing = "CONFIRMED" === value;
  const isCancelled = "CANCELLED" === value;
  const isCompleted = "COMPLETED" === value;

  const textType = isCompleted ? "success" : isCancelled ? "secondary" : null;

  return (
    <div className={"status-badge"}>
      {
        isProcessing
          ?
          <Link strong>{Mocks.ORDER.getOrderStatus(value)}</Link>
          :
          <Text strong type={textType} style={textType === "success" ? {color: "rgb(34, 201, 147)"} :null}>{Mocks.ORDER.getOrderStatus(value)}</Text>
      }
    </div>
  )
};


export default OrderStatus;