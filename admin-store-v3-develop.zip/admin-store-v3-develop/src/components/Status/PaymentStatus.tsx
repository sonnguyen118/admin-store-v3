import React from "react";
import {Mocks} from "../../utils";
import { Badge, Typography } from 'antd';
import "./styled.scss";

const { Text, Link } = Typography;

const PaymentStatus = ({value}) => {
  const isProcessing = ["PENDING"].includes(value);
  const isFailed = ["FAILED", "CANCELLED"].includes(value);
  const isPaid = "PAID" === value;

  const badgeStatus = isProcessing ? "processing": isPaid ? "success" : "default";
  const textType = isPaid ? "success" : "secondary";

  return (
    <div className={"status-badge"}>
      <Badge status={badgeStatus} />
      {
        isProcessing ?
          <Link strong>{Mocks.ORDER.getOrderStatus(value)}</Link> :
          <Text strong type={textType}>{Mocks.ORDER.getPaymentStatus(value)}</Text>
      }
    </div>
  )
};


export default PaymentStatus;