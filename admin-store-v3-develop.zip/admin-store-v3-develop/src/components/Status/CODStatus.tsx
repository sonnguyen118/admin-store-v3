import { Typography } from 'antd';
import "./styled.scss";

const { Text } = Typography;

const CODStatus = ({ value, isFulfillmentReceipt }) => {
  return (
    <div className={"status-badge"}>
      {isFulfillmentReceipt ?
        <Text strong type="success">Đã nhận</Text>
        :
        <Text strong type={value ? null : "secondary"}>{value ? "Thu hộ" : "Không thu"}</Text>}

    </div>
  )
};


export default CODStatus;