import { Badge, Tabs } from "antd";
import { AndroidOutlined, AppleOutlined } from "@ant-design/icons";

const { TabPane } = Tabs;

export default function EditTabs(props) {
  const {
    tabItems,
    mode = "top",
    activeKey = "0",
    defaultActiveKey,
    onChangeTab,
    onEdit,
    fullProductOrderQuantity
  } = props;

  return (
    <div>
      <Tabs
        activeKey={activeKey}
        defaultActiveKey={defaultActiveKey}
        onChange={onChangeTab}
        tabPosition={mode}
        type="editable-card"
        hideAdd
        onEdit={onEdit}
        destroyInactiveTabPane={true}
      >
        {tabItems.map((item): any => (
          <TabPane
            tab={
              item.key === "isFullProduct" ? (
                <Badge count={fullProductOrderQuantity} overflowCount={99}>
                  {item.title}
                </Badge>
              ) : (
                item.title
              )
            }
            // tab={}
            key={item.key}
            closable={item.closable || false}
          >
            {item.component}
          </TabPane>
        ))}
      </Tabs>
    </div>
  );
}
