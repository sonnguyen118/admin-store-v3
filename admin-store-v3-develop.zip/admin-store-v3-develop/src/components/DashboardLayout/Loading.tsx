import React from "react";

export default function Loading() {
    return (
        <h1>Loading</h1>
    )
}