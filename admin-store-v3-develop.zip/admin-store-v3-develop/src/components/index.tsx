export { default as Selector } from "./Selector";
export { default as InventorySelector } from "./Selector/inventorySelect";

export { default as SimpleTabs } from "./SimpleTabs";
export { default as Editor } from "./Editor";
export { default as UploadSingle } from "./UploadSingle";
export { default as UploadMultiple } from "./UploadMultiple";
export { default as ChooseProductsTable } from "./ChooseProductsTable";
export { default as CheckSlug } from "./CheckSlug";
export { default as CreateCustomer } from "./CreateCustomer";
export { default as PrivateRoute } from "./PrivateRoute";
export { default as ComponentToPrint } from "./ComponentToPrint";
export { default as ComponentToPrintExportProduct } from "./ComponentToPrintExportProduct";
export { default as EditTabs } from "./EditTabs";
