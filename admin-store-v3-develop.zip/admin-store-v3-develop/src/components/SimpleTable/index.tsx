import { Table } from "antd";

function SimpleTable(props) {
  const {
    columns,
    data,
    rowSelection = null,
  } = props;
  return (
    <div>
      <Table
        columns={columns}
        rowSelection={rowSelection}
        dataSource={data}
      />
    </div>
  );
};

export default SimpleTable;
