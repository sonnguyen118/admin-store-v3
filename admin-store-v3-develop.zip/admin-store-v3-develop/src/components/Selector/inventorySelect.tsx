import React, { useState, useEffect } from "react";
import { Select } from "antd";

const { Option } = Select;

export default function InventorySelector(props) {
  const {
    options,
    value,
    defaultValue,
    placeholder,
    allowClear = false,
    mode = null,
    dropdownRender = null,
    onChange,
    onSelect,
    onDeselect,
    disabled,
    fulfillmentCompany,
    stateSee,
    listInventorySee,
  } = props;
  const [newValue, setNewValue] = useState("");
  useEffect(() => {
    if (value && value !== "") {
      if (typeof fulfillmentCompany !== "object") {
        if (fulfillmentCompany) {
          setNewValue(value + "/" + fulfillmentCompany);
        } else {
          setNewValue("Chọn lại kho xuất hàng");
        }
      } else {
        setNewValue(value + "/" + fulfillmentCompany);
      }
    } else {
      setNewValue("Chọn kho xuất hàng");
    }
  }, [value, fulfillmentCompany]);
  console.log(newValue, "newValue");
  return (
    <>
      {stateSee ? (
        <>
          <Select
            value={1}
            defaultValue={defaultValue}
            placeholder={placeholder}
            style={{ width: "100%" }}
            mode={mode}
            allowClear={allowClear}
            dropdownRender={dropdownRender}
            onChange={onChange}
            onSelect={onSelect}
            onDeselect={onDeselect}
            showSearch
            disabled={disabled}
            filterOption={(input, option): any =>
              // console.log(option.props.children.props.children[0].props.children)
              option
                ? option.props.children.props.children[0].props.children
                    .toString()
                    .toLowerCase()
                    .indexOf(input.toString().toLowerCase()) >= 0
                : null
            }
          >
            {listInventorySee
              ? listInventorySee.map((option, key) => {
                  return (
                    <Option key={key} value={option.value}>
                      {option.label}
                    </Option>
                  );
                })
              : null}
          </Select>
        </>
      ) : (
        <>
          {" "}
          <Select
            value={newValue}
            defaultValue={defaultValue}
            placeholder={placeholder}
            style={{ width: "100%" }}
            mode={mode}
            allowClear={allowClear}
            dropdownRender={dropdownRender}
            onChange={onChange}
            onSelect={onSelect}
            onDeselect={onDeselect}
            showSearch
            disabled={disabled}
            filterOption={(input, option): any =>
              // console.log(option.props.children.props.children[0].props.children)
              option
                ? option.props.children.props.children[0].props.children
                    .toString()
                    .toLowerCase()
                    .indexOf(input.toString().toLowerCase()) >= 0
                : null
            }
          >
            {options
              ? options.map((option, key) => {
                  return (
                    <Option key={key} value={option.value}>
                      {option.label}
                    </Option>
                  );
                })
              : null}
          </Select>
        </>
      )}
    </>
  );
}
