import React from 'react'
import { Select } from "antd";

const { Option } = Select;


export default function Selector(props) {
  const {
    options,
    value,
    defaultValue,
    placeholder,
    allowClear = false,
    mode = null,
    dropdownRender = null,
    onChange,
    onSelect,
    onDeselect,
    disabled
  } = props;
  return (
    <Select
      value={value}
      defaultValue={defaultValue}
      placeholder={placeholder}
      style={{ width: "100%" }}
      mode={mode}
      allowClear={allowClear}
      dropdownRender={dropdownRender}
      onChange={onChange}
      onSelect={onSelect}
      onDeselect={onDeselect}
      showSearch
      disabled={disabled}
      filterOption={(input, option): any =>
        option
          ? option.props.children
            .toString()
            .toLowerCase()
            .indexOf(input.toString().toLowerCase()) >= 0
          : null
      }
    >
      {options
        ? options.map((option, key) => {
          return (
            <Option key={key} value={option.value}>
              {option.label}
            </Option>
          );
        })
        : null}
    </Select>
  );
}

export function SelectorInventory(props) {
  const {
    options,
    value,
    defaultValue,
    placeholder,
    allowClear = false,
    mode = null,
    dropdownRender = null,
    onChange,
    onSelect,
    onDeselect,
    disabled
  } = props;
  return (
    <Select
      value={value}
      defaultValue={defaultValue}
      placeholder={placeholder}
      style={{ width: "100%" }}
      mode={mode}
      allowClear={allowClear}
      dropdownRender={dropdownRender}
      onChange={onChange}
      onSelect={onSelect}
      onDeselect={onDeselect}
      showSearch
      disabled={disabled}
      filterOption={(input, option): any =>
        option
          ? option.props.children
            .toString()
            .toLowerCase()
            .indexOf(input.toString().toLowerCase()) >= 0
          : null
      }
    >
      {options
        ? options.map((option, key) => {
          return (
            <Option key={key} value={option.value}>
              {option.label}
            </Option>
          );
        })
        : null}
    </Select>
  );
}
