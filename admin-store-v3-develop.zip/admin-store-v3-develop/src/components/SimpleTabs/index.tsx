import React from 'react'
import { Tabs } from "antd";

const { TabPane } = Tabs;

export default function SimpleTabs({ tabItems }) {
  function callback(key) {
  }

  return (
    <div>
      <Tabs defaultActiveKey="0" onChange={callback}>
        {tabItems.map((item, index): any => (
          <TabPane tab={item.title} key={index}>
            {item.component}
          </TabPane>
        ))}
      </Tabs>
    </div>
  );
}              
