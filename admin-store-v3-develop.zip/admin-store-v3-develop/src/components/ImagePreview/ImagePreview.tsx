import React, { useState } from 'react';
import "./styled.scss";
import {orNull} from "../../utils/Selector";
import {Button, Tooltip, Upload} from "antd";
import {
    EyeFilled,
    EditFilled
} from "@ant-design/icons";
import ModalPreviewImage from "./ModalPreviewImage";

export default function ImagePreview(props: { image: any, onChangeImage: Function, onRemoveImage: Function }) {
    const { image, onRemoveImage, onChangeImage } = props;
    const [isVisiblePreview, setIsVisiblePreview] = useState<boolean>(false);

}