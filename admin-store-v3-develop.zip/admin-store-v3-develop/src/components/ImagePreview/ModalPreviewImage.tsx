import React, {useEffect, useState} from "react";
import {Input, Modal} from "antd";
import "./styled.scss";

export default function ModalPreviewImage(props: { isVisible: boolean, image: any, onClose: Function, onOk: Function }) {
    const { isVisible, image, onClose, onOk } = props;
    const [imageName, setImageName] = useState<string>(image ? image.name : "");
    const [imageAlt, setImageAlt] = useState<string>(image ? image.alt : "");

    function handleOk() {
        const imageObj = {
            name: imageName,
            url: image.url,
            alt: imageAlt
        };
        return onOk(imageObj);
    }

    useEffect(() => {
        setImageAlt(image.alt);
        setImageName(image.name);
    }, [image]);

    return (
        <Modal
            title={"Hình ảnh"}
            centered
            visible={isVisible}
            onOk={handleOk}
            onCancel={() => onClose()}
            okText={"OK"}
            cancelText={"Huỷ"}
            destroyOnClose={true}
        >
            { image && <div className={"modal-preview"}>
                <div className={"image"}>
                    { image.url && <img src={image.url} alt={ image.alt }/> }
                </div>
                <div className={"alt"}>
                    <span>Tên hình ảnh:</span>
                    <Input onChange={(e => setImageName(e.target.value))} defaultValue={image.name} placeholder="Nhập tên..." style={{marginBottom: 10}}/>
                    <span>Mô tả hình ảnh:</span>
                    <Input.TextArea onChange={(e => setImageAlt(e.target.value))} rows={3} defaultValue={image.alt} placeholder="Nhập mô tả..." />
                </div>
            </div>}
        </Modal>
    )
}