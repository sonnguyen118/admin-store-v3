import { Form as FormBase, Input, Typography, Tooltip } from "antd";
const { Text, Link } = Typography;
const { Item } = FormBase;

function CheckSlug(props) {
  const { idItem, slug, addonSlug, onChangeSlug, onSearchSlug, statusSlug, isActive, isParent = false, slugParent = "" } = props


  const getHrefUrl = () => {
    if (isActive) {
      if (isParent) {
        return `${addonSlug}/${slugParent}/${slug}`
      }
      return `${addonSlug}/${slug}`
    }
    return null
  }

  return (
    <div>
      {!idItem ?
        <Item
          label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Đường dẫn:</span>}
          name="slug"
          rules={[
            { required: true, message: 'Vui lòng nhập đường dẫn' }
          ]}
          required>
          <Input
            addonBefore={`${addonSlug}/`}
            value={slug}
            onChange={onChangeSlug}
            addonAfter={
              <div className="cursor-pointer" onClick={onSearchSlug}>
                <Tooltip title="Kiểm tra đường dẫn">
                  <span>Kiểm tra</span>
                </Tooltip>
              </div>
            }
          />
          {statusSlug === false
            ?
            <Text type="danger">Đường dẫn đã tồn tại, vui lòng kiểm tra và thử lại</Text>
            :
            statusSlug === true
              ?
              <Text type="success">Đường dẫn hợp lệ</Text>
              :
              null}
        </Item> :
        <Item label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Đường dẫn:</span>}>
          <Link copyable href={getHrefUrl()} target="_blank">
            {isParent ? `${addonSlug}/${slugParent}/${slug}` : `${addonSlug}/${slug}`}
          </Link>
        </Item>}
    </div>
  );
}

export default CheckSlug;