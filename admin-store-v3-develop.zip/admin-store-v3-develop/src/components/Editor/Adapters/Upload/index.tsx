import { Product as ProductAPI } from "api";
import { construct } from 'ramda'

function Upload(props): any {
  this.loader = props.loader
  this.token = props.token
}

Upload.prototype = {
  upload: function (): Promise<any> {
    return this.loader.file.then((file): any => {
      return this._initListeners(file)
    })
  },

  abort(): void { },
  _initRequest(): void { },
  _initListeners: async function (file): Promise<any> {
    const acceptedFiles = {
      original: file,
      preview: URL.createObjectURL(file)
    };
    const {data:res} = await ProductAPI.uploadSingle(acceptedFiles)

    return new Promise((resolve): any => {
      resolve({ default: res })
    })
  },
  _sendRequest(): void { },
}

export default construct(Upload)

