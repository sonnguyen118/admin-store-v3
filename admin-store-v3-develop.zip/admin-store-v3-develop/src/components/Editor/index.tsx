import React from "react";
import { CKEditor } from "@ckeditor/ckeditor5-react";
import TechfoxEditor from "techfox-editor";
import { Upload } from "./Adapters";
import "./styled.scss";

interface editorInterface {
  isDisable?: boolean;
  onChange?: any;
  value?: string;
  placeholder?: string;
  token?: string;
}

export default function Editor(props: editorInterface) {
  const { isDisable = false, token, value, onChange, placeholder } = props;

  return (
    <div className="wrapper ck-editor-custom">
      <CKEditor
        config={{
          link: {
            decorators: {
              openInNewTab: {
                mode: "manual",
                label: "Mở link trong tab mới",
                attributes: {
                  target: "_blank",
                  rel: "noopener noreferrer",
                },
              },
              addRelNoFollow: {
                mode: "manual",
                label: 'Add rel="nofollow"',
                attributes: {
                  rel: "nofollow",
                },
              },
              addRelSponsored: {
                mode: "manual",
                label: 'Add rel="sponsored"',
                attributes: {
                  rel: "sponsored",
                },
              },
            },
          },
          heading: {
            options: [
              {
                model: "paragraph",
                title: "Paragraph",
                class: "ck-heading_paragraph",
              },
              {
                model: "heading1",
                view: "h1",
                title: "Heading 1",
                class: "ck-heading_heading1",
              },
              {
                model: "heading2",
                view: "h2",
                title: "Heading 2",
                class: "ck-heading_heading2",
              },
              {
                model: "heading3",
                view: "h3",
                title: "Heading 3",
                class: "ck-heading_heading3",
              },
              {
                model: "heading4",
                view: "h4",
                title: "Heading 4",
                class: "ck-heading_heading4",
              },
              {
                model: "heading5",
                view: "h5",
                title: "Heading 5",
                class: "ck-heading_heading5",
              },
              {
                model: "heading6",
                view: "h6",
                title: "Heading 6",
                class: "ck-heading_heading6",
              },
            ],
          },
          ui: {
            viewportOffset: { top: 100 },
          },
          toolbar: {
            viewportTopOffset: 100,
          },
        }}
        onReady={(editor): void => {
          if (isDisable || !editor) return;

          editor.ui
            .getEditableElement()
            .parentElement.insertBefore(
              editor.ui.view.toolbar.element,
              editor.ui.getEditableElement()
            );

          editor.plugins.get("FileRepository").createUploadAdapter = (
            loader: any
          ): any => {
            return Upload({ loader });
          };
        }}
        placeholder={placeholder}
        editor={TechfoxEditor}
        disabled={!!isDisable}
        onChange={(_, editor) => {
          if (isDisable) return;
          onChange(editor.getData());
        }}
        data={value}
      />
    </div>
  );
}
