import { Typography, Row, Col, Space, Table } from "antd";
import { useState, useEffect, useCallback } from "react";
import { Helpers, Mocks } from "utils";
import { orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import "./styled.scss";

var Barcode = require("react-barcode");
var QRCode = require("qrcode.react");

const { Text, Title } = Typography;

function ComponentToPrint(props) {
  const { item } = props;
  const [dataTable, setDataTable] = useState([]);

  const getFulfillmentCompanyName = () => {
    if (orEmpty("fulfillmentCompany.slug", item) === "SHIP-LE") {
      return "Shipper 30shine";
    }
    return orEmpty("fulfillmentCompany.name", item);
  };

  const columns = [
    {
      title: "Sản phẩm",
      dataIndex: "productName",
      render: (value, record) => {
        return (
          <div style={{ fontSize: 14 }}>
            {value} - {record.variantName}
          </div>
        );
      },
      width: "70%",
    },
    {
      title: "Mã sản phẩm",
      dataIndex: "productSKU",
      render: (value) => {
        return <div style={{ fontSize: 14 }}>{value}</div>;
      },
      width: "15%",
    },
    {
      title: "Số lượng",
      dataIndex: "quantity",
      render: (value) => {
        return <div style={{ fontSize: 14 }}>{value}</div>;
      },
      width: "15%",
    },
  ];

  useEffect(() => {
    if (item.orderItems) {
      const r = [] as any;
      item.orderItems.slice(0, 7).forEach((node): void => {
        r.push({
          key: node.id,
          id: node.id,
          productName: node.productName,
          quantity: node.quantity,
          price: Helpers.currencyFormatVND(node.price * node.quantity),
          productSKU: node.productSKU,
          variantName: node.variantName,
        });
      });
      setDataTable(r);
    }
  }, [item.orderItems]);

  const renderLogoFulfillmentCompany = () => {
    switch (orEmpty("fulfillmentCompany.slug", item)) {
      case "GIAOHANGNHANH":
        return <img src={process.env.PUBLIC_URL + "/images/logo-ghn.jpg"} />;
      case "AHAMOVE":
        return <img src={process.env.PUBLIC_URL + "/images/logo-ahm.jpg"} />;
      case "VIETTELPOST":
        return <img src={process.env.PUBLIC_URL + "/images/logo-vtp.jpg"} />;
      default:
        return;
    }
  };

  const renderBarcodeFulfillment = useCallback(() => {
    if (orEmpty("fulfillmentCode", item)) {
      return (
        <div style={{ marginTop: 10 }}>
          <Barcode
            value={orEmpty("fulfillmentCode", item)}
            height={40}
            displayValue={orEmpty("fulfillmentCode", item)}
            fontSize={14}
            margin={0}
            textAlign="center"
          />
          {orEmpty("fulfillmentCompany.slug", item) === "GIAOHANGNHANH" ? (
            <div style={{ fontSize: 24 }}>{orEmpty("sortCode", item)}</div>
          ) : null}
        </div>
      );
    }
    return null;
  }, [orEmpty("fulfillmentCode", item)]);

  const renderBarcodeOrder = () => {
    switch (orEmpty("fulfillmentCompany.slug", item)) {
      case "GIAOHANGNHANH":
        return null;
      case "AHAMOVE":
        return null;
      case "VIETTELPOST":
        return null;
      default:
        return (
          <Space direction="vertical" size={1}>
            <div
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
              }}
            >
              <Barcode
                value={item.orderCode}
                height={40}
                displayValue={false}
                fontSize={14}
                margin={0}
                textAlign="left"
              />

              <div style={{ fontSize: 14 }}>Mã đơn hàng: {item.orderCode}</div>
            </div>
          </Space>
        );
    }
  };

  const InventoryAddress = ({ title }: { title?: string }) => {
    return (
      <Space direction="vertical" size={1}>
        <div>
          <Text strong>{title || "Từ"}:</Text>{" "}
          <span>
            <Text>{orEmpty("inventory.name", item) || "30Shine shop"}</Text>
          </span>
        </div>
        <Text>{`${orEmpty("inventory.address.address", item)},${orEmpty(
          "inventory.address.wardName",
          item
        )},${orEmpty("inventory.address.districtName", item)},${orEmpty(
          "inventory.address.countryName",
          item
        )}`}</Text>
        <Text>Điện thoại: {orEmpty("inventory.phone", item)}</Text>
        <Text>Website: https://shop.30shine.com</Text>
        <Text>Email: 30shinestore@30shine.com</Text>
      </Space>
    );
  };

  const CustomerAddress = () => {
    return (
      <Space direction="vertical" size={1}>
        <div>
          <Text strong>Đến:</Text>{" "}
          <span>
            <Text>{orEmpty("customerName", item)}</Text>
          </span>
        </div>
        <Text>
          {`${orEmpty("address", item)}, ${orEmpty(
            "wardName",
            item
          )}, ${orEmpty("districtName", item)}, ${orEmpty(
            "provinceName",
            item
          )}`}
        </Text>
        <Text>Điện thoại: {orEmpty("customerPhone", item)}</Text>
      </Space>
    );
  };

  const AddressRefund = () => {
    return (
      <Space direction="vertical" size={1}>
        <div>
          <Text strong>Từ:</Text>{" "}
          <span>
            <Text>{orEmpty("fromAddressRefund.customerName", item)}</Text>
          </span>
        </div>
        <Text>
          {`${orEmpty("fromAddressRefund.address", item)}, ${orEmpty(
            "fromAddressRefund.wardName",
            item
          )}, ${orEmpty("fromAddressRefund.districtName", item)}, ${orEmpty(
            "fromAddressRefund.provinceName",
            item
          )}`}
        </Text>
        <Text>
          Điện thoại: {orEmpty("fromAddressRefund.customerPhone", item)}
        </Text>
      </Space>
    );
  };

  return (
    <div className="print-source">
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          borderBottom: "1px solid #cdcdcd",
          paddingBottom: 10,
        }}
      >
        <Space direction="vertical" size={1}>
          <img
            width={80}
            height={42}
            src="https://30shine.com/static/media/log-30shine-white.9945e644.jpg"
          />
          <Title level={5}>shop.30shine.com</Title>
        </Space>
        {renderBarcodeOrder()}
      </div>
      <Row
        gutter={24}
        style={{
          borderBottom: "1px solid #cdcdcd",
          paddingBottom: 10,
          paddingTop: 10,
        }}
      >
        <Col span={12}>
          {orEmpty("fulfillmentType", item) === "REFUND" ? (
            <AddressRefund />
          ) : (
            <InventoryAddress />
          )}
        </Col>
        <Col span={12}>
          {orEmpty("fulfillmentType", item) === "REFUND" ? (
            <InventoryAddress title="Đến" />
          ) : (
            <CustomerAddress />
          )}
        </Col>
      </Row>
      <Row
        gutter={24}
        style={{
          borderBottom: "1px solid #cdcdcd",
          paddingBottom: 10,
          paddingTop: 10,
        }}
      >
        <Col span={12}>
          <Space direction="vertical" size={1}>
            <Text strong>Chỉ dẫn giao hàng:</Text>
            <Text>
              - {Mocks.ORDER.getDeliveryTime(item.shippingType).label}
            </Text>
            <Text>
              {orBoolean("cashByRecipient", item)
                ? "- Người nhận tự trả phí vận chuyển"
                : null}
            </Text>
            <Text>
              {orBoolean("enableReviewBefore", item)
                ? "- Sản phẩm được kiểm tra trước khi thanh toán"
                : null}
            </Text>
            {item.customerNote ? (
              <Text>- {orEmpty("customerNote", item)}</Text>
            ) : null}
          </Space>
        </Col>
        <Col span={12}>
          <Space direction="vertical" size={1}>
            <div style={{ display: "flex" }}>
              <div style={{ display: "flex", flexDirection: "column" }}>
                <Text strong>Nhà vận chuyển:</Text>
                <Text>
                  {orNull("fulfillmentCompany", item)
                    ? getFulfillmentCompanyName()
                    : "Chưa xác định"}
                </Text>
              </div>
              {renderLogoFulfillmentCompany()}
            </div>
            {renderBarcodeFulfillment()}
          </Space>
        </Col>
      </Row>
      <Row
        gutter={24}
        style={{
          borderBottom: "1px solid #cdcdcd",
          paddingTop: 10,
        }}
      >
        <Col span={24}>
          <div style={{ textAlign: "center" }}>
            <Title level={4}>
              {orEmpty("paymentGateway", item) === "COD" ||
              orBoolean("isCOD", item)
                ? `Số tiền thu hộ:`
                : `Tổng đơn: `}{" "}
              {orEmpty("paymentGateway", item) === "COD" ||
              orBoolean("isCOD", item)
                ? Helpers.currencyFormatVND(orNumber("codAmount", item))
                : Helpers.currencyFormatVND(orNumber("totalPrice", item))}
            </Title>
          </div>
        </Col>
      </Row>
      <Row
        gutter={24}
        style={{
          paddingBottom: 10,
          paddingTop: 10,
        }}
      >
        <Col span={24}>
          <table style={{ width: "100%" }}>
            <tr>
              <th style={{ width: "70%" }}>Tên sản phẩm</th>
              <th style={{ width: "15%" }}>Mã SKU</th>
              <th style={{ width: "15%" }}>Số lượng</th>
            </tr>
          </table>
          <Table
            showHeader={false}
            columns={columns}
            dataSource={dataTable}
            size="small"
            pagination={false}
          />
          <span
            style={{
              fontSize: 10,
              fontStyle: "italic",
            }}
          >
            {item.orderItems.length > 7
              ? `Một số sản phẩm có thể bị ẩn do danh sách quá dài`
              : null}
          </span>
        </Col>
      </Row>
      <div
        style={{
          fontSize: 10,
          fontStyle: "italic",
          position: "absolute",
          bottom: 0,
        }}
      >
        Nếu có thắc mắc vui lòng liên hệ chúng tôi qua số điện thoại 0335081796
        hoặc email 30shinestore@30shine.com.
      </div>
    </div>
  );
}

export default ComponentToPrint;
