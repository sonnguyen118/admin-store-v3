import { withToken } from "hoc";
import { CloudUploadOutlined } from "@ant-design/icons";
import { Upload, message } from "antd";
import { useState } from "react";
import ModalPreviewImage from "../ImagePreview/ModalPreviewImage";
import { orEmpty, orNull } from "../../utils/Selector";

function UploadMultiple(props) {
  const { token, fileList, setFileList } = props;
  const [isVisiblePreview, setIsVisiblePreview] = useState<boolean>(false);
  const [imagePreview, setImagePreview] = useState({
    name: "",
    url: "",
    alt: "",
  });

  function uploadButton() {
    return (
      <div>
        <CloudUploadOutlined className="upload-icon" />
        <div className="upload-text">Thêm ảnh sản phẩm</div>
      </div>
    );
  }

  const onChange = ({ fileList: newFileList }) => {
    const fileListDefault = newFileList.filter((item) => item.url);
    const fileListChange = newFileList.filter((item) => !item.url);
    if (fileListChange.length) {
      const validFileList = fileListChange.filter(
        (file) => file.type === "image/jpeg" && file.size / 1024 / 1024 < 0.2
      );
      setFileList(fileListDefault.concat(validFileList));
      return;
    }
    setFileList(newFileList);
  };

  function mappingImage(image) {
    return {
      uid: orNull("response", image)
        ? image.response[0]
        : orEmpty("url", image),
      name: orEmpty("name", image),
      url: orNull("response", image)
        ? image.response[0]
        : orEmpty("url", image),
      alt: orEmpty("alt", image),
    };
  }

  function handlePreview(image) {
    const imagePreview = mappingImage(image);
    setImagePreview(imagePreview);
    setIsVisiblePreview(true);
  }

  function handleClosePreview() {
    setIsVisiblePreview(false);
  }

  function handleUpdateImage(image) {
    const flatData = fileList.map((image) => mappingImage(image));
    const index = flatData.findIndex((i) => i.url === image.url);
    flatData[index].name = image.name;
    flatData[index].alt = image.alt;

    setFileList(flatData);
    handleClosePreview();
  }

  function beforeUpload(file) {
    const isJpgOrPng = file.type === "image/jpeg";
    if (!isJpgOrPng) {
      message.error("Bạn chỉ có thể upload file .JPG!");
    }
    const isLt2M = file.size / 1024 / 1024 < 0.2;
    if (!isLt2M) {
      message.error("Bạn chỉ có thể upload file nhỏ hơn 200KB!");
    }
    return isJpgOrPng && isLt2M;
  }

  return (
    <div>
      <Upload
        listType="picture-card"
        fileList={fileList}
        onPreview={handlePreview}
        beforeUpload={beforeUpload}
        multiple={true}
        name="images"
        action={`${process.env.REACT_APP_BASE_API_URL}/admin/common/upload-images`}
        headers={{
          Authorization: `Bearer ${token}`,
        }}
        onChange={onChange}
      >
        {fileList.length >= 8 ? null : uploadButton()}
      </Upload>
      <ModalPreviewImage
        isVisible={isVisiblePreview}
        image={imagePreview}
        onClose={handleClosePreview}
        onOk={handleUpdateImage}
      />
    </div>
  );
}

export default withToken(UploadMultiple);
