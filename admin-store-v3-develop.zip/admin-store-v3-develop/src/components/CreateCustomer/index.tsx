import React, { useState, useEffect } from "react";
import "./styled.scss";
import {
  Row,
  Col,
  Modal,
  Form,
  Input,
  Spin,
  Button,
  Typography,
  Select,
} from "antd";
import { Provinces as ProvincesAPI, Users as UsersAPI } from "api";
import { orArray, orEmpty } from "utils/Selector";
import { Selector } from "components";

const { Text } = Typography;
const { Option } = Select;

function CreateCustomer(props) {
  const {
    onCancel,
    visible,
    onSubmit,
    customer,
    item,
    isUpdateOrder = false,
  } = props;

  const [form] = Form.useForm();
  const [provinces, setProvinces] = useState([]);
  const [districts, setDistricts] = useState([]);
  const [wards, setWards] = useState([]);
  const [listAddress, setListAddress] = useState([]);
  const [chooseAddress, setChooseAddress] = useState({
    value: null,
    item: null,
  });
  const [address, setAddress] = useState({
    addressId: null,
    customerName: "",
    customerPhone: "",
    customerEmail: "",
    provinceName: "",
    provinceId: null,
    districtName: "",
    districtId: null,
    wardName: "",
    wardId: null,
  });

  useEffect(() => {
    if (item) {
      const result = listAddress.find(
        (address) => address.id === item.addressId
      );
      if (result) {
        setChooseAddress((prevState) => ({
          ...prevState,
          value: item.addressId,
        }));
      }
      setAddress({
        addressId: item.addressId,
        customerName: item.customerName,
        customerPhone: item.customerPhone,
        customerEmail: item.customerEmail,
        provinceName: item.provinceName,
        provinceId: item.provinceId,
        districtName: item.districtName,
        districtId: item.districtId,
        wardName: item.wardName,
        wardId: item.wardId,
      });
      form.setFieldsValue({
        customerName: item.customerName,
        customerPhone: item.customerPhone,
        customerEmail: item.customerEmail,
        address: item.address,
        provinceId: item.provinceId,
        districtId: item.districtId,
        wardId: item.wardId,
      });
      return;
    }
    const defaultAddress = listAddress.find((item) => item.isDefault);
    if (defaultAddress) {
      setChooseAddress((prevState) => ({
        ...prevState,
        value: defaultAddress.id,
      }));
      setAddress({
        addressId: defaultAddress.id,
        customerName: defaultAddress.name,
        customerPhone: defaultAddress.customerPhone,
        customerEmail: defaultAddress.email,
        provinceName: defaultAddress.provinceName,
        provinceId: defaultAddress.provinceId,
        districtName: defaultAddress.districtName,
        districtId: defaultAddress.districtId,
        wardName: defaultAddress.wardName,
        wardId: defaultAddress.wardId,
      });
      form.setFieldsValue({
        customerName: defaultAddress.name,
        customerPhone: defaultAddress.customerPhone,
        customerEmail: defaultAddress.email,
        address: defaultAddress.address,
        provinceId: defaultAddress.provinceId,
        districtId: defaultAddress.districtId,
        wardId: defaultAddress.wardId,
      });
      return;
    }
    if (customer) {
      form.setFieldsValue({
        customerName: customer.customerName,
        customerPhone: customer.customerPhone,
      });
      return;
    }
  }, [item, listAddress]);

  //   useEffect(() => {

  //   }, [listAddress]);

  async function getCustomerAddress() {
    try {
      if (customer && customer.customerId) {
        const params = {
          customerId: customer.customerId,
        };
        const { data } = await UsersAPI.customerAddress(params);
        if (data) {
          setListAddress(data.data);
        }
      }
    } catch (error) {
      console.log(error);
    }
  }

  useEffect(() => {
    getCustomerAddress();
  }, [customer]);

  const handleSubmit = (values) => {
    const newValues = {
      ...values,
      addressId: address.addressId,
      provinceName: address.provinceName,
      districtName: address.districtName,
      wardName: address.wardName,
      address: orEmpty("address", values),
      customerEmail: orEmpty("customerEmail", values),
      customerName: orEmpty("customerName", values),
    };
    onSubmit(newValues);
    setChooseAddress((prevState) => ({
      ...prevState,
      item: null,
    }));
  };

  async function getListProvince() {
    const response = await ProvincesAPI.getListProvince();
    if (response) {
      const listProvince = orArray("data.data", response).map((item) => ({
        label: item.name,
        value: item.provinceId,
      }));
      setProvinces(listProvince);
    }
  }

  async function getListDistrict() {
    if (address.provinceId) {
      const params = {
        provinceId: address.provinceId,
      };
      const response = await ProvincesAPI.getListDistrict(params);
      if (response) {
        const listDistrict = orArray("data.data", response).map((item) => ({
          label: item.name,
          value: item.districtId,
        }));
        setDistricts(listDistrict);
      }
    }
  }

  async function getListWard() {
    if (address.provinceId && address.districtId) {
      const params = {
        provinceId: address.provinceId,
        districtId: address.districtId,
      };
      const response = await ProvincesAPI.getListWards(params);
      if (response) {
        const listWard = orArray("data.data", response).map((item) => ({
          label: item.name,
          value: item.wardId,
        }));
        setWards(listWard);
      }
    }
  }

  const onChangeProvince = (value) => {
    const provinceItem = provinces.find((item) => item.value === value);
    setAddress((prevState) => ({
      ...prevState,
      provinceName: orEmpty("label", provinceItem),
      provinceId: orEmpty("value", provinceItem),
    }));
    form.setFieldsValue({
      districtId: null,
      wardId: null,
    });
  };

  const onChangeDistrict = (value) => {
    const districtItem = districts.find((item) => item.value === value);
    setAddress((prevState) => ({
      ...prevState,
      districtName: orEmpty("label", districtItem),
      districtId: orEmpty("value", districtItem),
    }));
    form.setFieldsValue({
      wardId: null,
    });
  };

  const onChangeWard = (value) => {
    const wardItem = wards.find((item) => item.value === value);
    setAddress((prevState) => ({
      ...prevState,
      wardName: orEmpty("label", wardItem),
      wardId: orEmpty("value", wardItem),
    }));
  };

  const handleChange = (value) => {
    const addressItem = listAddress.find((item) => item.id === value);
    setChooseAddress((prevState) => ({
      ...prevState,
      value: value,
      item: addressItem,
    }));
  };

  useEffect(() => {
    if (chooseAddress.item) {
      setAddress({
        addressId: chooseAddress.item.id,
        customerName: chooseAddress.item.name,
        customerPhone: chooseAddress.item.phone,
        customerEmail: chooseAddress.item.email,
        provinceName: chooseAddress.item.provinceName,
        provinceId: chooseAddress.item.provinceId,
        districtName: chooseAddress.item.districtName,
        districtId: chooseAddress.item.districtId,
        wardName: chooseAddress.item.wardName,
        wardId: chooseAddress.item.wardId,
      });
      form.setFieldsValue({
        customerName: chooseAddress.item.name,
        customerPhone: chooseAddress.item.phone,
        customerEmail: chooseAddress.item.email,
        address: chooseAddress.item.address,
        provinceId: chooseAddress.item.provinceId,
        districtId: chooseAddress.item.districtId,
        wardId: chooseAddress.item.wardId,
      });
    }
  }, [chooseAddress.item]);

  const onValuesChange = () => {
    if (!isUpdateOrder) {
      setChooseAddress((prevState) => ({
        ...prevState,
        value: null,
      }));
      setAddress((prevState) => ({
        ...prevState,
        addressId: null,
      }));
    }
  };

  const handleCancel = () => {
    if (item) {
      setChooseAddress((prevState) => ({
        ...prevState,
        value: item.addressId,
      }));
      setAddress({
        addressId: item.addressId,
        customerName: item.customerName,
        customerPhone: item.customerPhone,
        customerEmail: item.customerEmail,
        provinceName: item.provinceName,
        provinceId: item.provinceId,
        districtName: item.districtName,
        districtId: item.districtId,
        wardName: item.wardName,
        wardId: item.wardId,
      });
      form.setFieldsValue({
        customerName: item.customerName,
        customerPhone: item.customerPhone,
        customerEmail: item.customerEmail,
        address: item.address,
        provinceId: item.provinceId,
        districtId: item.districtId,
        wardId: item.wardId,
      });
    }
    setChooseAddress((prevState) => ({
      ...prevState,
      item: null,
    }));
    onCancel();
  };

  useEffect(() => {
    getListProvince();
  }, []);

  useEffect(() => {
    getListDistrict();
  }, [address.provinceId]);

  useEffect(() => {
    getListWard();
  }, [address.provinceId, address.districtId]);

  function onValidPhone(phone) {
    if (phone) {
      const convertArr = phone.split("");
      if (isNaN(phone)) {
        return Promise.reject(new Error("Vui lòng nhập đúng số điện thoại"));
      }
      if (phone.length < 10 || phone.length > 10) {
        return Promise.reject(new Error("Vui lòng nhập đúng số điện thoại"));
      }
      if (convertArr[0] != 0 || convertArr[1] == 0) {
        return Promise.reject(new Error("Vui lòng nhập đúng số điện thoại"));
      }
      return Promise.resolve();
    }
    return Promise.reject(new Error("Vui lòng nhập số điện thoại"));
  }

  return (
    <Modal
      title={
        customer || item
          ? "Cập nhật địa chỉ giao hàng"
          : "Tạo mới địa chỉ giao hàng"
      }
      visible={visible}
      onOk={form.submit}
      onCancel={handleCancel}
      footer={[
        <Button key="back" onClick={handleCancel}>
          Hủy
        </Button>,
        <Button key="submit" type="primary" onClick={form.submit}>
          Lưu
        </Button>,
        ,
      ]}
    >
      <Spin spinning={false}>
        {listAddress.length > 0 ? (
          <div className="choose-address-customer">
            <Text className="choose-address-customer-title" strong>
              Chọn Địa chỉ
            </Text>
            <Select
              value={chooseAddress.value}
              onChange={handleChange}
              placeholder="Chọn địa chỉ khách hàng"
              className="choose-address-customer-selector"
            >
              {listAddress.map((item, index) => {
                return (
                  <Option key={index} value={orEmpty("id", item)}>
                    <div style={{ display: "flex", flexDirection: "column" }}>
                      <div>
                        <Text strong>{orEmpty("name", item)}</Text>
                        <Text style={{ marginLeft: 10 }} strong>
                          {orEmpty("phone", item)}
                        </Text>
                      </div>
                      <div>
                        <Text type="secondary">
                          {orEmpty("address", item)},{" "}
                          {orEmpty("wardName", item)},{" "}
                          {orEmpty("districtName", item)},{" "}
                          {orEmpty("provinceName", item)}
                        </Text>
                      </div>
                      {/* <br /> */}
                    </div>
                  </Option>
                );
              })}
            </Select>
          </div>
        ) : null}

        <Form
          layout="vertical"
          form={form}
          onFinish={handleSubmit}
          onValuesChange={onValuesChange}
        >
          <Row gutter={24}>
            <Col span={12}>
              <Form.Item
                label="Tên khách hàng"
                name="customerName"
                required
                rules={[
                  { required: true, message: "Vui lòng nhập tên khách hàng" },
                ]}
              >
                <Input placeholder="Nhập tên khách hàng" />
              </Form.Item>
              <Form.Item label="Email" name="customerEmail">
                <Input placeholder="Nhập địa chỉ email" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label="Số điện thoại"
                name="customerPhone"
                required
                rules={[
                  {
                    validator: (_, value) => onValidPhone(value),
                  },
                ]}
              >
                <Input maxLength={10} placeholder="Nhập số điện thoại" />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="provinceId"
                label="Tỉnh / Thành Phố"
                required
                rules={[
                  { required: true, message: "Vui lòng chọn Tỉnh / Thành Phố" },
                ]}
              >
                <Selector
                  options={provinces}
                  onChange={onChangeProvince}
                  placeholder={"Nhập Tỉnh / Thành Phố"}
                />
              </Form.Item>
              <Form.Item
                name="wardId"
                label="Xã / Thị Trấn"
                required
                rules={[
                  { required: true, message: "Vui lòng chọn Xã / Thị Trấn" },
                ]}
              >
                <Selector
                  options={wards}
                  onChange={onChangeWard}
                  placeholder={"Nhập Xã / Thị Trấn"}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                name="districtId"
                label="Quận / Huyện"
                required
                rules={[
                  { required: true, message: "Vui lòng chọn Quận / Huyện" },
                ]}
              >
                <Selector
                  options={districts}
                  onChange={onChangeDistrict}
                  placeholder={"Nhập Quận / Huyện"}
                />
              </Form.Item>
              <Form.Item
                label="Địa chỉ"
                name="address"
                required
                rules={[{ required: true, message: "Vui lòng nhập địa chỉ" }]}
              >
                <Input placeholder="Nhập địa chỉ" />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Spin>
    </Modal>
  );
}

export default CreateCustomer;
