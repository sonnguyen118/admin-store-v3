import { Typography, Row, Col, Table } from "antd";
import moment from "moment";
import React from "react";
import { useMemo } from "react";
import { orEmpty } from "utils/Selector";
import "./styled.scss";

const { Text, Title } = Typography;

function ComponentToPrintExportProduct(props) {
  const { listProduct } = props;

  function checkVariantName(variantName) {
    if (variantName.toLowerCase() === "default") {
      return;
    }
    return `- ${variantName}`;
  }

  const columns = [
    {
      title: "STT",
      dataIndex: "key",
      render: (value) => {
        return <div>{value + 1}</div>;
      },
      width: "5%",
    },
    {
      title: "Sản phẩm",
      dataIndex: "productName",
      render: (value, record) => {
        return (
          <div>
            {value} {checkVariantName(orEmpty("variantName", record))}
          </div>
        );
      },
      width: "65%",
    },
    {
      title: "Mã SKU",
      dataIndex: "productSKU",
      width: "15%",
    },
    {
      title: "Số lượng",
      dataIndex: "quantity",
      width: "15%",
    },
  ];

  const onGetListProduct: any = useMemo(() => {
    if (listProduct) {
      const r = [] as any;
      listProduct.forEach((node, index): void => {
        r.push({
          key: index,
          ...node,
        });
      });
      return r;
    }
    return [];
  }, [listProduct]);

  const TableComponent = React.useCallback(() => {
    return (
      <Row gutter={24} style={{ marginTop: 10 }}>
        <Col span={24}>
          <table style={{ width: "100%" }}>
            <tr>
              <th style={{ width: "5%" }}>Stt</th>
              <th style={{ width: "65%" }}>Tên sản phẩm</th>
              <th style={{ width: "15%" }}>Mã SKU</th>
              <th style={{ width: "15%" }}>Số lượng</th>
            </tr>
          </table>
          <Table
            className="print-export-product-table"
            showHeader={false}
            columns={columns}
            dataSource={onGetListProduct}
            size="small"
            pagination={false}
            bordered
          />
        </Col>
      </Row>
    );
  }, [onGetListProduct]);

  return (
    <div className="print-export-product">
      <div className="print-export-product-title">
        <Title level={4}>PHIẾU XUẤT HÀNG</Title>
      </div>
      <div className="print-export-product-date">
        <Text>Ngày in phiếu: {moment().format("hh:mm A DD/MM/YYYY")}</Text>
      </div>
      <TableComponent />
    </div>
  );
}

export default ComponentToPrintExportProduct;
