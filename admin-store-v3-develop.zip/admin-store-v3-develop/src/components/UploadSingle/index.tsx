import React, { useState } from "react";
import { withToken } from "hoc";
import {
  LoadingOutlined,
  CloudUploadOutlined,
  EditFilled,
  EyeFilled,
} from "@ant-design/icons";
import { Upload, message, Tooltip } from "antd";
import "./styled.scss";
import { orNull } from "utils/Selector";
import ModalPreviewImage from "../ImagePreview/ModalPreviewImage";
import ImgCrop from "antd-img-crop";

function UploadSingle(props) {
  const { token, image, setImage, style, isUploadBanner = false } = props;
  const [loading, setLoading] = useState(false);
  const [isVisiblePreview, setIsVisiblePreview] = useState<boolean>(false);

  const UploadForm = () => {
    return (
      <Upload
        showUploadList={false}
        beforeUpload={beforeUpload}
        onChange={onUploadThumb}
        name="images"
        action={`${process.env.REACT_APP_BASE_API_URL}/admin/common/upload-images`}
        headers={{
          Authorization: `Bearer ${token}`,
        }}
      >
        <div className={"upload-button avatar-uploader"} style={style}>
          {loading ? (
            <LoadingOutlined className="upload-icon" />
          ) : (
            <CloudUploadOutlined className="upload-icon" />
          )}
          <div className="upload-text">Thêm ảnh</div>
        </div>
      </Upload>
    );
  };

  function uploadButton() {
    if (isUploadBanner) {
      return <UploadForm />;
    }
    return (
      <ImgCrop
        rotate
        cropperProps={{ cropSize: { width: 600, height: 600 }, showGrid: true }}
      >
        <UploadForm />
      </ImgCrop>
    );
  }

  function beforeUpload(file) {
    const isJpgOrPng = file.type === "image/jpeg";
    if (!isJpgOrPng) {
      message.error("Bạn chỉ có thể upload file .JPG!");
    }
    const isLt2M = file.size / 1024 / 1024 < 0.2;
    if (!isLt2M) {
      message.error("Bạn chỉ có thể upload file nhỏ hơn 200KB!");
    }
    return isJpgOrPng && isLt2M;
  }

  const onUploadThumb = (info) => {
    if (info.file.status === "uploading") {
      setLoading(true);
      return;
    }
    if (info.file.status === "error") {
      setLoading(false);
      message.error("ĐÃ SẢY RA LỖI VUI LÒNG THỬ LẠI");
      return;
    }
    if (info.file.status === "done") {
      setLoading(false);
      const objImage = {
        name: info.file.name,
        url: info.file.response[0],
        alt: "",
      };
      setImage(objImage);
    }
  };

  function handleOpenPreviewImage(e) {
    e.preventDefault();
    setIsVisiblePreview(true);
  }

  function handleClosePreviewImage() {
    setIsVisiblePreview(false);
  }

  function onUpdateImageInfo(image) {
    setImage(image);
    handleClosePreviewImage();
  }

  return (
    <div className={"upload-single"}>
      {orNull("url", image) ? (
        <div className={"image-preview avatar-uploader"} style={style}>
          <img
            src={orNull("url", image)}
            alt="avatar"
            style={{ width: "100%" }}
          />
          {loading && (
            <div className={"image-loading"}>
              <LoadingOutlined className="upload-icon" />
            </div>
          )}
          <div className={"overlay"}>
            <div className={"action-list"}>
              <Tooltip placement="top" title={"Xem chi tiết"}>
                <EyeFilled
                  onClick={handleOpenPreviewImage}
                  style={{ fontSize: 22, color: "#fff", padding: 5 }}
                />
              </Tooltip>
              <Tooltip placement="top" title={"Thay đổi ảnh đại diện"}>
                {isUploadBanner ? (
                  <Upload
                    showUploadList={false}
                    beforeUpload={beforeUpload}
                    onChange={onUploadThumb}
                    name="images"
                    action={`${process.env.REACT_APP_BASE_API_URL}/admin/common/upload-images`}
                    headers={{
                      Authorization: `Bearer ${token}`,
                    }}
                  >
                    <EditFilled
                      style={{ fontSize: 22, color: "#fff", padding: 5 }}
                    />
                  </Upload>
                ) : (
                  <ImgCrop
                    rotate
                    cropperProps={{ cropSize: { width: 600, height: 600 } }}
                  >
                    <Upload
                      showUploadList={false}
                      beforeUpload={beforeUpload}
                      onChange={onUploadThumb}
                      name="images"
                      action={`${process.env.REACT_APP_BASE_API_URL}/admin/common/upload-images`}
                      headers={{
                        Authorization: `Bearer ${token}`,
                      }}
                    >
                      <EditFilled
                        style={{ fontSize: 22, color: "#fff", padding: 5 }}
                      />
                    </Upload>
                  </ImgCrop>
                )}
              </Tooltip>
            </div>
          </div>
          <ModalPreviewImage
            isVisible={isVisiblePreview}
            image={image}
            onClose={handleClosePreviewImage}
            onOk={onUpdateImageInfo}
          />
        </div>
      ) : (
        uploadButton()
      )}
    </div>
  );
}

export default withToken(UploadSingle);
