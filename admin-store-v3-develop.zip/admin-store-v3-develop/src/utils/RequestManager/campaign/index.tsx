import request from "../RequestGlobalConfig";

const campaign = {
    withAuthorize: {
        get: function (path, params = {}) {
            return request({
                method: "GET",
                url: process.env.REACT_APP_CUSTOMER_CAMPAIGN + path,
                params: params,
                headers: {
                    "Content-type": "application/json"
                }
            });
        },
        post: function(path, entity = {}) {
            return request({
              method: "POST",
              url: process.env.REACT_APP_CUSTOMER_CAMPAIGN + path,
              responseType: "json",
              headers: {
                "Content-type": "application/json"
              },
              data: entity
            });
          },
    }
};

export default campaign;
