import request from "../RequestGlobalConfig";

const customerInsight = {
    withAuthorize: {
        get: function (path, params = {}) {
            return request({
                method: "GET",
                url: process.env.REACT_APP_CUSTOMER_INSIGHT + path,
                params: params,
                headers: {
                    "Content-type": "application/json"
                }
            });
        },
    }
};

export default customerInsight;
