import v1 from "./v1";
import customerInsight from "./customerInsight"
import campaign from "./campaign"
export default {
  v1,
  customerInsight,
  campaign
};
