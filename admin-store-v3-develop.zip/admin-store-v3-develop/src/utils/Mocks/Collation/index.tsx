import { orEmpty } from "utils/Selector";

export const CODStatus = [
    {
        label: "Thu hộ",
        value: 1
    },
    {
        label: "Không thu",
        value: 0
    },
]

export const CollationStatus = [
    {
        label: "Đã đối soát",
        value: 1
    },
    {
        label: "Chưa đối soát",
        value: 0
    },
]

export const defaultFilters = [
    {
        name: "Tất cả",
        key: "all",
        params: '',
    },
];

export const filterOptions = [
    {
        label: "Giao từ kho",
        value: "withInventory",
    },
    {
        label: "Nhà vận chuyển",
        value: "withTransporter",
    },
    {
        label: "Trạng thái COD",
        value: "withCODStatus",
    },
    {
        label: "Trạng thái đối soát",
        value: "withIsCollation",
    },
    {
        label: "Thời gian tạo mã vận đơn",
        value: "withDateTime",
    },

];

export const optionMultiple = ["withTransporter", "withInventory"]

function checkFilterValue(arr) {
    if (Array.isArray(arr)) {
        return arr
    }
    return [arr]
}


export const getLabelFilter = (filterType, filterValue, filterDate?: any, listFulFillmentCompany?: any, listInventory?: any) => {
    switch (filterType) {
        case "withTransporter":
            const listTransporterFilter = []
            listFulFillmentCompany.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listTransporterFilter.push(item)
                    return
                }
            })
            return `Nhà vận chuyển là ${listTransporterFilter.map((item) => { return (item.label) })}`

        case "withCODStatus":
            return `Trạng thái thu COD là ${getCODStatus(filterValue)}`
        case "withIsCollation":
            return `Trạng thái đơn là là ${getCollationStatus(filterValue)}`
        case "withInventory":
            const listInventoryFilter = []
            listInventory.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listInventoryFilter.push(item)
                    return
                }
            })
            return `Giao từ kho ${listInventoryFilter.map((item) => { return (item.label) })}`
        case "withDateTime":
            return `Ngày tạo từ ngày ${[filterDate[0].format("DD-MM-YYYY"),]} đến ngày ${[filterDate[1].format("DD-MM-YYYY")]}`
        default:
            break;
    }
}

export const getCODStatus = (value) => {
    const codStatus = CODStatus.find((item) => item.value == value)
    return orEmpty("label", codStatus)
}

export const getCollationStatus = (value) => {
    const collationStatus = CollationStatus.find((item) => item.value == value)
    return orEmpty("label", collationStatus)
}