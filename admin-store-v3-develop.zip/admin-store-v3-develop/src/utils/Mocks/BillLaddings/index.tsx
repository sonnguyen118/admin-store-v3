

export const defaultFilters = [
    {
        name: "Tất cả đơn hàng",
        key: "all",
        filter: {},
    }, ,
];

export const filterOptions = [
    {
        label: "Trạng thái thanh toán",
        value: "withPaymentStatus"
    },
    {
        label: "Phương thức thanh toán",
        value: "withPaymentGateway"
    },
    {
        label: "Thời gian khách nhận hàng",
        value: "withShippingType",
    },
    {
        label: "Tên Seller",
        value: "withNameSeller"
    },
    {
        label: "Tags",
        value: "withTags"
    },
    {
        label: "Ngày tạo",
        value: "withDateTime"
    },
]

export const PaymentGateway = [
    {
        label: "COD",
        value: "COD",
    },
    {
        label: "TOPUP",
        value: "TOPUP",
    },
    {
        label: "VNPAY",
        value: "VNPAY",
    },
    {
        label: "ZALOPAY",
        value: "ZALOPAY",
    },
];

export const PaymentStatus = [
    {
        label: "Chờ thanh toán",
        value: "PENDING",
    },
    {
        label: "Đã thanh toán",
        value: "PAID",
    },
    {
        label: "Lỗi thanh toán",
        value: "FAILED",
    },
    {
        label: "Đã hủy",
        value: "CANCELLED",
    },
];

export const ShippingType = [
    {
        label: "Giao trong giờ hành chính",
        value: "IN_OFFICE_HOURS",
    },
    {
        label: "Giao nhanh trong 2 giờ",
        value: "IN_TWO_HOURS",
    },
    {
        label: "Tất cả các ngày trong tuần",
        value: "FREE_TIME",
    },
]

function checkFilterValue(arr) {
    if (Array.isArray(arr)) {
        return arr
    }
    return [arr]
}

export const getLabelFilter = (filterType, filterValue, listOrderTagOption?: any) => {
    switch (filterType) {
        case "withPaymentStatus":
            const listPaymentStatusFilter = []
            PaymentStatus.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listPaymentStatusFilter.push(item)
                    return
                }
            })
            return `Trạng thái thanh toán là ${listPaymentStatusFilter.map((item) => { return (item.label) })}`

        case "withPaymentGateway":
            const listPaymentGatewayFilter = []
            PaymentGateway.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listPaymentGatewayFilter.push(item)
                    return
                }
            })
            return `Phương thức thanh toán là ${listPaymentGatewayFilter.map((item) => { return (item.label) })}`

        case "withShippingType":
            const listShippingTypeFilter = []
            ShippingType.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listShippingTypeFilter.push(item)
                    return
                }
            })
            return `Thời gian nhận hàng là ${listShippingTypeFilter.map((item) => { return (item.label) })}`;

        case "withNameSeller":
            return `Đơn hàng của seller ${filterValue} `

        case "withTags":
            const listOrderTagFilter = []
            listOrderTagOption.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listOrderTagFilter.push(item)
                    return
                }
            })
            return `Tag đơn hàng là ${listOrderTagFilter.map((item) => { return (item.label) })}`

        case "withDateTime":
            return `Ngày tạo từ ngày ${[filterValue[0].format("DD-MM-YYYY"),]} đến ngày ${[filterValue[1].format("DD-MM-YYYY")]}`
        default:
            break;
    }
}