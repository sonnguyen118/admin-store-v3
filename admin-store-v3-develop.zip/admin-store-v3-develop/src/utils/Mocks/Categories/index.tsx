import { orBoolean, orEmpty, orNull } from "utils/Selector";

export const ActiveStatus = [
    {
        label: "Kích hoạt",
        value: true
    },
    {
        label: "Chưa kích hoạt",
        value: false
    },
];

export const getLabelFilter = (filterType, filterValue) => {
    switch (filterType) {
        case "withIsActive":
            return `Trạng thái kích hoạt là ${filterValue ? "Đã kích hoạt" : "Chưa kích hoạt"}`;
        default:
            break;
    }
}

export const getBodyCategory = (node = {}) => {
    const id = orNull("id", node);
    const data = {
        name: orEmpty("name", node),
        slug: orEmpty("slug", node),
        description: orEmpty("description", node),
        content: orEmpty("content", node),
        icon: orNull("icon", node),
        banner: orNull("banner", node),
        parentCategory: orNull("parentCategory", node) === "none" ? "" : orNull("parentCategory", node),
        pageSEO: {
            title: orEmpty("pageSEO_title", node),
            keywords: orEmpty("pageSEO_keywords", node),
            description: orEmpty("pageSEO_description", node),
        },
    };
    const updateData = { id, ...data };
    const createData = { ...data };
    if (id) {
        return updateData;
    }
    return createData;
};
