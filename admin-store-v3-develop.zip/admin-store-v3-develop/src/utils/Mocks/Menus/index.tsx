import {
  LineChartOutlined,
  TagOutlined,
  RocketOutlined,
  TeamOutlined,
  BookOutlined,
  ContactsOutlined,
  DollarCircleOutlined,
} from "@ant-design/icons";

export const menus = [
  {
    isParent: true,
    key: "/",
    path: "/",
    title: "Tổng quan",
    icon: <LineChartOutlined />,
    roles: [
      "ADMIN",
      "SALE_ADMIN",
      "SELLER",
      "INVENTORY_ADMIN",
      "SELLER_HOTLINE",
    ],
  },
  {
    isParent: true,
    key: "products",
    path: "/products",
    title: "Sản phẩm",
    icon: <TagOutlined />,
    roles: ["ADMIN"],
  },
  {
    isParent: "/products",
    key: "/products",
    path: "/products",
    title: "Danh sách sản phẩm",
    roles: ["ADMIN"],
  },
  {
    isParent: "/products",
    key: "/product-groups",
    path: "/product-groups",
    title: "Nhóm sản phẩm",
    roles: ["ADMIN"],
  },
  {
    isParent: "/products",
    key: "/product-brands",
    path: "/product-brands",
    title: "Thương hiệu",
    roles: ["ADMIN"],
  },
  {
    isParent: "/products",
    key: "/product-categories",
    path: "/product-categories",
    title: "Danh mục",
    roles: ["ADMIN"],
  },
  {
    isParent: "/products",
    key: "/product-reviews",
    path: "/product-reviews",
    title: "Đánh giá sản phẩm",
    roles: ["ADMIN"],
  },
  {
    isParent: true,
    key: "orders",
    path: "/orders",
    title: "Đơn hàng",
    icon: <TagOutlined />,
    roles: ["ADMIN", "SALE_ADMIN", "SELLER", "SELLER_HOTLINE"],
  },
  {
    isParent: "/orders",
    key: "/orders",
    path: "/orders",
    title: "Tất cả đơn hàng",
    roles: ["ADMIN", "SALE_ADMIN", "SELLER", "SELLER_HOTLINE"],
  },
  {
    isParent: "/orders",
    key: "/orders-seller",
    path: "/orders-seller",
    title: "DS đơn hàng Seller",
    roles: ["ADMIN", "SALE_ADMIN", "SELLER", "SELLER_HOTLINE"],
  },
  {
    isParent: true,
    key: "transports",
    path: "/transports",
    title: "Vận chuyển",
    icon: <RocketOutlined />,
    roles: [
      "ADMIN",
      "INVENTORY_ADMIN",
      "SELLER_HOTLINE",
      "SALE_ADMIN",
      "SELLER",
      "ACCOUNTING",
    ],
  },
  {
    isParent: "/transports",
    key: "/bill-laddings",
    path: "/bill-laddings",
    title: "Chưa tạo vận đơn",
    roles: ["ADMIN", "INVENTORY_ADMIN"],
  },
  {
    isParent: "/transports",
    key: "/transports",
    path: "/transports",
    title: "Vận chuyển",
    roles: [
      "ADMIN",
      "INVENTORY_ADMIN",
      "SELLER_HOTLINE",
      "SALE_ADMIN",
      "SELLER",
      "ACCOUNTING",
    ],
  },
  {
    isParent: "/transports",
    key: "/delivery-order",
    path: "/delivery-order",
    title: "Xuất hàng",
    roles: [
      "ADMIN",
      "INVENTORY_ADMIN",
      "SELLER_HOTLINE",
      "SALE_ADMIN",
      "SELLER",
      "ACCOUNTING",
    ],
  },
  {
    isParent: true,
    key: "blogs",
    path: "/blogs",
    title: "Bài Viết",
    icon: <BookOutlined />,
    roles: ["ADMIN", "COLLABORATOR"],
  },
  {
    isParent: "/blogs",
    key: "/blogs",
    path: "/blogs",
    title: "Bài viết",
    roles: ["ADMIN", "COLLABORATOR"],
  },
  {
    isParent: "/blogs",
    key: "/blog-categories",
    path: "/blog-categories",
    title: "Danh mục",
    roles: ["ADMIN", "COLLABORATOR"],
  },
  {
    isParent: true,
    key: "/customers",
    path: "/customers",
    title: "Khách hàng",
    icon: <TeamOutlined />,
    roles: [
      "ADMIN",
      "SALE_ADMIN",
      "SELLER",
      "INVENTORY_ADMIN",
      "SELLER_HOTLINE",
    ],
  },
  {
    isParent: true,
    key: "/customer-contacts",
    path: "/customer-contacts",
    title: "Khách hàng liên hệ",
    icon: <ContactsOutlined />,
    roles: ["ADMIN", "SALE_ADMIN", "SELLER", "SELLER_HOTLINE"],
  },
  {
    isParent: true,
    key: "/collation",
    path: "/collation",
    title: "Đối soát",
    icon: <DollarCircleOutlined />,
    roles: ["ADMIN", "ACCOUNTING"],
  },
];

export const getRoleMenus = (role) => {
  const result = menus.filter((item) => item.roles.includes(role));
  switch (role) {
    case "ADMIN":
      return result;
    case "SELLER":
      return result;
    case "SALE_ADMIN":
      return result;
    case "INVENTORY_ADMIN":
      return result;
    case "SELLER_HOTLINE":
      return result;
    case "ACCOUNTING":
      return result;
    case "COLLABORATOR":
      return result;

    default:
      return [];
  }
};

export const getRoleMenusDefine = (role) => {
  const result = menus.filter((item) => item.roles.includes(role));
  function parse(menus1) {
    return menus1
      .filter((menu) => menu.isParent === true)
      .map((parentCat) => {
        parentCat.nested = menus1.filter(
          (menu) => menu.isParent === parentCat.path
        );
        return parentCat;
      });
  }
  switch (role) {
    case "ADMIN":
      return parse(result);
    case "SELLER":
      return parse(result);
    case "SALE_ADMIN":
      return parse(result);
    case "INVENTORY_ADMIN":
      return parse(result);
    case "SELLER_HOTLINE":
      return parse(result);
    case "ACCOUNTING":
      return parse(result);
    case "COLLABORATOR":
      return parse(result);

    default:
      return [];
  }
};
