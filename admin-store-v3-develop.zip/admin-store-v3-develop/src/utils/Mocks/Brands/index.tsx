import { orBoolean, orEmpty, orNull } from "utils/Selector";

export const ShowStatus = [
    {
        label: "Hiển thị",
        value: true
    },
    {
        label: "Tạm ẩn",
        value: false
    },
];

export const ActiveStatus = [
    {
        label: "Đã kích hoạt",
        value: true
    },
    {
        label: "Chưa kích hoạt",
        value: false
    },
];

export const getLabelFilter = (filterType, filterValue) => {
    switch (filterType) {
        case "withIsActive":
            return `Trạng thái kích hoạt là ${filterValue ? "Đã kích hoạt" : "Chưa kích hoạt"}`;
        case "withIsShow":
            return `Trạng thái hiển thị là ${filterValue ? "Đang hiển thị" : "Tạm ẩn"}`;
        default:
            break;
    }
}

export const getBodyBrand = (node = {}) => {
    const id = orNull("id", node);
    const data = {
        name: orEmpty("name", node),
        slug: orEmpty("slug", node),
        description: orEmpty("description", node),
        icon: orNull("icon", node),
        banner: orNull("banner", node),
        isShow: orBoolean("isShow", node),
        pageSEO: {
            title: orEmpty("pageSEO_title", node),
            keywords: orEmpty("pageSEO_keywords", node),
            description: orEmpty("pageSEO_description", node),
        },
    };
    const updateData = { id, ...data };
    const createData = { ...data };
    if (id) {
        return updateData;
    }
    return createData;
};
