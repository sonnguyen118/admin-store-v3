import * as PRODUCT from './Product'
import * as GROUP_PRODUCT from './GroupProducts'
import * as ORDER from './Orders'
import * as MENUS from './Menus'
import * as TRANSPORTS from './Transports'
import * as BRANDS from './Brands'
import * as CATEGORIES from './Categories'
import * as BLOGS from './Blogs'
import * as BILLLADDINGS from './BillLaddings'
import * as CONTACTS from './Contacts'
import * as COLLATION from './Collation'
import * as PRODUCT_REVIEWS from './ProductReviews'
import * as DELIVERY_ORDER from './DeliveryOrder'
export default {
    PRODUCT,
    GROUP_PRODUCT,
    ORDER,
    MENUS,
    TRANSPORTS,
    BRANDS,
    CATEGORIES,
    BLOGS,
    BILLLADDINGS,
    CONTACTS,
    COLLATION,
    PRODUCT_REVIEWS,
    DELIVERY_ORDER
}
