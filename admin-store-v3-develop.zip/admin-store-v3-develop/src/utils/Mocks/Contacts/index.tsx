import { orBoolean, orEmpty, orNull } from 'utils/Selector';

export const defaultFilters = [
	{
		name: "Tất cả liên hệ",
		key: "all",
		filter: {},
	},
	{
		name: "Chưa xử lý",
		key: "isPending",
		filter: {
			isProcessed: false
		},
	},
	{
		name: "Đã xử lý",
		key: "isCompleted",
		filter: {
			isProcessed: true
		},
	},
];

export const ShowStatus = [
	{
		label: 'Đã xử lý',
		value: true,
	},
	{
		label: 'Chưa xử lý',
		value: false,
	},
];

export const getLabelProcessed = (filterValue) => {
	return `Trạng thái kích hoạt là ${filterValue ? 'Đã xử lý' : 'Chưa xử lý'}`;
};

export const getBodyContact = (node = {}) => {
	const id = orNull('_id', node);
	const data = {
		name: orEmpty('name', node),
		phone: orEmpty('phone', node),
		email: orEmpty('email', node),
		message: orEmpty('message', node),
		createDate: orNull('createDate', node),
		isProcessed: orBoolean('isProcessed', node),
	};
	const updateData = { ...data };
	if (id) {
		return updateData;
	}
};
