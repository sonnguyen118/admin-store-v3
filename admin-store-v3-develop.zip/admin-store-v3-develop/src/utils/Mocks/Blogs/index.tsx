import { orArray, orBoolean, orEmpty, orNull } from "utils/Selector";

export const ShowStatus = [
    {
        label: "Hiển thị",
        value: true
    },
    {
        label: "Tạm ẩn",
        value: false
    },
];

export const ActiveStatus = [
    {
        label: "Đã kích hoạt",
        value: true
    },
    {
        label: "Chưa kích hoạt",
        value: false
    },
];

export const getLabelFilter = (filterType, filterValue) => {
    switch (filterType) {
        case "withIsActive":
            return `Trạng thái kích hoạt là ${filterValue ? "Đã kích hoạt" : "Chưa kích hoạt"}`;
        case "withIsShow":
            return `Trạng thái hiển thị là ${filterValue ? "Đang hiển thị" : "Tạm ẩn"}`;
        case "withAuthor":
            return `Người viết bài là ${filterValue}`;
        default:
            break;
    }
}

export const getBodyBlog = (node = {}) => {
    const id = orNull("id", node);
    const data = {
        title: orEmpty("title", node),
        slug: orEmpty("slug", node),
        description: orEmpty("description", node),
        category: orEmpty("category", node),
        subCategory: orNull("subCategory", node),
        content: orEmpty("content", node),
        featuredImage: orNull("icon", node),
        banner: orNull("banner", node),
        template: orBoolean("template", node),
        tags: orArray("tags", node).map(item => (item.value)),
        pageSEO: {
            title: orEmpty("pageSEO_title", node),
            keywords: orEmpty("pageSEO_keywords", node),
            description: orEmpty("pageSEO_description", node),
        },
    };
    const updateData = { id, ...data };
    const createData = { ...data };
    if (id) {
        return updateData;
    }
    return createData;
};
