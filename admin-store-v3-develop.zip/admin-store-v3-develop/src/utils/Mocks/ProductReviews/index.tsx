
export const defaultFilters = [
	{
		name: "Tất cả đánh giá",
		key: "all",
		filter: {},
	},
	{
		name: "Chưa kích hoạt",
		key: "isPending",
		filter: {
			isPublished: false
		},
	},
	{
		name: "Đã kích hoạt",
		key: "isCompleted",
		filter: {
			isPublished: true
		},
	},
];