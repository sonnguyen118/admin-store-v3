import { orEmpty, orNull, orArray, orBoolean, orNumber } from "utils/Selector";

export const listPageId = [
  {
    label: "Trang khác",
    value: "NONE",
  },
  {
    label: "Trang chủ",
    value: "HOME_PAGE",
  },
];

export const listPlacementId = [
  {
    label: "Sản phẩm nổi bật",
    value: 1,
  },
  {
    label: "Sản phẩm gợi ý",
    value: 2,
  },
];

export const getBodyGroupProduct = (node = {}) => {
  const id = orNull("id", node);
  const products = orArray("products", node);
  const data = {
    name: orEmpty("name", node),
    slug: orEmpty("slug", node),
    pageId: orEmpty("pageId", node) || "NONE",
    groupType: orEmpty("groupType", node),
    placementId: orNumber("placementId", node) || 0,
    description: orEmpty("description", node),
    content: orEmpty("content", node),
    icon: {
      url: orEmpty("url", node),
    },
    pageSEO: {
      title: orEmpty("pageSEO_title", node),
      keywords: orEmpty("pageSEO_keywords", node),
      description: orEmpty("pageSEO_description", node),
    },
  };
  const updateData = { id, ...data };
  const createData = { ...data, products };
  if (id) {
    return updateData;
  }
  return createData;
};
