export const defaultFilters = [
  {
    name: "Tất cả",
    key: "all",
    filter: {},
  },
];

export const filterOptions = [
  {
    label: "Trạng thái xuất đơn",
    value: "withExported",
  },
  //   {
  //     label: "Giao từ kho",
  //     value: "withInventory",
  //   },
  {
    label: "Nguồn đơn",
    value: "withSource",
  },
  {
    label: "Trạng thái In đơn",
    value: "withPrinted",
  },
  {
    label: "Thời gian tạo đơn vận chuyển",
    value: "withDateTime",
  },
  {
    label: "Thời gian dự kiến giao hàng",
    value: "withEstimateDeliveryDate",
  },
];

export const PrintedStatus = [
  {
    label: "Đã in vận đơn",
    value: 1,
  },
  {
    label: "Chưa in vận đơn",
    value: 0,
  },
];

export const ExportedStatus = [
  {
    label: "Đã xuất đơn",
    value: 1,
  },
  {
    label: "Chưa xuất đơn",
    value: 0,
  },
];

export const ListSource = [
  {
    label: "WEB",
    value: "WEB",
  },
  {
    label: "APP",
    value: "APP",
  },
  {
    label: "FACEBOOK",
    value: "FACEBOOK",
  },
  {
    label: "ZALO",
    value: "ZALO",
  },
  {
    label: "STAFF",
    value: "STAFF",
  },
  {
    label: "PHONE",
    value: "PHONE",
  },
  {
    label: "POS",
    value: "POS",
  },
  {
    label: "LAZADA",
    value: "LAZADA",
  },
  {
    label: "SHOPEE",
    value: "SHOPEE",
  },
  {
    label: "TIKI",
    value: "TIKI",
  },
  {
    label: "GOOGLE SHOPPING",
    value: "GOOGLESHOP",
  },
  {
    label: "LANDINGPAGE",
    value: "LANDINGPAGE",
  },
  {
    label: "SAPO GRABMART",
    value: "SAPO_GRABMART",
  },
  {
    label: "SAPO WEBORDER",
    value: "SAPO_WEBORDER",
  },
  {
    label: "SAPO INSTAGRAM",
    value: "SAPO_INSTAGRAM",
  },
  {
    label: "SAPO SENDO",
    value: "SAPO_SENDO",
  },
  {
    label: "SAPO OTHER",
    value: "SAPO_OTHER",
  },
  {
    label: "SAPO SHOPEE",
    value: "SAPO_SHOPEE",
  },
  {
    label: "SAPO SHOPEE HA NOI",
    value: "SAPO_SHOPEE_HA_NOI",
  },
  {
    label: "SAPO SHOPEE HO CHI MINH",
    value: "SAPO_SHOPEE_HO_CHI_MINH",
  },
  {
    label: "SAPO POS",
    value: "SAPO_POS",
  },
  {
    label: "SAPO TIKI",
    value: "SAPO_TIKI",
  },
  {
    label: "SAPO LAZADA",
    value: "SAPO_LAZADA",
  },
  {
    label: "SAPO ZALO",
    value: "SAPO_ZALO",
  },
  {
    label: "SAPO_FACEBOOK",
    value: "SAPO_FACEBOOK",
  },
  {
    label: "SAPO WEB",
    value: "SAPO_WEB",
  },
];

export const optionMultiple = ["withInventory", "withSource"];

function checkFilterValue(arr) {
  if (Array.isArray(arr)) {
    return arr;
  }
  return [arr];
}

export const getLabelFilter = (
  filterType,
  filterValue,
  listinventory?: any
) => {
  switch (filterType) {
    case "withExported":
      return `Trạng thái xuất đơn là ${
        filterValue ? "đã xuất đơn" : "chưa xuất đơn"
      }`;
    case "withInventory":
      const listInventoryFilter = [];
      listinventory.length &&
        listinventory.forEach((item) => {
          const result = checkFilterValue(filterValue).find(
            (value) => value === item.value
          );
          if (result) {
            listInventoryFilter.push(item);
            return;
          }
        });
      return `Giao từ kho ${listInventoryFilter.map((item) => {
        return item.label;
      })}`;
    case "withPrinted":
      return `Trạng thái in đơn là ${
        filterValue ? "đã in vận đơn" : "chưa in vận đơn"
      }`;
    case "withSource":
      const listSourceFilter = [];
      ListSource.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listSourceFilter.push(item);
          return;
        }
      });
      return `Giao từ kho ${listSourceFilter.map((item) => {
        return item.label;
      })}`;
    case "withDateTime":
      return `Ngày tạo từ ngày ${[
        filterValue[0].format("DD-MM-YYYY"),
      ]} đến ngày ${[filterValue[1].format("DD-MM-YYYY")]}`;
      case "withEstimateDeliveryDate":
      return `Thời gian dự kiến giao hàng là ngày ${[filterValue.format("DD-MM-YYYY"),]}`;
    default:
      break;
  }
};
