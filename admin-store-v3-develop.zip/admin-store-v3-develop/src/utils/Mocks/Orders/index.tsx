import { orEmpty, orNull, orArray } from "utils/Selector";

export const OrderStatus = [
  {
    label: "Chờ xử lý",
    value: "PENDING",
  },
  {
    label: "Chờ lấy hàng",
    value: "SHIPPING",
  },
  {
    label: "Đang giao hàng",
    value: "DELIVERING",
  },
  {
    label: "Đã xác nhận",
    value: "CONFIRMED",
  },
  {
    label: "Đã giao hàng",
    value: "COMPLETED",
  },
  {
    label: "Đã hủy",
    value: "CANCELLED",
  },
];

export const PaymentGateway = [
  {
    label: "COD",
    value: "COD",
  },
  {
    label: "TOPUP",
    value: "TOPUP",
  },
  {
    label: "VNPAY",
    value: "VNPAY",
  },
  {
    label: "ZALOPAY",
    value: "ZALOPAY",
  },
];

export const ListSource = [
  {
    label: "WEB",
    value: "WEB",
  },
  {
    label: "APP",
    value: "APP",
  },
  {
    label: "FACEBOOK",
    value: "FACEBOOK",
  },
  {
    label: "ZALO",
    value: "ZALO",
  },
  {
    label: "STAFF",
    value: "STAFF",
  },
  {
    label: "PHONE",
    value: "PHONE",
  },
  {
    label: "POS",
    value: "POS",
  },
  {
    label: "LAZADA",
    value: "LAZADA",
  },
  {
    label: "SHOPEE",
    value: "SHOPEE",
  },
  {
    label: "TIKI",
    value: "TIKI",
  },
  {
    label: "GOOGLE SHOPPING",
    value: "GOOGLESHOP",
  },
  {
    label: "LANDINGPAGE",
    value: "LANDINGPAGE",
  },
  {
    label: "SAPO GRABMART",
    value: "SAPO_GRABMART",
  },
  {
    label: "SAPO WEBORDER",
    value: "SAPO_WEBORDER",
  },
  {
    label: "SAPO INSTAGRAM",
    value: "SAPO_INSTAGRAM",
  },
  {
    label: "SAPO SENDO",
    value: "SAPO_SENDO",
  },
  {
    label: "SAPO OTHER",
    value: "SAPO_OTHER",
  },
  {
    label: "SAPO SHOPEE",
    value: "SAPO_SHOPEE",
  },
  {
    label: "SAPO SHOPEE HA NOI",
    value: "SAPO_SHOPEE_HA_NOI",
  },
  {
    label: "SAPO SHOPEE HO CHI MINH",
    value: "SAPO_SHOPEE_HO_CHI_MINH",
  },
  {
    label: "SAPO POS",
    value: "SAPO_POS",
  },
  {
    label: "SAPO TIKI",
    value: "SAPO_TIKI",
  },
  {
    label: "SAPO LAZADA",
    value: "SAPO_LAZADA",
  },
  {
    label: "SAPO ZALO",
    value: "SAPO_ZALO",
  },
  {
    label: "SAPO_FACEBOOK",
    value: "SAPO_FACEBOOK",
  },
  {
    label: "SAPO WEB",
    value: "SAPO_WEB",
  },
];

export const getListSourceOverview = () => {
  const optionAll = [
    {
      label: "Tất cả các kênh bán hàng",
      value: "All",
    },
  ];
  return optionAll.concat(ListSource);
};

export const PaymentGatewayDescription = [
  {
    label: "Thanh toán khi nhận hàng (COD)",
    value: "COD",
  },
  {
    label: "Thanh toán qua TOPUP",
    value: "TOPUP",
  },
  {
    label: "Thanh toán qua VNPAY",
    value: "VNPAY",
  },
  {
    label: "Thanh toán qua ZALOPAY",
    value: "ZALOPAY",
  },
  {
    label: "Thanh toán chuyển khoản",
    value: "CUSTOM",
  },
];

export const PaymentStatus = [
  {
    label: "Chờ thanh toán",
    value: "PENDING",
  },
  {
    label: "Đã thanh toán",
    value: "PAID",
  },
  {
    label: "Lỗi thanh toán",
    value: "FAILED",
  },
  {
    label: "Đã hủy",
    value: "CANCELLED",
  },
];

export const SellerStatus = [
  {
    label: "Đã được gán cho seller",
    value: 1,
  },
  {
    label: "Chưa được gán cho seller",
    value: 0,
  },
];

export const DeliveryTime = [
  {
    label: "Chỉ giao trong giờ hành chính",
    description: "(phù hợp với địa chỉ văn phòng/cơ quan)",
    value: "IN_OFFICE_HOURS",
    color: "#22C993",
  },
  {
    label: "Tất cả các ngày trong tuần",
    description: "(phù hợp với địa chỉ nhà riêng luôn có người nhận hàng)",
    value: "FREE_TIME",
    color: "#1890FF",
  },
  {
    label: "Giao nhanh trong 2h",
    description: "(Áp dụng địa chỉ giao hàng tại Hà Nội và Hồ Chí Minh)",
    value: "IN_TWO_HOURS",
    color: "#FA8C16",
  },
];

export const OrdertStatus = [
  {
    label: "Chờ xử lý",
    value: "PENDING",
  },
  {
    label: "Chờ lấy hàng",
    value: "SHIPPING",
  },
  {
    label: "Đang giao hàng",
    value: "DELIVERING",
  },
  {
    label: "Đã xác nhận",
    value: "CONFIRMED",
  },
  {
    label: "Đã giao hàng",
    value: "COMPLETED",
  },
  {
    label: "Đã hủy",
    value: "CANCELLED",
  },
];

export const sellerAcceptStatus = [
  {
    label: "Chờ nhận đơn",
    value: "PENDING",
  },
  {
    label: "Đã nhận đơn",
    value: "ACCEPTED",
  },
  {
    label: "Đã bị từ chối",
    value: "REJECTED",
  },
  {
    label: "Chưa được gán đơn",
    value: "NONE",
  },
];

export const ShippingType = [
  {
    label: "Giao trong giờ hành chính",
    value: "IN_OFFICE_HOURS",
  },
  {
    label: "Giao nhanh trong 2 giờ",
    value: "IN_TWO_HOURS",
  },
  {
    label: "Tất cả các ngày trong tuần",
    value: "FREE_TIME",
  },
];

export const OrderCompletedType = [
  {
    label: "Đơn upsale thành công",
    value: "isUpsale",
    filter: {
      isSellerProcessCompleted: true,
      isUpsale: true,
      isNotStatus: "CANCELLED",
    },
  },
  {
    label: "Đơn thường",
    value: "isNormal",
    filter: {
      isSellerProcessCompleted: true,
      isUpsale: false,
      isNotStatus: "CANCELLED",
    },
  },
];

export const defaultAdminFilters = [
  {
    name: "Tất cả đơn hàng",
    key: "all",
    filter: {},
  },
  {
    name: "Chưa được gán",
    key: "isNotSeller",
    filter: {
      withSeller: false,
      isNotStatus: "CANCELLED",
      isNotSapoOrder: true,
    },
  },
  {
    name: "Đã được gán",
    key: "isSeller",
    filter: {
      withSeller: true,
      isNotStatus: "CANCELLED",
      isNotSellerAcceptedForwardStatus: "PENDING",
      isNotSapoOrder: true,
    },
  },
  {
    name: "Đang chuyển tiếp",
    key: "isForward",
    filter: {
      isSellerForward: true,
      isNotStatus: "CANCELLED",
      isNotSapoOrder: true,
    },
  },
  {
    name: "Đã đủ sản phẩm",
    key: "isFullProduct",
    filter: {
      hasFullProduct: true,
    },
  },
  {
    name: "Chờ sản phẩm về",
    key: "isWaitingProduct",
    filter: {
      hasFullProduct: false,
    },
  },
  {
    name: "Đã hủy",
    key: "isCanceled",
    filter: {
      status: "CANCELLED",
      isNotSapoOrder: true,
    },
  },
];

export const defaultSellerFilters = [
  {
    name: "Tất cả đơn hàng",
    key: "all",
    filter: {},
  },
  {
    name: "Đang xử lý",
    key: "isPending",
    filter: {
      isSellerProcessCompleted: false,
    },
  },
  {
    name: "Đã hoàn thành",
    key: "isCompleted",
    filter: {
      isSellerProcessCompleted: true,
      isNotStatus: "CANCELLED",
    },
  },
  {
    name: "Đã đủ sản phẩm",
    key: "isFullProduct",
    filter: {
      hasFullProduct: true,
      isSeller: true,
    },
  },
  {
    name: "Chờ sản phẩm về",
    key: "isWaitingProduct",
    filter: {
      isSeller: true,
      hasFullProduct: false,
    },
  },
  {
    name: "Đã hủy",
    key: "isCanceled",
    filter: {
      status: "CANCELLED",
    },
  },
];

export const CancelReasonOptions = [
  {
    label: "Chuyển hoàn",
    value: "ORDERS_REFUNDED",
  },
  {
    label: "Khách hàng hủy đơn",
    value: "CUSTOMER_CANCEL",
  },
  {
    label: "Khách hàng đổi sản phẩm",
    value: "CUSTOMER_CHANGED_PRODUCT",
  },
  {
    label: "Khách hàng ra salon",
    value: "CUSTOMER_CHANGED_SALON",
  },
  {
    label: "Khách hàng đổi ý",
    value: "CUSTOMER_CHANGED_MIND",
  },
  {
    label: "Không gọi được cho khách",
    value: "CAN_NOT_CALL",
  },
  {
    label: "Nhầm, sai số điện thoại",
    value: "WRONG_PHONE",
  },
  {
    label: "Hết hàng tạo đơn mới",
    value: "OUT_OF_STOCK_NEW_ORDER",
  },
  {
    label: "Đặt lại đơn",
    value: "REORDERS",
  },
  {
    label: "Trùng đơn",
    value: "SAME_ORDERS",
  },
  {
    label: "Upsale đơn",
    value: "REORDERS_UPSALE",
  },
  {
    label: "Đơn hàng giả mạo",
    value: "FAKE_ORDERS",
  },
  {
    label: "Hết hàng",
    value: "OUT_OF_STOCK",
  },
  {
    label: "Khác",
    value: "OTHER",
  },
];

export const CompensationAndRefundType = [
  {
    label: "Đơn trả hàng",
    value: "isRefund",
    filter: {
      isRefund: true,
    },
  },
  {
    label: "Đơn bù hàng",
    value: "isCompensation",
    filter: {
      isCompensation: true,
    },
  },
];

export function getListCancelReasonOptions() {
  const arr = [
    "ORDERS_REFUNDED",
    "CUSTOMER_CANCEL",
    "CUSTOMER_CHANGED_PRODUCT",
    "CUSTOMER_CHANGED_SALON",
    "CAN_NOT_CALL",
    "WRONG_PHONE",
    "OUT_OF_STOCK_NEW_ORDER",
    "REORDERS",
    "REORDERS_UPSALE",
    "OUT_OF_STOCK",
  ];
  return CancelReasonOptions.filter((item) => !arr.includes(item.value));
}

export const roleDisableAction = ["SELLER", "SELLER_HOTLINE"];

function checkFilterValue(arr) {
  if (Array.isArray(arr)) {
    return arr;
  }
  return [arr];
}

export const getLabelFilter = (
  filterType,
  filterValue,
  sellerProcessStepOption?: any,
  listOrderTagOption?: any
) => {
  switch (filterType) {
    case "status":
      const listOrderStatusFilter = [];
      OrderStatus.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listOrderStatusFilter.push(item);
          return;
        }
      });
      return `Trạng thái đơn hàng là ${listOrderStatusFilter.map((item) => {
        return item.label;
      })}`;

    case "withOrderCompletedType":
      return `Loại đơn hàng là đơn ${
        filterValue === "isUpsale" ? "upsale thành công" : "thường"
      }`;

    case "withShippingType":
      const listShippingTypeFilter = [];
      ShippingType.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listShippingTypeFilter.push(item);
          return;
        }
      });
      return `Thời gian nhận hàng là ${listShippingTypeFilter.map((item) => {
        return item.label;
      })}`;

    case "withPaymentStatus":
      const listPaymentStatusFilter = [];
      PaymentStatus.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listPaymentStatusFilter.push(item);
          return;
        }
      });
      return `Trạng thái thanh toán là ${listPaymentStatusFilter.map((item) => {
        return item.label;
      })}`;

    case "withPaymentGateway":
      const listPaymentGatewayFilter = [];
      PaymentGateway.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listPaymentGatewayFilter.push(item);
          return;
        }
      });
      return `Phương thức thanh toán là ${listPaymentGatewayFilter.map(
        (item) => {
          return item.label;
        }
      )}`;

    case "withNameSeller":
      return `Đơn hàng của seller ${filterValue} `;

    case "withSellerStep":
      const listSellerProcessStepFilter = [];
      sellerProcessStepOption.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listSellerProcessStepFilter.push(item);
          return;
        }
      });
      return `Tác nghiệp của seller là ${listSellerProcessStepFilter.map(
        (item) => {
          return item.label;
        }
      )}`;

    case "withSellerAcceptStatus":
      const listSellerAcceptStatusFilter = [];
      sellerAcceptStatus.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listSellerAcceptStatusFilter.push(item);
          return;
        }
      });
      return `Trạng thái nhận đơn là ${listSellerAcceptStatusFilter.map(
        (item) => {
          return item.label;
        }
      )}`;

    case "withSource":
      return `Kênh bán hàng là ${filterValue}`;

    case "withTags":
      const listOrderTagFilter = [];
      listOrderTagOption.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listOrderTagFilter.push(item);
          return;
        }
      });
      return `Tag đơn hàng là ${listOrderTagFilter.map((item) => {
        return item.label;
      })}`;

    case "withDateTime":
      return `Ngày tạo từ ngày ${[
        filterValue[0].format("DD-MM-YYYY"),
      ]} đến ngày ${[filterValue[1].format("DD-MM-YYYY")]}`;
    case "withCancelReason":
      const listCancelReasonFilter = [];
      CancelReasonOptions.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listCancelReasonFilter.push(item);
          return;
        }
      });
      return `Lý do hủy đơn là ${listCancelReasonFilter.map((item) => {
        return item.label;
      })}`;
    case "withCompensationAndRefund":
      const listCompensationAndRefund = [];
      CompensationAndRefundType.forEach((item) => {
        const result = checkFilterValue(filterValue).find(
          (value) => value === item.value
        );
        if (result) {
          listCompensationAndRefund.push(item);
          return;
        }
      });
      return `Loại đơn hàng là đơn ${listCompensationAndRefund.map((item) => {
        return item.label;
      })}`;
    default:
      break;
  }
};

export const getSellerAcceptStatus = (value) => {
  const sellerAcceptStatusItem = sellerAcceptStatus.find(
    (item) => item.value === value
  );
  return sellerAcceptStatusItem;
};

export const getOrderStatus = (value) => {
  const orderStatus = OrderStatus.find((item) => item.value === value);
  return orEmpty("label", orderStatus);
};

export const getSellerStatus = (value) => {
  const sellerStatus = SellerStatus.find((item) => item.value === value);
  return orEmpty("label", sellerStatus);
};

export const getPaymentGateway = (value) => {
  const paymentGateway = PaymentGateway.find((item) => item.value === value);
  return orEmpty("label", paymentGateway);
};

export const getPaymentGatewayDescription = (value) => {
  const paymentGatewayd = PaymentGatewayDescription.find(
    (item) => item.value === value
  );
  return orEmpty("label", paymentGatewayd);
};

export const getPaymentStatus = (value) => {
  const paymentStatus = PaymentStatus.find((item) => item.value === value);
  return orEmpty("label", paymentStatus);
};

export const getDeliveryTime = (value) => {
  const deliveryTime = DeliveryTime.find((item) => item.value === value);
  return deliveryTime;
};

export const getBodyOrder = (node = {}) => {
  const data = {
    ...node,
    customerNote: orEmpty("customerNote", node),
    paymentGateway: "COD",
  };
  const createData = { ...data };
  return createData;
};

export const onGetVoucherMessage = (value) => {
  switch (value) {
    case "campaign_not_exist":
      return "Campaign không tồn tại";
    case "voucher_not_exist":
      return "Code không tồn tại";
    case "voucher_already_using":
      return "Khách hàng đã sử dụng code";
    case "voucher_already_using_by_other":
      return "Code đã được sử dụng";
    default:
      return "Lỗi không xác định";
  }
};

export const campaignShineMember = {
  selectCampaign: true,
  used: 0,
  mktCampaign: {
    id: "Shine member",
    name: "Áp dụng Shine member",
    maxUsage: 1,
    endDate: "",
  },
  listProduct: [],
  descriptionCampaign: {
    campaignId: "Shine member",
    campaignName: "Áp dụng Shine member",
    conditionUse: "Áp dụng với Shine member",
    conditionUseGeneral: "Được sử dụng với một số campaign khác",
  },
};
