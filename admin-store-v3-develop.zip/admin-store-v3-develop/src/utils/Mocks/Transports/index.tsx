import { orEmpty } from "utils/Selector"

export const FulfillmentStatus = [
    {
        label: "Chờ lấy hàng",
        value: "READY_TO_PICK"
    },
    {
        label: "Đang đi lấy hàng",
        value: "PICKING"
    },
    {
        label: "Đang giao hàng",
        value: "DELIVERING"
    },
    {
        label: "Đã giao hàng",
        value: "DELIVERED"
    },
    {
        label: "Đang chuyển hoàn",
        value: "REFUNDING"
    },
    {
        label: "Đã hủy giao hàng",
        value: "CANCELLED"
    },
    {
        label: "Đã chuyển hoàn",
        value: "REFUNDED"
    },
]

export const CODStatus = [
    {
        label: "Thu hộ",
        value: 1
    },
    {
        label: "Không thu",
        value: 0
    },
]

export const PaymentStatus = [
    {
        label: "Chờ thanh toán",
        value: "PENDING"
    },
    {
        label: "Đã thanh toán",
        value: "PAID"
    },
    {
        label: "Lỗi thanh toán",
        value: "FAILED"
    },
    {
        label: "Đã hủy",
        value: "CANCELLED"
    },
]

export const CodStatus = [
    {
        label: "Chưa thu",
        value: "PENDING"
    },
    {
        label: "Đã thu",
        value: "RECEIPTED"
    },
]

export const PrintedStatus = [
    {
        label: "Đã in vận đơn",
        value: 1
    },
    {
        label: "Chưa in vận đơn",
        value: 0
    },
]

export const ShippingType = [
    {
        label: "Giao trong giờ hành chính",
        value: "IN_OFFICE_HOURS",
    },
    {
        label: "Giao nhanh trong 2 giờ",
        value: "IN_TWO_HOURS",
    },
    {
        label: "Tất cả các ngày trong tuần",
        value: "FREE_TIME",
    },
]

export const defaultFilters = [
    {
        name: "Tất cả đơn vận chuyển",
        key: "all",
        filter: {},
    },
    {
        name: "Chờ Lấy hàng",
        key: "withStatusReadyToPick",
        filter: {
            status: "READY_TO_PICK",
        },
    },
    {
        name: "Đang lấy hàng",
        key: "withStatusPicking",
        filter: {
            status: "PICKING",
        },
    },
    {
        name: "Đơn hàng không thu hộ",
        key: "withNotCOD",
        filter: {
            isCOD: false,
        },
    },
    {
        name: "Đơn hàng thu hộ",
        key: "withCOD",
        filter: {
            isCOD: true,
        },
    },
];

export const CompensationAndRefundStatus = [
    {
        label: "Vận đơn trả hàng",
        value: "REFUND",
    },
    {
        label: "Vận đơn bù hàng",
        value: "COMPENSATION",
    },
]

export const filterOptions = [
    {
        label: "Trạng thái giao hàng",
        value: "withStatus",
    },
    {
        label: "Thời gian khách nhận hàng",
        value: "withShippingType",
    },
    {
        label: "Trạng thái COD",
        value: "withCODStatus",
    },
    {
        label: "Nhà vận chuyển",
        value: "withTransporter",
    },
    {
        label: "Thời gian tạo mã vận đơn",
        value: "withDateTime",
    },
    {
        label: "Thời gian dự kiến giao hàng",
        value: "withEstimateDeliveryDate",
    },
    {
        label: "Giao từ kho",
        value: "withInventory",
    },
    {
        label: "Trạng thái In đơn",
        value: "withPrinted",
    },
    {
        label: "Đơn vận chuyển trả hàng, bù hàng",
        value: "withCompensationAndRefund",
    },
];

export const optionMultiple = ["withStatus", "withShippingType", "withTransporter", "withInventory", 'withCompensationAndRefund']

function checkFilterValue(arr) {
    if (Array.isArray(arr)) {
        return arr
    }
    return [arr]
}


export const getLabelFilter = (filterType, filterValue, listFulFillmentCompany?: any, listinventory?: any) => {
    switch (filterType) {
        case "withStatus":
            const listFulfillmentStatusFilter = []
            FulfillmentStatus.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listFulfillmentStatusFilter.push(item)
                    return
                }
            })
            return `Trạng thái giao hàng là ${listFulfillmentStatusFilter.map((item) => { return (item.label) })}`
        case "withShippingType":
            const listShippingTypeFilter = []
            ShippingType.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listShippingTypeFilter.push(item)
                    return
                }
            })
            return `Thời gian nhận hàng là ${listShippingTypeFilter.map((item) => { return (item.label) })}`;
        case "withTransporter":
            const listTransporterFilter = []
            listFulFillmentCompany.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listTransporterFilter.push(item)
                    return
                }
            })
            return `Nhà vận chuyển là ${listTransporterFilter.map((item) => { return (item.label) })}`

        case "withCODStatus":
            return `Trạng thái thu COD là ${getCODStatus(filterValue)}`
        case "withInventory":
            const listInventoryFilter = []
            listinventory.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listInventoryFilter.push(item)
                    return
                }
            })
            return `Giao từ kho ${listInventoryFilter.map((item) => { return (item.label) })}`
        case "withPrinted":
            return `Trạng thái in đơn là ${filterValue ? "đã in vận đơn" : "chưa in vận đơn"}`
        case "withEstimateDeliveryDate":
            return `Thời gian dự kiến giao hàng ngày ${[filterValue.format("DD-MM-YYYY"),]}`
        case "withDateTime":
            return `Ngày tạo từ ngày ${[filterValue[0].format("DD-MM-YYYY"),]} đến ngày ${[filterValue[1].format("DD-MM-YYYY")]}`
        case 'withCompensationAndRefund':
            const listCompensationAndRefund = []
            CompensationAndRefundStatus.forEach(item => {
                const result = checkFilterValue(filterValue).find(value => value === item.value)
                if (result) {
                    listCompensationAndRefund.push(item)
                    return
                }
            })
            return `Vận đơn là ${listCompensationAndRefund.map((item) => { return (item.label) })}`
        default:
            break;
    }
}

export const getFulfillmentStatus = (value) => {
    const fulfillmentStatus = FulfillmentStatus.find((item) => item.value === value)
    return orEmpty("label", fulfillmentStatus)
}

export const getCODStatus = (value) => {
    const codStatus = CODStatus.find((item) => item.value === value)
    return orEmpty("label", codStatus)
}

export const getCodStatus = (value) => {
    const codStatus = CodStatus.find((item) => item.value === value)
    return orEmpty("label", codStatus)
}

export const getPaymentStatus = (value) => {
    const paymentStatus = PaymentStatus.find((item) => item.value === value)
    return orEmpty("label", paymentStatus)
}
