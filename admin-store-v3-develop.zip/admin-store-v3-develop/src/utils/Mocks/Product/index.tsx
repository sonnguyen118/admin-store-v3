import { orEmpty, orNull, orArray, orBoolean } from "utils/Selector";

export const getBodyProduct = (node = {}) => {
  const id = orNull("id", node);
  const variants = orArray("variants", node).map((item) => ({
    name: orEmpty("name", item),
    weight: orNull("weight", item),
    sku: orNull("sku", item),
    price:
      orNull("price", item) === 0
        ? orNull("listedPrice", item)
        : orNull("price", item),
    listedPrice: orNull("listedPrice", item),
  }));
  const tags = orArray("tags", node).map((item) => item.value);
  const priavtePromotions = orArray("priavtePromotions", node);
  const tagValues = orArray("tags", node).map((item) => orEmpty("label", item));
  const keywords = `${orEmpty("name", node)},${tagValues.toString()}`;
  const data = {
    name: orEmpty("name", node),
    slug: orEmpty("slug", node),
    featuredImage: orNull("featuredImage", node),
    images: orArray("images", node),
    description: orEmpty("description", node),
    shortDescription: orEmpty("shortDescription", node),
    channels: orArray("channels", node),
    category: orNull("category", node),
    keywords: keywords,
    subCategory: orNull("subCategory", node),
    brand: orNull("brand", node),
    tags: tags,
    priavtePromotions: priavtePromotions,
    productIngredients: orEmpty("productIngredients", node),
    productManual: orEmpty("productManual", node),
    pageSEO: {
      title: orEmpty("pageSEO_title", node),
      keywords: orEmpty("pageSEO_keywords", node),
      description: orEmpty("pageSEO_description", node),
    },
  };
  const updateData = { id, ...data };
  const createData = { ...data, variants };
  if (id) {
    return updateData;
  }
  return createData;
};

export const getBodyVariant = (node = {}) => {
  const id = orNull("variantId", node);
  const data = {
    name: orEmpty("name", node),
    image: orNull("image", node),
    weight: orNull("weight", node),
    isActive: orBoolean("isActive", node),
    sku: orNull("sku", node),
    price:
      orNull("price", node) === 0
        ? orNull("listedPrice", node)
        : orNull("price", node),
    listedPrice: orNull("listedPrice", node),
    isOutOfStock: orBoolean("isOutOfStock", node),
  };
  const updateData = { id, ...data };
  if (id) {
    return updateData;
  }
  return data;
};
