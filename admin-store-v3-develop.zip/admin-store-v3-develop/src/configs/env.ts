interface EnvInterface {
    greeting: string;
    base_api_url: string;
    base_url: string;
    base_author_url: string;
    base_staff_url: string;
    customer_dashboard: string;
}

const env: EnvInterface = {
    greeting: process.env.REACT_APP_GREETING,
    base_api_url: process.env.REACT_APP_BASE_API_URL,
    base_url: process.env.REACT_APP_BASE_URL,
    base_author_url: process.env.REACT_APP_BASE_AUTHOR_API_URL,
    base_staff_url: process.env.REACT_APP_BASE_STAFF_API_URL,
    customer_dashboard: process.env.REACT_APP_CUSTOMER_DASHBOARD
};

export default env;