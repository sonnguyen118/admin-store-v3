import {
    LineChartOutlined,
    ShoppingCartOutlined,
    TagOutlined,
    RocketOutlined,
    TeamOutlined,
    SettingOutlined,
    ScheduleOutlined,
    ShopOutlined,
    BookOutlined,
    ContactsOutlined
} from "@ant-design/icons";

export const menus = [

    {
        key: "/",
        path: "/",
        title: "Tổng quan",
        icon: <LineChartOutlined />,
    },
    {
        key: "/products",
        path: "/products",
        title: "Sản phẩm",
        icon: <TagOutlined />,
        nested: [
            {
                key: "/products",
                path: "/products",
                title: "Danh sách sản phẩm",
            },
            {
                key: "/product-groups",
                path: "/product-groups",
                title: "Nhóm sản phẩm",
            }
        ]
    },
    {
        key: "/orders",
        path: "/orders",
        title: "Đơn hàng",
        icon: <TagOutlined />,
        nested: [
            {
                key: "/orders",
                path: "/orders",
                title: "Tất cả đơn hàng",
            },
            {
                key: "/orders-seller",
                path: "/orders-seller",
                title: "Quản lý đơn hàng Seller",
            }
        ]
    },
    {
        key: "/transports",
        path: "/transports",
        title: "Vận chuyển",
        icon: <RocketOutlined />,
        nested: [
            {
                key: "/transports",
                path: "/transports",
                title: "Đơn vận chuyển",
            },
            {
                key: "/transports-name",
                path: "/transports-name",
                title: "Đối soát",
            }
        ]
    },
    {
        key: "/customers",
        path: "/customers",
        title: "Khách hàng",
        icon: <TeamOutlined />,
    },
]


export const admin_menus = ["/products", "/orders"]

