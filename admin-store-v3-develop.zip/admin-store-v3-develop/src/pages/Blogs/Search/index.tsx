import React, { useState, useMemo } from "react";
import { Row, Col, Input, Button, Popover, Form, Tag, Dropdown, Menu } from "antd";
import { FilterOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { Selector } from "components";
import "./styled.scss"
import { Mocks } from "utils";
import { DownOutlined } from "@ant-design/icons";
import { orEmpty } from "utils/Selector";

const filterOptions = [
  {
    label: "Trạng thái kích hoạt",
    value: "withIsActive"
  },
]

export default function Filter(props) {
  const { setFilter, filter, onChangePage, listAuthor, user } = props
  const [form] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const inputDebounce = useDebounce(searchValue, 300);
  const [listFilter, setListFilter] = useState([])
  const [filterType, setFilterType] = useState("withIsActive")

  const isCTV = useMemo(() => {
    return orEmpty("role", user) === "COLLABORATOR"
  }, [user])


  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withIsActive",
      filterValue: null
    });

  }


  const handleVisibleChange = (visible) => {
    setFilterVisible(visible);
  };


  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value);
  };

  const handleCloseVisible = () => {
    setFilterType("withIsActive")
    setFilterVisible(false);
  };

  const onFilter = (filterType, filterValue) => {
    switch (filterType) {
      case "withIsActive":
        setFilter(prevState => ({
          ...prevState,
          isActive: filterValue,
        }))
        return;
      case "withAuthor":
        setFilter(prevState => ({
          ...prevState,
          author: filterValue,
        }))
        return;

      default:
        break;
    }
  }

  const checkListFilter = (filterType, filterValue) => {
    const arr = [...listFilter];
    const resultItem = listFilter.findIndex(item => item.value === filterType)
    if (resultItem === -1) {
      arr.push({
        value: filterType,
        label: Mocks.BLOGS.getLabelFilter(filterType, filterValue)
      })
      setListFilter(arr)
    } else {
      listFilter[resultItem].label = Mocks.BLOGS.getLabelFilter(filterType, filterValue)
      setListFilter(arr)
    }
    return (
      form.setFieldsValue({
        filterType: filterType,
        filterValue: filterValue
      }),
      onFilter(filterType, filterValue),
      onChangePage(1)
    );
  }

  const onFinish = (values) => {
    checkListFilter(values.filterType, values.filterValue)
    handleCloseVisible()
  }

  const onChangeTypeFilter = (e) => {
    setFilterType(e)
  }

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "withIsActive":
        return Mocks.BLOGS.ActiveStatus
      case "withAuthor":
        return listAuthor.map(item => ({ label: item.name, value: item.username }))
      default:
        break;
    }
  }

  useMemo(() => {
    if (filterType === "withIsActive") {
      form.setFieldsValue({
        filterType: "withIsActive",
        filterValue: null
      });
    } else if (filterType === "withAuthor") {
      form.setFieldsValue({
        filterType: "withAuthor",
        filterValue: null
      });
    }
  }, [filterType])

  function getFilterOptions() {
    if (isCTV) {
      return filterOptions
    } else {
      const optionFilterAuthor = [
        {
          label: "Người viết bài",
          value: "withAuthor"
        }
      ]
      return filterOptions.concat(optionFilterAuthor)
    }
  }


  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter(node => node.value != item.value))
    if (item.value === 'withIsActive') {
      delete filter.isActive;
      setFilter({ ...filter });
      onChangePage(1);
    }
    if (item.value === 'withAuthor') {
      delete filter.author;
      setFilter({ ...filter });
      onChangePage(1);
    }

  }


  const content = (
    <Form
      form={form}
      onFinish={onFinish}
    >
      <p>Hiển thị tất cả blog theo</p>
      <Form.Item
        name="filterType"
        style={{ marginBottom: 0 }}
      >
        <Selector onChange={onChangeTypeFilter} options={getFilterOptions()} />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      <Form.Item
        name="filterValue"
      >
        <Selector options={getOptionFilter(filterType)} placeholder="Lựa chọn điều kiện lọc" />
      </Form.Item>
      <Form.Item>
        <Button onClick={handleCloseVisible} style={{ marginRight: 10 }}>Huỷ</Button>
        <Button htmlType="submit" type="primary">Thêm điều kiện lọc</Button>
      </Form.Item>
    </Form>
  );

  // useMemo(() => {
  //   if (filterType === "withIsActive") {
  //     form.setFieldsValue({
  //       filterType: "withIsActive",
  //       filterValue: Mocks.BLOGS.ActiveStatus[0].value
  //     });
  //   }
  // }, [filterType])

  useMemo(() => {
    if (inputDebounce) {
      setFilter(prevState => ({
        ...prevState,
        s: searchValue
      }));
      onChangePage(1);
      return
    }
  }, [inputDebounce])


  useMemo(() => {
    if (searchValue === "" && filter.s) {
      delete filter.s;
      setFilter({ ...filter });
      onChangePage(1);
    }

  }, [searchValue, filter])


  useMemo(onSetupForm, []);


  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title={"Thêm điều kiện lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>
              Thêm điều kiện lọc
            </Button>
          </Popover>
        </Col>
        <Col span={18}>
          <Input
            value={searchValue}
            onChange={onChangeSearchValue}
            allowClear
            placeholder={
              "Tìm kiếm theo tên blog"
            }
          />
        </Col>
      </Row>
      <Row style={{ marginTop: 15 }} gutter={24}>
        <Col span={24}>
          {listFilter.map((item, index) => {
            return (
              <Tag key={index} closable onClose={(e) => handleRemoveFilter(e, item)}>
                {item.label}
              </Tag>
            )
          })}
        </Col>
      </Row>
    </div>
  );
}
