import { UploadSingle, UploadMultiple, Selector } from "components";
import { Card, Form as FormBase, Space } from "antd";
import { orArray, orEmpty, orNull } from 'utils/Selector';
import { useEffect, useState } from "react";

const { Item } = FormBase;

const templateDefault = [
    {
        label: "TIN TỨC",
        value: "NEWS"
    },
    {
        label: "VIDEO",
        value: "VIDEO"
    }
]

function Template(): JSX.Element {

    return (
        <Card
            title="Loại"
            className="wrapper"
        >
            <Item
                name="template"
                label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Loại:</span>}
                required
                rules={[
                    { required: true, message: 'Vui lòng chọn loại bài viết' }
                ]}>
                <Selector options={templateDefault} placeholder={"Chọn loại bài viết"} />
            </Item>
        </Card>
    );
};

export default Template;