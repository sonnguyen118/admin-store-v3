import { UploadSingle, UploadMultiple, Selector } from "components";
import { Card, Form as FormBase, Space } from "antd";
import { orArray, orEmpty, orNull } from 'utils/Selector';
import { useEffect, useState } from "react";

const { Item } = FormBase;

function Category(props): JSX.Element {
    const { form, categoryOptions, categories, item } = props;
    const [subCategoryOptions, setSubCategoryOptions] = useState([])

    const onChangeCategory = (value) => {
        const listSubCategory = categories.find(item => item.id === value)
        setSubCategoryOptions(orArray('subCategories', listSubCategory).map(
            (item) => ({ value: item.id, label: item.name })
        )
        )
        form.setFieldsValue({
            subCategory: null,
        });
    }

    useEffect(() => {
        if (orEmpty("category.id", item) && categories.length) {
            const listSubCategory = categories.find(category => category.id == orEmpty("category.id", item))
            setSubCategoryOptions(orArray('subCategories', listSubCategory).map(
                (item) => ({ value: item.id, label: item.name })
            )
            )
        }
    }, [orEmpty("category.id", item), categories])

    return (
        <Card
            title="Danh mục"
            className="wrapper"
        >
            <Item
                name="category"
                label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Danh mục:</span>}
                required
                rules={[
                    { required: true, message: 'Vui lòng chọn danh mục bài viết' }
                ]}>
                <Selector onChange={onChangeCategory} options={categoryOptions} placeholder={"Chọn danh mục bài viết"} />
            </Item>
            <Item
                name="subCategory"
                label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Danh mục con:</span>}
            >
                <Selector disabled={subCategoryOptions.length === 0} options={subCategoryOptions} placeholder={"Chọn danh mục bài viết"} />
            </Item>
        </Card>
    );
};

export default Category;