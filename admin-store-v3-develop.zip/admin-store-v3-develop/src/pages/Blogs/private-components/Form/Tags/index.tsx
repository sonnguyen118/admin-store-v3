import { Selector } from "components";
import { Card, Form as FormBase, notification } from "antd";
import { useState } from "react";
import { BlogTags as BlogTagsAPI } from "api";
import CreatableSelect from "react-select/creatable";

const { Item } = FormBase;

function Tags(props): JSX.Element {
    const { tags, setTags, form } = props;
    const [isLoadingTag, setIsLoadingTag] = useState(false)

    const formatCreateLabel = (inputValue) => `Thêm mới... ${inputValue}`;

    async function handleCreate(inputValue: any) {
        try {
            setIsLoadingTag(true)
            const params = {
                name: inputValue,
                isActive: true
            }
            const response = await BlogTagsAPI.createBlogTag(params);
            const { data, status } = response;
            if (status === 200) {
                const listTag = []
                setIsLoadingTag(false)
                const tag = {
                    value: data.data.id,
                    label: data.data.name,
                }
                listTag.push(tag)
                setTags(prevState => prevState.concat(listTag))
                form.setFieldsValue({
                    tags: form.getFieldsValue()['tags'].concat(listTag)
                });
                return;
            }
        } catch (error) {
            console.log(error);
            setIsLoadingTag(false)
            notification['error']({
                message: 'Không thể tạo tag mới',
                description:
                    'Có lỗi xảy ra trong quá trình tạo mới tag, vui lòng kiểm tra và thử lại!',
            });
        }
    };

    return (
        <Card
            title="Nhãn"
            className="wrapper"
        >
            <Item name="tags">
                <CreatableSelect
                    isClearable
                    options={tags}
                    isDisabled={isLoadingTag}
                    isLoading={isLoadingTag}
                    formatCreateLabel={formatCreateLabel}
                    onCreateOption={handleCreate}
                    isMulti
                    placeholder={'Chọn nhãn'}
                />
            </Item>
        </Card>
    );
};

export default Tags;