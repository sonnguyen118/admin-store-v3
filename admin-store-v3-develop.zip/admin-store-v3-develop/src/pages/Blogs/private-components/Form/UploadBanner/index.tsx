import React, { useState } from 'react';
import { Card, Form } from "antd";
import { UploadSingle } from "components";
const { Item } = Form;
function UploadBanner(props): JSX.Element {
    const { image, setImage } = props

    return (
        <Card title="Banner blog" className="space-thumb-wrapper">
            <Item
                name="banner"
            >
                <UploadSingle style={{ width: 240, height: 240 }} image={image} setImage={setImage} isUploadBanner />
            </Item>
        </Card>
    );
};

export default UploadBanner;