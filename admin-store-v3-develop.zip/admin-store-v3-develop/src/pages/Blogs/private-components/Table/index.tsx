import React, { useEffect, useState } from 'react';
import { Table as SimpleTable, Typography, Tag } from "antd";
import { orEmpty, orNumber } from 'utils/Selector';

const { Link } = Typography

export default function Table(props) {
    const { blogs, meta, onChangePage, onDeatailBlog } = props

    const [rows, setRows] = useState([]);
    const columns = [
        {
            title: "Hình ảnh",
            dataIndex: "featuredImage",
            render: (value, record) => (
                <Link onClick={(e) => onDeatailBlog(e, record.id)} href={`/blogs/update/${record.id}`}>
                    <img src={orEmpty("url", value) ? orEmpty("url", value) : "https://i.stack.imgur.com/y9DpT.jpg"} style={{ objectFit: "contain", width: 64, height: 64, borderRadius: 8 }} />
                </Link>

            ),
            width: 100,
        },
        {
            title: "Tên bài viết",
            dataIndex: "title",
            render: (value, record) => (
                <Link onClick={(e) => onDeatailBlog(e, record.id)} href={`/blogs/update/${record.id}`}>{value}</Link>
            ),
            width: 500
        },
        {
            title: "Danh mục",
            dataIndex: "category",
            render: (value) => (
                <Link href={`/blog-categories/update/${orEmpty("id", value)}`} target="_blank" rel="noopener">{orEmpty("name", value)}</Link>
            )
        },
        {
            title: "Người viết",
            dataIndex: "author",
            render: (value) => value
        },
        {
            title: "Trạng thái kích hoạt",
            dataIndex: "isActive",
            render: (value) => (value ? <Tag color="#108ee9">Đã kích hoạt</Tag> : <Tag>Chưa kích hoạt</Tag>)
        }
    ];

    function onUpdateData(): void {
        if (blogs) {
            const r = [] as any;

            blogs.forEach((node): void => {
                r.push({
                    key: node.id,
                    ...node
                });
            });
            setRows(r);
        }
    }

    function showTotal(total) {
        return `Tổng: ${total}`;
    }

    useEffect(onUpdateData, [blogs]);

    return (
        <SimpleTable
            columns={columns}
            dataSource={rows}
            pagination={{
                defaultPageSize: 15,
                defaultCurrent: orNumber("page", meta),
                current: orNumber("page", meta),
                total: orNumber("total", meta),
                onChange: onChangePage,
                showSizeChanger: false,
                showTotal: showTotal
            }} />
    );
}
