import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orArray, orBoolean, orNull } from "utils/Selector";
import createBlogReducer from "../../../Reducer";
import { useEffect, useMemo } from "react";
import { useHistory } from "react-router-dom";

function Create(props) {
  const { action, state, dispatch } = props
  const history = useHistory();

  function onCancelClick() {
    history.push("/blogs");
  }

  function onSearchSlug(slug) {
    action.createBlogReducer.slugCheck(
      { s: slug },
      dispatch.createBlogReducer
    );
  }

  function onSetup() {
    action.createBlogReducer.onGetListCategory(
      { isFull: true, isParent: true },
      dispatch.createBlogReducer
    );
    action.createBlogReducer.onGetListBlogTags(
      {},
      dispatch.createBlogReducer
    );
  }

  function onSave(body) {
    action.createBlogReducer.createBlog(
      body,
      dispatch.createBlogReducer
    );
  }

  function setSlugStatusToNull() {
    action.createBlogReducer.setSlugStatus(
      dispatch.createBlogReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean('createBlogReducer.isRedirect', state)) {
      onCancelClick()
    }
  }

  useEffect(() => {
    onSetup()
  }, []);
  useMemo(onRedirect, [orBoolean('createBlogReducer.isRedirect', state)])

  return <Form
    onSearchSlug={onSearchSlug}
    statusSlug={orNull("createBlogReducer.statusSlug", state)}
    categories={orArray("createBlogReducer.categories", state)}
    blogTags={orArray("createBlogReducer.blogTags", state)}
    onSave={onSave}
    onCancelClick={onCancelClick}
    setSlugStatusToNull={setSlugStatusToNull}
  />;
}

export default withReducer({
  key: "createBlogReducer",
  ...createBlogReducer
})(Create);
