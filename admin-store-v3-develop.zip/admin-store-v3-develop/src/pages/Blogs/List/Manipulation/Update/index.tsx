import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orArray, orBoolean, orEmpty, orNull } from "utils/Selector";
import updateBlogReducer from "../../../Reducer";
import { useEffect, useMemo } from "react";
import { useHistory, useParams } from "react-router-dom";

function Update(props) {
    const { action, state, dispatch } = props
    const history = useHistory();
    const params = useParams()

    function onSetup() {
        action.updateBlogReducer.detailBlog(
            orEmpty('id', params),
            dispatch.updateBlogReducer
        );
    }

    function onCancelClick() {
        history.push("/blogs");
    }

    function onSave(body) {
        const { id, ...ortherParams } = body
        action.updateBlogReducer.updateBlog(
            id,
            ortherParams,
            dispatch.updateBlogReducer
        );
    }

    const onRedirect = () => {
        if (orBoolean('updateBlogReducer.isRedirect', state)) {
            onCancelClick()
        }
    }

    function onGetListCategoryAndTags() {
        action.updateBlogReducer.onGetListCategory(
            { isFull: true, isParent: true },
            dispatch.updateBlogReducer
        );
        action.updateBlogReducer.onGetListBlogTags(
            {},
            dispatch.updateBlogReducer
        );
    }

    function onUpdateStatus(body) {
        action.updateBlogReducer.updateStatusBlogs(
            body,
            dispatch.updateBlogReducer
        );
    }


    useEffect(() => {
        onGetListCategoryAndTags()
    }, []);

    useMemo(onRedirect, [orBoolean('updateBlogReducer.isRedirect', state)])
    useMemo(onSetup, [orEmpty('id', params)])

    return <Form
        onUpdateStatus={onUpdateStatus}
        item={orNull("updateBlogReducer.detailBlog", state)}
        onSave={onSave}
        user={orNull("userReducer.user", state)}
        onCancelClick={onCancelClick}
        categories={orArray("updateBlogReducer.categories", state)}
        blogTags={orArray("updateBlogReducer.blogTags", state)}
    />;
}

export default withReducer({
    key: "updateBlogReducer",
    ...updateBlogReducer
})(Update);
