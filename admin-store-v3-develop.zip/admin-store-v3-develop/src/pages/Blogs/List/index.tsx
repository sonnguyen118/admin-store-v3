import React, { useState, useMemo, useEffect } from "react";
import Search from "../Search"
import blogsReducer from "../Reducer";
import { withReducer } from "hoc";
import queryString from "query-string";
import { useHistory } from "react-router-dom";
import { Table } from "../private-components";
import { orArray, orBoolean, orNull } from "utils/Selector";

function List(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: data.page ? parseInt(data.page as string) : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15
    }
  }, [history.location.search]);

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize,
    sort: "-createdAt"
  });

  function onGetListBlogs() {
    action.blogsReducer.getListBlogs(
      filter,
      dispatch.blogsReducer
    );
  }

  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "blogs",
        search: queryString.stringify({ ...query, page: query.page })
      })
      setFilter(prevState => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize
        }
      })
    }
  }, [query]);

  function onChangePage(page) {
    history.push({
      pathname: "blogs",
      search: queryString.stringify({ ...query, page })
    })
  }

  function onDeatailBlog(e, id) {
    e.preventDefault()
    history.push(`/blogs/update/${id}`)
  }

  function onGetListUser() {
    action.blogsReducer.listUser(
      {},
      dispatch.blogsReducer
    );
  }


  useMemo(() => {
    onGetListBlogs()
  }, [filter]);

  useMemo(() => {
    onGetListUser()
  }, []);


  useMemo(() => {
    if (orBoolean("blogsReducer.isRefresh", state)) {
      onGetListBlogs()
    }
  }, [orBoolean("blogsReducer.isRefresh", state)]);

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        onChangePage={onChangePage}
        listAuthor={orArray("blogsReducer.listUser", state)}
        user={orNull("userReducer.user", state)}
      />
      <Table
        blogs={orArray("blogsReducer.blogs", state)}
        meta={orNull("blogsReducer.blogsMeta", state)}
        onChangePage={onChangePage}
        onDeatailBlog={onDeatailBlog}
      />
    </div>
  );
}

export default withReducer({
  key: "blogsReducer",
  ...blogsReducer,
})(List);
