import {
    BlogCategories as BlogCategoriesAPI,
    Blogs as BlogsAPI,
    BlogTags as BlogTagsAPI
} from "api";
import { orArray, orBoolean, orNull } from "utils/Selector";
import {
    setListCategory,
    setListSubCategory,
    IncrementLoading,
    DecrementLoading,
    setListBlogs,
    setCheckSlug,
    setCreateBlog,
    setDetailBlog,
    setUpdateBlog,
    setListBlogTags,
    setUpdateStatusBlogs,
    setListUsers

} from "./action-type";

export const getListBlogs = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.getListProductBlogs(params);
        const { data, status } = response;
        if (status === 200) {
            const meta = {
                page: data.data.page,
                pageSize: data.data.pageSize,
                total: data.data.total,
            };
            const listBlogs = orArray("data.datas", data);
            return dispatch(
                setListBlogs({
                    blogs: listBlogs,
                    blogsMeta: meta,
                })
            );
        }
    } catch (error) {
        return dispatch(
            setListBlogs({
                blogs: [],
                blogsMeta: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const slugCheck = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.slugCheck(params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setCheckSlug({
                    statusSlug: orBoolean("data.status", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setCheckSlug({
                statusSlug: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const createBlog = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.createBlog(params);
        const { status } = response;
        if (status === 200) {
            return dispatch(
                setCreateBlog({
                    type: "success",
                    isRedirect: true,
                    message: "Tạo mới thành công"
                })
            )
        }
    } catch (error) {
        return dispatch(
            setCreateBlog({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const setSlugStatus = async (dispatch) => {
    return dispatch(
        setCheckSlug({
            statusSlug: null
        })
    )
};



export const detailBlog = async (id, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.detailBlog(id);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setDetailBlog({
                    detailBlog: data.data
                })
            )
        }
    } catch (error) {
        return dispatch(
            setDetailBlog({
                detailBlog: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const updateBlog = async (id, params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.updateBlog(id, params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setUpdateBlog({
                    type: "success",
                    message: "Cập nhật blog thành công",
                    updateBlog: orNull("data", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateBlog({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};


export const onGetListCategory = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.getListBlogCategories(params);
        const { data, status } = response;

        if (status === 200) {
            dispatch(
                setListCategory({
                    categories: data.data.datas
                })
            )
            dispatch(DecrementLoading);
            return;
        }
        dispatch(
            setListCategory({
                categories: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error"
            })
        )
        dispatch(DecrementLoading);
    } catch (error) {
        dispatch(
            setListCategory({
                categories: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error"
            })
        )
    }
    dispatch(DecrementLoading);
};

export const onGetListSubCategory = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.getListBlogCategories(params);
        const { data, status } = response;

        if (status === 200) {
            dispatch(
                setListSubCategory({
                    subCategories: data.data.datas
                })
            )
            dispatch(DecrementLoading);
            return;
        }
        dispatch(
            setListSubCategory({
                subCategories: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error"
            })
        )
        dispatch(DecrementLoading);
    } catch (error) {
        dispatch(
            setListSubCategory({
                subCategories: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error"
            })
        )
    }
    dispatch(DecrementLoading);
};

export const onGetListBlogTags = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogTagsAPI.getListBlogTags(params);
        const { data, status } = response;
        if (status === 200) {
            dispatch(
                setListBlogTags({
                    blogTags: data.data,
                })
            );
            return;
        }
    } catch (error) {
        dispatch(
            setListBlogTags({
                blogTags: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        dispatch(DecrementLoading);
    }

};

export const updateStatusBlogs = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.updateStatusBlog(params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setUpdateStatusBlogs({
                    type: "success",
                    message: "Cập nhật trạng thái thành công",
                    updateStatusBlog: orNull("data", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateStatusBlogs({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const listUser = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogsAPI.listUsers(params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setListUsers({
                    listUser: orArray("data", data)
                })
            );
        }
    } catch (error) {
        return dispatch(
            setListUsers({
                listUser: [],
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};
