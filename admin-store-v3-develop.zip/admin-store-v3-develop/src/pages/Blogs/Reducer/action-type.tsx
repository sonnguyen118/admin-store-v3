export const GET_LIST_CATEGORY = "blog/GET_LIST_CATEGORY";
export const GET_LIST_SUBCATEGORY = "blog/GET_LIST_SUBCATEGORY";
export const INCREMENT_LOADING = "blog/INCREMENT_LOADING";
export const DECREMENT_LOADING = "blog/DECREMENT_LOADING";
export const LIST_BLOGS = "blog/LIST_BLOGS";
export const LIST_BLOG_TAGS = "blog/LIST_BLOG_TAGS";
export const SLUG_CHECK = "blog/SLUG_CHECK";
export const CREATE_BLOG = "blog/CREATE_BLOG";
export const DETAIL_BLOG = "blog/DETAIL_BLOG";
export const UPDATE_BLOG = "blog/UPDATE_BLOG";
export const UPDATE_STATUS_BLOGS = "blog/UPDATE_STATUS_BLOGS";
export const LIST_USER = "blog/LIST_USER";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListBlogs = payload => {
  return {
    payload,
    type: LIST_BLOGS
  };
};

export const setCheckSlug = payload => {
  return {
    payload,
    type: SLUG_CHECK
  };
};

export const setCreateBlog = payload => {
  return {
    payload,
    type: CREATE_BLOG
  };
};

export const setDetailBlog = payload => {
  return {
    payload,
    type: DETAIL_BLOG
  };
};

export const setUpdateBlog = payload => {
  return {
    payload,
    type: UPDATE_BLOG
  };
};

export const setUpdateStatusBlogs = payload => {
  return {
    payload,
    type: UPDATE_STATUS_BLOGS
  };
};


export const setListCategory = payload => {
  return {
    payload,
    type: GET_LIST_CATEGORY
  };
};

export const setListSubCategory = payload => {
  return {
    payload,
    type: GET_LIST_SUBCATEGORY
  };
};

export const setListBlogTags = payload => {
  return {
    payload,
    type: LIST_BLOG_TAGS
  };
};

export const setListUsers = payload => {
  return {
    payload,
    type: LIST_USER
  };
};



