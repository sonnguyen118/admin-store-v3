import * as action from "./action";
import {
  GET_LIST_CATEGORY,
  GET_LIST_SUBCATEGORY,
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  LIST_BLOGS,
  SLUG_CHECK,
  CREATE_BLOG,
  DETAIL_BLOG,
  UPDATE_BLOG,
  UPDATE_STATUS_BLOGS,
  LIST_BLOG_TAGS,
  LIST_USER
} from "./action-type";

const initialState = ({
  isLoading: false,
  counter: 0,
  statusSlug: null,
});

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null
      };
    case LIST_BLOGS:
      return {
        ...state,
        ...action.payload,
      };
    case SLUG_CHECK:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_BLOG:
      return {
        ...state,
        ...action.payload,
      };
    case DETAIL_BLOG:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_CATEGORY:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_SUBCATEGORY:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_BLOG:
      const { updateBlog } = action.payload
      delete action.payload.detailBlog;
      return {
        ...state,
        ...action.payload,
        detailBlog: updateBlog
      };
    case UPDATE_STATUS_BLOGS:
      const { updateStatusBlog } = action.payload
      delete action.payload.detailBlog;
      return {
        ...state,
        ...action.payload,
        detailBlog: updateStatusBlog
      };

    case LIST_BLOG_TAGS:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_USER:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer
};
