import { SimpleTabs } from "../../components";
import { Typography, Row, Col, Button } from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List"
import { useHistory } from "react-router-dom";

const { Title } = Typography;

export default function Blogs() {
  const history = useHistory()

  const tabItems = [
    {
      title: "Tất cả bài viết",
      component: <List />
    }
  ];

  function onCreateBlog() {
    history.push("/blogs/create");
  }



  return (
    <div>
      <Row>
        <Col span={8}>
          <Title level={2}>Quản lý bài viết</Title>
        </Col>
        <Col span={8} offset={8}>
          <Row>
            <Col span={10} offset={14}
            >
              <Button onClick={onCreateBlog} type="primary" icon={<PlusCircleOutlined />}>
                Tạo mới bài viết
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
      <SimpleTabs tabItems={tabItems} />
    </div>
  );
}
