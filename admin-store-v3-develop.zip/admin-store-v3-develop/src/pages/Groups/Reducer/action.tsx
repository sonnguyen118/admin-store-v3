import {
  GroupProducts as GroupProductsAPI
} from "api";
import {
  IncrementLoading,
  DecrementLoading,
  setListGroupProduct,
  setCheckSlugGroupProduct,
  setCreateGroupProduct,
  setDetailGroupProduct,
  setUpdateGroupProduct,
  setListProductGroup,
  onActionItemProductGroup
} from "./action-type";

export const onGetListGroupProduct = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.getListGroupProduct(params);
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      }
      dispatch(
        setListGroupProduct({
          groupProducts: data.data.datas,
          groupProductsMeta: meta
        })
      )
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListGroupProduct({
        groupProducts: [],
        groupProductsMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const slugCheck = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.slugCheck(body);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setCheckSlugGroupProduct({
          statusSlug: data.data.status
        })
      )
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setCheckSlugGroupProduct({
        statusSlug: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createGroupProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.onCreateGroupProduct(body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        setCreateGroupProduct({
          type: "success",
          isRedirect: true,
          message: "Tạo mới thành công"
        })
      )
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setCreateGroupProduct({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const detailGroupProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.getDetailGroupProduct(body);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setDetailGroupProduct({
          detailGroupProduct: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setDetailGroupProduct({
        detailGroupProduct: {},
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateGroupProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.updateGroupProduct(body);
    const { status, data } = response;

    if (status === 200) {
      dispatch(
        setUpdateGroupProduct({
          type: "success",
          isRefresh: false,
          message: "Cập nhật thành công"
        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        setDetailGroupProduct({
          detailGroupProduct: data.data
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateGroupProduct({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getListProductGroup = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.getListProductGroup(body);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setListProductGroup({
          listProductGroup: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListProductGroup({
        listProductGroup: {},
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const actionItemProductGroup = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await GroupProductsAPI.actionItemProductGroup(id, body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        onActionItemProductGroup({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công"
        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        onActionItemProductGroup({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      onActionItemProductGroup({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

