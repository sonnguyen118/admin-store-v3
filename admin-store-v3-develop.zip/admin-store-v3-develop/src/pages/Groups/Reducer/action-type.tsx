export const INCREMENT_LOADING = "groupProducts/INCREMENT_LOADING";
export const DECREMENT_LOADING = "groupProducts/DECREMENT_LOADING";
export const GET_LIST_GROUP_PRODUCT = "groupProducts/GET_LIST_GROUP_PRODUCT";
export const SLUG_CHECK = "groupProducts/SLUG_CHECK";
export const ON_CREATE_GROUP_PRODUCT = "groupProducts/ON_CREATE_GROUP_PRODUCT";
export const GET_DETAIL_GROUP_PRODUCT = "groupProducts/GET_DETAIL_GROUP_PRODUCT";
export const ON_UPDATE_GROUP_PRODUCT = "groupProducts/ON_UPDATE_GROUP_PRODUCT";
export const GET_LIST_PRODUCT_GROUP = "groupProducts/GET_LIST_PRODUCT_GROUP";
export const ACTION_ITEM_PRODUCT_GROUP = "groupProducts/ACTION_ITEM_PRODUCT_GROUP";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListGroupProduct = payload => {
  return {
    payload,
    type: GET_LIST_GROUP_PRODUCT
  };
};

export const setCheckSlugGroupProduct = payload => {
  return {
    payload,
    type: SLUG_CHECK
  };
};

export const setCreateGroupProduct = payload => {
  return {
    payload,
    type: ON_CREATE_GROUP_PRODUCT
  };
};

export const setDetailGroupProduct = payload => {
  return {
    payload,
    type: GET_DETAIL_GROUP_PRODUCT
  };
};

export const setUpdateGroupProduct = payload => {
  return {
    payload,
    type: ON_UPDATE_GROUP_PRODUCT
  };
};

export const setListProductGroup = payload => {
  return {
    payload,
    type: GET_LIST_PRODUCT_GROUP
  };
};

export const onActionItemProductGroup = payload => {
  return {
    payload,
    type: ACTION_ITEM_PRODUCT_GROUP
  };
};








