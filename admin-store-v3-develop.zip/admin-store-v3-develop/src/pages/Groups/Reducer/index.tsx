import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  SLUG_CHECK,
  GET_LIST_GROUP_PRODUCT,
  ON_CREATE_GROUP_PRODUCT,
  GET_DETAIL_GROUP_PRODUCT,
  ON_UPDATE_GROUP_PRODUCT,
  GET_LIST_PRODUCT_GROUP,
  ACTION_ITEM_PRODUCT_GROUP
} from "./action-type";

const initialState = ({
  isLoading: false,
  counter: 0,
  groupProducts: [],
  groupProductMeta: null,
  statusSlug: null,
  detailGroupProduct: null,
  listProductGroup: [],
});

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null
      };
    case GET_LIST_GROUP_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case SLUG_CHECK:
      return {
        ...state,
        ...action.payload,
      };
    case ON_CREATE_GROUP_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case GET_DETAIL_GROUP_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case ON_UPDATE_GROUP_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_PRODUCT_GROUP:
      return {
        ...state,
        ...action.payload,
      };
    case ACTION_ITEM_PRODUCT_GROUP:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};



export default {
  action,
  initialState,
  reducer
};
