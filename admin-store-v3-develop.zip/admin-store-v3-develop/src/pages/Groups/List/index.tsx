import React, { useState, useEffect, useMemo } from "react";
import { Table, Tag } from "antd";
import Search from "../Search"
import groupProductReducer from "../Reducer";
import { withReducer } from "hoc";
import { orArray, orNumber } from "utils/Selector";
import { useHistory } from "react-router-dom";
import queryString from "query-string";

function List(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: data.page ? parseInt(data.page as string) : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15
    }
  }, [history.location.search]);

  const [selectedListRow, setSelectedListRow] = useState([]);
  const [rows, setRows] = useState([]);
  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize
  });

  useEffect(() => {
    action.groupProductReducer.onGetListGroupProduct(
      filter,
      dispatch.groupProductReducer
    );
  }, [filter]);

  useEffect(() => {
    if (query.page !== filter.page || query.pageSize !== filter.pageSize) {
      setFilter(prevState => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize
        }
      })
    }
  }, [query]);

  function onChangePage(page) {
    history.push({
      pathname: "product-groups",
      search: queryString.stringify({ ...query, page })
    })
  }

  function onDetailProductGroup(e, id): any {
    e.preventDefault();
    history.push(`/product-groups/update/${id}`)
  }

  const columns = [
    {
      title: "Tên nhóm sản phẩm",
      dataIndex: "name",
      render: (value, record) =>
        <div>
          <a onClick={(e) => onDetailProductGroup(e, record.id)} rel="noreferrer" href={`/product-groups/update/${record.id}`} style={{ cursor: "pointer", fontWeight: "bold", display: 'block' }}>{value}</a>
          <span style={{ fontSize: 12, color: "grey" }}>{record.totalProduct} sản phẩm</span>
        </div>
    },
    {
      title: "Loại nhóm",
      dataIndex: "type"
    },
    {
      title: "Hiển thị",
      dataIndex: "pageId"
    },
    {
      title: "Sản phẩm",
      dataIndex: "totalProduct",
      render: (_, record) =>
        <div>
          <a
            href={`/product-groups/${record.id}/products`}
            target="_blank"
            style={{ cursor: "pointer", marginLeft: 3 }}
          >
            Danh sách sản phẩm
          </a>
        </div>
    },
    {
      title: "Trạng thái",
      dataIndex: "isActive",
      render: (value) => (value ? <Tag color="#108ee9">Kích hoạt</Tag> : <Tag>Chưa kích hoạt</Tag>)
    }
  ];

  function onUpdateData(): void {
    const listGroupProduct = orArray('groupProductReducer.groupProducts', state)
    if (listGroupProduct) {
      const r = [] as any;

      listGroupProduct.forEach((node, index): void => {
        r.push({
          key: index,
          id: node.id,
          name: node.name,
          type: node.groupType,
          totalProduct: node.totalProduct,
          isActive: node.isActive,
          pageId: node.pageId === "HOME_PAGE" ? "Trang chủ" : node.pageId === "NONE" ? "Tuỳ chọn" : "Chưa xác định"
        });
      });

      setRows(r);
    }
  }

  function showTotal(total) {
    return `Tổng: ${total}`;
  }

  useEffect(onUpdateData, [orArray('groupProductReducer.groupProducts', state)]);

  return (
    <div>
      <Search filter={filter} onChangePage={onChangePage} setFilter={setFilter} />
      <Table
        columns={columns}
        dataSource={rows}
        pagination={{
          defaultPageSize: filter.pageSize,
          defaultCurrent: filter.page,
          current: filter.page,
          total: orNumber('groupProductReducer.groupProductsMeta.total', state),
          onChange: onChangePage,
          showSizeChanger: false,
          showTotal: showTotal
        }}
      />
    </div>
  );
}

export default withReducer({
  key: "groupProductReducer",
  ...groupProductReducer
})(List);
