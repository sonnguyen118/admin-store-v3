import React, { useEffect } from 'react';
import { Form } from "../../../private-components"
import { useHistory } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean } from "utils/Selector";
import groupProductReducer from "../../../Reducer";

function Create(props) {
  const { dispatch, action, state } = props
  const history = useHistory();
  

  function onCancelClick() {
    history.push("/product-groups");
  }

  function onCreateGroup(body) {
    action.createGroupProductReducer.createGroupProduct(
      body,
      dispatch.createGroupProductReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean('createGroupProductReducer.isRedirect', state)) {
      onCancelClick()
    }
  }

  useEffect(onRedirect, [orBoolean('createGroupProductReducer.isRedirect', state)])

  return (
    <Form item={null} onCancelClick={onCancelClick} onSave={onCreateGroup}/>
  );                 
}

export default withReducer({
  key: "createGroupProductReducer",
  ...groupProductReducer
})(Create);
