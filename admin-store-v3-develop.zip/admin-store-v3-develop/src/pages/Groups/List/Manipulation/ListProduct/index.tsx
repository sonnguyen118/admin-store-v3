import { useHistory, useParams } from "react-router-dom";
import groupProductReducer from "../../../Reducer";
import { withReducer } from "hoc";
import React, { useEffect, useState } from "react";
import { orBoolean, orEmpty, orArray } from "utils/Selector";
import {
    Row,
    Col,
    Input,
    Button,
    Popconfirm,
    Typography,
    Divider,
    Table,
    Avatar, Tag,
} from 'antd';
import { PlusCircleOutlined } from "@ant-design/icons";
import { ChooseProductsTable } from 'components';
import useDebounce from "hook/useDebounce"
import helpers from "utils/Helpers";

const { Title } = Typography;

function ListProduct(props) {
    const { dispatch, action, state, isHeader = true } = props
    const history = useHistory();
    const params = useParams()
    const [searchValue, setSearchValue] = useState("")
    const [cacheDataTable, setCacheDataTable] = useState([])
    const [dataTable, setDataTable] = useState([])
    const [chooseProduct, setChooseProduct] = useState({
        status: false,
        data: []
    })
    const [selectProducts, setSelectProducts] = useState({
        selectedKeys: [],
        selectedDatas: []
    })
    const inputDebounce = useDebounce(searchValue, 300)


    useEffect(() => {
        if (inputDebounce) {
            setDataTable(cacheDataTable.filter((item) => item.name.toLowerCase().includes(searchValue.toLowerCase().trim())))
            return
        }
    }, [inputDebounce])

    useEffect(() => {
        if (searchValue === "") {
            setDataTable(cacheDataTable)
        }
    }, [searchValue])


    function onSetup() {
        action.listProductGroupReducer.getListProductGroup(
            orEmpty('id', params),
            dispatch.listProductGroupReducer
        );
        action.listProductGroupReducer.detailGroupProduct(
            orEmpty('id', params),
            dispatch.listProductGroupReducer
        );
    }

    const onChangeSearchValue = (e) => {
        setSearchValue(e.target.value)
    }

    function onCancelClick() {
        history.goBack();
    }

    const columns = [
        {
            title: '',
            dataIndex: 'image',
            key: 'image',
            render: value => {
                return (
                    <Avatar style={{ marginRight: 10 }} shape="square" size={48} src={value} />
                )
            },
            width: "5%"
        },
        {
            title: 'Tên Sản phẩm',
            dataIndex: 'name',
            key: 'name',
            render(value, record) {
                return {
                    props: {
                        style: { padding: "3px", }
                    },
                    children: (
                        <div onClick={() => history.push(`/products/update/${record.id}`)} style={{ cursor: "pointer", display: "flex", alignItems: "center" }}>
                            <a style={{ fontWeight: "bold" }} href={"#"}>{value}</a>
                        </div>
                    )
                };
            },
            fixed: true
        },
        {
            title: 'Danh mục',
            dataIndex: 'category',
            key: 'category',
            width: '15%',
        },
        {
            title: "Trạng thái",
            dataIndex: "isActive",
            render: (value) => (value ? <Tag color="#108ee9">Hiển thị</Tag> : <Tag>Tạm khóa</Tag>),
            width: "5%"
        }
    ]

    const onUpdateData = () => {
        const listProduct = orArray('listProductGroupReducer.listProductGroup', state)
        if (listProduct) {
            const result = listProduct.map((item, index) => ({
                key: `${orEmpty("product.id", item)}--${index}`,
                id: orEmpty("product.id", item),
                name: orEmpty("product.name", item),
                image: orEmpty("product.featuredImage.url", item),
                price: orEmpty("product.staticPrice.minPrice", item) === orEmpty("product.staticPrice.maxPrice", item)
                    ? helpers.currencyFormatVND(orEmpty("product.staticPrice.maxPrice", item))
                    : `${helpers.currencyFormatVND(orEmpty("product.staticPrice.minPrice", item))} - ${helpers.currencyFormatVND(orEmpty("product.staticPrice.maxPrice", item))}`,
                category: orEmpty("product.category.name", item),
                isActive: orEmpty("product.isActive", item),
            }))
            setDataTable(result)
            setCacheDataTable(result)
        }
    }

    const rowSelection = {
        selectedRowKeys: selectProducts.selectedKeys,
        onChange: (selectedkeys, selectedRows) => {
            setSelectProducts({
                selectedKeys: selectedkeys,
                selectedDatas: selectedRows
            })
        },
    };

    function onDeleteItems() {
        const listProduct = selectProducts.selectedDatas.map((item) => (
            item.id
        ))
        const body = {
            action: "DELETE",
            payloads: listProduct
        }
        action.listProductGroupReducer.actionItemProductGroup(
            orEmpty('id', params),
            body,
            dispatch.listProductGroupReducer
        );
    }

    const onRefresh = () => {
        if (orBoolean('listProductGroupReducer.isRefresh', state)) {
            onSetup()
            setSelectProducts({
                selectedKeys: [],
                selectedDatas: []
            })
        }
    }

    function handleConfirmChooseProduct(datas) {
        const listProduct = datas.map((item) => (
            item.id
        ))
        const body = {
            action: "ADD",
            payloads: listProduct
        }
        action.listProductGroupReducer.actionItemProductGroup(
            orEmpty('id', params),
            body,
            dispatch.listProductGroupReducer
        );
        setChooseProduct({
            status: false,
            data: []
        })
    }

    const TableComponent = React.useCallback(() => {
        return (
            <Table
                className="product-table-wrapper"
                columns={columns}
                rowKey="key"
                rowSelection={{ ...rowSelection, checkStrictly: false }}
                dataSource={dataTable}
            />
        )
    }, [dataTable, selectProducts])

    useEffect(onRefresh, [orBoolean('listProductGroupReducer.isRefresh', state)])
    useEffect(onSetup, [params])
    useEffect(onUpdateData, [orArray('listProductGroupReducer.listProductGroup', state)])

    return (
        <div style={{ backgroundColor: "#fff", padding: 15 }} className="search-wrapper">
            {isHeader ?
                <Row gutter={24}>
                    <Col span={20}>
                        <Title style={{ marginBottom: 0 }} level={2}>
                            {orEmpty("listProductGroupReducer.detailGroupProduct.name", state)} ({dataTable.length} sản phẩm)
                        </Title>
                    </Col>
                    <Col
                        style={{
                            display: "flex",
                            justifyContent: "flex-end",
                            alignItems: "center"
                        }}
                        span={4}
                    >
                        <Button onClick={onCancelClick} className="btn">
                            Quay lại
                        </Button>
                    </Col>
                </Row>
                : null}

            <Divider />
            <Row gutter={24}>
                <Col span={14}>
                    Hành động:
                    <Popconfirm
                        placement="bottom"
                        title={`Bạn chắc chắn muốn xoá ${selectProducts.selectedDatas.length} sản phẩm`}
                        onConfirm={onDeleteItems}
                        okText="Xác nhận"
                        cancelText="Hủy"
                    >
                        <Button
                            disabled={selectProducts.selectedDatas.length ? false : true}
                            style={{ marginLeft: 10 }}
                            type="primary"
                        >
                            Xoá {selectProducts.selectedDatas.length} sản phẩm
                        </Button>
                    </Popconfirm>
                    <Button
                        style={{ marginLeft: 10 }}
                        type="primary"
                        icon={<PlusCircleOutlined />}
                        onClick={() => setChooseProduct(prevState => ({ ...prevState, status: true }))}
                    >
                        Thêm sản phẩm
                    </Button>
                </Col>
                <Col
                    style={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center"
                    }}
                    span={10}
                >
                    <Input value={searchValue} onChange={onChangeSearchValue} allowClear placeholder="Tìm kiếm theo tên sản phẩm ..." />
                </Col>
            </Row>
            <Divider />
            <Row gutter={24}>
                <Col span={24}>
                    <TableComponent />
                </Col>
            </Row>
            {chooseProduct.status ?
                <ChooseProductsTable
                    visible={chooseProduct.status}
                    listItemChoose={chooseProduct.data}
                    itemDisable={orArray('listProductGroupReducer.listProductGroup', state)}
                    handleCancel={() => setChooseProduct(prevState => ({ ...prevState, status: false }))}
                    allowInactive={true}
                    handleConfirm={handleConfirmChooseProduct}
                    isGroupProduct={true}
                />
                : null}
        </div>
    );
}

export default withReducer({
    key: "listProductGroupReducer",
    ...groupProductReducer
})(ListProduct);