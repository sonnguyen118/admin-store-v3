import { Form } from "../../../private-components"
import { useHistory, useParams } from "react-router-dom";
import groupProductReducer from "../../../Reducer";
import { withReducer } from "hoc";
import { useEffect } from "react";
import { orBoolean, orEmpty, orNull } from "utils/Selector";

function Update(props) {
    const { dispatch, action, state } = props
    const history = useHistory();
    const params = useParams()

    function onSetup() {
        action.updateGroupProductReducer.detailGroupProduct(
            orEmpty('id', params),
            dispatch.updateGroupProductReducer
        );
    }

    function onCancelClick() {
        history.goBack();
    };

    function onSave(body) {
        action.updateGroupProductReducer.updateGroupProduct(
            body,
            dispatch.updateGroupProductReducer
        );
    }

    const onRefresh = () => {
        if (orBoolean('updateGroupProductReducer.isRefresh', state)) {
            onSetup()
        }
      }
    
    useEffect(onRefresh, [orBoolean('updateGroupProductReducer.isRefresh', state)])
    useEffect(onSetup, [params])

    return <Form 
                item={orNull("updateGroupProductReducer.detailGroupProduct",state)}
                onCancelClick={onCancelClick} 
                onSave={onSave} 
            />;
}

export default withReducer({
    key: "updateGroupProductReducer",
    ...groupProductReducer
})(Update);
