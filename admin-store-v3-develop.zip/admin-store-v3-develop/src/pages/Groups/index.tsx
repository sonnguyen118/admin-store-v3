import { SimpleTabs } from "../../components";
import { Button, PageHeader} from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List"
import { useHistory } from "react-router-dom";

export default function Groups() {
  const history = useHistory()

  const tabItems = [
    {
      title: "Tất cả nhóm sản phẩm",
      component: <List/>
    }
  ];


  function onCreateClick(){
    history.push("/product-groups/create");
  }

  return (
    <div>
      <PageHeader
          style={{padding: 0}}
          ghost={true}
          title="Nhóm sản phẩm"
          extra={[
            <Button onClick={onCreateClick} type="primary" icon={<PlusCircleOutlined />}>
              Tạo nhóm sản phẩm
            </Button>
          ]}
      />
      <SimpleTabs tabItems={tabItems} />
    </div>
  );
}
