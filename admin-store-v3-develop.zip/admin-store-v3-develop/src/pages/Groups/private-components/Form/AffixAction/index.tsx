import React, { useState } from 'react';
import {
  Typography,
  Affix,
  Row,
  Col,
  Button,
  Form as FormBase,
  Popconfirm
} from "antd";

const { Title } = Typography;
const { Item } = FormBase;

function AffixAction(props): JSX.Element {
  const { onCancelClick, id, isActive , onClickActive} = props
  const [isShow, setIsShow] = useState(false);

  function onChangeAffix(affixed) {
    setIsShow(affixed);
  }

  return (
    <Affix offsetTop={0} onChange={onChangeAffix}>
      <Row style={{ padding: "0 15px" }} className="actions">
        <Col span={12}>
          {isShow 
            ?
              <Title style={{ marginBottom: 0 }} level={2}>{id ? "Cập nhật nhóm sản phẩm" : "Tạo mới chưa được lưu"} </Title> 
            : 
              <Title style={{ marginBottom: 0 }} level={2}>{id ? "Cập nhật nhóm sản phẩm" : "Tạo nhóm sản phẩm"}</Title>
          }
        </Col>
        <Col style={{ display: "flex", alignItems:"center" }} span={8} offset={4} className="action-right">
          {id
            ?
            <Popconfirm placement="bottom" title={isActive ? "Bạn chắc chắn muốn hủy kích Hoạt" : "Bạn chắc chắn muốn kích hoạt"} onConfirm={() => onClickActive(isActive)} okText="Xác nhận" cancelText="Hủy">
              <Button
                className="btn"
                type="primary"
                style={{ marginRight: 10 }}
              >
                {isActive ? "Hủy kích Hoạt" : "Kích hoạt"}
              </Button>
            </Popconfirm>
            :
          null}
          <Button style={{ marginRight: 10 }} onClick={onCancelClick} className="btn">
            Hủy
          </Button>
          <Item style={{ display: "flex", alignItems:"center", marginBottom: 0 }}>
            <Button
              htmlType="submit"
              className="btn"
              type="primary"
            >
              Lưu
            </Button>
          </Item>
        </Col>
      </Row>
    </Affix>
  );
};

export default AffixAction;