import React, { useState, useEffect } from "react";
import "./styled.scss";
import AffixAction from "./AffixAction";
import {
  Button,
  Card,
  Col,
  Form as FormBase,
  Input,
  Row,
  Space,
  message,
  Avatar,
  Table,
  notification,
} from "antd";
import { CloseOutlined } from "@ant-design/icons";
import {
  UploadSingle,
  ChooseProductsTable,
  CheckSlug,
  Selector,
  Editor,
} from "components";
import env from "configs/env";
import { Helpers } from "utils";
import OptimalSEO from "./OptimalSEO";
import { withReducer } from "hoc";
import groupProductReducer from "../../Reducer";
import { orBoolean, orDefaultValue, orEmpty, orNull } from "utils/Selector";
import { Mocks } from "utils";
import ListProduct from "../../List/Manipulation/ListProduct";

const { Item } = FormBase;

function Form(props) {
  const { item, onCancelClick, dispatch, action, state, onSave } = props;
  const [form] = FormBase.useForm();
  const [image, setImage] = useState(null);
  const [slug, setSlug] = useState("");
  const [chooseProduct, setChooseProduct] = useState({
    status: false,
    data: [],
  });
  const [isFinish, setIsFinish] = useState({
    status: false,
    data: {},
  });

  function onSetupForm() {
    if (item) {
      setSlug(orEmpty("slug", item));
      setImage(orEmpty("icon", item));
      form.setFieldsValue({
        name: orEmpty("name", item),
        slug: orEmpty("slug", item),
        description: orEmpty("description", item),
        content: orEmpty("content", item),
        url: orEmpty("icon.url", item),
        pageSEO_title: orEmpty("pageSEO.title", item),
        pageSEO_keywords: orEmpty("pageSEO.keywords", item),
        pageSEO_description: orEmpty("pageSEO.description", item),
        groupType: orDefaultValue(orEmpty("groupType", item), "SLIDE"),
        placementId: orDefaultValue(orEmpty("placementId", item), 0),
        pageId: orDefaultValue(orEmpty("pageId", item), "NONE"),
      });
      return;
    }
    form.setFieldsValue({
      groupType: "SLIDE",
      placementId: 0,
      pageId: "NONE",
    });
  }

  useEffect(() => {
    onSetupForm();
  }, [item]);

  function onFinish(values) {
    setIsFinish({
      status: true,
      data: values,
    });
    if (orNull("id", item)) {
      if (
        !values.pageSEO_title &&
        !values.pageSEO_keywords &&
        !values.pageSEO_description
      ) {
        const newValues = {
          ...values,
          id: orEmpty("id", item),
          pageSEO_title: orEmpty("pageSEO.title", item),
          pageSEO_keywords: orEmpty("pageSEO.keywords", item),
          pageSEO_description: orEmpty("pageSEO.description", item),
          slug: orEmpty("slug", item),
        };
        onSave(Mocks.GROUP_PRODUCT.getBodyGroupProduct({ ...newValues }));
        return;
      }
      onSave(
        Mocks.GROUP_PRODUCT.getBodyGroupProduct({
          ...values,
          id: orEmpty("id", item),
          slug: orEmpty("slug", item),
        })
      );
      return;
    }
    if (orNull("groupProductReducer.statusSlug", state) != null) {
      if (orBoolean("groupProductReducer.statusSlug", state)) {
        onSave(Mocks.GROUP_PRODUCT.getBodyGroupProduct(values));
      } else {
        notification["warning"]({
          message: "Không thể tạo mới nhóm sản phẩm",
          description:
            "Lỗi đường dẫn nhóm sản phẩm đã tồn tại, vui lòng kiểm tra và thử lại!",
        });
      }
      return;
    }
    onSearchSlug();
  }

  useEffect(() => {
    if (orNull("groupProductReducer.statusSlug", state) != null) {
      if (
        isFinish.status &&
        orBoolean("groupProductReducer.statusSlug", state)
      ) {
        onSave(Mocks.GROUP_PRODUCT.getBodyGroupProduct(isFinish.data));
      } else if (
        isFinish.status &&
        !orBoolean("groupProductReducer.statusSlug", state)
      ) {
        notification["warning"]({
          message: "Không thể tạo mới nhóm sản phẩm",
          description:
            "Lỗi đường dẫn nhóm sản phẩm đã tồn tại, vui lòng kiểm tra và thử lại!",
        });
      }
      return;
    }
  }, [orNull("groupProductReducer.statusSlug", state)]);

  function onFinishFailed() {
    notification["warning"]({
      message: "Không thể tạo mới nhóm sản phẩm",
      description:
        "Lỗi do chưa cập nhật đủ thông tin, vui lòng kiểm tra và thử lại!",
    });
  }

  function onChangeSlug(e) {
    form.setFieldsValue({
      pageSEO_title: e.target.value,
    });
    if (!orNull("id", item)) {
      setSlug(Helpers.getSlug(e.target.value));
      setIsFinish((prevState) => ({
        ...prevState,
        status: false,
      }));
      form.setFieldsValue({
        slug: Helpers.getSlug(e.target.value),
      });
      return;
    }
  }

  function onChangeDescription(e) {
    form.setFieldsValue({
      pageSEO_description: e.target.value,
    });
  }

  function onSearchSlug() {
    if (!orNull("id", item) && slug != "") {
      action.groupProductReducer.slugCheck(
        { s: slug },
        dispatch.groupProductReducer
      );
      return;
    }
    message.warning("Vui lòng nhập tên sản phẩm hoặc đường dẫn để kiểm tra");
    return;
  }

  useEffect(() => {
    if (slug && orBoolean("groupProductReducer.statusSlug", state)) {
      form.setFieldsValue({
        slug: slug,
      });
    }
  }, [slug, orBoolean("groupProductReducer.statusSlug", state)]);

  useEffect(() => {
    if (image) {
      form.setFieldsValue({
        url: image.url,
      });
    }
  }, [image]);

  useEffect(() => {
    if (chooseProduct.data) {
      const productDatas = chooseProduct.data.map((item) => ({
        product: item.id,
      }));
      form.setFieldsValue({
        products: productDatas,
      });
    }
  }, [chooseProduct.data]);

  function onClickActive(isActive) {
    if (item) {
      const body = {
        id: orNull("id", item),
        isActive: !isActive,
      };
      onSave(body);
    }
  }

  function headerActions() {
    return (
      <AffixAction
        onCancelClick={onCancelClick}
        id={orNull("id", item)}
        isActive={orBoolean("isActive", item)}
        onClickActive={onClickActive}
      />
    );
  }

  function renderInfoGeneral() {
    return (
      <Card title="Thông tin chung" className="space-general-wrapper">
        <Item
          name="name"
          label={
            <span style={{ color: "#6c798f", fontWeight: "bold" }}>
              Tên nhóm sản phẩm:
            </span>
          }
          rules={[
            { required: true, message: "Vui lòng nhập tên nhóm sản phẩm" },
          ]}
          required
        >
          <Input onChange={onChangeSlug} placeholder="Nhập tên nhóm sản phẩm" />
        </Item>
        <CheckSlug
          slug={slug}
          onChangeSlug={onChangeSlug}
          onSearchSlug={onSearchSlug}
          addonSlug={`${env.base_url}/nhom-san-pham`}
          statusSlug={orNull("groupProductReducer.statusSlug", state)}
          idItem={orNull("id", item)}
          isActive={orNull("isActive", item)}
        />
        <Item
          name="description"
          label={
            <span style={{ color: "#6c798f", fontWeight: "bold" }}>
              Mô tả nhóm sản phẩm:
            </span>
          }
        >
          <Input.TextArea
            onChange={onChangeDescription}
            rows={7}
            placeholder="Mô tả nhóm sản phẩm"
          />
        </Item>
        <Item
          name="content"
          label={
            <span style={{ color: "#6c798f", fontWeight: "bold" }}>
              Mô tả chi tiết:
            </span>
          }
        >
          <Editor />
        </Item>
      </Card>
    );
  }

  function renderOptimalSEO() {
    return (
      <OptimalSEO
        id={orNull("id", item)}
        isActive={orNull("isActive", item)}
        slug={slug}
        item={item}
      />
    );
  }

  function renderUploadThumb() {
    return (
      <Card title="Ảnh đại diện" className="space-thumb-wrapper">
        <Item name="url">
          <UploadSingle
            style={{ width: 240, height: 240 }}
            image={image}
            setImage={setImage}
          />
        </Item>
      </Card>
    );
  }

  function renderGroupType() {
    return (
      <Card title="Loại" className="space-general-wrapper">
        <Item label="Loại nhóm" name="groupType" style={{ marginBottom: 0 }}>
          <Selector value={"list"} options={groupType} />
        </Item>
      </Card>
    );
  }

  function renderSettingGroup() {
    return (
      <Card title="Cấu hình" className="space-general-wrapper">
        <Item label="Hiển thị" name="pageId">
          <Selector value={"NONE"} options={Mocks.GROUP_PRODUCT.listPageId} />
        </Item>
        <Item
          label="Vị trí hiển thị"
          name="placementId"
          style={{ marginBottom: 0 }}
        >
          <Selector value={0} options={Mocks.GROUP_PRODUCT.listPlacementId} />
        </Item>
      </Card>
    );
  }

  function handleConfirmChooseProduct(datas) {
    setChooseProduct({
      status: false,
      data: datas,
    });
  }

  function onRemoveItem(value) {
    setChooseProduct((prevState) => ({
      ...prevState,
      data: prevState.data.filter((item) => item.key != value),
    }));
  }

  const columnsChooseTable = [
    {
      title: "Tên Sản phẩm",
      dataIndex: "name",
      key: "name",
      render(value, record) {
        return {
          props: {
            style: { padding: "0" },
          },
          children: (
            <div style={{ cursor: "pointer" }}>
              {record.image ? (
                <Avatar
                  style={{ marginRight: 10 }}
                  shape="square"
                  size={48}
                  src={record.image}
                />
              ) : null}
              {value}
            </div>
          ),
        };
      },
    },
    {
      title: "Giá sản phẩm",
      dataIndex: "price",
      key: "price",
      // render: (price: string) => <div>{Helpers.currencyFormatVND(price)}</div>,
      width: "20%",
    },
    {
      title: "",
      dataIndex: "key",
      render: (value) => (
        <div>
          <CloseOutlined onClick={() => onRemoveItem(value)} />
        </div>
      ),
    },
  ];

  function renderChooseProducts() {
    return (
      <Card
        title={
          chooseProduct.data.length
            ? `Đã chọn ${chooseProduct.data.length} sản phẩm`
            : "Chọn sản phẩm vào nhóm"
        }
        className="space-products-wrapper"
        extra={
          <Button
            onClick={() =>
              setChooseProduct((prevState) => ({ ...prevState, status: true }))
            }
            type="primary"
          >
            Chọn sản phẩm
          </Button>
        }
      >
        <Item
          name="products"
          style={{ marginBottom: 0 }}
          rules={[{ required: true, message: "Vui lòng lựa chọn sản phẩm" }]}
          required
        >
          {chooseProduct.data.length ? (
            <Table
              columns={columnsChooseTable}
              dataSource={chooseProduct.data}
            />
          ) : (
            <div style={{ textAlign: "center" }}>
              Chưa có sản phẩm nào được chọn
              <span
                onClick={() =>
                  setChooseProduct((prevState) => ({
                    ...prevState,
                    status: true,
                  }))
                }
                style={{
                  color: "blue",
                  cursor: "pointer",
                  marginLeft: 2,
                }}
              >
                Chọn sản phẩm ngay
              </span>
            </div>
          )}
        </Item>
        {chooseProduct.status ? (
          <ChooseProductsTable
            visible={chooseProduct.status}
            listItemChoose={chooseProduct.data}
            handleCancel={() =>
              setChooseProduct((prevState) => ({ ...prevState, status: false }))
            }
            handleConfirm={handleConfirmChooseProduct}
          />
        ) : null}
      </Card>
    );
  }

  return (
    <FormBase
      layout="vertical"
      form={form}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
    >
      {headerActions()}
      <Row gutter={24}>
        <Col span={18}>
          <Space className="space-main-wrapper" direction="vertical">
            {renderInfoGeneral()}
            {orNull("id", item) ? (
              <ListProduct isHeader={false} />
            ) : (
              renderChooseProducts()
            )}
            {renderOptimalSEO()}
          </Space>
        </Col>
        <Col span={6}>
          <Space className="space-sidebar-wrapper" direction="vertical">
            {/* {renderIsActive()} */}
            {renderGroupType()}
            {renderUploadThumb()}
            {renderSettingGroup()}
          </Space>
        </Col>
      </Row>
    </FormBase>
  );
}

export default withReducer({
  key: "groupProductReducer",
  ...groupProductReducer,
})(Form);

const groupType = [
  {
    value: "LIST",
    label: "LIST",
  },
  {
    value: "SLIDE",
    label: "SLIDE",
  },
];
