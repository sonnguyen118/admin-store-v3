import { useState, useEffect } from "react";
import './styled.scss'
import { Selector } from "components";
import { Form, Row, Col, Input, Button, Popover, Tag } from 'antd';
import { FilterOutlined } from '@ant-design/icons';
import useDebounce from "../../../hook/useDebounce"

function Search(props) {
  const { filter, setFilter, onChangePage} = props
  const [form] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false)
  const [listFilter, setListFilter] = useState ([])
  const [filterType, setFilterType] = useState("withIsActive")
  const [searchValue, setSearchValue] = useState("")
  const inputDebounce = useDebounce(searchValue, 300)

  const onFinish = (values) =>{
    const arr = [...listFilter];
    setFilterVisible(false);
    switch (values.filterType) {
      case "withIsActive":
        const resultItem = listFilter.findIndex(item => item.value === "withIsActive")
        if(resultItem === -1){
          arr.push({
            value: "withIsActive",
            label: `Tình trạng là ${values.filterValue ? "Hiển thị" : "Tạm khoá"}`
          })
          setListFilter(arr)
        } else {
          listFilter[resultItem].label = `Tình trạng là ${values.filterValue ? "Hiển thị" : "Tạm khoá"}`
          setListFilter(arr)
        }
        return (
          form.setFieldsValue({
            filterType: "withIsActive",
            filterValue: values.filterValue
          }),
          setFilter(prevState => ({
            ...prevState,
            isActive: values.filterValue,
          })),
          onChangePage(1)
        );
      default:
        break;
    }
  }

  useEffect(()=>{
    if (inputDebounce) {
      setFilter(prevState => ({
        ...prevState,
        s: searchValue
      }));
      onChangePage(1);
      return
    }
  },[inputDebounce])


  useEffect(()=>{
    if(searchValue === "" && filter.s){
      delete filter.s;
      setFilter({...filter});
      onChangePage(1);
    }

  },[searchValue, filter])

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withIsActive",
      filterValue: true
    });
  }

  useEffect(onSetupForm, []);

  const handleRemoveFilter = (e, item) =>{
    e.preventDefault();
    setListFilter(listFilter.filter(node=> node.value != item.value))
    if(item.value === 'withIsActive'){
      delete filter.isActive;
      setFilter({...filter});
      onChangePage(1);
    }
  }

  const filterOptions = [
    {
      label: "Tình trạng hiển thị",
      value: "withIsActive"
    },
  ]

  const valueOptions = [
    {
      label: "Hiển thị",
      value: true
    },
    {
      label: "Tạm khoá",
      value: false
    },
  ]

  const handleVisibleChange = (visible) => {
    setFilterVisible(visible)
  }

  const onChangeSearchValue = (e) =>{
    setSearchValue(e.target.value)
  }

  const onChangeTypeFilter = (e) =>{
    setFilterType(e)
  }

  const getOptionFilter = (filterType) =>{
    switch (filterType) {
      case "withIsActive":
        return valueOptions
      default:
        break;
    }
  }

  useEffect(() => {
    if(filterType === "withIsActive"){
      form.setFieldsValue({
          filterType: "withIsActive",
          filterValue: valueOptions[0].value
      });
    }
  },[filterType])

  const content = (
    <Form
    form={form}
    onFinish={onFinish}
    >
      <p>Hiển thị tất cả sản phẩm theo</p>
      <Form.Item
          name="filterType"
          style={{ marginBottom: 0}}
      >
        <Selector onChange={onChangeTypeFilter} options={filterOptions} />
      </Form.Item>
      <div style={{ margin: "10px 0"}}>Là</div>
      <Form.Item
          name="filterValue"
      >
        <Selector options={getOptionFilter(filterType)} />
      </Form.Item>
      <Form.Item>
        <Button style={{ marginRight: 10 }}>Huỷ</Button>
        <Button htmlType="submit" type="primary">Thêm điều kiện lọc</Button>
      </Form.Item>
    </Form>
  );

  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
        <Popover 
          placement="bottom" 
          title="Thêm điều kiện lọc" 
          content={content} 
          trigger="click"
          visible={filterVisible}
          onVisibleChange={handleVisibleChange}>
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>Thêm điều kiện lọc</Button>
        </Popover>
        </Col>
        <Col span={18}>
          <Input value={searchValue} onChange={onChangeSearchValue} allowClear placeholder="Tìm kiếm theo tên sản phẩm ..."/>
        </Col>
      </Row>
      <Row style={{ marginTop: 15 }} gutter={24}>
        <Col span={24}>
          {listFilter.map((item,index)=>{
            return (
              <Tag key={index} closable onClose={(e) => handleRemoveFilter(e, item)}>
                {item.label}
              </Tag>
            )
          })}
        </Col>
      </Row>
    </div>
  );
}

export default Search;
