import { useEffect, useState } from 'react';
import { Table as SimpleTable, Typography } from "antd";
import { orNumber } from 'utils/Selector';
import { Helpers, Mocks } from "utils";
import moment from "moment";
const { Text } = Typography

export default function Table(props) {
    const { orders, meta, onChangePage, onDetailBillLadding, tabSelected } = props
    const [rows, setRows] = useState([]);
    

    const columns = [
        {
            title: "Mã đơn hàng",
            dataIndex: "code",
            render: (value) => (
                <a
                    onClick={(e) => onDetailBillLadding(e, value)}
                    className="order-nomal-row"
                    href={`/bill-laddings/order/${value}`}
                >
                    {value}
                </a>
            ),
        },
        {
            title: "Khách hàng",
            dataIndex: "shippingAddress",
            render: (value, record) => (
                <a onClick={(e) => onDetailBillLadding(e, record.code)} href={`/bill-laddings/order/${record.code}`} style={{ display: "flex", flexDirection: "column" }}>
                    <Text>{value.customerName}</Text>
                    <Text>{value.customerPhone}</Text>
                </a>
            ),
        },
        {
            title: "Seller",
            dataIndex: "seller",
            render: (value, record) => (
                <div style={{ display: "flex", flexDirection: "column" }}>
                    <Text>{value ? value.name : "---"}</Text>
                    <Text>
                        {record.sellerAssigneeAt
                            ? moment(record.sellerAssigneeAt).format("DD/MM/YYYY")
                            : ""}
                    </Text>
                </div>
            ),
        },
        {
            title: "Ngày tạo",
            dataIndex: "createdAt",
            render: (value) => (
                <div style={{ display: "flex", flexDirection: "column" }}>
                    <Text>{value ? moment(value).format("DD/MM/YYYY") : "---"}</Text>
                    <Text>{value ? moment(value).format("LT") : ""}</Text>
                </div>
            ),
        },
        {
            title: "TT giao hàng",
            dataIndex: "status",
            render: () => (
                <div className={"status-badge"}>
                    Chưa tạo vận đơn
                </div>
            ),
        },
        {
            title: "Thời gian giao hàng",
            dataIndex: "shippingType",
            render: (value) => (
                <div style={{ display: "flex", flexDirection: "column" }}>
                    <Text style={{ color: value.color }}>{value.label}</Text>
                </div>
            ),
        },
        {
            title: "Tổng tiền",
            dataIndex: "totalPrice",
        },
    ];

    function onUpdateData(): void {
        if (orders) {
            const r = [] as any;
            orders.forEach((node): void => {
                r.push({
                    key: node.id,
                    ...node,
                    totalPrice: Helpers.currencyFormatVND(node.totalPrice),
                    shippingType: Mocks.ORDER.getDeliveryTime(node.shippingType),

                });
            });
            setRows(r);
        }
    }

    function showTotal(total) {
        return `Tổng: ${total}`;
    }

    useEffect(onUpdateData, [orders]);

    return (
        <SimpleTable
            columns={columns}
            dataSource={rows}
            pagination={{
                defaultPageSize: 15,
                defaultCurrent: orNumber("page", meta),
                current: orNumber("page", meta),
                total: orNumber("total", meta),
                onChange: (page) => onChangePage(page, tabSelected),
                showSizeChanger: false,
                showTotal: showTotal
            }}
        />
    );
}
