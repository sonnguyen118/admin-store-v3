import "./styled.scss";
import { Row, Col, Space } from "antd";
import Header from "./Header";
import ShippingNote from "./ShippingNote";
import Products from "./Products";
import DeliveryInfo from "./DeliveryInfo";
import DeliveryTime from "./DeliveryTime";
import Tags from "./Tags";
import Note from "./Note";
import Histories from "./Histories";
import OrderInfo from "./OrderInfo";
import { useState, useEffect } from "react";
import SellerInfo from "../Detail/SellerInfo";

export default function Reorder(props) {
  const {
    item,
    handleBack,
    orderLogs,
    handleCreateOrderLog,
    onUpdateOrder,
    listOrderTag,
    fullfillmentCompanies,
    inventories,
    handleCreateOrderTransport,
    handleCalculateShippingFee,
    shippingFeeCalculate,
    user,
    message,
    setShippingFeeToEmpty,
  } = props;
  const [tags, setTags] = useState([]);

  useEffect(() => {
    if (listOrderTag) {
      const listOrderTagOption = listOrderTag.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setTags(listOrderTagOption);
    }
  }, [listOrderTag]);

  const renderHeader = () => {
    return <Header item={item} user={user} />;
  };

  const renderShippingNote = () => {
    return (
      <ShippingNote
        item={item}
        fullfillmentCompanies={fullfillmentCompanies}
        inventories={inventories}
        handleBack={handleBack}
        handleCreateOrderTransport={handleCreateOrderTransport}
        handleCalculateShippingFee={handleCalculateShippingFee}
        shippingFeeCalculate={shippingFeeCalculate}
        message={message}
        setShippingFeeToEmpty={setShippingFeeToEmpty}
      />
    );
  };

  const renderOrderInfo = () => {
    return <OrderInfo item={item} />;
  };

  const renderProducts = () => {
    return <Products item={item} />;
  };
  const renderDeliveryInfo = () => {
    return <DeliveryInfo item={item} />;
  };
  const renderDeliveryTime = () => {
    return <DeliveryTime item={item} />;
  };
  const renderSellerInfo = () => {
    return <SellerInfo item={item} />
  };
  const renderTags = () => {
    return (
      <Tags
        tags={tags}
        setTags={setTags}
        item={item}
        handleUpdateOrder={onUpdateOrder}
      />
    );
  };
  const renderNote = () => {
    return <Note item={item} handleUpdateOrder={onUpdateOrder} />;
  };
  const renderHistories = () => {
    return (
      <Histories
        item={item}
        orderLogs={orderLogs}
        handleCreateOrderLog={handleCreateOrderLog}
      />
    );
  };

  return (
    <div className="bill-order-detail">
      {renderHeader()}
      <Row gutter={24}>
        <Col span={18}>
          <Space className="bill-order-detail-main" direction="vertical">
            {renderShippingNote()}
            {renderOrderInfo()}
            {renderProducts()}
            {renderNote()}
            {renderHistories()}
          </Space>
        </Col>
        <Col span={6}>
          <Space className="bill-order-detail-sidebar" direction="vertical">
            {renderDeliveryInfo()}
            {renderDeliveryTime()}
            {item && item.seller ? renderSellerInfo() : null}
            {renderTags()}
          </Space>
        </Col>
      </Row>
    </div>
  );
}
