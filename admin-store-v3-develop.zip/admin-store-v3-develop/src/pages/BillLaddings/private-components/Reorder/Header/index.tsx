import { Col, Row, Space, Typography, Divider, notification } from "antd";
import { orEmpty } from "utils/Selector";
import moment from "moment";
import OrderStatus from "components/Status/OrderStatus";
import PaymentStatus from "components/Status/PaymentStatus";
import { Mocks } from "utils";

const { Title, Text } = Typography;

export default function Header(props) {
  const { item, user } = props;
  function onDetailOrder(value) {
    const itemMenuOrder = Mocks.MENUS.getRoleMenusDefine(
      orEmpty("role", user)
    ).find((item) => item.key === "orders");
    if (itemMenuOrder) {
      const isMenuUser = itemMenuOrder.nested.find((item) => item);
      window.open(`${isMenuUser.path}/detail/${value}`, "_blank");
      return;
    }
    notification["warning"]({
      message: "Thông báo",
      description: "Bạn không đủ quyền để truy cập đường dẫn này!",
    });
  }

  return (
    <Row gutter={24} className="bill-order-detail-header">
      <Col span={16} className="bill-order-detail-header-title">
        <Title level={4}>
          Đơn hàng{" "}
          <span
            className="cursor-pointer"
            onClick={() => onDetailOrder(orEmpty("code", item))}
          >
            {orEmpty("code", item)}
          </span>
        </Title>
      </Col>
      <Col span={14} className="bill-order-detail-header-info">
        <Space
          className="bill-order-detail-header-info-space"
          split={<Divider type="vertical" />}
        >
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Mã đơn hàng</Text>
            <Text strong copyable>
              <span
                className="cursor-pointer"
                onClick={() => onDetailOrder(orEmpty("code", item))}
              >
                {orEmpty("code", item)}
              </span>
            </Text>
          </div>
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái đơn hàng</Text>
            <OrderStatus value={"SHIPPING"} />
          </div>
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái thanh toán</Text>
            <PaymentStatus value={orEmpty("paymentStatus", item)} />
          </div>
        </Space>
      </Col>
      <Col span={14} className="bill-order-detail-header-info-2">
        <Space size={20}>
          <div>
            Ngày tạo: {moment(orEmpty("createdAt", item)).format("DD/MM/YYYY")}
          </div>
        </Space>
      </Col>
    </Row>
  );
}
