import {
    Card,
    Space,
    Typography,
    Form,
    Radio,
    Button
} from "antd";
import { EditOutlined } from '@ant-design/icons';
import { useState, useEffect } from "react";
import { Helpers, Mocks } from "utils";
import { orEmpty } from "utils/Selector";
const { Text } = Typography;

export default function DeliveryTime(props) {
    const { item } = props

    return (
        <Card title={"Thời gian giao hàng"} className="bill-order-detail-sidebar-selectTime bill-order-detail-sidebar-card">
            <Space direction="vertical">
                    <Text>{orEmpty("label", Mocks.ORDER.getDeliveryTime(orEmpty("shippingType", item)))}</Text>
                    <Text className="order-detail-sidebar-selectTime-desc" type="secondary">{orEmpty("description", Mocks.ORDER.getDeliveryTime(orEmpty("shippingType", item)))}</Text>
                </Space>
        </Card>
    );
}
