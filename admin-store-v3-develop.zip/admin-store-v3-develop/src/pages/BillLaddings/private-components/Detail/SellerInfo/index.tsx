import {
    Card,
    Space,
    Typography,
} from "antd";
import { Mocks } from "utils";
import { orEmpty } from "utils/Selector";
const { Text } = Typography;

export default function SellerInfo(props) {
    const { item } = props

    return (
        <Card className="bill-order-detail-sidebar-selectTime bill-order-detail-sidebar-card">
            <Space direction="vertical">
                <Text>Đơn hàng được chốt thành công bởi: <strong>{orEmpty("seller.name", item)}</strong></Text>
            </Space>
        </Card>
    );
}