import {
    Card,
    Space,
    Typography
} from "antd";
import { orEmpty } from "utils/Selector";
const { Text } = Typography;

export default function DeliveryInfo(props) {
    const { item } = props

    return (
        <Card title={"Thông tin giao hàng"} className="bill-order-detail-sidebar-card">
            <Space direction="vertical">
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {orEmpty("shippingAddress.customerName", item)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {orEmpty("shippingAddress.customerPhone", item)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {orEmpty("shippingAddress.customerEmail", item)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {`${orEmpty("shippingAddress.address", item) != "" ? orEmpty("shippingAddress.address", item) + "," : ""} ${orEmpty("shippingAddress.wardName", item)}, ${orEmpty("shippingAddress.districtName", item)}, ${orEmpty("shippingAddress.provinceName", item)}`}
                </Text>
            </Space>
        </Card>
    );
}
