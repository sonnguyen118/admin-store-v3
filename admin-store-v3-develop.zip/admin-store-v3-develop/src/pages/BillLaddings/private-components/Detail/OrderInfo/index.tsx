import { Col, Row, Space, Typography, Card } from "antd";
import { Helpers, Mocks } from "utils";
import { orArray, orBoolean, orEmpty, orNumber } from "utils/Selector";
const { Text } = Typography;

export default function OrderInfo(props) {
  const { item } = props;

  const TitleCard = () => {
    return (
      <div className="bill-order-detail-main-info-title">
        <Text strong>Thông tin thanh toán</Text>
        <Text className="bill-order-detail-main-info-title-type">
          Phương thức thanh toán:{" "}
          {Mocks.ORDER.getPaymentGatewayDescription(
            orEmpty("paymentGateway", item)
          )}
        </Text>
      </div>
    );
  };

  const renderShipOption = () => {
    if (orBoolean("isFreeShip", item)) {
      return "(Free Ship)";
    }
    if (!orBoolean("isFreeShip", item) && orEmpty("shippingFeeOption", item)) {
      return `(${orEmpty("shippingFeeOption.name", item)})`;
    }
    return "(Mặc định)";
  };

  return (
    <Card title={<TitleCard />} className="bill-order-detail-main-info">
      <Row gutter={24} style={{ marginBottom: 8 }}>
        <Col span={16}>
          <Space
            className="bill-order-detail-main-info-space"
            direction="vertical"
          >
            <div className="bill-order-detail-main-info-space-item">
              <Text>Tổng số lượng sản phẩm</Text>
              <Text>{orArray("orderItems", item).length}</Text>
            </div>
            <div className="bill-order-detail-main-info-space-item">
              <Text>Tổng tiền hàng</Text>
              <Text>
                {Helpers.currencyFormatVND(orNumber("totalItemPrice", item))}
              </Text>
            </div>
          </Space>
        </Col>
      </Row>
      <Row gutter={24}>
        <Col span={16}>
          <Space
            className="bill-order-detail-main-info-space"
            direction="vertical"
          >
            <div className="bill-order-detail-main-info-space-item">
              <Text>Giảm giá</Text>
              <Text>{Helpers.currencyFormatVND(orNumber("discountPrice", item))}</Text>
            </div>
            <div className="bill-order-detail-main-info-space-item">
              <Text>Phí vận chuyển</Text>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "flex-end",
                }}
              >
                <Text>
                  {Helpers.currencyFormatVND(orNumber("shippingFee", item))}
                </Text>
                <div style={{ fontSize: 12 }}>{renderShipOption()}</div>
              </div>
            </div>
            <div className="bill-order-detail-main-info-space-item">
              <Text>Tổng thanh toán</Text>
              <Text>
                {Helpers.currencyFormatVND(orNumber("totalPrice", item))}
              </Text>
            </div>
            <div className="bill-order-detail-main-info-space-item">
              <Text>Đã thanh toán</Text>
              <Text>
                {orEmpty("paymentStatus", item) === "PAID"
                  ? Helpers.currencyFormatVND(orNumber("totalPrice", item))
                  : Helpers.currencyFormatVND(0)}
              </Text>
            </div>
          </Space>
        </Col>
      </Row>
    </Card>
  );
}
