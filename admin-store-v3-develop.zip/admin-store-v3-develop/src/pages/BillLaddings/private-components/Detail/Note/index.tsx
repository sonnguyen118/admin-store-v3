import {
    Button,
    Card,
    Form,
    Input,
    Typography
} from "antd";
import { useEffect } from "react";
import { orEmpty } from "utils/Selector";

const { Item } = Form;
const { Text } = Typography

export default function OrderNote(props) {
    const { item, handleUpdateOrder } = props
    const [form] = Form.useForm();

    function onFinish(values) {
        handleUpdateOrder({ id: orEmpty("id", item), ...values })
        // handleAssigneeSeller(values)
    }

    function onSetupForm() {
        if (item) {
            form.setFieldsValue({
                adminNote: item.adminNote,
            });
            return
        }
    }

    function checkStatusOrder() {
        return orEmpty("status", item) === "CANCELLED"
    }

    useEffect(() => {
        onSetupForm()
    }, [item])



    return (
        <Card title="Ghi chú đơn hàng" className="bill-order-detail-main-note">
            <Form
                layout="vertical"
                form={form}
                onFinish={onFinish}
                className="bill-order-detail-main-note-form"
            >
                <Item>
                    <Text strong>Ghi chú của khách hàng: </Text> <Text>{orEmpty("customerNote", item)}</Text>
                </Item>
                <Item
                    name="adminNote"
                    required
                    rules={[{ required: true, message: 'Vui lòng thêm ghi chú cho đơn hàng' }]}
                >
                    <Input.TextArea rows={4} placeholder="Thêm ghi chú cho đơn hàng" />
                </Item>
                <Item className="bill-order-detail-main-note-form-item" >
                    <Button disabled={checkStatusOrder()} htmlType="submit">Lưu ghi chú</Button>
                </Item>
            </Form>
        </Card>
    );
}
