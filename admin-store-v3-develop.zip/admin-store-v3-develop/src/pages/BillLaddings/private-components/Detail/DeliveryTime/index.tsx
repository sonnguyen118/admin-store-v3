import {
    Card,
    Space,
    Typography,
} from "antd";
import { Mocks } from "utils";
import { orEmpty } from "utils/Selector";
const { Text } = Typography;

export default function DeliveryTime(props) {
    const { item } = props

    return (
        <Card title={"Thời gian giao hàng"} className="bill-order-detail-sidebar-selectTime bill-order-detail-sidebar-card">
            <Space direction="vertical">
                    <Text>{orEmpty("label", Mocks.ORDER.getDeliveryTime(orEmpty("shippingType", item)))}</Text>
                    <Text className="order-detail-sidebar-selectTime-desc" type="secondary">{orEmpty("description", Mocks.ORDER.getDeliveryTime(orEmpty("shippingType", item)))}</Text>
                </Space>
        </Card>
    );
}
