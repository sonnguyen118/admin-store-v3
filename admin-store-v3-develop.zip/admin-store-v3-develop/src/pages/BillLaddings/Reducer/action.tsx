import {
  FullfillmentOrders as FullfillmentOrdersAPI,
  OrderTags as OrderTagsAPI,
  Users as UsersAPI,
  Orders as OrdersAPI,
} from "api";
import { orEmpty, orNumber } from "utils/Selector";
import {
  IncrementLoading,
  DecrementLoading,
  setListInventoryOrder,
  setDetailOrder,
  setUpdateOrder,
  setListOrderLogs,
  setCreateOrderLogs,
  setListOrderTag,
  setListFulfillmentCompany,
  setListInventory,
  setCreateOrderTransport,
  setListSeller,
  setReorderTransport,
  setShippingFeeOption,
  setShippingFeeCalculate,
} from "./action-type";

export const onGetListInventoryOrder = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListInventoryOrder(params);
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      };
      dispatch(
        setListInventoryOrder({
          inventoryOrders: data.data.datas,
          inventoryOrderMeta: meta,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListInventoryOrder({
        inventoryOrders: [],
        inventoryOrderMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getDetailOrder = async (id, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setDetailOrder({
      isRefresh: false,
      message: null,
      type: null,
    })
  );
  try {
    const response = await FullfillmentOrdersAPI.detailOrder(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setDetailOrder({
          detailOrder: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setDetailOrder({
        detailOrder: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateOrder = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.updateOrder(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setUpdateOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setUpdateOrder({
          type: null,
          isRefresh: false,
          message: null,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};
export const updateNewOrder = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.updateOrder(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setUpdateOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setUpdateOrder({
          type: null,
          isRefresh: false,
          message: null,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderLogs = async (params, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setListOrderLogs({
      isRefresh: false,
      message: null,
      type: null,
    })
  );
  try {
    const response = await FullfillmentOrdersAPI.getOrderLogs(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListOrderLogs({
          orderLogs: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrderLogs({
        orderLogs: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createOrderLogs = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.createOrderLogs(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setCreateOrderLogs({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setCreateOrderLogs({
          type: null,
          isRedirect: false,
          message: null,
        })
      );
    }
  } catch (error) {
    dispatch(
      setCreateOrderLogs({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderTag = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrderTagsAPI.getListOrderTags(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListOrderTag({
          orderTags: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrderTag({
        orderTags: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListFulfillmentCompany = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListFulfillmentCompany(
      params
    );
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListFulfillmentCompany({
          fullfillmentCompanies: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListFulfillmentCompany({
        fullfillmentCompanies: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListInventory = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListInventory(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListInventory({
          inventories: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListInventory({
        inventories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createOrderTransport = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.createOrderTransport(id, body);
    const { data, status } = response;
    if (response) {
      switch (orNumber("data.meta.status", response)) {
        case 2000:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message: orEmpty("data.meta.internalMessage", response),
            })
          );
          return dispatch(DecrementLoading);
        case 2001:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message:
                "Đã xảy ra lỗi từ hệ thống nhà của nhà vận chuyển vui lòng thử lại sau",
            })
          );
          return dispatch(DecrementLoading);
        case 2002:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message: "Request Timeout",
            })
          );
          return dispatch(DecrementLoading);
        case 2003:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message: "Đã xảy ra lỗi do nhà vận chuyển đang bảo trì",
            })
          );
          return dispatch(DecrementLoading);
        default:
          dispatch(
            setCreateOrderTransport({
              type: "success",
              createData: data.data,
              isRedirect: true,
              message: "Cập nhật thành công",
            })
          );
          dispatch(DecrementLoading);
          return dispatch(
            setCreateOrderTransport({
              type: null,
              isRedirect: false,
              message: null,
            })
          );
      }
    }
    // if (status === 200) {
    //   dispatch(
    //     setCreateOrderTransport({
    //       type: "success",
    //       createData: data.data,
    //       isRedirect: true,
    //       message: "Cập nhật thành công",
    //     })
    //   );
    //   dispatch(DecrementLoading);
    //   return dispatch(
    //     setCreateOrderTransport({
    //       type: null,
    //       isRedirect: false,
    //       message: null,
    //     })
    //   );
    // }
  } catch (error) {
    dispatch(
      setCreateOrderTransport({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const calculateShippingFee = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.shippingFeeCalculate(body);
    const { data, status } = response;
    if (response && data.meta.success) {
      dispatch(
        setShippingFeeCalculate({
          shippingFeeCalculate: data.data,
        })
      );
      return;
    }
    return dispatch(
      setShippingFeeCalculate({
        isGetShippingFee: false,
        shippingFeeMessage: data.meta.internalMessage,
      })
    );
  } catch (error) {
    dispatch(
      setShippingFeeCalculate({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error",
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};

export const setShippingFeeToEmpty = (dispatch) => {
  return dispatch(
    setShippingFeeCalculate({
      shippingFeeCalculate: 0,
    })
  );
};

export const onGetListSeller = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await UsersAPI.getListSeller(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListSeller({
          sellers: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListSeller({
        sellers: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const reorderTransport = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.reorderTransport(id, body);
    const { data, status } = response;
    if (response) {
      switch (orNumber("data.meta.status", response)) {
        case 2000:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message: orEmpty("data.meta.internalMessage", response),
            })
          );
          return dispatch(DecrementLoading);
        case 2001:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message:
                "Đã xảy ra lỗi từ hệ thống nhà của nhà vận chuyển vui lòng thử lại sau",
            })
          );
          return dispatch(DecrementLoading);
        case 2002:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message: "Request Timeout",
            })
          );
          return dispatch(DecrementLoading);
        case 2003:
          dispatch(
            setCreateOrderTransport({
              type: "error",
              message: "Đã xảy ra lỗi do nhà vận chuyển đang bảo trì",
            })
          );
          return dispatch(DecrementLoading);
        default:
          dispatch(
            setCreateOrderTransport({
              type: "success",
              createData: data.data,
              isRedirect: true,
              message: "Cập nhật thành công",
            })
          );
          dispatch(DecrementLoading);
          return dispatch(
            setCreateOrderTransport({
              type: null,
              isRedirect: false,
              message: null,
            })
          );
      }
    }
    // if (status === 200) {
    //   dispatch(
    //     setReorderTransport({
    //       type: "success",
    //       createData: data.data,
    //       isRedirect: true,
    //       message: "Cập nhật thành công",
    //     })
    //   );
    //   dispatch(DecrementLoading);
    //   return dispatch(
    //     setReorderTransport({
    //       type: null,
    //       isRedirect: false,
    //       message: null,
    //     })
    //   );
    // }
  } catch (error) {
    dispatch(
      setReorderTransport({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetShippingFeeOption = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getShippingFeeOption(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setShippingFeeOption({
          shippingFeeList: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setShippingFeeOption({
        shippingFeeList: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};
