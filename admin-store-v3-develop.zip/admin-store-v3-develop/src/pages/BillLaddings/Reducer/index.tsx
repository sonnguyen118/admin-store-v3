import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  GET_LIST_INVENTORY_ORDER,
  DETAIL_ORDER,
  UPDATE_ORDER,
  LIST_ORDER_LOGS,
  CREATE_ORDER_LOGS,
  GET_LIST_ORDER_TAGS,
  GET_LIST_FULFILLMENT_COMPANY,
  GET_LIST_INVENTORY,
  CREATE_ORDER_TRANSPORT,
  LIST_SELLER,
  REORDER_TRANSPORT,
  SHIPPING_FEE_OPTION,
  SHIPPING_FEE_CALCULATE
} from "./action-type";

const initialState = {
  isLoading: false,
  counter: 0,
};

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload,
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null,
      };
    case GET_LIST_INVENTORY_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case DETAIL_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_ORDER_LOGS:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_ORDER_LOGS:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_ORDER_TAGS:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_FULFILLMENT_COMPANY:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_INVENTORY:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_ORDER_TRANSPORT:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_SELLER:
      return {
        ...state,
        ...action.payload,
      };
    case REORDER_TRANSPORT:
      return {
        ...state,
        ...action.payload,
      };
    case SHIPPING_FEE_OPTION:
      return {
        ...state,
        ...action.payload,
      };
    case SHIPPING_FEE_CALCULATE:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer,
};
