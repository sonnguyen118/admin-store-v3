export const INCREMENT_LOADING = "orders/INCREMENT_LOADING";
export const DECREMENT_LOADING = "orders/DECREMENT_LOADING";
export const GET_LIST_INVENTORY_ORDER = "orders/GET_LIST_INVENTORY_ORDER";
export const DETAIL_ORDER = "orders/DETAIL_ORDER";
export const UPDATE_ORDER = "orders/UPDATE_ORDER";
export const LIST_ORDER_LOGS = "orders/LIST_ORDER_LOGS";
export const CREATE_ORDER_LOGS = "orders/CREATE_ORDER_LOGS";
export const GET_LIST_ORDER_TAGS = "orders/GET_LIST_ORDER_TAGS";
export const GET_LIST_FULFILLMENT_COMPANY = "orders/GET_LIST_FULFILLMENT_COMPANY";
export const GET_LIST_INVENTORY = "orders/GET_LIST_INVENTORY";
export const CREATE_ORDER_TRANSPORT = "orders/CREATE_ORDER_TRANSPORT";
export const LIST_SELLER = "orders/LIST_SELLER";
export const REORDER_TRANSPORT = "orders/REORDER_TRANSPORT";
export const SHIPPING_FEE_OPTION = "orders/SHIPPING_FEE_OPTION";
export const SHIPPING_FEE_CALCULATE = "orders/SHIPPING_FEE_CALCULATE";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListInventoryOrder = payload => {
  return {
    payload,
    type: GET_LIST_INVENTORY_ORDER
  };
};

export const setDetailOrder = payload => {
  return {
    payload,
    type: DETAIL_ORDER
  };
};

export const setUpdateOrder = payload => {
  return {
    payload,
    type: UPDATE_ORDER
  };
};

export const setListOrderLogs = payload => {
  return {
    payload,
    type: LIST_ORDER_LOGS
  };
};

export const setCreateOrderLogs = payload => {
  return {
    payload,
    type: CREATE_ORDER_LOGS
  };
};

export const setListOrderTag = payload => {
  return {
    payload,
    type: GET_LIST_ORDER_TAGS
  };
};

export const setListFulfillmentCompany = payload => {
  return {
    payload,
    type: GET_LIST_FULFILLMENT_COMPANY
  };
};

export const setListInventory = payload => {
  return {
    payload,
    type: GET_LIST_INVENTORY
  };
};

export const setCreateOrderTransport = payload => {
  return {
    payload,
    type: CREATE_ORDER_TRANSPORT
  };
};

export const setListSeller = payload => {
  return {
    payload,
    type: LIST_SELLER
  };
};

export const setReorderTransport = payload => {
  return {
    payload,
    type: REORDER_TRANSPORT
  };
};

export const setShippingFeeOption = payload => {
  return {
    payload,
    type: SHIPPING_FEE_OPTION
  };
};

export const setShippingFeeCalculate = payload => {
  return {
    payload,
    type: SHIPPING_FEE_CALCULATE
  };
};







