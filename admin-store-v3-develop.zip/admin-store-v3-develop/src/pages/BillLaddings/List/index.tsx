import { useState, useEffect, useMemo } from "react";
import { Typography } from "antd";
import { Helpers, Mocks } from "utils";
import moment from "moment";
import { orArray, orNull, orNumber } from "utils/Selector";
import { useHistory } from "react-router-dom";
import Search from "../Search";
import "./styled.scss";
import queryString from "query-string";
import { Table } from "../private-components"

const { Text } = Typography;

function List(props) {
  const { dispatch, action, state, onReloadData, filterDefault, query, localFilterOrders, tabSelected } = props;
  const history = useHistory();

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize,
    ...filterDefault
  });

  useEffect(() => {
    action.inventoryOdersReducer.onGetListInventoryOrder(
      filter,
      dispatch.inventoryOdersReducer
    );
  }, [filter]);

  useEffect(() => {
    action.inventoryOdersReducer.onGetListSeller(
      {},
      dispatch.inventoryOdersReducer
    );
    action.inventoryOdersReducer.onGetListOrderTag(
      {},
      dispatch.inventoryOdersReducer
    );
  }, []);

  function onDetailBillLadding(e, code) {
    e.preventDefault();
    history.push(`/bill-laddings/order/${code}`)
  }


  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "bill-laddings",
        search: queryString.stringify({ ...query, page: query.page, type: tabSelected })
      })
      setFilter(prevState => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize
        }
      })
    }
  }, [query]);

  function onChangePage(page, type) {
    history.push({
      pathname: "bill-laddings",
      search: queryString.stringify({ ...query, page, type: type ? type : tabSelected })
    })
  }

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        listSeller={orArray("inventoryOdersReducer.sellers", state)}
        listOrderTag={orArray("inventoryOdersReducer.orderTags", state)}
        onChangePage={onChangePage}
        localFilterOrders={localFilterOrders}
        path="/bill-laddings"
        onReloadData={onReloadData}
        filterDefault={filterDefault}
        tabSelected={tabSelected}
      />
      <Table
        orders={orArray("inventoryOdersReducer.inventoryOrders", state)}
        meta={orNull("inventoryOdersReducer.inventoryOrderMeta", state)}
        onChangePage={onChangePage}
        onDetailBillLadding={onDetailBillLadding}
        tabSelected={tabSelected}
      />
    </div>
  );
}

export default List;
