import { DetailOrder } from "../../../private-components";
import { useHistory, useParams } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray, orNumber } from "utils/Selector";
import inventoryDetailOrderReducer from "../../../Reducer";
import { useEffect } from "react";

function Detail(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();
  const params = useParams();
  function handleBack() {
    history.goBack();
  }

  function onSetup() {
    if (orEmpty("id", params)) {
      action.inventoryDetailOrderReducer.getDetailOrder(
        orEmpty("id", params),
        dispatch.inventoryDetailOrderReducer
      );
    }
  }

  const onGetListOrderTag = () => {
    action.inventoryDetailOrderReducer.onGetListOrderTag(
      {},
      dispatch.inventoryDetailOrderReducer
    );
  };

  const onGetListFulfillmentCompany = () => {
    action.inventoryDetailOrderReducer.onGetListFulfillmentCompany(
      {},
      dispatch.inventoryDetailOrderReducer
    );
  };

  const onGetListOrderLogs = () => {
    if (orNull("inventoryDetailOrderReducer.detailOrder", state)) {
      action.inventoryDetailOrderReducer.onGetListOrderLogs(
        orEmpty("inventoryDetailOrderReducer.detailOrder.id", state),
        dispatch.inventoryDetailOrderReducer
      );
    }
  };

  const handleCreateOrderLog = (values) => {
    const { id, ...body } = values;
    action.inventoryDetailOrderReducer.createOrderLogs(
      id,
      body,
      dispatch.inventoryDetailOrderReducer
    );
  };

  const onUpdateOrder = (values) => {
    const { id, ...body } = values;
    action.inventoryDetailOrderReducer.updateOrder(
      id,
      body,
      dispatch.inventoryDetailOrderReducer
    );
  };
  const onUpdateOrderNew = (values) => {
    const { id, ...body } = values;
    action.inventoryDetailOrderReducer.updateOrder(
      id,
      body,
      dispatch.inventoryDetailOrderReducer
    );
  };

  const onRefresh = () => {
    if (orBoolean("inventoryDetailOrderReducer.isRefresh", state)) {
      onSetup();
      onGetListOrderLogs();
    }
  };

  const onRedirect = () => {
    if (orBoolean("inventoryDetailOrderReducer.isRedirect", state)) {
      history.push(
        `/transports/detail/${orEmpty(
          "inventoryDetailOrderReducer.createData.code",
          state
        )}`
      );
    }
  };

  const handleCreateOrderTransport = (params) => {
    const { id, ...body } = params;
    action.inventoryDetailOrderReducer.createOrderTransport(
      id,
      body,
      dispatch.inventoryDetailOrderReducer
    );
  };

  const handleCalculateShippingFee = (body) => {
    action.inventoryDetailOrderReducer.calculateShippingFee(
      body,
      dispatch.inventoryDetailOrderReducer
    );
  };

  const setShippingFeeToEmpty = () => {
    action.inventoryDetailOrderReducer.setShippingFeeToEmpty(
      dispatch.inventoryDetailOrderReducer
    );
  };

  useEffect(onSetup, [orEmpty("id", params)]);
  useEffect(onGetListOrderTag, []);
  useEffect(onGetListFulfillmentCompany, []);
  useEffect(onRedirect, [
    orBoolean("inventoryDetailOrderReducer.isRedirect", state),
  ]);
  useEffect(onGetListOrderLogs, [
    orNull("inventoryDetailOrderReducer.detailOrder", state),
  ]);
  useEffect(onRefresh, [
    orBoolean("inventoryDetailOrderReducer.isRefresh", state),
  ]);

  return (
    <DetailOrder
      fullfillmentCompanies={orArray(
        "inventoryDetailOrderReducer.fullfillmentCompanies",
        state
      )}
      orderLogs={orArray("inventoryDetailOrderReducer.orderLogs", state)}
      item={orNull("inventoryDetailOrderReducer.detailOrder", state)}
      user={orNull("userReducer.user", state)}
      listOrderTag={orArray("inventoryDetailOrderReducer.orderTags", state)}
      handleBack={handleBack}
      handleCreateOrderLog={handleCreateOrderLog}
      onUpdateOrder={onUpdateOrder}
      handleCreateOrderTransport={handleCreateOrderTransport}
      handleCalculateShippingFee={handleCalculateShippingFee}
      shippingFeeCalculate={orNumber(
        "inventoryDetailOrderReducer.shippingFeeCalculate",
        state
      )}
      isGetShippingFee={orBoolean(
        "inventoryDetailOrderReducer.isGetShippingFee",
        state
      )}
      message={orBoolean(
        "inventoryDetailOrderReducer.shippingFeeMessage",
        state
      )}
      setShippingFeeToEmpty={setShippingFeeToEmpty}
    />
  );
}
export default withReducer({
  key: "inventoryDetailOrderReducer",
  ...inventoryDetailOrderReducer,
})(Detail);
