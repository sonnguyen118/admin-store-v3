import { useHistory, useParams } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray, orNumber } from "utils/Selector";
import transportReorderReducer from "../../../Reducer";
import { useMemo } from "react";
import { Reorder as ReorderComponent } from "../../../private-components";

function Reorder(props) {
  const { dispatch, action, state } = props;
  const params = useParams();
  const history = useHistory();
  function handleBack() {
    history.goBack();
  }

  function onSetup() {
    if (orEmpty("id", params)) {
      action.transportReorderReducer.getDetailOrder(
        orEmpty("id", params),
        dispatch.transportReorderReducer
      );
    }
  }

  const onGetListOrderTag = () => {
    action.transportReorderReducer.onGetListOrderTag(
      {},
      dispatch.transportReorderReducer
    );
  };

  const onGetListFulfillmentCompany = () => {
    action.transportReorderReducer.onGetListFulfillmentCompany(
      {},
      dispatch.transportReorderReducer
    );
  };

  const onGetListOrderLogs = () => {
    if (orNull("transportReorderReducer.detailOrder", state)) {
      action.transportReorderReducer.onGetListOrderLogs(
        orEmpty("transportReorderReducer.detailOrder.id", state),
        dispatch.transportReorderReducer
      );
    }
  };

  const onRedirect = () => {
    if (orBoolean("transportReorderReducer.isRedirect", state)) {
      history.push(
        `/transports/detail/${orEmpty(
          "transportReorderReducer.createData.code",
          state
        )}`
      );
    }
  };

  const handleCreateOrderLog = (values) => {
    const { id, ...body } = values;
    action.transportReorderReducer.createOrderLogs(
      id,
      body,
      dispatch.transportReorderReducer
    );
  };

  const onUpdateOrder = (values) => {
    const { id, ...body } = values;
    action.transportReorderReducer.updateOrder(
      id,
      body,
      dispatch.transportReorderReducer
    );
  };

  const handleCalculateShippingFee = (body) => {
    action.transportReorderReducer.calculateShippingFee(
      body,
      dispatch.transportReorderReducer
    );
  };

  const setShippingFeeToEmpty = () => {
    action.transportReorderReducer.setShippingFeeToEmpty(
      dispatch.transportReorderReducer
    );
  };

  useMemo(onSetup, [orEmpty("id", params)]);
  useMemo(onGetListOrderTag, []);
  useMemo(onGetListFulfillmentCompany, []);
  useMemo(onGetListOrderLogs, [
    orNull("transportReorderReducer.detailOrder", state),
  ]);
  useMemo(() => {
    onSetup();
  }, [orEmpty("id", params)]);
  useMemo(onRedirect, [orBoolean("transportReorderReducer.isRedirect", state)]);

  const handleCreateOrderTransport = (params) => {
    const { id, ...body } = params;
    action.transportReorderReducer.reorderTransport(
      id,
      body,
      dispatch.transportReorderReducer
    );
  };

  return (
    <ReorderComponent
      fullfillmentCompanies={orArray(
        "transportReorderReducer.fullfillmentCompanies",
        state
      )}
      orderLogs={orArray("transportReorderReducer.orderLogs", state)}
      item={orNull("transportReorderReducer.detailOrder", state)}
      user={orNull("userReducer.user", state)}
      listOrderTag={orArray("transportReorderReducer.orderTags", state)}
      handleBack={handleBack}
      handleCreateOrderLog={handleCreateOrderLog}
      onUpdateOrder={onUpdateOrder}
      handleCreateOrderTransport={handleCreateOrderTransport}
      handleCalculateShippingFee={handleCalculateShippingFee}
      shippingFeeCalculate={orNumber(
        "transportReorderReducer.shippingFeeCalculate",
        state
      )}
      isGetShippingFee={orBoolean(
        "transportReorderReducer.isGetShippingFee",
        state
      )}
      message={orBoolean("transportReorderReducer.shippingFeeMessage", state)}
      setShippingFeeToEmpty={setShippingFeeToEmpty}
    />
  );
}
export default withReducer({
  key: "transportReorderReducer",
  ...transportReorderReducer,
})(Reorder);
