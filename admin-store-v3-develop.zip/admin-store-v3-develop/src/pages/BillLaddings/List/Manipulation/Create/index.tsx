import { Modal } from "antd";
import { Form } from "../../../private-components"

export default function Create({ visible, onVisible }) {
  function handleOk() {
    onVisible(false, false, false);
  }
  function handleCancel() {
    onVisible(false, false, false);
  }
  return (
    <Modal
      title="Thêm thương hiệu"
      visible={visible.isCreate}
      onOk={handleOk}
      onCancel={handleCancel}
    >
      <Form/>
    </Modal>
  );                 
}
