import React, { useState, useEffect } from "react";
import { Selector } from "components";
import { Form, Row, Col, Input, Button, Popover, Tag, DatePicker, Modal, Radio, Space, notification } from 'antd';
import { FilterOutlined } from '@ant-design/icons';
import useDebounce from "hook/useDebounce"
import { Helpers, Mocks } from "utils";
import moment from "moment";
import "./styled.scss"
import { orNull } from "utils/Selector";
const { RangePicker } = DatePicker;

export default function Filter(props) {
  const {
    filter,
    setFilter,
    listSeller = [],
    onChangePage,
    listOrderTag = [],
    localFilterOrders,
    path,
    onReloadData,
    filterDefault,
    tabSelected
  } = props
  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false)
  const [listFilter, setListFilter] = useState([])
  const [filterType, setFilterType] = useState("withPaymentStatus")
  const [searchValue, setSearchValue] = useState("")
  const [searchType, setSearchType] = useState("all")
  const [listSellerOption, setListSellerOption] = useState([])
  const [listOrderTagOption, setListOrderTagOption] = useState([])
  const [dataFilter, setDataFilter] = useState({});
  const inputDebounce = useDebounce(searchValue, 300)
  const [isUpdateFilter, setIsUpdateFilter] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);

  useEffect(() => {
    if (filterDefault) {
      setDataFilter((prevState) => ({
        ...prevState,
        ...filterDefault,
      }))
    }
  }, [filterDefault])

  useEffect(() => {
    if (listSeller.length) {
      const listSellers = listSeller.map((item) => ({
        label: item.name,
        value: item.username
      }))
      setListSellerOption(listSellers)
    }
  }, [listSeller])

  useEffect(() => {
    if (listOrderTag.length) {
      setListOrderTagOption(listOrderTag.map((item) => ({
        label: item.name,
        value: item.id
      })))
    }
  }, [listOrderTag])

  useEffect(() => {
    const arr = [...listFilter];
    if (filterDefault && listOrderTagOption.length) {
      if (orNull("paymentStatus", filterDefault)) {
        arr.push({
          value: "withPaymentStatus",
          label: Mocks.ORDER.getLabelFilter("withPaymentStatus", orNull("paymentStatus", filterDefault))
        })
        setListFilter(arr)
      }
      if (orNull("paymentGateway", filterDefault)) {
        arr.push({
          value: "withPaymentGateway",
          label: Mocks.ORDER.getLabelFilter("withPaymentGateway", orNull("paymentGateway", filterDefault))
        })
        setListFilter(arr)
      }
      if (orNull("shippingType", filterDefault)) {
        arr.push({
          value: "withShippingType",
          label: Mocks.ORDER.getLabelFilter("withShippingType", orNull("shippingType", filterDefault))
        })
        setListFilter(arr)
      }
      if (orNull("seller", filterDefault)) {
        arr.push({
          value: "withNameSeller",
          label: Mocks.ORDER.getLabelFilter("withNameSeller", orNull("seller", filterDefault))
        })
        setListFilter(arr)
      }
      if (orNull("tags", filterDefault)) {
        arr.push({
          value: "withTags",
          label: Mocks.ORDER.getLabelFilter("withTags", orNull("tags", filterDefault), listOrderTagOption)
        })
        setListFilter(arr)
      }
      if (orNull("before", filterDefault) && orNull("after", filterDefault)) {
        arr.push({
          value: "withDateTime",
          label: `Ngày tạo từ ngày ${moment(orNull("after", filterDefault)).format("DD-MM-YYYY")} đến ngày ${moment(orNull("before", filterDefault)).subtract(1, "days").format("DD-MM-YYYY")}`
        })
        setListFilter(arr)
      }
    }
  }, [filterDefault, listOrderTagOption])

  const onFilter = (filterType, filterValue) => {
    switch (filterType) {
      case "withPaymentStatus":
        setDataFilter((prevState) => ({
          ...prevState,
          paymentStatus: filterValue,
        }))
        setFilter(prevState => ({
          ...prevState,
          paymentStatus: filterValue,
        }))
        return;
      case "withPaymentGateway":
        setDataFilter((prevState) => ({
          ...prevState,
          paymentGateway: filterValue,
        }))
        setFilter(prevState => ({
          ...prevState,
          paymentGateway: filterValue,
        }))
        return;
      case "withShippingType":
        setDataFilter((prevState) => ({
          ...prevState,
          shippingType: filterValue,
        }))
        setFilter(prevState => ({
          ...prevState,
          shippingType: filterValue,
        }))
        return;
      case "withNameSeller":
        setDataFilter((prevState) => ({
          ...prevState,
          seller: filterValue,
        }))
        setFilter(prevState => ({
          ...prevState,
          seller: filterValue,
        }))
        return
      case "withTags":
        setDataFilter((prevState) => ({
          ...prevState,
          tags: filterValue,
        }))
        setFilter(prevState => ({
          ...prevState,
          tags: filterValue,
        }))
        return
      case "withDateTime":
        setDataFilter((prevState) => ({
          ...prevState,
          after: filterValue[0].format("YYYY-MM-DD"),
          before: moment(filterValue[1]).add(1, "days").format("YYYY-MM-DD"),
        }))
        setFilter(prevState => ({
          ...prevState,
          after: filterValue[0].format("YYYY-MM-DD"),
          before: moment(filterValue[1]).add(1, "days").format("YYYY-MM-DD"),
        }))
        return
      default:
        break;
    }
  }

  const checkListFilter = (filterType, filterValue, filterDate) => {
    handleCloseVisible();
    const arr = [...listFilter];
    const resultItem = listFilter.findIndex(item => item.value === filterType)
    if (resultItem === -1) {
      arr.push({
        value: filterType,
        label: Mocks.BILLLADDINGS.getLabelFilter(filterType, filterValue || filterDate, listOrderTagOption)
      })
      setListFilter(arr)
    } else {
      listFilter[resultItem].label = Mocks.BILLLADDINGS.getLabelFilter(filterType, filterValue || filterDate)
      setListFilter(arr)
    }
    return (
      form.setFieldsValue({
        filterType: filterType,
        filterValue: filterValue,
        filterDate: filterDate
      }),
      onFilter(filterType, filterValue || filterDate),
      onChangePage(1)
    );
  }


  const onFinish = (values) => {
    checkListFilter(values.filterType, values.filterValue, values.filterDate)
  }

  function onFinishModal(values) {
    const arr = [...localFilterOrders]
    const newFilter = {
      name: values.name,
      key: Helpers.getKey(values.name),
      filter: dataFilter
    }
    if (values.isCreate === "update") {
      const itemUpdateIndex = arr.findIndex(item => item.key === newFilter.key)
      newFilter.name = arr[itemUpdateIndex].name
      arr[itemUpdateIndex] = newFilter
      Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
        return onReloadData(newFilter)
      })
      form2.resetFields()
      setIsUpdateFilter(false)
      return
    }
    if (arr.find(item => item.key === newFilter.key)) {
      notification['warning']({
        message: 'Thông báo',
        description: `Bộ lọc đã tồn tại vui lòng kiểm tra và thử lại`
      });
      return
    }
    arr.push(newFilter)
    Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
      return onReloadData(newFilter)
    })
    form2.resetFields()
    setIsUpdateFilter(false)
  }

  function handleCancel() {
    setIsUpdateFilter(false)
  }

  const handleChangeIsCreate = (e) => {
    if (e.target.value === "update") {
      setIsUpdate(true)
      form2.setFieldsValue({
        name: localFilterOrders.find(item => item.key === tabSelected) ? tabSelected : null,
      });
      return
    }
    setIsUpdate(false)
    form2.setFieldsValue({
      name: "",
    });
  }

  function handleAddFilterToLocal() {
    setIsUpdateFilter(true)
  }

  useEffect(() => {
    form2.setFieldsValue({
      isCreate: "create",
    });
  }, [])


  useEffect(() => {
    if (inputDebounce) {
      if (searchType === "code") {
        setFilter(prevState => ({
          ...prevState,
          code: searchValue
        }));
        onChangePage(1);
        return
      }
      setFilter(prevState => ({
        ...prevState,
        s: searchValue
      }));
      onChangePage(1);
      return
    }
  }, [inputDebounce])

  useEffect(() => {
    if (searchValue === "" && filter.s) {
      delete filter.s;
      setFilter({ ...filter });
      onChangePage(1);
      return
    }
    if (searchValue === "" && filter.code) {
      delete filter.code;
      setFilter({ ...filter });
      onChangePage(1);
      return
    }
  }, [searchValue, filter])

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withPaymentStatus",
      filterValue: []
    });
  }

  useEffect(onSetupForm, [dataFilter]);



  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter(node => node.value != item.value))
    if (item.value === 'withPaymentStatus') {
      delete filter.paymentStatus;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.paymentStatus;
      setDataFilter({ ...dataFilter })
      onChangePage(1);
      return
    }
    if (item.value === 'withDateTime') {
      delete filter.after;
      delete filter.before;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.after;
      // @ts-ignore
      delete dataFilter.before;
      setDataFilter({ ...dataFilter })
      onChangePage(1);
      return
    }
    if (item.value === "withShippingType") {
      delete filter.shippingType;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.shippingType;
      setDataFilter({ ...dataFilter })
      onChangePage(1);
      return;
    }
    if (item.value === 'withPaymentGateway') {
      delete filter.paymentGateway;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.paymentGateway;
      setDataFilter({ ...dataFilter })
      onChangePage(1);
      return
    }
    if (item.value === 'withNameSeller') {
      delete filter.seller;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.seller;
      setDataFilter({ ...dataFilter })
      onChangePage(1);
      return
    }
    if (item.value === 'withTags') {
      delete filter.tags;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.tags;
      setDataFilter({ ...dataFilter })
      onChangePage(1);
      return
    }
  }

  const handleVisibleChange = (visible) => {
    setFilterVisible(visible)
  }

  const handleCloseVisible = () => {
    setFilterType("withPaymentStatus")
    setFilterVisible(false)
  }

  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value)
  }

  const onChangeTypeFilter = (e) => {
    setFilterType(e)
  }

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "withPaymentStatus":
        return Mocks.ORDER.PaymentStatus
      case "withPaymentGateway":
        return Mocks.ORDER.PaymentGateway
      case "withShippingType":
        return Mocks.ORDER.ShippingType
      case "withNameSeller":
        return listSellerOption
      case "withTags":
        return listOrderTagOption
      default:
        break;
    }
  }

  useEffect(() => {
    if (filterType === "withPaymentStatus") {
      form.setFieldsValue({
        filterType: "withPaymentStatus",
        filterValue: orNull("paymentStatus", dataFilter) ? orNull("paymentStatus", dataFilter) : []
      });
      return
    }
    if (filterType === "withPaymentGateway") {
      form.setFieldsValue({
        filterType: "withPaymentGateway",
        filterValue: orNull("paymentGateway", dataFilter) ? orNull("paymentGateway", dataFilter) : []
      });
      return
    }
    if (filterType === "withShippingType") {
      form.setFieldsValue({
        filterType: "withShippingType",
        filterValue: orNull("shippingType", dataFilter) ? orNull("shippingType", dataFilter) : [],
      });
      return;
    }
    if (filterType === "withNameSeller") {
      form.setFieldsValue({
        filterType: "withNameSeller",
        filterValue: orNull("seller", dataFilter) ? orNull("seller", dataFilter) : []
      });
      return
    }
    if (filterType === "withTags") {
      form.setFieldsValue({
        filterType: "withTags",
        filterValue: orNull("tags", dataFilter) ? orNull("tags", dataFilter) : []
      });
      return
    }
  }, [filterType])

  const searchTypeOptions = [
    {
      label: "Tất cả",
      value: "all"
    },
    {
      label: "Mã đơn hàng",
      value: "code"
    }
  ]

  const onChangeSearchType = (value) => {
    setSearchValue("")
    setSearchType(value)
  }

  const content = (
    <Form
      form={form}
      onFinish={onFinish}
      style={{ width: 300, maxWidth: 300 }}
    >
      <p>Hiển thị tất cả sản phẩm theo</p>
      <Form.Item
        name="filterType"
        style={{ marginBottom: 0 }}
      >
        <Selector onChange={onChangeTypeFilter} options={Mocks.BILLLADDINGS.filterOptions} />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      {filterType === "withDateTime"
        ?
        <Form.Item
          name="filterDate"
          rules={[
            { required: true, message: 'Vui lòng lựa chọn thời gian' }
          ]}
          required
        >
          <RangePicker />
        </Form.Item>
        :
        <Form.Item
          name="filterValue"
          rules={[{ required: true, message: "Vui lòng chọn thông tin để lọc" }]}
        >
          <Selector
            mode="multiple"
            options={getOptionFilter(filterType)}
            placeholder="Chọn điều kiện lọc"
          />
        </Form.Item>
      }

      <Form.Item style={{ display: "flex", justifyContent: "space-between" }}>
        <Button onClick={handleCloseVisible} style={{ marginRight: 10 }}>Huỷ</Button>
        <Button htmlType="submit" type="primary">Thêm điều kiện lọc</Button>
      </Form.Item>
    </Form>
  );


  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title={"Thêm điều kiện lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>Thêm điều kiện lọc</Button>
          </Popover>
        </Col>
        <Col span={3}>
          <Selector onChange={onChangeSearchType} value={searchType} options={searchTypeOptions} />
        </Col>
        <Col span={listFilter.length ? 12 : 15}>
          <Input value={searchValue} onChange={onChangeSearchValue} allowClear placeholder={searchType === "code" ? "Nhập mã đơn hàng VD: ABC0123456, XYZ7891011" : "Tìm kiếm theo mã đơn hàng, số điện thoại, email, tên khách hàng ..."} />
        </Col>
        {listFilter.length ?
          <Col span={3}>
            <Button onClick={handleAddFilterToLocal} style={{ width: "100%" }} icon={<FilterOutlined />}>
              Lưu bộ lọc
            </Button>
          </Col>
          : null}
      </Row>
      {listFilter.length ?
        <Row style={{ margin: "15px 0" }} gutter={24}>
          <Col span={24}>
            {Helpers.getUnique(listFilter, "value").map((item, index) => {
              return (
                <Tag key={index} closable onClose={(e) => handleRemoveFilter(e, item)}>
                  {item.label}
                </Tag>
              )
            })}
          </Col>
        </Row>
        : null}
      <Modal title="Lưu bộ lọc" visible={isUpdateFilter} onOk={form2.submit} onCancel={handleCancel}>
        <Form
          name="addFilter"
          form={form2}
          onFinish={onFinishModal}
          layout="vertical"
        >
          <Form.Item name="isCreate">
            <Radio.Group onChange={handleChangeIsCreate}>
              <Space direction="vertical">
                <Radio value="create">Tạo mới bộ lọc</Radio>
                <Radio value="update">Lưu đè lên bộ lọc đã tồn tại</Radio>
              </Space>
            </Radio.Group>
          </Form.Item>
          <Form.Item
            label={isUpdate ? "Chọn bộ lọc" : "Tên bộ lọc"}
            name="name"
            rules={[{ required: true, message: `${isUpdate ? "Vui lòng chọn bộ lọc" : "Vui lòng nhập tên bộ lọc"}` }]}
          >
            {isUpdate ?
              <Selector options={localFilterOrders.map(item => ({ label: item.name, value: item.key }))} placeholder="Chọn bộ lọc" />
              :
              <Input placeholder="Nhập tên bộ lọc" />
            }

          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
}
