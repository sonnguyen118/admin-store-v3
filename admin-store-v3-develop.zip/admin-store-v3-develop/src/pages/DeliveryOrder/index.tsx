import React, { useCallback, useMemo, useState } from "react";
import { EditTabs } from "components";
import { Typography, Row, Col, Modal, Button } from "antd";
import List from "./List";
import { useHistory } from "react-router-dom";
import { Helpers, Mocks } from "utils";
import queryString from "query-string";
import deliveryOrdersReducer from "./Reducer";
import { withReducer } from "hoc";
const { Title } = Typography;
const { confirm } = Modal;

function DeliveryOrder(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  const [localFilterOrders, setLocalFilterOrders] = useState([]);
  const [initialState, setInitialState] = useState(true);

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: !data.type
        ? 1
        : data.type && data.page
        ? parseInt(data.page as string)
        : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15,
      type: data.type ? data.type : "all",
    };
  }, [history.location.search]);

  const tabSelected: any = useMemo(() => {
    return query.type ? query.type : "all";
  }, [query.type]);

  useMemo(() => {
    if (initialState) {
      Helpers.localStorageGetItem("/delivery-order").then(function (value) {
        setLocalFilterOrders(JSON.parse(value) || []);
        if (value) {
          if (
            !JSON.parse(value).find((item) => item.key === tabSelected) &&
            !Mocks.ORDER.defaultAdminFilters.find(
              (item) => item.key === tabSelected
            )
          ) {
            history.push({
              pathname: "delivery-order",
              search: queryString.stringify({ ...query, type: "all" }),
            });
          }
          return;
        }
        if (
          !Mocks.ORDER.defaultAdminFilters.find(
            (item) => item.key === tabSelected
          )
        ) {
          history.push({
            pathname: "delivery-order",
            search: queryString.stringify({ ...query, type: "all" }),
          });
        }
      });
    }
    return setInitialState(false);
  }, [initialState]);

  const onReloadData = (newFilter) => {
    setInitialState(true);
    history.push({
      pathname: "delivery-order",
      search: queryString.stringify({ ...query, type: newFilter.key }),
    });
  };

  const getTabItems = useCallback(() => {
    if (localFilterOrders.length) {
      const tabs = Mocks.DELIVERY_ORDER.defaultFilters
        .concat(localFilterOrders)
        .map((item) => ({
          title: item.name,
          closable: localFilterOrders.find((f) => f.key === item.key)
            ? true
            : false,
          key: item.key,
          component: (
            <List
              dispatch={dispatch}
              action={action}
              state={state}
              localFilterOrders={localFilterOrders}
              query={query}
              tabSelected={tabSelected}
              filterDefault={item.filter}
              onReloadData={onReloadData}
            />
          ),
        }));
      return (
        <EditTabs
          activeKey={tabSelected}
          tabItems={tabs}
          onChangeTab={onChangeTab}
          onEdit={onEditTab}
        />
      );
    }
    const tabs = Mocks.DELIVERY_ORDER.defaultFilters.map((item) => ({
      title: item.name,
      closable: false,
      key: item.key,
      component: (
        <List
          dispatch={dispatch}
          action={action}
          state={state}
          localFilterOrders={localFilterOrders}
          query={query}
          tabSelected={tabSelected}
          filterDefault={item.filter}
          onReloadData={onReloadData}
        />
      ),
    }));
    return (
      <EditTabs
        activeKey={tabSelected}
        tabItems={tabs}
        onChangeTab={onChangeTab}
        onEdit={onEditTab}
      />
    );
  }, [localFilterOrders, query, tabSelected]);

  function onChangeTab(activeKey) {
    history.push({
      pathname: "delivery-order",
      search: queryString.stringify({ ...query, page: 1, type: activeKey }),
    });
  }

  function onConfirmRemoveFilter(targetKey) {
    Helpers.localStorageSetItem(
      "/delivery-order",
      JSON.stringify(localFilterOrders.filter((f) => f.key != targetKey))
    ).then(function () {
      return setInitialState(true);
    });
  }

  function onEditTab(targetKey, action) {
    switch (action) {
      case "remove":
        confirm({
          closable: true,
          title: "Thông báo!",
          okText: "Xác nhận",
          cancelText: "Hủy",
          content:
            "Bạn chắc chẳn muốn xóa bộ lọc này? Bộ lọc bị xóa sẽ không thể hoàn tác lại!",
          okType: "primary",
          onOk() {
            onConfirmRemoveFilter(targetKey);
          },
        });
        return;
      default:
        return;
    }
  }

  return (
    <div>
      <Row>
        <Col span={8}>
          <Title level={2}>Danh sách đơn</Title>
        </Col>
        <Col span={8} offset={8}>
          <div style={styles.buttonWrapper}>
            <Button
              onClick={() => history.push("delivery-order/job")}
              type="primary"
            >
              Xem tất cả Job
            </Button>
          </div>
        </Col>
      </Row>
      {getTabItems()}
    </div>
  );
}

export default withReducer({
  key: "deliveryOrdersReducer",
  ...deliveryOrdersReducer,
})(DeliveryOrder);

const styles = {
  buttonWrapper: {
    display: "flex",
    justifyContent: "flex-end",
  },
};
