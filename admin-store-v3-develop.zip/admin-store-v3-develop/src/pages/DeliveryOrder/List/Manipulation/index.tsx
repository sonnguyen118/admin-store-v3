export { default as Detail } from "./Detail";
