import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { Radio, Typography, notification, Table, Modal } from "antd";
import { Helpers, Mocks } from "utils";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import { useHistory } from "react-router-dom";
import Search from "../Search";
import "./styled.scss";
import queryString from "query-string";
import moment from "moment";
import FulfillmentStatus from "components/Status/FulfillmentStatus";
import CODStatus from "components/Status/CODStatus";
import { ExportExcelCollationAll } from "../private-components";

const { Text, Link } = Typography;

function List(props) {
  const {
    dispatch,
    action,
    state,
    onReloadData,
    filterDefault,
    query,
    localFilterOrders,
    tabSelected,
  } = props;
  const history = useHistory();
  const roleDisable = ["SELLER", "SELLER_HOTLINE", "ACCOUNTING"];
  const roleUsed = ["ADMIN", "ACCOUNTING"];
  const roleUser = orEmpty("userReducer.user.role", state);

  const [selectedItems, setSelectedItems] = useState([]);

  const [filter, setFilter]: any = useState({
    page: 1,
    pageSize: 15,
    ...filterDefault,
  });

  const onGetListFulfillmentOrderExport = () => {
    if (filter.inventory) {
      action.deliveryOrdersReducer.onGetListFulfillmentOrderExport(
        filter,
        dispatch.deliveryOrdersReducer
      );
    }
  };

  useMemo(() => {
    if (orBoolean("deliveryOrdersReducer.isRefresh", state)) {
      onGetListFulfillmentOrderExport();
    }
  }, [orBoolean("deliveryOrdersReducer.isRefresh", state)]);

  useEffect(() => {
    onGetListFulfillmentOrderExport();
  }, [filter]);

  const onGetListInventory = () => {
    action.deliveryOrdersReducer.onGetListInventory(
      {},
      dispatch.deliveryOrdersReducer
    );
  };

  const listOrderSourceOption = useMemo(() => {
    const list = orArray("deliveryOrdersReducer.listOrderSource", state).map((item) => ({
      value: item,
      label: item,
    }));
    return list;
  }, [state.deliveryOrdersReducer]);

  function onGetListOrderSource() {
    action.deliveryOrdersReducer.onGetListOrderSource(dispatch.deliveryOrdersReducer);
  }

  useEffect(() => {
    onGetListOrderSource();
  }, []);

  useEffect(() => {
    onGetListInventory();
  }, []);

  function onDetailOrder(value) {
    const itemMenuOrder = Mocks.MENUS.getRoleMenusDefine(
      orEmpty("userReducer.user.role", state)
    ).find((item) => item.key === "orders");
    if (itemMenuOrder) {
      const isMenuUser = itemMenuOrder.nested.find((item) => item);
      window.open(`${isMenuUser.path}/detail/${value}`, "_blank");
      return;
    }
    notification["warning"]({
      message: "Thông báo",
      description: "Bạn không đủ quyền để truy cập đường dẫn này!",
    });
  }

  function onDetailTransport(e, value) {
    e.preventDefault();
    history.push(`/transports/detail/${orEmpty("code", value)}`);
  }

  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "delivery-order",
        search: queryString.stringify({
          ...query,
          page: query.page,
          type: tabSelected,
        }),
      });
      setFilter((prevState) => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize,
        };
      });
    }
  }, [query]);

  function onChangePage(page, type) {
    history.push({
      pathname: "delivery-order",
      search: queryString.stringify({
        ...query,
        page,
        type: type ? type : tabSelected,
      }),
    });
  }

  function onConfirmPrintItems(orders) {
    action.deliveryOrdersReducer.confirmPrintItems(
      orders,
      dispatch.deliveryOrdersReducer
    );
  }

  function checkStatus(statusValue) {
    const isCancelled = ["CANCELLED", "REFUNDED"].includes(statusValue);
    if (isCancelled) {
      return "transport-cancel-color";
    }
    return "transport-normal-color";
  }

  const columns = [
    {
      title: "Mã vận chuyển",
      dataIndex: "fulfillmentOrder",
      render: (value, record) => (
        <a
          style={{ display: "flex", flexDirection: "column" }}
          className={checkStatus(record.status)}
          onClick={(e) => onDetailTransport(e, value)}
          href={`/delivery-order/detail/${orEmpty("code", value)}`}
        >
          {orEmpty("code", value)}
          <div>
            <Text
              style={
                record.status === "CANCELLED" || record.status === "REFUNDED"
                  ? { color: "rgba(0, 0, 0, 0.45)" }
                  : { color: "#5BC983" }
              }
            >
              {record.isPrinted ? "Đã in vận đơn" : null}
            </Text>
          </div>
        </a>
      ),
    },
    {
      title: "Mã đơn hàng",
      dataIndex: "code",
      render: (value, record) => (
        <div
          style={{ cursor: "pointer" }}
          className={checkStatus(record.status)}
          onClick={() => onDetailOrder(value)}
        >
          {value}
        </div>
      ),
    },
    {
      title: "Ngày tạo",
      dataIndex: "fulfillmentOrder",
      render: (value, record) => (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Text className={checkStatus(record.status)}>
            {value
              ? moment(orEmpty("createdAt", value)).format("DD/MM/YYYY")
              : "---"}
          </Text>
          <Text className={checkStatus(record.status)}>
            {value ? moment(orEmpty("createdAt", value)).format("LT") : ""}
          </Text>
        </div>
      ),
    },
    {
      title: "Nhà vận chuyển",
      dataIndex: "fulfillmentOrder",
      render: (value) => (
        <Text
          style={{ color: orEmpty("fulfillmentCompany.color", value) }}
          strong
        >
          {orEmpty("fulfillmentCompany.name", value)}
        </Text>
      ),
    },
    {
      title: "Nguồn đơn",
      dataIndex: "source",
      render: (value) => <Text strong>{value}</Text>,
    },
    {
      title: "TT xuất đơn",
      dataIndex: "isExported",
      render: (value) => (
        <Text type={value ? "success" : "secondary"} strong>
          {value ? "ĐÃ XUẤT ĐƠN" : "CHƯA XUẤT ĐƠN"}
        </Text>
      ),
    },
  ];

  const [rows, setRows] = useState([]);

  function onUpdateData(): void {
    const listInventoryOrder = orArray(
      "deliveryOrdersReducer.fulfillmentOrderExport",
      state
    );
    if (listInventoryOrder) {
      const r = [] as any;

      listInventoryOrder.forEach((node): void => {
        r.push({
          key: node.id,
          ...node,
          shippingAddress: node.toAddress,
          statusValue: node.status,
          totalPrice: node.codAmount,
          deliveryCompany: orEmpty("fulfillmentCompany.name", node),
        });
      });
      setRows(r);
    }
  }

  useEffect(onUpdateData, [orArray("deliveryOrdersReducer", state)]);

  function showTotal(total) {
    return `Tổng: ${total}`;
  }

  const rowSelection = {
    selectedRowKeys: selectedItems.map((item) => orEmpty("key", item)),
    onSelect: (record, selected) => {
      if (selected) {
        const r = selectedItems.slice();
        r.push(record);
        setSelectedItems(r);
        return;
      } else {
        setSelectedItems((prevState) =>
          prevState.filter((item) => item.id != record.id)
        );
      }
    },
    onSelectAll: (selected, selectedRows, changeRows) => {
      if (selected) {
        const r = selectedItems.slice();
        const newSelectedRows = selectedRows.filter((item) => {
          if (!r.includes(item)) {
            return item;
          }
        });
        setSelectedItems(r.concat(newSelectedRows).filter((item) => item));
        return;
      } else {
        const r = selectedItems.slice();
        const data = [];
        r.forEach((e) => {
          const result = changeRows.find((item) => item.key === e.key);
          if (!result) {
            data.push(e);
            return;
          }
        });
        setSelectedItems(data);
      }
    },
  };

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        listFulFillmentCompany={orArray(
          "deliveryOrdersReducer.fullfillmentCompanies",
          state
        )}
        listinventory={orArray("deliveryOrdersReducer.inventories", state)}
        onChangePage={onChangePage}
        onConfirmPrintItems={onConfirmPrintItems}
        localFilterOrders={localFilterOrders}
        path="/delivery-order"
        onReloadData={onReloadData}
        filterDefault={filterDefault}
        tabSelected={tabSelected}
        selectedItems={selectedItems}
        setSelectedItems={setSelectedItems}
        listOrderSourceOption={listOrderSourceOption}
      />
      <Table
        rowSelection={rowSelection}
        columns={columns}
        dataSource={rows}
        rowClassName={(record) =>
          record.statusValue === "CANCELLED" ||
          record.statusValue === "REFUNDED"
            ? "transport-cancel-row"
            : "transport-normal-row"
        }
        pagination={{
          defaultPageSize: filter.pageSize,
          defaultCurrent: filter.page,
          current: filter.page,
          showSizeChanger: false,
          total: orNumber(
            "deliveryOrdersReducer.fulfillmentOrderExportMeta.total",
            state
          ),
          onChange: (page) => onChangePage(page, tabSelected),
          showTotal: showTotal,
        }}
      />
    </div>
  );
}

export default List;
