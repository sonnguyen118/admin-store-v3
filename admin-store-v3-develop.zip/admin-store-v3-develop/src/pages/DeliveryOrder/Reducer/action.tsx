import {
  FullfillmentOrders as FullfillmentOrdersAPI,
  Common as CommonAPI,
} from "api";
import {
  IncrementLoading,
  DecrementLoading,
  setListInventory,
  setListFulfillmentOrder,
  setListOrderSource,
} from "./action-type";
import { orArray } from "utils/Selector";

export const onGetListFulfillmentOrderExport = async (params, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setListFulfillmentOrder({
      message: null,
      isRefresh: false,
      type: null,
    })
  );
  try {
    const response = await FullfillmentOrdersAPI.listFulFillmentOrderExport(
      params
    );
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      };
      dispatch(
        setListFulfillmentOrder({
          fulfillmentOrderExport: data.data.datas,
          fulfillmentOrderExportMeta: meta,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListFulfillmentOrder({
        fulfillmentOrderExport: [],
        fulfillmentOrderExportMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListInventory = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListInventory(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListInventory({
          inventories: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListInventory({
        inventories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderSource = async (dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await CommonAPI.getListOrderSource();
    const { data } = response;
    return dispatch(
      setListOrderSource({
        listOrderSource: orArray("data", data),
      })
    );
  } catch (error) {
    return dispatch(
      setListOrderSource({
        listOrderSource: [],
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};
