import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  GET_LIST_FULFILLMENT_ORDER,
  GET_LIST_INVENTORY,
  SET_LIST_ORDER_SOURCE,
} from "./action-type";

const initialState = {
  isLoading: false,
  counter: 0,
  logs: [],
};

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload,
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null,
      };
    case GET_LIST_FULFILLMENT_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_INVENTORY:
      return {
        ...state,
        ...action.payload,
      };
    case SET_LIST_ORDER_SOURCE:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer,
};
