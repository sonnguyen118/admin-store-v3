export const INCREMENT_LOADING = "orders/INCREMENT_LOADING";
export const DECREMENT_LOADING = "orders/DECREMENT_LOADING";
export const GET_LIST_FULFILLMENT_ORDER = "orders/GET_LIST_FULFILLMENT_ORDER";
export const GET_LIST_INVENTORY = "orders/GET_LIST_INVENTORY";
export const SET_LIST_ORDER_SOURCE = "orders/SET_LIST_ORDER_SOURCE";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListFulfillmentOrder = payload => {
  return {
    payload,
    type: GET_LIST_FULFILLMENT_ORDER
  };
};

export const setListInventory = payload => {
  return {
    payload,
    type: GET_LIST_INVENTORY
  };
};

export const setListOrderSource = (payload) => {
  return {
    payload,
    type: SET_LIST_ORDER_SOURCE,
  };
};








