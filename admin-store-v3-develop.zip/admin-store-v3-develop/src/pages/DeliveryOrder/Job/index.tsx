import { Button, PageHeader, Progress, Table, Tag } from "antd";
import { useHistory } from "react-router-dom";
import { Jobs as JobsAPI } from "api";
import { useEffect, useState } from "react";
import { orArray } from "utils/Selector";
import {
  CloseCircleOutlined,
  CheckCircleOutlined,
  SyncOutlined,
  FieldTimeOutlined,
} from "@ant-design/icons";
import moment from "moment";

function DeliveryOrder(props) {
  const history = useHistory();
  const [jobs, setJobs] = useState([]);
  const [timeline, setTimeline] = useState(0);
  function onClickBack() {
    history.goBack();
  }

  useEffect(() => {
    if (timeline === 0) {
      setTimeout(() => {
        setTimeline(Math.round((1 / 3) * 100));
      }, 1000);
    } else if (timeline < 100) {
      setTimeout(() => {
        setTimeline((prevState) => Math.round(prevState + (1 / 3) * 100));
      }, 1000);
    }
  }, [timeline]);

  async function listJob() {
    try {
      const response = await JobsAPI.listJob();
      if (response) {
        setJobs(
          orArray("data.data.datas", response).map((item) => ({
            key: item.id,
            ...item,
          }))
        );
      }
    } catch (error) {
      console.log(error);
    } finally {
      setTimeline(0);
    }
  }

  async function retryJob(id) {
    try {
      const response = await JobsAPI.retryJob(id);
      if (response) {
        listJob();
      }
    } catch (error) {
      console.log(error);
    }
  }

  const renderStatus = (value) => {
    switch (value) {
      case "SUCCESS":
        return (
          <Tag icon={<CheckCircleOutlined />} color="success">
            Thành công
          </Tag>
        );
      case "FAIL":
        return (
          <Tag icon={<CloseCircleOutlined />} color="error">
            Thất bại
          </Tag>
        );
      case "PENDING":
        return (
          <Tag icon={<FieldTimeOutlined />} color="warning">
            Chờ xử lý
          </Tag>
        );
      case "PROCESSING":
        return (
          <Tag icon={<SyncOutlined spin />} color="processing">
            Đang xử lý
          </Tag>
        );
      default:
        return null;
    }
  };

  function onRetryJob(record) {
    retryJob(record.id);
  }

  const renderButtonRetry = (value, record) => {
    switch (value) {
      case "FAIL":
        return (
          <Button onClick={() => onRetryJob(record)} type="primary">
            Xuất đơn lại
          </Button>
        );
      default:
        return null;
    }
  };

  const columns = [
    {
      title: "Trạng thái",
      dataIndex: "status",
      render: (value) => renderStatus(value),
    },
    {
      title: "Ngày tạo",
      dataIndex: "createdAt",
      render: (value) => moment(value).format("DD/MM/YYYY"),
    },
    {
      title: "Người tạo",
      dataIndex: "createdBy",
      render: (value) => value.name,
    },
    {
      title: "Ghi chú",
      dataIndex: "name",
    },
    {
      title: "Lý do lỗi",
      dataIndex: "messageFail",
      key: "messageFail",
      render: (value) => <div style={{ maxWidth: 500 }}>{value}</div>,
    },
    {
      title: (
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <Progress
            type="circle"
            percent={timeline}
            showInfo={false}
            width={25}
            strokeWidth={10}
          />
        </div>
      ),
      dataIndex: "status",
      render: (value, record) => renderButtonRetry(value, record),
    },
  ];

  useEffect(() => {
    if (jobs.length === 0) {
      listJob();
      return;
    }
    if (timeline >= 100) {
      listJob();
    }
  }, [jobs, timeline]);

  return (
    <div>
      <PageHeader
        title="Job"
        ghost={false}
        extra={[
          <Button key="1" type="default" onClick={onClickBack}>
            Quay lại
          </Button>,
        ]}
      />
      <Table columns={columns} dataSource={jobs} pagination={null} />
    </div>
  );
}

export default DeliveryOrder;
