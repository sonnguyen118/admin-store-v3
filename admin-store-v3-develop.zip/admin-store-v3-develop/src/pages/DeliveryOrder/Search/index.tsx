import React, { useState, useEffect, useRef } from "react";
import { Selector } from "components";
import {
  Form,
  Row,
  Col,
  Input,
  Button,
  Popover,
  Tag,
  Modal,
  Radio,
  Space,
  notification,
  Dropdown,
  Menu,
  DatePicker,
} from "antd";
import { FilterOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { Helpers, Mocks } from "utils";
import "./styled.scss";
import { orNull } from "utils/Selector";
import _ from "lodash";
import { DownOutlined } from "@ant-design/icons";
import ModalCreateDeliveryOrder from "./components/ModalCreateDeliveryOrder";
import moment from "moment";

const { RangePicker } = DatePicker;

export default function Filter(props) {
  const {
    filter,
    setFilter,
    listFulFillmentCompany,
    listinventory,
    onChangePage,
    localFilterOrders,
    path,
    onReloadData,
    filterDefault,
    tabSelected,
    selectedItems,
    setSelectedItems,
    listOrderSourceOption
  } = props;
  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false);
  const [listFilter, setListFilter] = useState([]);
  const [filterType, setFilterType] = useState("withExported");
  const [searchValue, setSearchValue] = useState("");
  const [listFulFillmentCompanyOption, setListFulFillmentCompanyOption] =
    useState([]);
  const [listinventoryOption, setListinventoryOption] = useState([]);
  const inputDebounce = useDebounce(searchValue, 300);
  const [dataFilter, setDataFilter] = useState({});
  const [isUpdateFilter, setIsUpdateFilter] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (filterDefault) {
      setDataFilter((prevState) => ({
        ...prevState,
        ...filterDefault,
      }));
    }
  }, [filterDefault]);

  useEffect(() => {
    if (listFulFillmentCompany.length) {
      const listFulFillmentCompanyOption = listFulFillmentCompany.map(
        (item) => ({
          label: item.name,
          value: item.id,
        })
      );
      setListFulFillmentCompanyOption(listFulFillmentCompanyOption);
    }
  }, [listFulFillmentCompany]);

  useEffect(() => {
    if (listinventory.length) {
      const listinventoryOption = listinventory.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setListinventoryOption(listinventoryOption);
    }
  }, [listinventory]);

  useEffect(() => {
    form2.setFieldsValue({
      isCreate: "create",
    });
  }, []);

  useEffect(() => {
    const arr = [...listFilter];
    if (filterDefault) {
      if (orNull("isExported", filterDefault)) {
        arr.push({
          value: "withExported",
          label: Mocks.DELIVERY_ORDER.getLabelFilter(
            "withExported",
            orNull("isExported", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("source", filterDefault)) {
        arr.push({
          value: "withSource",
          label: Mocks.DELIVERY_ORDER.getLabelFilter(
            "withSource",
            orNull("source", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("isPrinted", filterDefault)) {
        arr.push({
          value: "withPrinted",
          label: Mocks.DELIVERY_ORDER.getLabelFilter(
            "withPrinted",
            orNull("isPrinted", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("before", filterDefault) && orNull("after", filterDefault)) {
        arr.push({
          value: "withDateTime",
          label: `Ngày tạo từ ngày ${moment(
            orNull("after", filterDefault)
          ).format("DD-MM-YYYY")} đến ngày ${moment(
            orNull("before", filterDefault)
          )
            .subtract(1, "days")
            .format("DD-MM-YYYY")}`,
        });
        setListFilter(arr);
      }
      if (orNull("estimateDeliveryDate", filterDefault)) {
        arr.push({
          value: "withEstimateDeliveryDate",
          label: `Thời gian dự kiến giao hàng là ngày ${moment(
            orNull("estimateDeliveryDate", filterDefault)
          ).format("DD-MM-YYYY")}`,
        });
        setListFilter(arr);
      }
    }
  }, [filterDefault]);

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "withExported":
        return Mocks.DELIVERY_ORDER.ExportedStatus;
      case "withInventory":
        return listinventoryOption;
      case "withPrinted":
        return Mocks.DELIVERY_ORDER.PrintedStatus;
      case "withSource":
        return listOrderSourceOption;
      default:
        break;
    }
  };

  useEffect(() => {
    if (filterType === "withExported") {
      form.setFieldsValue({
        filterType: "withExported",
        filterValue: orNull("isExported", dataFilter)
          ? orNull("isExported", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withInventory") {
      form.setFieldsValue({
        filterType: "withInventory",
        filterValue: orNull("inventory", dataFilter)
          ? orNull("inventory", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withPrinted") {
      form.setFieldsValue({
        filterType: "withPrinted",
        filterValue: orNull("isPrinted", dataFilter)
          ? orNull("isPrinted", dataFilter)
          : null,
      });
      return;
    }
    if (filterType === "withSource") {
      form.setFieldsValue({
        filterType: "withSource",
        filterValue: orNull("source", dataFilter)
          ? orNull("source", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withDateTime") {
      form.setFieldsValue({
        filterType: "withDateTime",
        filterDate:
          orNull("before", dataFilter) && orNull("after", dataFilter)
            ? [
                moment(orNull("after", dataFilter)),
                moment(orNull("before", dataFilter)).subtract(1, "days"),
              ]
            : null,
      });
      return;
    }
    if (filterType === "withEstimateDeliveryDate") {
      form.setFieldsValue({
        filterType: "withEstimateDeliveryDate",
        filterDate2: orNull("estimateDeliveryDate", dataFilter)
          ? moment(orNull("estimateDeliveryDate", dataFilter))
          : null,
      });
      return;
    }
  }, [filterType]);

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withExported",
      filterValue: orNull("isExported", dataFilter)
        ? orNull("isExported", dataFilter)
        : [],
    });
  }

  useEffect(onSetupForm, [dataFilter]);

  const onFilter = (filterType, filterValue, filterDate?: any) => {
    switch (filterType) {
      case "withExported":
        setDataFilter((prevState) => ({
          ...prevState,
          isExported: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          isExported: filterValue,
        }));
        return;
      case "withInventory":
        setDataFilter((prevState) => ({
          ...prevState,
          inventory: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          inventory: filterValue,
        }));
        return;
      case "withPrinted":
        setDataFilter((prevState) => ({
          ...prevState,
          isPrinted: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          isPrinted: filterValue,
        }));
        return;
      case "withSource":
        setDataFilter((prevState) => ({
          ...prevState,
          source: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          source: filterValue,
        }));
        return;
      case "withDateTime":
        setDataFilter((prevState) => ({
          ...prevState,
          after: filterDate[0].format("YYYY-MM-DD"),
          before: moment(filterDate[1]).add(1, "days").format("YYYY-MM-DD"),
        }));
        setFilter((prevState) => ({
          ...prevState,
          after: filterDate[0].format("YYYY-MM-DD"),
          before: moment(filterDate[1]).add(1, "days").format("YYYY-MM-DD"),
        }));
        return;
      case "withEstimateDeliveryDate":
        setDataFilter((prevState) => ({
          ...prevState,
          estimateDeliveryDate: filterDate.format("YYYY-MM-DD"),
        }));
        setFilter((prevState) => ({
          ...prevState,
          estimateDeliveryDate: filterDate.format("YYYY-MM-DD"),
        }));
        return;
      default:
        break;
    }
  };

  const checkListFilter = (
    filterType,
    filterValue,
    filterDate,
    filterDate2
  ) => {
    handleCloseVisible();
    const arr = [...listFilter];
    const resultItem = listFilter.findIndex(
      (item) => item.value === filterType
    );
    if (resultItem === -1) {
      arr.push({
        value: filterType,
        label: Mocks.DELIVERY_ORDER.getLabelFilter(
          filterType,
          filterValue || filterDate || filterDate2,
          listinventoryOption
        ),
      });
      setListFilter(arr);
    } else {
      listFilter[resultItem].label = Mocks.DELIVERY_ORDER.getLabelFilter(
        filterType,
        filterValue || filterDate || filterDate2,
        listinventoryOption
      );
      setListFilter(arr);
    }
    return (
      form.setFieldsValue({
        filterType: filterType,
        filterValue: filterValue,
        filterDate: filterDate,
        filterDate2: filterDate2,
      }),
      onFilter(filterType, filterValue, filterDate || filterDate2),
      onChangePage(1)
    );
  };

  const onFinish = (values) => {
    checkListFilter(
      values.filterType,
      values.filterValue,
      values.filterDate,
      values.filterDate2
    );
  };

  function onChangeInventory(e) {
    onFilter("withInventory", e.target.value);
  }

  useEffect(() => {
    if (inputDebounce) {
      setFilter((prevState) => ({
        ...prevState,
        s: searchValue,
      }));
      onChangePage(1);
      return;
    }
  }, [inputDebounce]);

  useEffect(() => {
    if (searchValue === "" && filter.s) {
      delete filter.s;
      setFilter({ ...filter });
      onChangePage(1);
      return;
    }
  }, [searchValue, filter]);

  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter((node) => node.value != item.value));
    if (item.value === "withExported") {
      delete filter.isExported;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.isExported;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withInventory") {
      delete filter.inventory;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.inventory;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withPrinted") {
      delete filter.isPrinted;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.isPrinted;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withSource") {
      delete filter.source;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.source;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withDateTime") {
      delete filter.after;
      delete filter.before;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.after;
      // @ts-ignore
      delete dataFilter.before;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withEstimateDeliveryDate") {
      delete filter.estimateDeliveryDate;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.estimateDeliveryDate;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
  };

  const handleVisibleChange = (visible) => {
    setFilterVisible(visible);
  };

  const handleCloseVisible = () => {
    setFilterType("withExported");
    setFilterVisible(false);
  };

  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value);
  };

  const onChangeTypeFilter = (e) => {
    setFilterType(e);
  };

  function handleMenuClick({ key }) {
    switch (key) {
      case "createDeliveryOrder":
        setIsVisible(true);
        return;
      default:
        break;
    }
  }

  const menu = (
    <Menu onClick={handleMenuClick}>
      <Menu.Item key="createDeliveryOrder">Tạo đơn xuất hàng</Menu.Item>
    </Menu>
  );

  const content = (
    <Form form={form} onFinish={onFinish} style={{ width: 300, maxWidth: 300 }}>
      <p>Hiển thị tất cả sản phẩm theo</p>
      <Form.Item name="filterType" style={{ marginBottom: 0 }}>
        <Selector
          onChange={onChangeTypeFilter}
          options={Mocks.DELIVERY_ORDER.filterOptions}
        />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      {filterType === "withDateTime" ? (
        <Form.Item
          name="filterDate"
          rules={[{ required: true, message: "Vui lòng lựa chọn thời gian" }]}
          required
        >
          <RangePicker />
        </Form.Item>
      ) : filterType === "withEstimateDeliveryDate" ? (
        <Form.Item
          name="filterDate2"
          rules={[{ required: true, message: "Vui lòng lựa chọn thời gian" }]}
          required
        >
          <DatePicker style={{ width: "100%" }} />
        </Form.Item>
      ) : (
        <Form.Item
          name="filterValue"
          rules={[
            { required: true, message: "Vui lòng chọn thông tin để lọc" },
          ]}
        >
          <Selector
            mode={
              Mocks.DELIVERY_ORDER.optionMultiple.includes(filterType)
                ? "multiple"
                : null
            }
            options={getOptionFilter(filterType)}
            placeholder="Chọn điều kiện lọc"
          />
        </Form.Item>
      )}

      <Form.Item style={{ display: "flex", justifyContent: "space-between" }}>
        <Button onClick={handleCloseVisible} style={{ marginRight: 10 }}>
          Huỷ
        </Button>
        <Button htmlType="submit" type="primary">
          Thêm điều kiện lọc
        </Button>
      </Form.Item>
    </Form>
  );

  const handleChangeIsCreate = (e) => {
    if (e.target.value === "update") {
      setIsUpdate(true);
      form2.setFieldsValue({
        name: localFilterOrders.find((item) => item.key === tabSelected)
          ? tabSelected
          : null,
      });
      return;
    }
    setIsUpdate(false);
    form2.setFieldsValue({
      name: "",
    });
  };

  function onFinishModal(values) {
    const arr = [...localFilterOrders];
    const newFilter = {
      name: values.name,
      key: Helpers.getKey(values.name),
      filter: dataFilter,
    };
    if (values.isCreate === "update") {
      const itemUpdateIndex = arr.findIndex(
        (item) => item.key === newFilter.key
      );
      newFilter.name = arr[itemUpdateIndex].name;
      arr[itemUpdateIndex] = newFilter;
      Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
        return onReloadData(newFilter);
      });
      form2.resetFields();
      setIsUpdateFilter(false);
      return;
    }
    if (arr.find((item) => item.key === newFilter.key)) {
      notification["warning"]({
        message: "Thông báo",
        description: `Bộ lọc đã tồn tại vui lòng kiểm tra và thử lại`,
      });
      return;
    }
    arr.push(newFilter);
    Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
      return onReloadData(newFilter);
    });
    form2.resetFields();
    setIsUpdateFilter(false);
  }

  function handleCancel() {
    setIsUpdateFilter(false);
  }

  function handleAddFilterToLocal() {
    setIsUpdateFilter(true);
  }

  function onSubmit(values) {
    console.log(values);
  }

  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title={"Thêm điều kiện lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>
              Thêm điều kiện lọc
            </Button>
          </Popover>
        </Col>
        <Col span={listFilter.length ? 15 : 18}>
          <Input
            value={searchValue}
            onChange={onChangeSearchValue}
            allowClear
            placeholder={"Tìm kiếm theo mã đơn hàng..."}
          />
        </Col>
        {listFilter.length ? (
          <Col span={3}>
            <Button
              onClick={handleAddFilterToLocal}
              style={{ width: "100%" }}
              icon={<FilterOutlined />}
            >
              Lưu bộ lọc
            </Button>
          </Col>
        ) : null}
      </Row>

      <Row style={{ margin: "15px 0" }} gutter={24}>
        <Col span={24}>
          <Radio.Group
            options={listinventoryOption}
            onChange={onChangeInventory}
            value={filter.inventory}
            optionType="button"
            buttonStyle="solid"
          />
        </Col>
      </Row>

      {listFilter.length ? (
        <Row style={{ margin: "15px 0" }} gutter={24}>
          <Col span={24}>
            {Helpers.getUnique(listFilter, "value").map((item, index) => {
              return (
                <Tag
                  key={index}
                  closable
                  onClose={(e) => handleRemoveFilter(e, item)}
                >
                  {item.label}
                </Tag>
              );
            })}
          </Col>
        </Row>
      ) : null}

      <Modal
        title="Lưu bộ lọc"
        visible={isUpdateFilter}
        onOk={form2.submit}
        onCancel={handleCancel}
      >
        <Form
          name="addFilter"
          form={form2}
          onFinish={onFinishModal}
          layout="vertical"
        >
          <Form.Item name="isCreate">
            <Radio.Group onChange={handleChangeIsCreate}>
              <Space direction="vertical">
                <Radio value="create">Tạo mới bộ lọc</Radio>
                <Radio value="update">Lưu đè lên bộ lọc đã tồn tại</Radio>
              </Space>
            </Radio.Group>
          </Form.Item>
          <Form.Item
            label={isUpdate ? "Chọn bộ lọc" : "Tên bộ lọc"}
            name="name"
            rules={[
              {
                required: true,
                message: `${
                  isUpdate ? "Vui lòng chọn bộ lọc" : "Vui lòng nhập tên bộ lọc"
                }`,
              },
            ]}
          >
            {isUpdate ? (
              <Selector
                options={localFilterOrders.map((item) => ({
                  label: item.name,
                  value: item.key,
                }))}
                placeholder="Chọn bộ lọc"
              />
            ) : (
              <Input placeholder="Nhập tên bộ lọc" />
            )}
          </Form.Item>
        </Form>
      </Modal>

      <div style={{ marginTop: 10, display: "flex" }}>
        {selectedItems.length ? (
          <div style={{ marginRight: 10 }}>
            <Dropdown overlay={menu} trigger={["click"]}>
              <Button>
                Chọn thao tác ({selectedItems.length} đơn hàng) <DownOutlined />
              </Button>
            </Dropdown>
            <Button
              onClick={() => setSelectedItems([])}
              style={{ marginLeft: 10 }}
            >
              Bỏ chọn tất cả
            </Button>
          </div>
        ) : null}
      </div>
      <ModalCreateDeliveryOrder
        visible={isVisible}
        onSubmit={onSubmit}
        handleCancel={() => setIsVisible(false)}
        setIsvisible={setIsVisible}
        selectedItems={selectedItems}
        inventory={filter.inventory}
      />
    </div>
  );
}
