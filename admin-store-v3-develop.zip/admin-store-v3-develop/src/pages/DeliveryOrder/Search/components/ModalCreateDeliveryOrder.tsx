import { Button, Modal, Popconfirm, Form, Radio, Input, message } from "antd";
import React from "react";
import { orEmpty } from "utils/Selector";
import { FullfillmentOrders as FullfillmentOrdersAPI } from "api";
interface IModalCreateDeliveryOrder {
  visible: boolean;
  onSubmit: (params) => void;
  handleCancel: () => void;
  setIsvisible: any;
  selectedItems: any;
  inventory: string;
}

const ModalCreateDeliveryOrder: React.FC<IModalCreateDeliveryOrder> = (
  props
) => {
  const {
    visible,
    onSubmit,
    handleCancel,
    setIsvisible,
    selectedItems,
    inventory,
  } = props;

  const [form] = Form.useForm();

  const renderSuccess = () => {
    message.success({
      content: (
        <span>
          Gửi xuất đơn hàng thành công. <a href={`/delivery-order/job`}>Kiểm tra trạng thái</a>
        </span>
      ),
      className: "custom-class",
    });
  };

  const renderError = () => {
    message.error("Gửi xuất đơn hàng thất bại. Vui lòng thử lại sau");
  };

  async function exportOrder(params) {
    try {
      const response = await FullfillmentOrdersAPI.exportOrder(params);
      if (response) {
        renderSuccess();
      }
    } catch (error) {
      console.log(error);
      renderError();
    }
  }

  const handleSubmit = (values) => {
    form.setFieldsValue({
      name: "",
    });
    const params = {
      inventory: inventory,
      name: orEmpty("name", values),
      ids: selectedItems.map((item) => item.id),
    };
    exportOrder(params);
    setIsvisible(false);
  };
  return (
    <Modal
      title="Change Status Active"
      visible={visible}
      footer={[
        <Button key="back" onClick={handleCancel}>
          Hủy
        </Button>,
        <Popconfirm
          key="save"
          placement="bottom"
          title={"Bạn chắc chắn muốn tạo đơn xuất hàng"}
          onConfirm={form.submit}
          okText="Đồng ý"
          cancelText="Huỷ"
        >
          <Button key="submit" type="primary">
            Lưu
          </Button>
        </Popconfirm>,
      ]}
    >
      <Form layout="vertical" form={form} onFinish={handleSubmit}>
        <Form.Item name="name" label="Ghi chú">
          <Input />
        </Form.Item>
      </Form>
    </Modal>
  );
};
export default ModalCreateDeliveryOrder;
