import moment from "moment";
import React, { useMemo, useState } from "react";
import ReactExport from "react-export-excel";
import { Helpers, Mocks } from "utils";
import { orArray, orEmpty, orNumber } from "utils/Selector";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;


export default function ExportExcel(props) {
    const { orders } = props
    const [orderExport, setOrderExport] = useState([])

    useMemo(() => {
        if (orders) {
            const dataTable = orders.map(item => ({
                orderCode: orEmpty("order.code", item),
                shippingCustomerName: orEmpty("shippingAddress.customerName", item),
                shippingCustomerPhone: orEmpty("shippingAddress.customerPhone", item),
                shippingCustomerAddress: `${orEmpty("shippingAddress.address", item)}, ${orEmpty("shippingAddress.wardName", item)}, ${orEmpty("shippingAddress.districtName", item)},  ${orEmpty("shippingAddress.provinceName", item)}`,
                province: orEmpty("shippingAddress.provinceName", item),
                // @ts-ignore
                products: `${orArray("order.orderItems", item).map((item) => `${orEmpty("quantity", item)}-${orEmpty("productName", item)} ${orEmpty("variantName", item)}\n`)}`.replaceAll(",", ""),
                revenue: Helpers.currencyFormatVND(orNumber("order.totalItemPrice", item) - orNumber("order.discountPrice", item)),
                shippingFee: Helpers.currencyFormatVND(orNumber("order.shippingFee", item)),
                source: orEmpty("order.source", item),
                sellerNote: orEmpty("order.adminNote", item),
                // @ts-ignore
                orderTags: `${orArray("order.tags", item).map((item) => `${orEmpty("name", item)}\n`)}`.replaceAll(",", ""),
                seller: orEmpty("seller.name", item),
                sellerAcceptAt: moment(orEmpty("order.sellerAcceptedAt", item)).format("DD/MM/YYYY"),
                upsaleValue: Helpers.currencyFormatVND(orNumber("order.upsaleValue", item)),
                orderStatus: Mocks.ORDER.getOrderStatus(orEmpty("order.status", item)),
                fulfillmentStatus: Mocks.TRANSPORTS.getFulfillmentStatus(orEmpty("status", item)),
                deliveryCompany: orEmpty("deliveryCompany", item),
                fulfillmentCode: orEmpty("fulfillmentCode", item),
                fulfillmentCreatedAt: moment(orEmpty("createdAt", item)).format("DD/MM/YYYY"),
            }))
            setOrderExport(dataTable)
        }
    }, [orders])

    return (
        <ExcelFile element={<span>Xuất file đơn hàng</span>}>
            <ExcelSheet data={orderExport} name="Đơn hàng">
                <ExcelColumn label="Mã đơn hàng" value="orderCode" />
                <ExcelColumn label="Tên khách hàng" value="shippingCustomerName" />
                <ExcelColumn label="Số điện thoại" value="shippingCustomerPhone" />
                <ExcelColumn label="Địa chỉ" value="shippingCustomerAddress" />
                <ExcelColumn label="Tỉnh/TP giao hàng" value="province" />
                <ExcelColumn label="Sản phẩm" value="products" />
                <ExcelColumn label="Doanh thu" value="revenue" />
                <ExcelColumn label="Phí ship" value="shippingFee" />
                <ExcelColumn label="Nguồn" value="source" />
                <ExcelColumn label="Ghi chú" value="sellerNote" />
                <ExcelColumn label="Tag" value="orderTags" />
                <ExcelColumn label="Seller" value="seller" />
                <ExcelColumn label="Thời gian seller nhận đơn" value="sellerAcceptAt" />
                <ExcelColumn label="Giá trị upsale" value="upsaleValue" />
                <ExcelColumn label="Trạng thái đơn" value="orderStatus" />
                <ExcelColumn label="Trạng thái giao hàng" value="fulfillmentStatus" />
                <ExcelColumn label="Nhà vận chuyển" value="deliveryCompany" />
                <ExcelColumn label="Mã vận đơn" value="fulfillmentCode" />
                <ExcelColumn label="Ngày tạo vận đơn" value="fulfillmentCreatedAt" />
            </ExcelSheet>
        </ExcelFile>
    );

}