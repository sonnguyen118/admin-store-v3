import moment from "moment";
import React, { useMemo, useState } from "react";
import ReactExport from "react-export-excel";
import { Helpers, Mocks } from "utils";
import { orArray, orEmpty, orNumber } from "utils/Selector";

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;
const ExcelColumn = ReactExport.ExcelFile.ExcelColumn;


export default function ExportExcelCollation(props) {
    const { orders } = props
    const [orderExport, setOrderExport] = useState([])

    function getTotalPrice(product) {
        if (orNumber("campaignPriceSale", product)) {
            return orNumber("campaignPrice", product)
        }
        return orNumber("orderItemPrice", product)
    }

    useMemo(() => {
        if (orders) {
            const arr = []
            orders.forEach((order) => {
                orArray("order.orderItems", order).forEach((product) => {
                    const data = {
                        orderCode: orEmpty("order.code", order),
                        fulfillmentCode: orEmpty("fulfillmentCode", order),
                        productName: `${orEmpty("productName", product)} - ${orEmpty("variantName", product)}`,
                        quantity: orNumber("quantity", product),
                        price: orNumber("price", product),
                        discountPrice: orNumber("campaignPriceSale", product),
                        totalPrice: getTotalPrice(product),
                        deliveryCompany: orEmpty("deliveryCompany", order),
                        fulfillmentCreatedAt: moment(orEmpty("createdAt", order)).format("MM/DD/YYYY HH:mm"),
                        totalCOD: orEmpty("codAmount", order),
                        status: Mocks.TRANSPORTS.getFulfillmentStatus(orEmpty("status", order)),
                        inventory: orEmpty("inventory.name", order),
                        paymentGateway: Mocks.ORDER.getPaymentGatewayDescription(orEmpty("order.paymentGateway", order)),
                        note: orEmpty("order.adminNote", order),
                    }
                    arr.push(data)
                })
            })
            setOrderExport(arr)
        }
    }, [orders])

    return (
        <ExcelFile filename={`file đối soát ${moment().format("DD/MM/YYYY")}`} element={<span>Xuất file đối soát</span>}>
            <ExcelSheet data={orderExport} name="Đơn hàng">
                <ExcelColumn label="Mã đơn hàng" value="orderCode" />
                <ExcelColumn label="Mã vận đơn" value="fulfillmentCode" />
                <ExcelColumn label="Tên sản phẩm" value="productName" />
                <ExcelColumn label="Số lượng" value="quantity" />
                <ExcelColumn label="Đơn giá" value="price" />
                <ExcelColumn label="Tổng giảm giá từng sản phẩm" value="discountPrice" />
                <ExcelColumn label="Tổng tiền" value="totalPrice" />
                <ExcelColumn label="NVC" value="deliveryCompany" />
                <ExcelColumn label="Ngày tạo vận đơn" value="fulfillmentCreatedAt" />
                <ExcelColumn label="Kho" value="inventory" />
                <ExcelColumn label="Tổng COD" value="totalCOD" />
                <ExcelColumn label="Trạng thái giao hàng" value="status" />
                <ExcelColumn label="Phương thức thanh toán" value="paymentGateway" />
                <ExcelColumn label="Ghi chú" value="note" />
            </ExcelSheet>
        </ExcelFile>
    );

}