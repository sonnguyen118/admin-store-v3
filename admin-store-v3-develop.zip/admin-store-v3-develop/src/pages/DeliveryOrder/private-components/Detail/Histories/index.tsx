import {
    Button,
    Card,
    Form,
    Input,
    Timeline,
    Typography
} from "antd";
import { useEffect } from "react";
import { orEmpty } from "utils/Selector";
import {
    UserOutlined,
    SendOutlined
} from '@ant-design/icons';
import moment from "moment";

const { Text } = Typography
const { Item } = Form;

export default function Histories(props) {
    moment.locale('vi')
    const { item, handleCreateLog, logs } = props
    const [form] = Form.useForm();

    function onFinish(values) {
        handleCreateLog({ id: orEmpty("id", item), ...values })
        form.setFieldsValue({
            message: "",
        });
    }



    return (
        <Card title="Lịch sử" className="bill-order-detail-main-note">
            <Timeline>
                <Timeline.Item dot={<UserOutlined style={{ fontSize: '16px' }} />}>
                    <Form
                        form={form}
                        onFinish={onFinish}
                        className="bill-order-detail-main-note-form bill-order-log-form"
                    >
                        <Item
                            name="message"
                            required
                            rules={[{ required: true, message: 'Vui lòng thêm nội dung ghi chú' }]}
                            className="bill-order-logs-form-item"
                        >
                            <Input placeholder="Thêm nội dung ghi chú" />

                            {/* <Button htmlType="submit">Lưu ghi chú</Button> */}

                        </Item>
                        <Item className="bill-order-logs-form-item">
                            <Button htmlType="submit" type="primary" icon={<SendOutlined />} />
                        </Item>

                    </Form>
                    <div style={{ marginTop: 15 }} >
                        <Text className="date-text" strong>{moment().format('l')}</Text>
                    </div>

                </Timeline.Item>
                {logs.length
                    ?
                    logs.map((item, key) => {
                        return (
                            <Timeline.Item key={key}>
                                <div style={{ width: "100%", display: "flex", justifyContent: "space-between" }}>
                                    <div>{item.message}</div>
                                    <div>{moment(item.createdAt).format('DD/MM/YYYY hh:mm a')}</div>
                                </div>

                            </Timeline.Item>
                        )
                    })
                    :
                    null
                }
            </Timeline>
        </Card>
    );
}
