import "./styled.scss"
import { Row, Col, Space } from "antd"
import Header from "./Header"
import ShippingNote from "./ShippingNote"
import Products from "./Products"
import DeliveryInfo from "./DeliveryInfo"
import DeliveryTime from "./DeliveryTime"
import Tags from "./Tags"
import Note from "./Note"
import Histories from "./Histories"
import { useState, useEffect } from "react"
import CodReceipt from "./CodReceipt"
import { orBoolean, orEmpty, orNull } from "utils/Selector"
import OrderInfo from "./OrderInfo";
import SellerInfo from "./SellerInfo";
export default function Detail(props) {
    const { item, handleBack, onUpdateTransport, onUpdateTransportData, onReceiptCod, logs, handleCreateLog, onReorderFulfillment, user } = props
    const [tags, setTags] = useState([]);
    const roleDisable = ["SELLER", "SELLER_HOTLINE"]
    const roleUser = orEmpty("role", user)

    const renderHeader = () => {
        return (
            <Header item={item} handleBack={handleBack} user={user} />
        )
    }

    const renderShippingNote = () => {
        return (
            <ShippingNote
                item={item}
                handleUpdateTransport={onUpdateTransportData}
                onReorderFulfillment={onReorderFulfillment}
                user={user}
            />
        )
    }

    const renderProducts = () => {
        return (
            <Products item={item} />
        )
    }
    const renderDeliveryInfo = () => {
        return (
            <DeliveryInfo item={item} />
        )
    }

    const renderSellerInfo = () => {
        return <SellerInfo item={item} />
    }

    const renderDeliveryTime = () => {
        return (
            <DeliveryTime item={item} />
        )
    }
    const renderTags = () => {
        return (
            <Tags tags={tags} setTags={setTags} item={item} handleUpdateTransport={onUpdateTransport} />
        )
    }
    const renderCodReceipt = () => {
        return (
            <CodReceipt item={item} onReceiptCod={onReceiptCod} />
        )
    }

    const renderHistories = () => {
        return (
            <Histories item={item} logs={logs} handleCreateLog={handleCreateLog} />
        )
    }

    const renderOrderInfo = () => {
        return <OrderInfo item={orNull("order", item)} />;
    };

    return (
        <div className="bill-order-detail">
            {renderHeader()}
            <Row gutter={24}>
                <Col span={18}>
                    <Space className="bill-order-detail-main" direction="vertical">
                        {renderShippingNote()}
                        {renderOrderInfo()}
                        {renderProducts()}
                        {renderHistories()}
                    </Space>
                </Col>
                <Col span={6}>
                    <Space className="bill-order-detail-sidebar" direction="vertical">
                        {!roleDisable.includes(roleUser) ? renderTags() : null}
                        {renderDeliveryInfo()}
                        {renderDeliveryTime()}
                        {item && item.seller ? renderSellerInfo() : null}
                        {orBoolean("isCOD", item) && !roleDisable.includes(roleUser) ? renderCodReceipt() : null}
                    </Space>
                </Col>
            </Row>
        </div>
    );
}
