import { Button, Card, Form, notification } from "antd";
import { Selector } from "components";
import { useEffect, useMemo } from "react";
import { orArray, orEmpty } from "utils/Selector";
import { Mocks } from "utils";

const { Item } = Form;

export default function OrderTags(props) {
  const { item, handleUpdateTransport } = props;
  const [form] = Form.useForm();

  function onFinish(values) {
    handleUpdateTransport({ id: orEmpty("id", item), ...values });
  }

  useEffect(() => {
    if (orEmpty("fulfillmentCompany.slug", item) === "SHIP-LE") {
      form.setFieldsValue({
        status: orEmpty("status", item),
      });
      return;
    }
    form.setFieldsValue({
      status: null,
    });
  }, [orEmpty("status", item)]);

  const getStatusOption = () => {
    if (item) {
      const r = [];
      Mocks.TRANSPORTS.FulfillmentStatus.forEach((node) => {
        if (orEmpty("fulfillmentCompany.slug", item) === "SHIP-LE") {
          switch (orEmpty("status", item)) {
            case "READY_TO_PICK":
              const ReadyToPickStatus = ["READY_TO_PICK", "PICKING", "CANCELLED"]
              if (ReadyToPickStatus.includes(node.value)) {
                r.push(node);
              }
              return;
            case "PICKING":
              const PickingStatus = ["PICKING", "DELIVERING", "CANCELLED"]
              if (PickingStatus.includes(node.value)) {
                r.push(node);
              }
              return
            case "DELIVERING":
              const DeliveringStatus = ["DELIVERING", "DELIVERED", "REFUNDING"]
              if (DeliveringStatus.includes(node.value)) {
                r.push(node);
              }
              return
            case "REFUNDING":
              const RefundingStatus = ["REFUNDING", "REFUNDED"]
              if (RefundingStatus.includes(node.value)) {
                r.push(node);
              }
              return
            case "DELIVERED":
              const DeliveredStatus = ["DELIVERED"]
              if (DeliveredStatus.includes(node.value)) {
                r.push(node);
              }
              return
            case "CANCELLED":
              const CancelledStatus = ["CANCELLED"]
              if (CancelledStatus.includes(node.value)) {
                r.push(node);
              }
              return
            case "REFUNDED":
              const RefundedStatus = ["REFUNDED"]
              if (RefundedStatus.includes(node.value)) {
                r.push(node);
              }
              return
            default:
              break;
          }
        }
        if (orEmpty("status", item) === "READY_TO_PICK" || orEmpty("status", item) === "PICKING") {
          if (orArray("fulfillmentCompany.enableUpdateStatus", item).includes(node.value) && node.value === "CANCELLED") {
            r.push(node);
          }
        }
      });
      return r;
    }
  };

  function checkStatus(status) {
    switch (status) {
      case "CANCELLED":
        return true;
      case "DELIVERING":
        if (orEmpty("fulfillmentCompany.slug", item) != "SHIP-LE") {
          return true;
        }
        return false
      case "REFUNDING":
        if (orEmpty("fulfillmentCompany.slug", item) != "SHIP-LE") {
          return true;
        }
        return false
      case "DELIVERED":
        return true;
      case "REFUNDED":
        return true;
      default:
        return false;
    }
  }

  return (
    <Card
      title="Trạng thái giao hàng"
      className="bill-order-detail-main-tags bill-order-detail-sidebar-card"
    >
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        className="bill-order-detail-main-tags-form"
      >
        <Item
          rules={[{ required: true, message: "Vui lòng chọn trạng thái" }]}
          name="status"
        >
          <Selector
            disabled={checkStatus(orEmpty("status", item))}
            placeholder="Lựa chọn trạng thái"
            options={getStatusOption()}
          />
        </Item>
        <Item className="bill-order-detail-main-tags-form-item">
          <Button
            disabled={checkStatus(orEmpty("status", item))}
            htmlType="submit"
          >
            Cập nhật
          </Button>
        </Item>
      </Form>
    </Card>
  );
}
