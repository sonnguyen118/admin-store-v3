import {
    Card,
    Button,
    Typography,
    Modal,
    Space
} from "antd";
import { orBoolean, orEmpty, orNull } from "utils/Selector";
import { useEffect, useState } from "react";
import { CreateCustomer } from "components"
import {
    EditOutlined,
    PrinterFilled,
    CheckCircleTwoTone,
    ExclamationCircleOutlined
} from '@ant-design/icons';

const { Text } = Typography;
const { confirm } = Modal

export default function CodReceipt(props) {
    const { item, onReceiptCod } = props


    const handleReceiptCod = () => {
        onReceiptCod(orEmpty("id", item))
    }

    function checkStatusOrder() {
        return orEmpty("status", item) === "CANCELLED"
    }

    function showPaymentConfirm() {
        confirm({
            title: 'Xác nhận thu hộ !',
            icon: <ExclamationCircleOutlined />,
            content: 'Bạn xác nhận thu hộ cho đơn hàng này?',
            okText: 'Xác nhận',
            okType: 'primary',
            cancelText: 'Hủy',
            onOk() {
                handleReceiptCod()
            },
        });
    }

    return (
        <Card title={"Xác nhận thu hộ (COD)"} className="bill-order-detail-sidebar-card">

            {orBoolean("isFulfillmentReceipt", item)
                ?
                <Space>
                    <div><CheckCircleTwoTone twoToneColor="#52c41a" /> Thông tin nhận tiền đã được xác nhận</div>
                </Space>
                :
                <Button disabled={checkStatusOrder()} onClick={showPaymentConfirm} style={{ width: "100%" }} type="primary" size="large">
                    Xác nhận thu hộ
                </Button>
            }

        </Card>
    );
}
