import { useState, useEffect } from 'react';
import {
  Card,
  Table,
  Avatar
} from "antd";
import { orArray, orNull, orEmpty } from 'utils/Selector';
import { Helpers } from 'utils';
import config from "configs/env";

export default function Products(props) {
  const { item } = props

  const [rows, setRows] = useState([]);

  const columns = [
    {
      title: "Sản phẩm",
      dataIndex: "name",
      render(value, record) {
        return {
          props: {
            style: { padding: "0" }
          },
          children: (
            <div onClick={(e) => onPreviewProduct(e,orEmpty("slug", record))} style={{ cursor: "pointer", display: "flex" }}>
              {orNull("image", record) ? <Avatar style={{ marginRight: 10 }} shape="square" size={48} src={orEmpty("image", record)} /> : null}
              <div style={{ display: "flex", flexDirection: "column" }}>
                <a href={`${config.base_url}/chi-tiet-san-pham/${record.slug}`} target="_blank">{value}</a>
                <div>
                  Phiên bản: {orEmpty("variantName", record)}
                </div>
              </div>
            </div>
          )
        };
      }
    },
    {
      title: "Đơn giá",
      dataIndex: "price"
    },
    {
      title: "Số lượng",
      dataIndex: "quantity"
    },
    {
      title: "Thành tiền",
      dataIndex: "totalPrice"
    },
  ];

  function onPreviewProduct(e,slug) {
    e.preventDefault()
    if (slug) window.open(`${config.base_url}/chi-tiet-san-pham/${slug}`, '_blank').focus();
  }

  function onUpdateData(): void {
    if (orArray("items", item)) {
      const r = [] as any;
      orArray("items", item).forEach((node): void => {
        r.push({
          key: node.id,
          id: node.id,
          name: node.productName,
          image: node.productImage.url,
          slug: node.productSlug,
          price: Helpers.currencyFormatVND(node.price),
          quantity: node.quantity,
          variantName: node.variantName,
          totalPrice: Helpers.currencyFormatVND(node.price * node.quantity)
        });
      });
      setRows(r);
    }
  }

  useEffect(onUpdateData, [orArray("items", item)]);

  return (
    <Card title={null} style={{ padding: 20 }} className="bill-order-detail-main-products">
      <Table
        columns={columns}
        dataSource={rows}
      />
    </Card>
  );
}
