import {
    Card,
    Space,
    Typography
} from "antd";
import { EditOutlined } from '@ant-design/icons';
import { orEmpty, orNull } from "utils/Selector";
import { useEffect, useState } from "react";
import { CreateCustomer } from "components"
const { Text } = Typography;

export default function DeliveryInfo(props) {
    const { item } = props

    return (
        <Card title={"Thông tin giao hàng"} className="bill-order-detail-sidebar-card">
            <Space direction="vertical">
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {orEmpty("toAddress.customerName", item)}
                </Text>
                <Text copyable className="form-sidebar-customer-item-detail-info-text">
                    {orEmpty("toAddress.customerPhone", item)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {orEmpty("toAddress.customerEmail", item)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                    {`${orEmpty("toAddress.address", item) != "" ? orEmpty("toAddress.address", item) + "," : ""} ${orEmpty("toAddress.wardName", item)}, ${orEmpty("toAddress.districtName", item)}, ${orEmpty("toAddress.provinceName", item)}`}
                </Text>
            </Space>
        </Card>
    );
}
