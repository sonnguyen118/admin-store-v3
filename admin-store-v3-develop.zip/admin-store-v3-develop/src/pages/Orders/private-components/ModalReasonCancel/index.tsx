import React, { useState, useEffect } from "react";
import { Modal, Button, Form, Typography, Space, Input } from 'antd';
import { Selector } from "components"
import { Mocks } from "utils";

const { Text } = Typography

export default function ModalReasonCancel(props) {
    const [form] = Form.useForm();
    const { visible, onSubmit, handleCancel } = props
    const [isReasionMore, setIsReasionMore] = useState(false)

    const handleSubmit = (values) => {
        if (values.cancelReasonType != "OTHER") {
            const cancelReasonOption = Mocks.ORDER.CancelReasonOptions.find(item => item.value === values.cancelReasonType)
            const params = {
                cancelReasonType: cancelReasonOption.value,
                cancelReason: cancelReasonOption.label
            }
            onSubmit(params)
            return
        }
        onSubmit(values)
    }

    const onchangeReasion = (value) => {
        if (value === "OTHER") {
            setIsReasionMore(true)
            return
        }
        setIsReasionMore(false)
    }

    return (
        <Modal
            visible={visible}
            title="Chọn lý do hủy đơn"
            // onOk={handleSubmit}
            onCancel={handleCancel}
            footer={[
                <Button key="back" onClick={handleCancel}>
                    Hủy
                </Button>,
                <Button key="submit" type="primary" onClick={form.submit}>
                    Lưu
                </Button>
            ]}
        >
            <Form
                layout="vertical"
                form={form}
                onFinish={handleSubmit}
            >

                <Space direction="vertical">
                    <div>
                        <Text strong>
                            Bạn chỉ nên hủy đơn hàng trong trường hợp đơn hàng giả mạo, khách hàng thay đổi nhu cầu hoặc hết hàng.
                        </Text>
                    </div>
                    <div>
                        <Text strong>
                            Hủy bỏ một đơn đặt hàng thao tác không thể phục hồi lại.
                        </Text>
                    </div>
                    <Form.Item
                        name="cancelReasonType"
                        required
                        rules={[{ required: true, message: 'Vui lòng chọn lý do hủy đơn' }]}
                    >
                        <Selector onChange={onchangeReasion} options={Mocks.ORDER.getListCancelReasonOptions()} placeholder="Chọn Lý do hủy đơn" />
                    </Form.Item>
                    {isReasionMore
                        ?
                        <Form.Item
                            name="cancelReason"
                            rules={[{ required: true, message: 'Vui lòng nhập lý do hủy đơn' }]}
                        >
                            <Input autoFocus={true} placeholder="Nhập lý do hủy đơn hàng" />
                        </Form.Item>
                        :
                        null
                    }
                </Space>



            </Form>

        </Modal>
    );
}
