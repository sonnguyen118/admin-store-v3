import React, { useState, useEffect, useRef } from "react";
import CreatableSelect from "react-select/creatable";
import { OrderTags as OrderTagsAPI } from "api";
import {
  Col,
  Divider,
  Row,
  List as ListItem,
  Avatar,
  Form,
  Input,
  Button,
  Typography,
  Space,
  notification,
} from "antd";
import {
  EditOutlined,
  PrinterFilled,
  CloseCircleOutlined,
} from "@ant-design/icons";
import {
  Selector,
  CreateCustomer,
  ComponentToPrint as PrintOrder,
} from "components";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import ReactToPrint from "react-to-print";
import ModalReasonCancel from "../../ModalReasonCancel";
import orderReducer from "../../../Reducer";
import { withReducer } from "hoc";
import Helpers from "utils/Helpers";

const { Text } = Typography;

function ExpenContent({
  record,
  handleAssingneeSeller,
  tags,
  setTags,
  sellerOptions,
  onSave,
  onCancelOrder,
  handleUpdateShippingAddress,
  handleForwardSeller,
  isRoleSaleHotline,
}) {
  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const [isLoadingTag, setIsLoadingTag] = useState(false);
  const [visible, setVisible] = useState({
    cancelOrder: false,
    updateCustomer: false,
    customerInfo: orNull("shippingAddress", record),
  });

  const onFinish = (values) => {
    const tags = values.tags.map((item) => item.value);
    onSave({ ...values, tags: tags, id: record.id });
  };

  const onFinish2 = (values) => {
    if (record.sellerAcceptStatus === "ACCEPTED") {
      const body = {
        seller: values.sellerForward,
      };
      handleForwardSeller({ ...body, id: record.id });
      return;
    }
    handleAssingneeSeller({ ...values, id: record.id });
    form2.setFieldsValue({
      seller: "",
    });
  };

  function checkStatusOrder() {
    if (orBoolean("isSapoOrder", record)) {
      return false;
    }
    return orEmpty("status", record) !== "CANCELLED";
  }

  useEffect(() => {
    if (orArray("tags", record)) {
      const defaultTags = orArray("tags", record).map((item) => ({
        label: item.name,
        value: item.id,
      }));
      form.setFieldsValue({
        adminNote: orEmpty("adminNote", record),
        tags: defaultTags,
      });
    }
  }, [orArray("tags", record)]);

  useEffect(() => {
    if (orNull("seller.username", record)) {
      form2.setFieldsValue({
        seller: orEmpty("seller.username", record),
      });
    }
  }, [orNull("seller.username", record)]);

  const handleSubmit = (value) => {
    const body = {
      id: orEmpty("id", record),
      cancelReason:
        value.cancelReason === "more"
          ? value.cancelReasonMore
          : value.cancelReason,
    };
    onCancelOrder(body);
    handleCancel();
  };

  const handleCancel = () => {
    setVisible((prevState) => ({
      ...prevState,
      cancelOrder: false,
      updateCustomer: false,
    }));
  };

  const onSubmitUpdateCustomer = (values) => {
    handleUpdateShippingAddress({
      id: orEmpty("id", record),
      shippingAddress: values,
    });
    handleCancel();
  };

  const formatCreateLabel = (inputValue) => `Thêm mới... ${inputValue}`;

  async function handleCreate(inputValue: any) {
    try {
      setIsLoadingTag(true);
      const params = {
        name: inputValue,
        isActive: true,
      };
      const response = await OrderTagsAPI.createOrderTag(params);
      const { data, status } = response;
      if (status === 200) {
        const listTag = [];
        setIsLoadingTag(false);
        const tag = {
          value: data.data.id,
          label: data.data.name,
        };
        listTag.push(tag);
        setTags((prevState) => prevState.concat(listTag));
        form.setFieldsValue({
          tags: form.getFieldsValue()["tags"].concat(listTag),
        });
        return;
      }
    } catch (error) {
      setIsLoadingTag(false);
      notification["error"]({
        message: "Không thể tạo tag mới",
        description:
          "Có lỗi xảy ra trong quá trình tạo mới tag, vui lòng kiểm tra và thử lại!",
      });
    }
  }

  const componentRef = useRef<HTMLDivElement>(null);

  const ComponentToPrint = () => {
    const itemPrint = {
      code: record.code,
      customerName: orEmpty("shippingAddress.customerName", record),
      address: orEmpty("shippingAddress.address", record),
      wardName: orEmpty("shippingAddress.wardName", record),
      districtName: orEmpty("shippingAddress.districtName", record),
      provinceName: orEmpty("shippingAddress.provinceName", record),
      customerPhone: orEmpty("shippingAddress.customerPhone", record),
      fulfillmentCompany: orEmpty(
        "fulfillmentOrder.fulfillmentCompany",
        record
      ),
      shippingType: orEmpty("shippingType", record),
      cashByRecipient: orBoolean("fulfillmentOrder.cashByRecipient", record),
      enableReviewBefore: orBoolean(
        "fulfillmentOrder.enableReviewBefore",
        record
      ),
      paymentGateway: orEmpty("paymentGateway", record),
      totalPrice: orNumber("totalPrice", record),
      orderItems: orArray("orderItems", record),
      customerNote: orEmpty("customerNote", record),
    };
    return <PrintOrder item={itemPrint} />;
  };

  const getOptionsForwardSeller = () => {
    if (record.sellerForward) {
      return sellerOptions.filter(
        (item) => item.value != orEmpty("sellerForward.username", record)
      );
    } else {
      return sellerOptions.filter(
        (item) => item.value != orEmpty("seller.username", record)
      );
    }
  };

  const checkDisableForward = (status, sellerAcceptStatus?: string) => {
    const arrStatus = ["COMPLETED", "CANCELLED", "SHIPPING"];
    const arrSellerAcceptStatus = ["ACCEPTED"];
    if (arrStatus.includes(status)) {
      return true;
    }
    if (arrSellerAcceptStatus.includes(sellerAcceptStatus)) {
      return true;
    }
    return false;
  };

  return (
    <div>
      <Row gutter={24}>
        <Col span={24}>
          <Form
            layout="vertical"
            form={form2}
            className="form-wrapper"
            onFinish={onFinish2}
          >
            {record.sellerAcceptStatus === "ACCEPTED" ? (
              <div style={{ width: "100%", display: "flex" }}>
                <Text>Chuyển tiếp đơn cho Seller khác xử lý:</Text>
                <div style={{ width: "250px", margin: "0 10px" }}>
                  <Form.Item
                    style={{ marginBottom: 0 }}
                    name="sellerForward"
                    rules={[
                      { required: true, message: "Vui lòng chọn seller" },
                    ]}
                    required
                  >
                    <Selector
                      options={getOptionsForwardSeller()}
                      placeholder="Chọn Seller"
                      allowClear={true}
                      disabled={
                        checkDisableForward(orEmpty("status", record)) ||
                        isRoleSaleHotline ||
                        orBoolean("isSapoOrder", record)
                      }
                    />
                  </Form.Item>
                </div>
                <Form.Item
                  style={{ marginBottom: 0 }}
                  className="form-item-button"
                >
                  <Button
                    htmlType="submit"
                    disabled={
                      checkDisableForward(orEmpty("status", record)) ||
                      isRoleSaleHotline ||
                      orBoolean("isSapoOrder", record)
                    }
                    type="primary"
                  >
                    Lưu
                  </Button>
                </Form.Item>
              </div>
            ) : (
              <div style={{ width: "100%", display: "flex" }}>
                <Text>Chọn Seller:</Text>
                <div style={{ width: "250px", margin: "0 10px" }}>
                  <Form.Item
                    style={{ marginBottom: 0 }}
                    name="seller"
                    rules={[
                      { required: true, message: "Vui lòng chọn seller" },
                    ]}
                    required
                  >
                    <Selector
                      options={sellerOptions}
                      placeholder="Chọn Seller"
                      allowClear={true}
                      disabled={
                        checkDisableForward(
                          orEmpty("status", record),
                          orEmpty("sellerAcceptStatus", record)
                        ) ||
                        isRoleSaleHotline ||
                        orBoolean("isSapoOrder", record)
                      }
                    />
                  </Form.Item>
                </div>
                <Form.Item
                  style={{ marginBottom: 0 }}
                  className="form-item-button"
                >
                  <Button
                    htmlType="submit"
                    disabled={
                      checkDisableForward(
                        orEmpty("status", record),
                        orEmpty("sellerAcceptStatus", record)
                      ) ||
                      isRoleSaleHotline ||
                      orBoolean("isSapoOrder", record)
                    }
                    type="primary"
                  >
                    Lưu
                  </Button>
                </Form.Item>
              </div>
            )}
          </Form>
        </Col>
      </Row>
      <Divider />
      <Row gutter={24}>
        <Col span={8}>
          <ListItem
            className="list-item-wrapper"
            dataSource={record.orderItems}
            renderItem={(item, index) => (
              <ListItem.Item className="item-wrapper" key={index}>
                <ListItem.Item.Meta
                  avatar={
                    <Avatar size={48} src={orEmpty("productImage.url", item)} />
                  }
                  title={
                    <Text className="item-title" strong>
                      {orEmpty("productName", item)}
                    </Text>
                  }
                  description={
                    <Space size={0} direction="vertical">
                      <Text className="item-variant" type="secondary">
                        Phiên bản: {orEmpty("variantName", item)}
                      </Text>
                    </Space>
                  }
                />
                <div>x{orEmpty("quantity", item)}</div>
              </ListItem.Item>
            )}
          />
          <div className="total-money">
            <Text className="total-money-text" strong>
              Tổng: {Helpers.currencyFormatVND(record.totalPrice)}
            </Text>
          </div>
        </Col>
        <Col span={8} className="info-customer-wrapper">
          <div className="info-customer-title">
            <Text className="info-customer-title-text" strong>
              Thông tin giao hàng
            </Text>
            {isRoleSaleHotline || orBoolean("isSapoOrder", record) ? null : (
              <EditOutlined
                onClick={() =>
                  setVisible((prevState) => ({
                    ...prevState,
                    updateCustomer: true,
                  }))
                }
                className="info-customer-title-icon"
              />
            )}
          </div>
          <div className="info-customer-content">
            <div className="info-customer-content-name">
              <span>{orEmpty("shippingAddress.customerName", record)}</span>
              <span>{orEmpty("shippingAddress.customerPhone", record)}</span>
            </div>

            {orEmpty("shippingAddress.customerEmail", record) != "" ? (
              <p>{orEmpty("shippingAddress.customerEmail", record)}</p>
            ) : null}

            <p>{`${
              orEmpty("shippingAddress.address", record) != ""
                ? orEmpty("shippingAddress.address", record) + ","
                : ""
            } ${orEmpty("shippingAddress.wardName", record)}, ${orEmpty(
              "shippingAddress.provinceName",
              record
            )}, ${orEmpty("shippingAddress.districtName", record)}`}</p>
          </div>
        </Col>
        <Col span={8}>
          <Form
            layout="vertical"
            form={form}
            className="form-wrapper"
            onFinish={onFinish}
          >
            <Form.Item label="Ghi chú" name="adminNote">
              <Input.TextArea
                disabled={orBoolean("isSapoOrder", record)}
                rows={4}
                placeholder="Ghi chú đơn hàng"
              />
            </Form.Item>
            <Form.Item label="Nhãn" name="tags">
              <CreatableSelect
                isClearable
                options={tags}
                isDisabled={isLoadingTag || orBoolean("isSapoOrder", record)}
                isLoading={isLoadingTag}
                formatCreateLabel={formatCreateLabel}
                onCreateOption={handleCreate}
                isMulti
                placeholder={"Chọn nhãn"}
              />
            </Form.Item>
            {checkStatusOrder() ? (
              <Form.Item className="form-item-button">
                <Button
                  disabled={orBoolean("isSapoOrder", record)}
                  htmlType="submit"
                  type="primary"
                >
                  Lưu
                </Button>
              </Form.Item>
            ) : null}
          </Form>
        </Col>
      </Row>
      <Divider />
      <Row gutter={24}>
        <Col span={24}>
          <ReactToPrint
            removeAfterPrint={true}
            trigger={() => (
              <Button type="text">
                <PrinterFilled /> In đơn hàng
              </Button>
            )}
            content={() => componentRef.current}
          />
          {checkStatusOrder() ? (
            <Button
              type="text"
              onClick={() =>
                setVisible((prevState) => ({
                  ...prevState,
                  cancelOrder: true,
                }))
              }
            >
              <CloseCircleOutlined /> Huỷ đơn hàng
            </Button>
          ) : null}
          <div ref={componentRef}>
            <ComponentToPrint />
          </div>
        </Col>
      </Row>
      <ModalReasonCancel
        visible={visible.cancelOrder}
        onSubmit={handleSubmit}
        handleCancel={handleCancel}
      />
      <CreateCustomer
        item={visible.customerInfo}
        visible={visible.updateCustomer}
        onCancel={handleCancel}
        onSubmit={onSubmitUpdateCustomer}
      />
    </div>
  );
}
export default withReducer({
  key: "orderExpanTableReducer",
  ...orderReducer,
})(ExpenContent);
