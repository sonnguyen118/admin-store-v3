import React, { useState, useEffect } from "react";
import { Radio, Table as AntTable, Typography } from "antd";
import { CaretRightOutlined, CaretDownOutlined } from "@ant-design/icons";
import moment from "moment";
import { orBoolean, orEmpty } from "utils/Selector";
import orderReducer from "../../Reducer";
import { withReducer } from "hoc";
import ExpanContent from "./ExpanContent";
import OrderStatus from "components/Status/OrderStatus";
import { Helpers, Mocks } from "utils";
import env from "configs/env";

const { Text } = Typography;

function Table(props) {
  const {
    rows,
    filter,
    total,
    action,
    dispatch,
    state,
    onRefreshData,
    setListItemSelected,
    listSeller,
    listOrderTag,
    isSeller = false,
    onChangePage,
    tabSelected,
    onDetailOrder,
    user,
    keySelectTed,
  } = props;
  const isRoleSaleHotline = Mocks.ORDER.roleDisableAction.includes(
    orEmpty("role", user)
  );

  const [sellerOptions, setSellerOptions] = useState([]);
  const [assigneeBody, setAssigneeBody] = useState({
    seller: null,
    orderId: null,
  });
  const [tags, setTags] = useState([]);
  const [selectedItems, setSelectedItems] = useState([]);
  const [expandItems, setExpandItems] = useState([]);

  useEffect(() => {
    if (listOrderTag) {
      const listOrderTagOption = listOrderTag.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setTags(listOrderTagOption);
    }
  }, [listOrderTag]);

  function onGetClassName(status, isLink?: boolean) {
    switch (status) {
      case "COMPLETED":
        return "order-completed-color";
      case "CANCELLED":
        return "order-cancel-color";
      default:
        if (isLink) {
          return "order-normal-color";
        }
        return "";
    }
  }

  const renderSellerProcessStep = (value, record) => {
    const isPending = record.sellerAcceptedForwardStatus === "PENDING";
    const isRejected = record.sellerAcceptedForwardStatus === "REJECTED";
    const isCancelled = record.status === "CANCELLED";

    return (
      <div style={{ display: "flex", flexDirection: "column" }}>
        {isPending ? (
          <Text
            strong
            className={onGetClassName(record.status)}
            style={{ color: !isCancelled ? "#FA8C16" : null }}
          >
            Chờ xác nhận chuyển tiếp
          </Text>
        ) : isRejected ? (
          <Text
            strong
            className={onGetClassName(record.status)}
            style={{ color: !isCancelled ? "#FC625D" : null }}
          >
            Chuyển tiếp đơn bị từ chối
          </Text>
        ) : value ? (
          <Text
            strong
            className={onGetClassName(record.status)}
            style={{ color: !isCancelled ? value.color : null }}
          >
            {value.name}
          </Text>
        ) : (
          <Text
            strong
            className={onGetClassName(record.status)}
            style={{ color: !isCancelled ? "#FA8C16" : null }}
          >
            Chưa xác nhận
          </Text>
        )}
      </div>
    );
  };

  const columns = [
    {
      title: "Mã đơn hàng",
      dataIndex: "code",
      render: (value, record) => {
        const isWaiting =
          keySelectTed === "isWaitingProduct" ||
          keySelectTed === "isFullProduct";
        const now = moment(moment(new Date()).format("YYYY-MM-DDT00:00:00"));
        const end = moment(
          moment(orEmpty("waitingProductAt", record)).format(
            "YYYY-MM-DDT00:00:00"
          )
        );
        const days = now.diff(end, "days");
        return (
          <a
            style={{
              display: "flex",
              cursor: "pointer",
              flexDirection: "column",
            }}
            onClick={(e) => onDetailOrder(e, record.code)}
            href={`${isSeller ? "/orders-seller" : "/orders"}/detail/${
              record.code
            }`}
          >
            <Text className={onGetClassName(record.status, true)}>{value}</Text>
            <Text className={onGetClassName(record.status)}>
              ({record.source})
            </Text>
            {isWaiting ? (
              <Text
                strong
                type={
                  days > 0 && days <= 3
                    ? "success"
                    : days > 3 && days <= 6
                    ? "warning"
                    : days > 6
                    ? "danger"
                    : "success"
                }
              >
                {days} ngày chờ hàng về
              </Text>
            ) : null}
          </a>
        );
      },
    },
    {
      title: "Ngày tạo",
      dataIndex: "createdAt",
      render: (value, record) => (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Text className={onGetClassName(record.status)}>
            {value ? moment(value).format("DD/MM/YYYY") : "---"}
          </Text>
          <Text className={onGetClassName(record.status)}>
            {value ? moment(value).format("LT") : ""}
          </Text>
        </div>
      ),
    },
    {
      title: "Khách hàng",
      dataIndex: "shippingAddress",
      render: (value, record) => (
        <a
          onClick={(e) => onDetailOrder(e, record.code)}
          href={`${isSeller ? "/orders-seller" : "/orders"}/detail/${
            record.code
          }`}
          style={{ display: "flex", flexDirection: "column" }}
        >
          <Text className={onGetClassName(record.status)}>
            {orEmpty("customerName", value)}
          </Text>
          <Text className={onGetClassName(record.status)}>
            {orEmpty("customerPhone", value)}
          </Text>
        </a>
      ),
    },
    {
      title: "Seller",
      dataIndex: "seller",
      render: (value, record) => (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Text className={onGetClassName(record.status)}>
            {record.sellerForward
              ? record.sellerForward.name
              : value
              ? value.name
              : "---"}
          </Text>
          <Text className={onGetClassName(record.status)}>
            {record.sellerForwardAt
              ? moment(record.sellerForwardAt).format("DD/MM/YYYY")
              : record.sellerAssigneeAt
              ? moment(record.sellerAssigneeAt).format("DD/MM/YYYY")
              : ""}
          </Text>
        </div>
      ),
    },
    {
      title: "TN Seller",
      dataIndex: "sellerProcessStep",
      render: (value, record) => renderSellerProcessStep(value, record),
    },
    {
      title: "TT Đơn hàng",
      dataIndex: "status",
      render: (value) => <OrderStatus value={value} />,
    },
    {
      title: "Tổng tiền",
      dataIndex: "totalPrice",
      render: (value, record) => (
        <div className={onGetClassName(record.status)}>
          {Helpers.currencyFormatVND(value)}
        </div>
      ),
    },
  ];

  useEffect(() => {
    if (listSeller) {
      const listSellerOption = listSeller.map((item) => ({
        label: item.name,
        value: item.username,
      }));
      setSellerOptions(listSellerOption);
    }
  }, [listSeller]);

  const onChangeSeller = (value, id) => {
    setAssigneeBody({
      seller: value,
      orderId: id,
    });
  };

  const handleAssingneeSeller = (params) => {
    const { id, ...body } = params;
    action.orderTableReducer.onAssingneeSeller(
      id,
      body,
      dispatch.orderTableReducer
    );
  };

  const handleForwardSeller = (params) => {
    const { id, ...body } = params;
    action.orderTableReducer.onForwardSeller(
      id,
      body,
      dispatch.orderTableReducer
    );
  };

  const onCancelOrder = (params) => {
    const { id, ...body } = params;
    action.orderTableReducer.onCancelOrder(
      id,
      body,
      dispatch.orderTableReducer
    );
    setExpandItems(expandItems.filter((item) => item.id != id));
  };

  const onUpdateShippingAddress = (params) => {
    const { id, ...body } = params;
    action.orderTableReducer.updateOrder(id, body, dispatch.orderTableReducer);
  };

  const onRefresh = () => {
    if (orBoolean("orderTableReducer.isRefresh", state)) {
      onRefreshData();
    }
  };

  useEffect(onRefresh, [orBoolean("orderTableReducer.isRefresh", state)]);

  function onSave(values) {
    const { id, ...body } = values;
    action.orderTableReducer.onUpdateOrderNoteAndTag(
      id,
      body,
      dispatch.orderTableReducer
    );
  }

  const expanContent = (record) => {
    return (
      <ExpanContent
        onChangeSeller={onChangeSeller}
        record={record}
        assigneeBody={assigneeBody}
        handleAssingneeSeller={handleAssingneeSeller}
        handleForwardSeller={handleForwardSeller}
        tags={tags}
        setTags={setTags}
        sellerOptions={sellerOptions}
        onSave={onSave}
        onCancelOrder={onCancelOrder}
        handleUpdateShippingAddress={onUpdateShippingAddress}
        isRoleSaleHotline={isRoleSaleHotline}
      />
    );
  };

  const rowSelection = {
    selectedRowKeys: selectedItems.map((item) => orEmpty("key", item)),
    getCheckboxProps: (record) => ({
      disabled: isRoleSaleHotline || record.isSapoOrder,
    }),
    onSelect: (record, selected) => {
      if (selected) {
        const r = selectedItems.slice();
        r.push(record);
        setSelectedItems(r);
        return;
      } else {
        setSelectedItems((prevState) =>
          prevState.filter((item) => item.id != record.id)
        );
      }
    },
    onSelectAll: (selected, selectedRows, changeRows) => {
      if (selected) {
        const r = selectedItems.slice();
        setSelectedItems(r.concat(selectedRows).filter((item) => item));
        return;
      } else {
        const r = selectedItems.slice();
        const data = [];
        r.forEach((e) => {
          const result = changeRows.find((item) => item.key === e.key);
          if (!result) {
            data.push(e);
            return;
          }
        });
        setSelectedItems(data);
      }
    },
  };

  useEffect(() => {
    if (selectedItems) {
      setListItemSelected(selectedItems);
    }
  }, [selectedItems]);

  const handleExpandItem = (expanded, record) => {
    if (expanded) {
      var arrayExpandItem = expandItems.slice();
      arrayExpandItem.push(record);
      setExpandItems(arrayExpandItem);
      return;
    }
    setExpandItems(expandItems.filter((item) => item.id != record.id));
  };

  function showTotal(total) {
    return `Tổng: ${total}`;
  }

  function getRowClassName(record) {
    if (
      keySelectTed === "isWaitingProduct" ||
      keySelectTed === "isFullProduct"
    ) {
      // if (days >= 0 && days <= 3) {
      //   return "order-normal-row";
      // } else if (days > 3 && days <= 6) {
      //   return "order-warning-row";
      // } else if (days > 6) {
      //   return "order-danger-row";
      // }
      return "";
    } else {
      if (record.status === "CANCELLED") {
        return "order-cancel-row";
      } else if (record.status === "COMPLETED") {
        return "order-completed-row";
      }
    }
    return "";
  }

  return (
    <AntTable
      expandable={{
        expandedRowRender: (record) =>
          !isSeller ? expanContent(record) : false,
        expandIcon: ({ expanded, onExpand, record }) =>
          isSeller ? (
            false
          ) : expanded ? (
            <CaretDownOutlined
              style={{ color: "black" }}
              onClick={(e) => onExpand(record, e)}
            />
          ) : (
            <CaretRightOutlined
              style={{ color: "black" }}
              onClick={(e) => onExpand(record, e)}
            />
          ),
        expandedRowKeys: expandItems.map((item) => item.id),
        onExpand: (expanded, record) => handleExpandItem(expanded, record),
      }}
      columns={columns}
      dataSource={rows}
      rowSelection={rowSelection}
      // rowClassName={(record) =>
      //   record.status === "CANCELLED"
      //     ? "order-cancel-row"
      //     : record.status === "COMPLETED"
      //     ? "order-completed-row"
      //     : ""
      // }
      rowClassName={(record) => getRowClassName(record)}
      pagination={
        keySelectTed != "isWaitingProduct" && keySelectTed != "isFullProduct"
          ? {
              defaultPageSize: filter.pageSize,
              defaultCurrent: filter.page,
              current: filter.page,
              showSizeChanger: false,
              total: total,
              onChange: (page) => onChangePage(page, tabSelected),
              showTotal: showTotal,
            }
          : false
      }
    />
  );
}

export default withReducer({
  key: "orderTableReducer",
  ...orderReducer,
})(Table);
