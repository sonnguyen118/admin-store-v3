import { useRef } from "react";
import {
  Button,
  Col,
  Row,
  Space,
  Typography,
  Dropdown,
  Menu,
  Divider,
  notification,
} from "antd";
import { DownOutlined, PrinterFilled } from "@ant-design/icons";
import { orEmpty, orArray, orBoolean, orNull, orNumber } from "utils/Selector";
import moment from "moment";
import ReactToPrint from "react-to-print";
import OrderStatus from "components/Status/OrderStatus";
import PaymentStatus from "components/Status/PaymentStatus";
import { useHistory } from "react-router-dom";
import { ComponentToPrint as PrintOrder } from "components";

const { Title, Text } = Typography;

const printPageStyle = `
  @page { size: auto;  margin: 5mm; }
  @media print {
    body { 
      -webkit-print-color-adjust: exact;
      page-break-after: auto;
    }
    html, body { 
      -webkit-print-color-adjust: exact;
      height: initial !important; 
      overflow: initial !important; 
    }
  }
  @media print { body { -webkit-print-color-adjust: exact; } }
`;

export default function Header(props) {
  const history = useHistory();
  const componentRef = useRef<HTMLDivElement>(null);
  const {
    handleBack,
    item,
    showDeleteConfirm,
    onReOrder,
    isAdmin,
    user,
    isRoleSaleHotline,
    customer,
  } = props;
  // const  = orEmpty("role", user) === "SELLER_HOTLINE";

  function handleMenuClick({ key }) {
    switch (key) {
      case "reOrder":
        onReOrder();
        return;
      case "cancelOrder":
        if (orNull("fulfillmentOrder", item)) {
          if (
            orEmpty("fulfillmentOrder.fulfillmentCompany.slug", item) ===
            "SHIP-LE"
          ) {
            switch (orEmpty("fulfillmentOrder.status", item)) {
              case "DELIVERING":
                notification["warning"]({
                  message: "Thông báo",
                  description:
                    "Đơn hàng đã được tạo mã vận chuyển, liên hệ Kho tổng để tiếp tục xử lý đơn",
                });
                return;
              default:
                showDeleteConfirm();
                break;
            }
            return;
          }
          switch (orEmpty("fulfillmentOrder.status", item)) {
            case "READY_TO_PICK":
              showDeleteConfirm();
              return;
            case "CANCELLED":
              showDeleteConfirm();
              return;
            default:
              notification["warning"]({
                message: "Thông báo",
                description:
                  "Đơn hàng đã được tạo mã vận chuyển, liên hệ Kho tổng để tiếp tục xử lý đơn",
              });
              break;
          }
          return;
        }
        showDeleteConfirm();
        return;
      case "createReturns":
        if (
          orNull("fulfillmentOrderRefund", item) &&
          !orBoolean("fulfillmentOrderRefund.isCancelled", item)
        ) {
          notification["warning"]({
            message: "Thông báo",
            description: "Đã có vận đơn trả hàng!",
          });
          return;
        }
        const now = moment(moment(new Date()).format("YYYY-MM-DDT00:00:00"));
        const end = moment(
          moment(orEmpty("completedAt", item)).format("YYYY-MM-DDT00:00:00")
        );
        const days = now.diff(end, "days");
        if (days > 60) {
          notification["warning"]({
            message: "Thông báo",
            description: "Chỉ có thể trả lại đơn hàng trong vòng 60 ngày",
          });
          return;
        }
        if (
          !orNull("shippingAddress.districtId", item) &&
          !orNull("shippingAddress.provinceId", item) &&
          !orNull("shippingAddress.wardId", item)
        ) {
          notification["warning"]({
            message: "Thông báo",
            description: "Vui lòng cập nhật địa chỉ khách hàng!",
          });
          return;
        }
        history.push(`/orders/${item.code}/create/refund`);

        break;
      case "createCompensation":
        if (
          orNull("fulfillmentOrderCompensation", item) &&
          !orBoolean("fulfillmentOrderCompensation.isCancelled", item)
        ) {
          notification["warning"]({
            message: "Thông báo",
            description: "Đã có vận đơn bù hàng!",
          });
          return;
        }
        if (
          !orNull("shippingAddress.districtId", item) &&
          !orNull("shippingAddress.provinceId", item) &&
          !orNull("shippingAddress.wardId", item)
        ) {
          notification["warning"]({
            message: "Thông báo",
            description: "Vui lòng cập nhật địa chỉ khách hàng!",
          });
          return;
        }
        history.push(`/orders/${item.code}/create/compensation`);
        break;
      default:
        break;
    }
  }

  function checkStatusOrder() {
    const listStatus = ["COMPLETED", "CANCELLED"];
    if (orBoolean("isSapoOrder", item)) {
      return false;
    }
    return !listStatus.includes(orEmpty("status", item));
  }

  const checkStatusCompensation = () => {
    const listStatus = ["COMPLETED", "DELIVERING"];
    return (
      orBoolean("isSapoOrder", item) &&
      listStatus.includes(orEmpty("status", item))
    );
  };

  const checkStatusCreateReturn = () => {
    return (
      orBoolean("isSapoOrder", item) && orEmpty("status", item) === "COMPLETED"
    );
  };

  const menu = (
    <Menu onClick={handleMenuClick}>
      <Menu.Item key="reOrder">
        <Text strong>Đặt lại</Text>
      </Menu.Item>
      {checkStatusOrder() ? (
        <Menu.Item key="cancelOrder">
          <Text strong>Huỷ đơn hàng</Text>
        </Menu.Item>
      ) : null}
      {checkStatusCreateReturn() ? (
        <Menu.Item key="createReturns">
          <Text strong>Tạo vận đơn trả hàng</Text>
        </Menu.Item>
      ) : null}
      {checkStatusCompensation() ? (
        <Menu.Item key="createCompensation">
          <Text strong>Tạo vận đơn bù</Text>
        </Menu.Item>
      ) : null}
    </Menu>
  );

  const ComponentToPrint = () => {
    if (item) {
      const itemPrint = {
        orderCode: orEmpty("code", item),
        customerName: orEmpty("shippingAddress.customerName", item),
        address: orEmpty("shippingAddress.address", item),
        wardName: orEmpty("shippingAddress.wardName", item),
        districtName: orEmpty("shippingAddress.districtName", item),
        provinceName: orEmpty("shippingAddress.provinceName", item),
        customerPhone: orEmpty("shippingAddress.customerPhone", item),
        fulfillmentCompany: orEmpty(
          "fulfillmentOrder.fulfillmentCompany",
          item
        ),
        shippingType: orEmpty("shippingType", item),
        cashByRecipient: orBoolean("fulfillmentOrder.cashByRecipient", item),
        enableReviewBefore: orBoolean(
          "fulfillmentOrder.enableReviewBefore",
          item
        ),
        paymentGateway: orEmpty("paymentGateway", item),
        totalPrice: orNumber("totalPrice", item),
        orderItems: orArray("orderItems", item),
        customerNote: orEmpty("customerNote", item),
      };
      return <PrintOrder item={itemPrint} />;
    }
    return <div></div>;
  };
  return (
    <Row gutter={24} className="order-detail-header">
      <Col span={16} className="order-detail-header-title">
        <Title level={4}>
          Đơn hàng {orEmpty("code", item)}{" "}
          {orBoolean("isUpsale", item) ? (
            <span>
              (Upsale từ đơn hàng{" "}
              <span
                onClick={() =>
                  history.push(
                    `/orders/detail/${orEmpty("refUpsaleOrderCode", item)}`
                  )
                }
                style={{ color: "#1890ff", cursor: "pointer" }}
              >
                {orEmpty("refUpsaleOrderCode", item)}
              </span>
              )
            </span>
          ) : null}
        </Title>
      </Col>
      <Col span={8} className="order-detail-header-action">
        {isAdmin && !isRoleSaleHotline ? (
          <Dropdown
            className="order-detail-header-action-dropdown"
            overlay={menu}
            trigger={["click"]}
          >
            <Text strong>
              Thao tác <DownOutlined />
            </Text>
          </Dropdown>
        ) : !isAdmin ? (
          <Dropdown
            className="order-detail-header-action-dropdown"
            overlay={menu}
            trigger={["click"]}
          >
            <Text strong>
              Thao tác <DownOutlined />
            </Text>
          </Dropdown>
        ) : null}

        <ReactToPrint
          pageStyle={printPageStyle}
          removeAfterPrint={true}
          trigger={() => (
            <Button ghost className="order-detail-header-action-print">
              <PrinterFilled /> In đơn hàng
            </Button>
          )}
          content={() => componentRef.current}
        />
        <Button
          onClick={handleBack}
          className="order-detail-header-action-back"
        >
          Quay lại
        </Button>
      </Col>
      <Col span={14} className="order-detail-header-info">
        <Space
          className="order-detail-header-info-space"
          split={<Divider type="vertical" />}
        >
          <div className="order-detail-header-info-space-item">
            <Text type="secondary">Mã đơn hàng</Text>
            <Text strong copyable={{ tooltips: false }}>
              {orEmpty("code", item)}
            </Text>
          </div>
          <div className="order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái đơn hàng</Text>
            <OrderStatus value={orEmpty("status", item)} />
          </div>
          <div className="order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái thanh toán</Text>
            <PaymentStatus value={orEmpty("paymentStatus", item)} />
          </div>
        </Space>
      </Col>
      <Col span={14} className="order-detail-header-info-2">
        <Space size={20}>
          <div>
            Thời gian đặt:{" "}
            {moment(orEmpty("createdAt", item)).format("DD/MM/YYYY hh:mm A")}
          </div>
          <div>Kênh bán hàng: {orEmpty("source", item)}</div>
        </Space>
      </Col>
      <div ref={componentRef}>
        <ComponentToPrint />
      </div>
    </Row>
  );
}
