import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  Col,
  Form,
  Input,
  Row,
  Space,
  message,
  Avatar,
  Table,
  notification,
  Typography,
} from "antd";
import { Selector } from "components";
import { orArray, orBoolean, orEmpty, orNull } from "utils/Selector";

const { Item } = Form;
const { Text } = Typography;

export default function SellerAction(props) {
  const {
    sellerOptions,
    handleAssigneeSeller,
    item,
    handleAcceptProcess,
    handleRejectProcess,
    handleOnProcessResult,
    user,
    isRoleSaleHotline
  } = props;
  const [form] = Form.useForm();

  function checkUser() {
    return orEmpty("username", user) !== orEmpty("seller.username", item);
  }

  function checkStatusOrder() {
    return orEmpty("status", item) === "CANCELLED";
  }

  function onFinish(values) {
    handleAssigneeSeller(values);
  }

  function onFinishProcessStep(values) {
    handleOnProcessResult({
      ...values,
      processStep: orEmpty("sellerProcessStep.id", item),
      id: orEmpty("id", item),
    });
    form.setFieldsValue({
      processResult: null,
    });
  }

  function onRejectProcess() {
    handleRejectProcess(orEmpty("id", item));
  }

  function onAcceptProcess() {
    handleAcceptProcess(orEmpty("id", item));
  }

  const renderChooseSellerForm = () => {
    return (
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        className="order-detail-main-note-form"
      >
        <Item
          name="seller"
          label="Chọn Seller"
          required
          rules={[{ required: true, message: "Vui lòng chọn Seller" }]}
        >
          <Selector
            disabled={checkStatusOrder() || isRoleSaleHotline || orBoolean("isSapoOrder", item)}
            placeholder="Chọn Seller"
            options={sellerOptions}
          />
        </Item>

        <Item className="order-detail-main-note-form-item">
          <Button disabled={checkStatusOrder() || isRoleSaleHotline || orBoolean("isSapoOrder", item)} htmlType="submit">
            Lưu
          </Button>
        </Item>

      </Form>
    );
  };

  const renderSellerAcceptForm = () => {
    return (
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        className="order-detail-main-note-form"
      >
        <Text>Đơn hàng được gắn cho seller: </Text>
        <br />
        <Text strong>{orEmpty("seller.name", item)}</Text>

        <div>
          <Text>Vui lòng xác nhận xử lý</Text>
        </div>

        {!checkStatusOrder() ? (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginTop: 15,
            }}
          >
            <Button disabled={checkUser()} onClick={onRejectProcess}>
              Không nhận
            </Button>
            <Button
              disabled={checkUser()}
              onClick={onAcceptProcess}
              type="primary"
            >
              Nhận xử lý
            </Button>
          </div>
        ) : null}
      </Form>
    );
  };

  const getResultProcessStep = () => {
    if (orNull("sellerProcessStep", item)) {
      if (orEmpty("paymentStatus", item) === "PAID") {
        return orArray("sellerProcessStep.results", item)
          .filter((i) => !i.isPendingPayment)
          .map((item) => ({
            label: item.name,
            value: item.id,
          }));
      }
      return orArray("sellerProcessStep.results", item).map((item) => ({
        label: item.name,
        value: item.id,
      }));
    }
    return []
  };

  const renderSellerActionForm = () => {
    return (
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinishProcessStep}
        className="order-detail-main-note-form"
      >
        <Text>Đơn hàng được gắn cho seller: </Text>
        <br />
        <Text strong>{orEmpty("seller.name", item)}</Text>

        <div style={{ marginTop: 15 }}>
          <Text>Đã nhận xử lý</Text>
        </div>

        <div style={{ marginTop: 15 }}>
          <Text>Tác Nghiệp tiếp theo: </Text>
          <br />
          <Text strong>{orEmpty("sellerProcessStep.name", item)}</Text>
        </div>

        {getResultProcessStep().length > 0 ? (
          <div style={{ marginTop: 15 }}>
            <Item
              name="processResult"
              label="Kết quả"
              required
              rules={[{ required: true, message: "Vui lòng chọn kết quả" }]}
            >
              <Selector
                disabled={checkUser() || checkStatusOrder()}
                placeholder="Kết quả"
                options={getResultProcessStep()}
              />
            </Item>

            <Item className="order-detail-main-note-form-item">
              <Button
                disabled={checkUser() || checkStatusOrder()}
                htmlType="submit"
              >
                Lưu
              </Button>
            </Item>
          </div>
        ) : null}
      </Form>
    );
  };

  return (
    <Card
      title="Tác nghiệp Seller"
      className="order-detail-main-note order-detail-sidebar-card"
    >
      {orEmpty("sellerAcceptStatus", item) === "NONE"
        ? renderChooseSellerForm()
        : orEmpty("sellerAcceptStatus", item) === "PENDING"
          ? renderSellerAcceptForm()
          : orEmpty("sellerAcceptStatus", item) === "ACCEPTED"
            ? renderSellerActionForm()
            : null}
    </Card>
  );
}
