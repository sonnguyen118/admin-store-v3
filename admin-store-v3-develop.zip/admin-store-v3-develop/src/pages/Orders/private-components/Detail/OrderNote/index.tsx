import { Button, Card, Form, Input, Typography } from "antd";
import { useEffect } from "react";
import { orBoolean, orEmpty } from "utils/Selector";

const { Item } = Form;
const { Text } = Typography;

export default function OrderNote(props) {
  const { item, handleUpdateOrder, isRoleSaleHotline, user } = props;
  const [form] = Form.useForm();

  function onFinish(values) {
    handleUpdateOrder({ id: orEmpty("id", item), ...values });
    // handleAssigneeSeller(values)
  }

  function onSetupForm() {
    if (item) {
      form.setFieldsValue({
        adminNote: item.adminNote,
      });
      return;
    }
  }

  function checkUser() {
    return orEmpty("username", user) === orEmpty("seller.username", item);
  }

  function checkStatusOrder() {
    if (checkUser()) {
      if (!orBoolean("isConfirmed", item)) {
        return true;
      }
      if (orBoolean("isSellerProcessCompleted", item)) {
        return true;
      }
      return false;
    }
    return true;
  }

  // function checkStatusOrder() {
  //   if (isRoleSaleHotline) {
  //     return isRoleSaleHotline;
  //   }
  //   return orEmpty("status", item) === "CANCELLED";
  // }

  useEffect(() => {
    onSetupForm();
  }, [item]);

  return (
    <Card title="Ghi chú đơn hàng" className="order-detail-main-note">
      <Form
        layout="vertical"
        form={form}
        onFinish={onFinish}
        className="order-detail-main-note-form"
      >
        <Item>
          <Text strong>Ghi chú của khách hàng: </Text>{" "}
          <Text>{orEmpty("customerNote", item)}</Text>
        </Item>
        <Item
          name="adminNote"
          required
          rules={[
            { required: true, message: "Vui lòng thêm ghi chú cho đơn hàng" },
          ]}
        >
          <Input.TextArea
            disabled={checkStatusOrder() || orBoolean("isSapoOrder", item)}
            rows={4}
            placeholder="Thêm ghi chú cho đơn hàng"
          />
        </Item>
        <Item className="order-detail-main-note-form-item">
          <Button
            disabled={checkStatusOrder() || orBoolean("isSapoOrder", item)}
            htmlType="submit"
          >
            Lưu ghi chú
          </Button>
        </Item>
      </Form>
    </Card>
  );
}
