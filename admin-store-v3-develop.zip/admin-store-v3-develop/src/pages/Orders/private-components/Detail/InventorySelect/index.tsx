import { Button, Card, Form, notification, Tag } from "antd";
import CreatableSelect from "react-select/creatable";
import { OrderTags as OrderTagsAPI } from "api";
import { SaveFilled } from "@ant-design/icons";
import { useEffect, useMemo, useState } from "react";
import { orArray, orBoolean, orEmpty } from "utils/Selector";
import { Selector, InventorySelector } from "components";

const { Item } = Form;

export default function InventorySelect(props) {
  const { item, listInventory, user, handleUpdateOrder } = props;

  const [fulfillmentCompany, setFulfillmentCompany] = useState(null);
  const [stateSee, setStateSee] = useState(false);
  const [listInventorySee, setListInventorySee] = useState(null);
  const [form] = Form.useForm();
  // const listInventoryOptions = useMemo(() => {
  //   return listInventory.map((item) => ({ value: item.id, label: item.name }));
  // }, [listInventory]);
  const listInventoryOptions = useMemo(() => {
    return listInventory.map((item) => ({
      value: item.id + "/" + item.fulfillmentCompany,
      label: (
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <span>{item.name}</span>
          <span>{item.shippingFee}</span>
        </div>
      ),
    }));
  }, [listInventory]);
  // const [isLoadingTag, setIsLoadingTag] = useState(false)

  // function onFinish(values) {
  //   handleUpdateOrder({ id: orEmpty("id", item), ...values });
  //   // console.log({ id: orEmpty("id", item), ...values }, "{ id: orEmpty");
  // }
  function onChangeInventory(value) {
    if (value && item?.code) {
      const [inventory, fulfillmentCompany] = value.split("/");
      const fc = fulfillmentCompany === "null" ? null : fulfillmentCompany;
      const filteredArr = listInventory.filter(
        (obj) => obj.id === inventory && obj.fulfillmentCompany === fc
      );
      const name = filteredArr.length > 0 ? filteredArr[0].shippingFee : "";
      const body = {
        inventory,
        fulfillmentCompany: fc,
        fulfillmentShippingFee: name,
      };
      // console.log(body, "body");
      handleUpdateOrder({ id: orEmpty("id", item), body });
    }
  }

  function checkUser() {
    return orEmpty("username", user) === orEmpty("seller.username", item);
  }

  function checkStatusOrder() {
    if (checkUser()) {
      if (!orBoolean("isConfirmed", item)) {
        return true;
      }
      if (orBoolean("isSellerProcessCompleted", item)) {
        return true;
      }
      return false;
    }
    return true;
  }
  useEffect(() => {
    if (item) {
      if (orBoolean("isSellerProcessCompleted", item)) {
        setStateSee(true);
        setListInventorySee([
          {
            value: 1,
            label: (
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  width: "100%",
                }}
              >
                <span>{item?.inventory.name}</span>
                <span>{item?.fulfillmentShippingFee}</span>
              </div>
            ),
          },
        ]);
      }
      form.setFieldsValue({
        inventory: orEmpty("inventory.id", item),
      });
      setFulfillmentCompany(item.fulfillmentCompany);
    }
  }, [item]);
  console.log(stateSee, "stateSee");
  // console.log(item?.inventory.name, "itemitem");
  // console.log(item?.fulfillmentOrder.fulfillmentCompany.name, "itemitem");
  return (
    <Card
      title="Kho xuất hàng"
      className="order-detail-main-note order-detail-sidebar-card"
    >
      {item && listInventoryOptions.length === 0 && (
        <Tag color="yellow" style={{ marginBottom: "10px" }}>
          Vui lòng chọn lại thông tin giao hàng
        </Tag>
      )}
      <Form
        layout="vertical"
        form={form}
        // onFinish={onFinish}
        className="order-detail-main-note-form"
      >
        <Item name="inventory">
          <InventorySelector
            onChange={onChangeInventory}
            options={listInventoryOptions}
            disabled={checkStatusOrder()}
            placeholder="Chọn kho xuất hàng"
            value="Chọn kho xuất hàng"
            fulfillmentCompany={fulfillmentCompany}
            stateSee={stateSee}
            listInventorySee={listInventorySee}
          />
        </Item>
        {/* <Item className="order-detail-main-note-form-item">
          <Button disabled={checkStatusOrder()} htmlType="submit">
            Lưu
          </Button>
        </Item> */}
      </Form>
    </Card>
  );
}
