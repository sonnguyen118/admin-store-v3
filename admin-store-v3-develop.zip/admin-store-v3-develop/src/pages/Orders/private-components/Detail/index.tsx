import "./styled.scss";
import { Col, Row, Space, Modal, Card, Typography } from "antd";
import Header from "./Header";
import Products from "./Products";
import OrderInfo from "./OrderInfo";
import OrderNote from "./OrderNote";
import SellerAction from "./SellerAction";
import DeliveryInfo from "./DeliveryInfo";
import DeliveryTime from "./DeliveryTime";
import InfoCustomer from "./InfoCustomer";
import OrderTags from "./OrderTags";
import OrderLogs from "./OrderLogs";
import { useEffect, useState } from "react";
import { orEmpty } from "utils/Selector";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import ModalReasonCancel from "../ModalReasonCancel";
import ForwardSeller from "./ForwardSeller";
import OrderCampaign from "./OrderCampaign";
import InventorySelect from "./InventorySelect";
import { Mocks } from "utils";

const { confirm } = Modal;
const { Text } = Typography;

export default function Detail(props) {
  const {
    handleBack,
    item,
    listOrderTag,
    listSeller,
    onAssigneeSeller,
    onAcceptProcess,
    onRejectProcess,
    onProcessResult,
    onCancelOrder,
    onReOrder,
    onUpdateOrder,
    onUpdateOrderNew,
    user,
    orderLogs,
    handleCreateOrderLog,
    onConfirmPayment,
    onConfirmPaymentFail,
    customer,
    onRejectForward,
    onAcceptForward,
    isAdmin = false,
    shippingFeeOptions,
    onSaveShippingFee,
    isRefresh,
    listCampaign,
    onUpdateCampaignForOrder,
    listCampaignOrder,
    listCurrentCampaign,
    listInventory,
  } = props;
  const [isDefault, setIsDefault] = useState(null);
  useEffect(() => {
    if (item) {
      if (item.status && item.status === "PENDING") {
        setIsDefault(false);
      } else {
        setIsDefault(true);
      }
    }
  }, [item]);

  const [sellerOptions, setSellerOptions] = useState([]);
  const [tags, setTags] = useState([]);
  const [isReasionCancel, setIsReasionCancel] = useState(false);
  const [campaignMoneyDiscount, setCampaignMoneyDiscount] = useState(null);

  const isRoleSaleHotline = Mocks.ORDER.roleDisableAction.includes(
    orEmpty("role", user)
  );

  useEffect(() => {
    if (listOrderTag) {
      const listOrderTagOption = listOrderTag.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setTags(listOrderTagOption);
    }
  }, [listOrderTag]);

  useEffect(() => {
    if (listSeller) {
      const listSellerOption = listSeller.map((item) => ({
        label: item.name,
        value: item.username,
      }));
      setSellerOptions(listSellerOption);
    }
  }, [listSeller]);

  const handleAssigneeSeller = (values) => {
    const body = {
      id: orEmpty("id", item),
      ...values,
    };
    onAssigneeSeller(body);
  };

  // const handleForwardSeller = (values) => {
  //   const body = {
  //     id: orEmpty("id", item),
  //     ...values,
  //   };
  //   onForwardSeller(body);
  // };

  const handleSubmit = (body) => {
    const params = {
      id: orEmpty("id", item),
      ...body,
    };
    onCancelOrder(params);
    setIsReasionCancel(false);
  };

  const handleCancel = () => {
    setIsReasionCancel(false);
  };

  function handleOnUpdateCampaignForOrder(body) {
    setCampaignMoneyDiscount(null);
    onUpdateCampaignForOrder(body);
  }
  return (
    <div className="order-detail">
      <Header
        isAdmin={isAdmin}
        user={user}
        item={item}
        handleBack={handleBack}
        showDeleteConfirm={() => setIsReasionCancel(true)}
        onReOrder={() => onReOrder(orEmpty("code", item))}
        isRoleSaleHotline={isRoleSaleHotline}
        customer={customer}
      />
      <Row gutter={24}>
        <Col span={18}>
          <Space className="order-detail-main" direction="vertical">
            <Products item={item} />
            <OrderInfo
              item={item}
              handleComfirmPayment={onConfirmPayment}
              onConfirmPaymentFail={onConfirmPaymentFail}
              handleUpdateOrder={onUpdateOrder}
              shippingFeeOptions={shippingFeeOptions}
              onSaveShippingFee={onSaveShippingFee}
              campaignMoneyDiscount={campaignMoneyDiscount}
              isRoleSaleHotline={isRoleSaleHotline}
              roleUser={orEmpty("role", user)}
            />
            <OrderCampaign
              item={item}
              user={user}
              listCampaign={listCampaign}
              onUpdateCampaignForOrder={handleOnUpdateCampaignForOrder}
              listCampaignOrder={listCampaignOrder}
              customer={customer}
              listCurrentCampaign={listCurrentCampaign}
              isAdmin={isAdmin}
              setCampaignMoneyDiscount={setCampaignMoneyDiscount}
              isRoleSaleHotline={isRoleSaleHotline}
            />
            <OrderNote
              item={item}
              handleUpdateOrder={onUpdateOrder}
              isRoleSaleHotline={isRoleSaleHotline}
              user={user}
            />
            <OrderLogs
              item={item}
              orderLogs={orderLogs}
              handleCreateOrderLog={handleCreateOrderLog}
              isRoleSaleHotline={isRoleSaleHotline}
              user={user}
            />
          </Space>
        </Col>
        <Col span={6}>
          <Space className="order-detail-sidebar" direction="vertical">
            {isAdmin &&
            orEmpty("sellerAcceptedForwardStatus", item) != "NONE" ? (
              <Card
                title="Xác nhận đơn chuyển tiếp"
                className="order-detail-main-note order-detail-sidebar-card"
              >
                <Text>Đơn hàng đang được chuyển tiếp cho seller: </Text>
                <br />
                <Text strong>{orEmpty("sellerForward.name", item)}</Text>
                <br />
                <div>
                  Trạng thái{" "}
                  <Text strong>
                    {orEmpty("sellerAcceptedForwardStatus", item) === "PENDING"
                      ? "Chờ xác nhận"
                      : orEmpty("sellerAcceptedForwardStatus", item) ===
                        "REJECTED"
                      ? "Đã từ chối"
                      : ""}
                  </Text>
                </div>
              </Card>
            ) : orEmpty("sellerAcceptedForwardStatus", item) ===
              "ACCEPTED" ? null : null}
            {orEmpty("sellerAcceptedForwardStatus", item) === "PENDING" ? (
              <ForwardSeller
                item={item}
                user={user}
                onRejectForward={onRejectForward}
                onAcceptForward={onAcceptForward}
                isRoleSaleHotline={isRoleSaleHotline}
              />
            ) : null}
            <SellerAction
              item={item}
              sellerOptions={sellerOptions}
              handleAssigneeSeller={handleAssigneeSeller}
              handleAcceptProcess={onAcceptProcess}
              handleRejectProcess={onRejectProcess}
              handleOnProcessResult={onProcessResult}
              user={user}
              isRoleSaleHotline={isRoleSaleHotline}
            />
            {isDefault ? (
              <InventorySelect
                item={item}
                listInventory={listInventory}
                user={user}
                handleUpdateOrder={onUpdateOrderNew}
              />
            ) : (
              <InventorySelect
                // item={""}
                listInventory={listInventory}
                user={user}
                handleUpdateOrder={onUpdateOrderNew}
              />
            )}

            <DeliveryInfo
              customer={customer}
              item={item}
              user={user}
              handleUpdateOrder={onUpdateOrder}
              shippingFeeOptions={shippingFeeOptions}
              onSaveShippingFee={onSaveShippingFee}
            />
            <DeliveryTime
              item={item}
              handleUpdateOrder={onUpdateOrder}
              user={user}
            />
            <InfoCustomer item={item} customer={customer} />
            <OrderTags
              tags={tags}
              setTags={setTags}
              item={item}
              handleUpdateOrder={onUpdateOrder}
              isRoleSaleHotline={isRoleSaleHotline}
              user={user}
            />
          </Space>
        </Col>
      </Row>
      <ModalReasonCancel
        visible={isReasionCancel}
        onSubmit={handleSubmit}
        handleCancel={handleCancel}
      />
    </div>
  );
}
