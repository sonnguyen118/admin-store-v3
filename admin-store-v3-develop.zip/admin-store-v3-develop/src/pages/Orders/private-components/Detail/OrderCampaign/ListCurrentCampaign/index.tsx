import { Popconfirm, Table, Typography } from "antd";
import moment from "moment";
import { orArray, orBoolean, orEmpty } from "utils/Selector";
import { DeleteFilled } from "@ant-design/icons";
import { useEffect, useMemo, useState } from "react";
import { Mocks } from "utils";
import ModalDetailCampaign from "../ModalDetailCampaign";
const { Text } = Typography;

const ListCampaignOrderUsed = (props) => {
  const {
    listCampaign,
    listCurrentCampaign,
    item,
    customer,
    onUpdateCampaignForOrder,
  } = props;

  const [campaignOrder, setCampaignOrder] = useState([]);
  const [detailCampaign, setDetailCampaign] = useState({
    isOpen: false,
    detail: null,
  });

  useEffect(() => {
    if (listCampaign && item && customer) {
      let listCurrentCampaign = [];
      listCampaign.filter((i) => {
        if (
          orArray("campaignIds", item).includes(
            orEmpty("descriptionCampaign.campaignId", i)
          )
        ) {
          return listCurrentCampaign.push(i);
        }
      });
      if (orBoolean("campaigns.isShineMemberApplied", item)) {
        const newCampaign = {
          selectCampaign: true,
          used: 0,
          voucherCode: null,
          voucherId: 0,
          descriptionCampaign: {
            campaignId: "ShineMember",
            campaignName: "khuyến mãi dành cho Shine member",
            channel: null,
            conditionUse: "",
            conditionUseGeneral: "",
            countUse: 0,
            expiryDate: orEmpty("memberEndTime", customer),
            listServiceProduct: null,
            maximumAmountReduction: null,
            minimumSpending: null,
            note: null,
            paymentMethods: null,
          },
          mktCampaign: {
            campaignMaxUsage: 0,
            endDate: orEmpty("memberEndTime", customer),
            id: "ShineMember",
            label: null,
            maxUsage: 1,
            name: null,
            startDate: orEmpty("memberStartTime", customer),
          },
        };
        setCampaignOrder([newCampaign].concat(listCurrentCampaign));
        return;
      }
      setCampaignOrder(listCurrentCampaign);
    }
  }, [listCampaign, item, customer]);

  function onRemoveCampaign(record) {
    const listCampaignApply = campaignOrder.filter(
      (item) => item.descriptionCampaign.campaignId !== "ShineMember"
    );
    if (record.descriptionCampaign.campaignId === "ShineMember") {
      const params = {
        id: orEmpty("id", item),
        isShineMemberApplied: false,
        campaignIds: listCampaignApply.map((item) => ({
          campaignId: orEmpty("descriptionCampaign.campaignId", item),
          voucherCode: orEmpty("descriptionCampaign.code", item),
        })),
      };
      onUpdateCampaignForOrder(params);
    } else {
      const params = {
        id: orEmpty("id", item),
        isShineMemberApplied: orBoolean("campaigns.isShineMemberApplied", item),
        campaignIds: listCampaignApply
          .filter(
            (item) =>
              item.descriptionCampaign.campaignId !==
              record.descriptionCampaign.campaignId
          )
          .map((item) => ({
            campaignId: orEmpty("descriptionCampaign.campaignId", item),
            voucherCode: orEmpty("descriptionCampaign.code", item),
          })),
      };
      onUpdateCampaignForOrder(params);
    }
  }

  const columns = [
    {
      title: "Tên Campaign (id)",
      dataIndex: "descriptionCampaign",
      render: (value, record) => {
        return (
          <div
            onClick={() => setDetailCampaign({ isOpen: true, detail: record })}
            style={{ display: "flex" }}
          >
            {value.campaignName}({value.campaignId})
          </div>
        );
      },
    },
    {
      title: "SL còn lại",
      dataIndex: "used",
      render: (value, record) => {
        if (orBoolean("isSellerProcessCompleted", item)) {
          return "";
        }
        return (
          <div>
            {record.descriptionCampaign.campaignId === "ShineMember"
              ? null
              : record.mktCampaign.maxUsage}
          </div>
        );
      },
    },
    {
      title: "Ngày kết thúc",
      dataIndex: "descriptionCampaign",
      render: (value, record) => {
        if (orBoolean("isSellerProcessCompleted", item)) {
          return "";
        }
        return (
          <div>
            {record.descriptionCampaign.campaignId === "ShineMember"
              ? null
              : orEmpty("expiryDate", value)
              ? moment(orEmpty("expiryDate", value)).format("DD-MM-YYYY")
              : null}
          </div>
        );
      },
    },
    {
      title: "",
      dataIndex: "message",
      render: (_, record) =>
        checkEndDate(record.mktCampaign.maxUsage, record.endDate),
    },
    {
      title: "Bỏ áp dụng",
      dataIndex: "key",
      active: true,
      render: (_, record) => {
        if (orBoolean("isSellerProcessCompleted", item)) {
          return "";
        }
        return (
          <div data-id="remove">
            <Popconfirm
              title="Bạn chắc chắn muốn xoá campaign này!"
              onConfirm={() => onRemoveCampaign(record)}
              okText="Xác nhận"
              cancelText="Huỷ"
            >
              <DeleteFilled />
            </Popconfirm>
          </div>
        );
      },
    },
  ];

  function checkEndDate(maxUsed, endDate) {
    if (orBoolean("isSellerProcessCompleted", item)) {
      return;
    }
    if (maxUsed <= 0) {
      return "Campaign đã hết số lần sử dụng";
    }
    var date = moment(endDate).add(1, "day");
    var now = moment();
    if (now > date) {
      return "Campaign đã quá ngày sử dụng";
    }
    return "";
  }

  const renderHeaderTable = () => {
    return (
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <div>
          <Text strong>Khuyến mãi đang được áp dụng vào đơn hàng</Text>
        </div>
      </div>
    );
  };

  return (
    <div>
      <Table
        columns={columns}
        dataSource={campaignOrder}
        pagination={false}
        title={renderHeaderTable}
      />
      <ModalDetailCampaign
        detailCampaign={detailCampaign}
        setDetailCampaign={setDetailCampaign}
      />
    </div>
  );
};

export default ListCampaignOrderUsed;
