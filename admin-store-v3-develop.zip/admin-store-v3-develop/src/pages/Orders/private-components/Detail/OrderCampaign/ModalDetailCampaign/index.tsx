import { Col, Modal, Row, Space, Table } from "antd";
import moment from "moment";
import { useMemo, useState } from "react";
import { Helpers, Mocks } from "utils";
import { orEmpty, orNull, orNumber } from "utils/Selector";

const ModalDetailCampaign = (props) => {
  const { detailCampaign, setDetailCampaign } = props;

  const rowModal = (title, content) => {
    return (
      <Row gutter={24}>
        <Col span={9}>{title}</Col>
        <Col span={15}>{content}</Col>
      </Row>
    );
  };

  const getMaxUsed = () => {
    if (
      orNumber("detail.descriptionCampaign.campaignId", detailCampaign) ===
      "ShineMember"
    ) {
      return "Không giới hạn";
    }
    return (
      orNumber("detail.mktCampaign.maxUsage", detailCampaign)
    );
  };

  return (
    <Modal
      title={`Khuyến mãi ${orEmpty(
        "detail.descriptionCampaign.campaignName",
        detailCampaign
      )}`}
      visible={detailCampaign.isOpen}
      footer={[]}
      onCancel={() => setDetailCampaign({ isOpen: false, detail: null })}
    >
      <Space direction="vertical" style={{ width: "100%" }}>
        {rowModal(
          "Tên khuyến mãi:",
          orEmpty("detail.descriptionCampaign.campaignName", detailCampaign)
        )}
        {rowModal(
          "Hạn sử dụng:",
          moment(
            orEmpty("detail.descriptionCampaign.expiryDate", detailCampaign)
          ).format("DD-MM-YYYY")
        )}
        {rowModal("Số lần sử dụng còn lại:", getMaxUsed())}
        {rowModal(
          "Điều kiện sử dụng:",
          orEmpty("detail.descriptionCampaign.conditionUse", detailCampaign)
        )}
        {orNumber(
          "detail.descriptionCampaign.maximumAmountReduction",
          detailCampaign
        )
          ? rowModal(
              "Tổng tiền giảm tối đa",
              Helpers.currencyFormatVND(
                orNumber(
                  "detail.descriptionCampaign.maximumAmountReduction",
                  detailCampaign
                )
              )
            )
          : null}
        <Row gutter={24}>
          <Col span={9}>Chi tiêu tối thiểu:</Col>
          <Col span={15}>
            {orNull(
              "detail.descriptionCampaign.minimumSpending.totalSpending",
              detailCampaign
            ) ? (
              <div>
                {Helpers.currencyFormatVND(
                  orNull(
                    "detail.descriptionCampaign.minimumSpending.totalSpending",
                    detailCampaign
                  )
                )}{" "}
                toàn bộ bill
              </div>
            ) : null}
            {orNull(
              "detail.descriptionCampaign.minimumSpending.productSpending",
              detailCampaign
            ) ? (
              <div>
                {Helpers.currencyFormatVND(
                  orNull(
                    "detail.descriptionCampaign.minimumSpending.productSpending",
                    detailCampaign
                  )
                )}{" "}
                trong sản phẩm
              </div>
            ) : null}
          </Col>
        </Row>
        {/* {rowModal(
                    "Điều kiện áp dụng:",
                    orEmpty(
                        "detail.conditionUseGeneral",
                        detailCampaign
                    ) === ""
                        ? `Campaign không được áp dụng cùng campaign khác`
                        : `Campaign được áp dụng cùng với ${orEmpty(
                            "detail.conditionUseGeneral",
                            detailCampaign
                        )}`
                )} */}
        {rowModal(
          "Ghi chú:",
          orEmpty("detail.descriptionCampaign.note", detailCampaign)
        )}
      </Space>
    </Modal>
  );
};

export default ModalDetailCampaign;
