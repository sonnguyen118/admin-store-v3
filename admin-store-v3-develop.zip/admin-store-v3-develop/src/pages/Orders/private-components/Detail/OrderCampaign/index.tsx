import { Col, Row, Card } from "antd";
import { useCallback, useMemo } from "react";
import { orArray, orBoolean, orEmpty } from "utils/Selector";

import ListCampaign from "./ListCampaign";
import ListCampaignOrderUsed from "./ListCampaignOrderUsed";
import ListCurrentCampaign from "./ListCurrentCampaign";

export default function OrderCampaign(props) {
  const {
    item,
    listCampaign,
    onUpdateCampaignForOrder,
    listCampaignOrder,
    user,
    setCampaignMoneyDiscount,
    customer,
    listCurrentCampaign,
    isAdmin,
    isRoleSaleHotline,
  } = props;

  const checkUser = useMemo(() => {
    return orEmpty("username", user) === orEmpty("seller.username", item);
  }, [user, item]);

  return (

    <Card title={"Thông tin khuyến mãi"} className="order-detail-main-info">
      <Row gutter={24} style={{ marginBottom: 8 }}>
        {orArray("listCampaign", listCampaign).length ||
        orBoolean("campaigns.isShineMemberApplied", item) ? (
          <Col span={24}>
            <ListCurrentCampaign
              listCampaign={orArray("listCampaign", listCampaign)}
              listCurrentCampaign={listCurrentCampaign}
              customer={customer}
              item={item}
              onUpdateCampaignForOrder={onUpdateCampaignForOrder}
            />
          </Col>
        ) : null}
        {!orBoolean("isSellerProcessCompleted", item) ? (
          <Col span={14}>
            <ListCampaign
              listCampaign={listCampaign}
              item={item}
              customer={customer}
              isRoleSaleHotline={isRoleSaleHotline}
              isAdmin={isAdmin}
              checkUser={checkUser}
              setCampaignMoneyDiscount={setCampaignMoneyDiscount}
              onUpdateCampaignForOrder={onUpdateCampaignForOrder}
              listCurrentCampaign={listCurrentCampaign}
            />
          </Col>
        ) : null}
        {!orBoolean("isSellerProcessCompleted", item) ? (
          <Col span={10}>
            <div style={{ height: 500, overflowY: "scroll" }}>
              <ListCampaignOrderUsed listCampaignOrder={listCampaignOrder} />
            </div>
          </Col>
        ) : null}
      </Row>
    </Card>
  );
}
