import { Table, Typography } from "antd";

const { Text } = Typography;

const ListCampaignOrderUsed = (props) => {
    const { listCampaignOrder } = props

    const columns = [
        {
            title: "Mã đơn hàng",
            dataIndex: "code",
        },
        {
            title: "Seller",
            dataIndex: "seller",
        },
        {
            title: "TN Seller",
            dataIndex: "sellerProcessStep",
            render: (value) => {
                return <div>{value ? value.name : "Chưa xác nhận"}</div>;
            },
        },
    ];

    const renderHeaderOrderTable = (campaignId) => {
        return (
            <div>
                Đơn hàng đang được áp dụng campaign
                <span style={{ marginLeft: 10 }}>
                    <Text strong>{campaignId}</Text>
                </span>
            </div>
        );
    };

    return (
        <div>
            {listCampaignOrder.map((item, index) => {
                if (item.orders.length) {
                    return (
                        <div key={index} style={{ marginBottom: 10 }}>
                            <Table
                                title={() => renderHeaderOrderTable(item.campaignId)}
                                columns={columns}
                                dataSource={item.orders}
                                pagination={false}
                                bordered
                            />
                        </div>
                    );
                }
            })}
        </div>
    );
}

export default ListCampaignOrderUsed;