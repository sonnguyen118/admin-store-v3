import {
  Table,
  Tag,
  Input,
  Typography,
  Button,
  notification,
  Modal,
  Spin,
} from "antd";
import moment from "moment";
import { useMemo, useState } from "react";
import { Mocks } from "utils";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import ModalDetailCampaign from "../ModalDetailCampaign";
import { Orders as OrdersAPI } from "api";
import campaign from "utils/RequestManager/campaign";

const { Search } = Input;
const { warning } = Modal;
const { Text } = Typography;

const ListCampaign = (props) => {
  const {
    listCampaign,
    item,
    customer,
    checkUser,
    isAdmin,
    setCampaignMoneyDiscount,
    onUpdateCampaignForOrder,
    listCurrentCampaign,
  } = props;

  const [listCampaigns, setListCampaigns] = useState([]);
  const [campaignSelected, setCampaignSelected] = useState([]);
  const [campaignApplied, setCampaignApplied] = useState([]);
  const [isShineMemberApplied, setIsShineMemberApplied] = useState(false);
  const [rows, setRows] = useState([]);
  const [isLoadingButton, setIsLoadingButton] = useState(false);
  const [voucherCodes, setVoucherCodes] = useState([]);
  const [loadingApplyCampaign, setLoadingApplyCampaign] = useState(0);
  const [detailCampaign, setDetailCampaign] = useState({
    isOpen: false,
    detail: null,
  });
  const [paramsUpdateCampaign, setParamsUpdateCampaign] = useState(null);

  const renderNotification = (record, message) => {
    notification["warning"]({
      message: "Thông báo",
      description: (
        <div>
          Ưu đãi{" "}
          <span>
            <Text strong>{record.name}</Text>
          </span>{" "}
          {message}
        </div>
      ),
    });
  };

  useMemo(() => {
    // let listCurrentCampaign = [];
    // orArray("listCampaign", listCampaign).filter((i) => {
    //   if (
    //     !orArray("campaignIds", item).includes(
    //       orEmpty("descriptionCampaign.campaignId", i)
    //     )
    //   ) {
    //     return listCurrentCampaign.push(i);
    //   }
    // });

    var statusOrder = [true, false];
    setListCampaigns(
      orArray("listCampaign", listCampaign).sort(function (a, b) {
        return (
          statusOrder.indexOf(a.selectCampaign) -
          statusOrder.indexOf(b.selectCampaign)
        );
      })
    );
  }, [listCampaign]);

  const columns = [
    {
      title: "Tên Campaign (id)",
      dataIndex: "descriptionCampaign",
      render: (value, record) => {
        function checkCampaignApply() {
          const arr = [...orArray("refCampaigns", item)];
          const campaignSM = {
            campaignId: "ShineMember",
            voucherCode: "",
          };
          if (orBoolean("refIsShineMemberApplied", item)) {
            arr.push(campaignSM);
          }
          const isRefCampaign = arr.find(
            // fix bug trắng trang 28/03/2023
            (item) =>
              item.campaignId ===
              record.descriptionCampaign.campaignId
          );
          if (isRefCampaign) {
            return true;
          }
          return false;
        }
        return (
          <div style={{ display: "flex" }}>
            {value.campaignName}({value.campaignId})
            {checkCampaignApply() ? (
              <Tag style={{ marginLeft: 10 }} color="#108ee9">
                KH áp dụng
              </Tag>
            ) : (
              ""
            )}
          </div>
        );
      },
      width: 500,
    },
    {
      title: "SL còn lại",
      dataIndex: "used",
      render: (value, record) => {
        return (
          <div>
            {record.descriptionCampaign.campaignId === "ShineMember"
              ? "Không giới hạn"
              : record.mktCampaign.maxUsage}
          </div>
        );
      },
      width: 150,
    },
    {
      title: "Ngày kết thúc",
      dataIndex: "endDate",
      render: (value, record) => {
        return (
          <div>
            {record.descriptionCampaign.campaignId === "ShineMember"
              ? null
              : moment(value).format("DD-MM-YYYY")}
          </div>
        );
      },
      width: 150,
    },
  ];

  useMemo(() => {
    if (
      orNumber("memberType", customer) &&
      !orBoolean("campaigns.isShineMemberApplied", item)
    ) {
      setIsShineMemberApplied(false);
    } else if (
      orNumber("memberType", customer) &&
      orBoolean("campaigns.isShineMemberApplied", item)
    ) {
      setIsShineMemberApplied(true);
    }
  }, [customer, item]);

  function onUpdateData(): void {
    if (listCampaigns) {
      const campaigns = [] as any;
      const campaignsApplied = [] as any;
      if (
        orNumber("memberType", customer) &&
        orBoolean("isShineMember", listCampaign) &&
        !orBoolean("campaigns.isShineMemberApplied", item)
      ) {
        const newCampaign = {
          key: "ShineMember",
          selectCampaign: true,
          used: 0,
          voucherCode: null,
          voucherId: 0,
          descriptionCampaign: {
            campaignId: "ShineMember",
            campaignName: "khuyến mãi dành cho Shine member",
            channel: null,
            conditionUse: "",
            conditionUseGeneral: "",
            countUse: 0,
            expiryDate: orEmpty("memberEndTime", customer),
            listServiceProduct: null,
            maximumAmountReduction: null,
            minimumSpending: null,
            note: null,
            paymentMethods: null,
          },
          mktCampaign: {
            campaignMaxUsage: 0,
            endDate: orEmpty("memberEndTime", customer),
            id: "ShineMember",
            label: null,
            maxUsage: 0,
            name: null,
            startDate: orEmpty("memberStartTime", customer),
          },
        };
        campaigns.push(newCampaign);
      } else if (
        orNumber("memberType", customer) &&
        orBoolean("campaigns.isShineMemberApplied", item)
      ) {
        const newCampaign = {
          key: "ShineMember",
          selectCampaign: true,
          used: 0,
          voucherCode: null,
          voucherId: 0,
          descriptionCampaign: {
            campaignId: "ShineMember",
            campaignName: "khuyến mãi dành cho Shine member",
            channel: null,
            conditionUse: "",
            conditionUseGeneral: "",
            countUse: 0,
            expiryDate: orEmpty("memberEndTime", customer),
            listServiceProduct: null,
            maximumAmountReduction: null,
            minimumSpending: null,
            note: null,
            paymentMethods: null,
          },
          mktCampaign: {
            campaignMaxUsage: 0,
            endDate: orEmpty("memberEndTime", customer),
            id: "ShineMember",
            label: null,
            maxUsage: 0,
            name: null,
            startDate: orEmpty("memberStartTime", customer),
          },
        };
        campaignsApplied.push(newCampaign);
      }
      listCampaigns.forEach((node): void => {
        const result = orArray("campaigns.campaigns", item).find(
          (c) => orEmpty("campaignId", c) === orEmpty("mktCampaign.id", node)
        );
        if (!result) {
          campaigns.push({
            key: node.descriptionCampaign.campaignId,
            ...node,
          });
          return;
        }
        campaignsApplied.push({
          key: node.descriptionCampaign.campaignId,
          ...node,
        });
      });
      setRows(campaigns);
      setCampaignApplied(campaignsApplied);
    }
  }

  async function onGetCampaignVoucherCode(params) {
    setIsLoadingButton(true);
    try {
      const response = await OrdersAPI.getCampaignVoucherCode(params);
      const { data } = response;
      if (orNumber("code", data) === 200) {
        const newCampaign = {
          ...data.data,
        };
        if (
          listCampaigns.find(
            (item) => item.mktCampaign.id === newCampaign.mktCampaign.id
          )
        ) {
          notification["warning"]({
            message: "Thông báo",
            description: `Khuyến mãi ${newCampaign.mktCampaign.id} đã có trong danh sách`,
          });
          return;
        }
        setListCampaigns((prevState) => [newCampaign].concat(prevState));
        notification["success"]({
          message: "Thông báo",
          description: "Thêm thành công mã giảm giá",
        });
        const arr = [...voucherCodes];
        arr.push(params.voucher);
        setVoucherCodes(arr);
        // setCampaignSelected(campaignSelected)
        return;
      }
      warning({
        title: "Thông báo!",
        okText: "Xác nhận",
        content: Mocks.ORDER.onGetVoucherMessage(orEmpty("message", data)),
      });
    } catch (error) {
      console.log(error);
    } finally {
      setIsLoadingButton(false);
    }
  }

  async function onCalculateCampaignDiscount(params) {
    setLoadingApplyCampaign((prevState) => prevState + 1);
    try {
      const response = await OrdersAPI.calculateCampaignDiscount(params);
      const { data } = response;
      if (orBoolean("meta.success", data)) {
        setCampaignMoneyDiscount(orNull("data", data));
        setParamsUpdateCampaign(params);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoadingApplyCampaign((prevState) => prevState - 1);
    }
  }

  async function onCheckCampaignApply(params) {
    setLoadingApplyCampaign((prevState) => prevState + 1);
    try {
      const response = await OrdersAPI.checkCampaign(params);
      const { data } = response;
      if (orBoolean("status", data)) {
        const body = {
          id: orEmpty("id", item),
          isShineMemberApplied: orBoolean("isShineMemberApplied", params),
          campaignIds: orArray("listCampaign", params),
        };
        onCalculateCampaignDiscount(body);
      } else {
        const dataFalse = data.data.filter((d) => !d.status);
        warning({
          title: "Thông báo!",
          okText: "Xác nhận",
          content: (
            <div>
              {dataFalse.length
                ? dataFalse.map((dt, index) => {
                    return <div key={index}>- {dt.message}</div>;
                  })
                : data.message}
            </div>
          ),
          width: 800,
        });
      }
    } catch (error) {
      console.log(error);
    } finally {
      setLoadingApplyCampaign((prevState) => prevState - 1);
    }
  }

  function onApplyVoucherCode(value) {
    if (value === "") {
      notification["warning"]({
        message: "Thông báo",
        description: `Vui lòng nhập mã giảm giá`,
      });
      return;
    }
    if (voucherCodes.find((item) => item === value)) {
      notification["warning"]({
        message: "Thông báo",
        description: `Mã giảm giá ${value} đã được sử dụng`,
      });
      return;
    }
    const listProduct = orArray("orderItems", item).map((item) => ({
      productSKU: item.productSKU,
      quantity: item.quantity,
    }));
    const params = {
      customerPhone: orNumber("phoneNumber", customer),
      bookDate: moment().format("YYYY-MM-DD"),
      voucher: value,
      listProduct: listProduct,
    };
    onGetCampaignVoucherCode(params);
  }

  function onDisableButtonApplyCampaign() {
    // if (isAdmin && checkUser) {
    //   return true;
    // }
    if (checkUser) {
      if (!orBoolean("isConfirmed", item)) {
        return true;
      }
      if (orBoolean("isSellerProcessCompleted", item)) {
        return true;
      }
      if (!paramsUpdateCampaign) {
        return true;
      }
      return false;
    }
    return true;
  }

  function onDisableCheckbox(record) {
    if (checkUser) {
      if (!orBoolean("isConfirmed", item)) {
        return true;
      }
      if (orBoolean("isSellerProcessCompleted", item)) {
        return true;
      }
      if (!record) {
        return true;
      }
      return false;
    }
    return true;
  }

  function onSelectedCampaign(record) {
    const listCampaignSelectedDefault = [...campaignSelected];
    if (record.descriptionCampaign.campaignId === "ShineMember") {
      setIsShineMemberApplied(true);
    }
    listCampaignSelectedDefault.push(record);
    setCampaignSelected(listCampaignSelectedDefault);

    // if (isShineMemberApplied) {
    //   const allowApplyWith = record.allowApplyWith.split(",");
    //   if (allowApplyWith.includes("SHINE_MEMBER")) {
    //     listCampaignSelectedDefault.push(record);
    //     setCampaignSelected(listCampaignSelectedDefault);
    //     return;
    //   }
    //   renderNotification(record, "không được phép áp dụng với Shine Member!");
    //   return;
    // }
    // if (record.id === "Shine member") {
    //   let campaignError = [];
    //   campaignSelected.concat(campaignApplied).forEach((campaign) => {
    //     const listAplly = campaign.allowApplyWith.split(",");
    //     if (listAplly.includes("SHINE_MEMBER")) {
    //       return;
    //     }
    //     campaignError.push(campaign);
    //   });
    //   if (campaignError.length) {
    //     warning({
    //       title: "Thông báo!",
    //       okText: "Xác nhận",
    //       onOk: (close) => (close(), (campaignError = [])),
    //       content: (
    //         <div>
    //           {campaignError.map((dt, index) => {
    //             return (
    //               <div key={index}>
    //                 - Campaign {dt.id} không được phép áp dụng với Shine Member!
    //               </div>
    //             );
    //           })}
    //         </div>
    //       ),
    //       width: 800,
    //     });
    //     return;
    //   }
    //   setIsShineMemberApplied(true);
    //   listCampaignSelectedDefault.push(record);
    //   setCampaignSelected(listCampaignSelectedDefault);
    //   return;
    // }
    // if (
    //   record.allowApplyWith === "" &&
    //   listCampaignSelectedDefault.concat(campaignApplied).length > 0
    // ) {
    //   renderNotification(record, "không được phép áp dụng với Campaign khác!");
    //   return;
    // } else if (
    //   listCampaignSelectedDefault
    //     .concat(campaignApplied)
    //     .find((item) => item.allowApplyWith === "")
    // ) {
    //   renderNotification(record, "không được phép áp dụng với Campaign khác!");
    //   return;
    // }
    // listCampaignSelectedDefault.push(record);
    // setCampaignSelected(listCampaignSelectedDefault);
  }

  function onUnSelectedCampaign(record) {
    setCampaignSelected((prevState) =>
      prevState.filter(
        (i) =>
          i.descriptionCampaign.campaignId !==
          record.descriptionCampaign.campaignId
      )
    );
    if (record.descriptionCampaign.campaignId === "ShineMember") {
      setIsShineMemberApplied(false);
    }
  }

  function getPaymentMethod(paymentMethod) {
    switch (paymentMethod) {
      case "COD":
        return "CASH";
      case "TOPUP":
        return "TOPUP";
      default:
        const arr = ["ZALOPAY", "VNPAY"];
        if (arr.includes(paymentMethod)) {
          return "BANKING";
        }
        break;
    }
  }

  useMemo(() => {
    if (campaignSelected.length) {
      // const params = {
      //   listCampaign: campaignSelected
      //     .concat(campaignApplied)
      //     .filter((campaign) => campaign.id !== "Shine member")
      //     .map((i) => ({
      //       campaignId: orEmpty("id", i),
      //       voucherCode: orEmpty("voucherCode", i),
      //     })),
      //   paymentMethod: getPaymentMethod(item.paymentGateway),
      //   isShineMemberApplied: isShineMemberApplied,
      //   totalMoneyOriginalPrice: item.totalItemPrice,
      //   customerId: item.customerId,
      //   isOnlyShineMember:
      //     campaignSelected.concat(campaignApplied).length === 0 &&
      //     isShineMemberApplied
      //       ? true
      //       : false,
      // };
      // onCheckCampaignApply(params);
      // console.log(campaignSelected);
      const body = {
        id: orEmpty("id", item),
        isShineMemberApplied: isShineMemberApplied,
        campaignIds: campaignSelected
          .concat(campaignApplied)
          .filter(
            (campaign) =>
              campaign.descriptionCampaign.campaignId !== "ShineMember"
          )
          .map((i) => ({
            campaignId: orEmpty("descriptionCampaign.campaignId", i),
            code: orEmpty("voucherCode", i),
          })),
      };
      onCalculateCampaignDiscount(body);
    } else {
      setCampaignMoneyDiscount(null);
      setParamsUpdateCampaign(null);
    }
  }, [campaignSelected, isShineMemberApplied, item]);

  const rowSelection = {
    hideSelectAll: true,
    selectedRowKeys: campaignSelected.map(
      (item) => item.descriptionCampaign.campaignId
    ),
    getCheckboxProps: (record) => ({
      disabled: onDisableCheckbox(record.selectCampaign),
    }),
    onSelect: (record, selected) => {
      if (selected) {
        onSelectedCampaign(record);
        return;
      }
      onUnSelectedCampaign(record);
    },
  };

  function onApplyCampaign() {
    onUpdateCampaignForOrder(paramsUpdateCampaign);
    setCampaignSelected([]);
    setVoucherCodes([]);
  }

  const renderHeaderTable = () => {
    return (
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ marginBottom: 10 }}>
          <Search
            placeholder="Nhập mã giảm giá"
            enterButton="Sử dụng"
            onSearch={onApplyVoucherCode}
            loading={isLoadingButton}
            allowClear
            disabled={!checkUser || orBoolean("isSapoOrder", item)}
          />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <div>
            <Text strong>Khuyến mãi của khách hàng</Text>
          </div>
          <div>
            <Button
              onClick={onApplyCampaign}
              type="primary"
              disabled={
                onDisableButtonApplyCampaign() || orBoolean("isSapoOrder", item)
              }
            >
              Áp dụng campaign
            </Button>
          </div>
        </div>
      </div>
    );
  };

  useMemo(onUpdateData, [
    listCampaign,
    listCampaigns,
    customer,
    item,
    listCurrentCampaign,
  ]);

  return (
    <div>
      <Spin spinning={loadingApplyCampaign ? true : false}>
        <Table
          onRow={(record) => {
            return {
              onClick: () =>
                setDetailCampaign({ isOpen: true, detail: record }), // click row
            };
          }}
          columns={columns}
          dataSource={rows}
          pagination={false}
          rowSelection={rowSelection}
          title={renderHeaderTable}
          rowClassName={(record) =>
            record.selectCampaign ? "" : "disable-row"
          }
          scroll={{ y: 385, x: 500 }}
        />
      </Spin>
      <ModalDetailCampaign
        detailCampaign={detailCampaign}
        setDetailCampaign={setDetailCampaign}
      />
    </div>
  );
};

export default ListCampaign;
