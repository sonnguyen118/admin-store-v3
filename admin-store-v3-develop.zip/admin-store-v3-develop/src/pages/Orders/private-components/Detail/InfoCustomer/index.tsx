import {
    Card,
    Space,
    Typography
} from "antd";
import { orEmpty, orNumber } from "utils/Selector";
import { Helpers } from "utils";
import moment from "moment";
import env from "configs/env";


const { Text } = Typography;

export default function InfoCustomer(props) {
    const { customer } = props;

    return (
        <Card title="Thông tin người mua" className="order-detail-sidebar-customer order-detail-sidebar-card">
            <Space direction="vertical">
                <div style={{ display: "flex", flexDirection: "column", fontWeight: "bold" }}>
                    <a href={`${env.customer_dashboard}/khach-hang/thong-tin-chung/${orEmpty("phoneNumber", customer)}`} target="_blank">{orEmpty("userName", customer)}</a>
                    <a href={`${env.customer_dashboard}/khach-hang/thong-tin-chung/${orEmpty("phoneNumber", customer)}`} target="_blank">{orEmpty("phoneNumber", customer)}</a>
                </div>
                <ul className="order-detail-sidebar-customer-list">
                    <li>
                        <Text>Ngày sinh: {orNumber("dateOfBirth", customer)}/{orNumber("monthOfBirth", customer)}/{orNumber("yearOfBirth", customer)}</Text>
                    </li>
                    {
                        orNumber("memberType", customer) > 0 && <li>
                            <Text>Shine member: {orEmpty("membershipName", customer)}</Text>
                        </li>
                    }
                    {
                        orNumber("memberType", customer) > 1 &&
                        <li>
                            <Text>Tích lũy: {Helpers.currencyFormatVND(orNumber("goldMemberProgress", customer))} / {Helpers.currencyFormatVND(orNumber("goldMemberMinSpending", customer))}</Text>
                        </li>
                    }
                    {orNumber("memberType", customer) > 1 &&
                        <li>
                            <Text>Kỳ xét hạng Gold Member tiếp theo: {moment(orEmpty("memberEndTime", customer)).format("DD/MM/YYYY")}</Text>
                        </li>
                    }
                </ul>
            </Space>
        </Card>
    );
}
