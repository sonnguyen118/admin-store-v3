import { Col, Row, Space, Typography, Card, Button, Modal, Select } from "antd";
import { Helpers, Mocks } from "utils";
import { orArray, orBoolean, orEmpty, orNumber } from "utils/Selector";
import { CreditCardFilled } from "@ant-design/icons";
import {
  ExclamationCircleOutlined,
  EditOutlined,
  SaveFilled,
  CloseCircleOutlined,
} from "@ant-design/icons";
import { useCallback, useMemo, useState } from "react";
import { Orders as OrdersAPI } from "api";
const { Text } = Typography;
const { confirm } = Modal;
const { Option } = Select;

export default function OrderInfo(props) {
  const {
    item,
    handleComfirmPayment,
    shippingFeeOptions,
    onSaveShippingFee,
    campaignMoneyDiscount,
    isRoleSaleHotline,
    roleUser,
    onConfirmPaymentFail,
  } = props;
  const [isEditShippingFee, setIsEditShippingFee] = useState(false);
  const [shippingFee, setShippingFee] = useState(null);
  const [shippingFeeCalculate, setShippingFeeCalculate] = useState(0);
  const [isConfirmPayment, setIsConfirmPayment] = useState(false);

  function checkStatusOrder() {
    return orEmpty("status", item) === "CANCELLED";
  }

  const handleChangeShippingFee = (value) => {
    setShippingFee(value);
    const body = {
      id: orEmpty("id", item),
      shippingFeeAction: "OPTION",
      shippingFeeOption: value,
    };
    onSaveShippingFee(body);
    setIsEditShippingFee(false);
  };

  const TitleCard = () => {
    return (
      <div className="order-detail-main-info-title">
        <Text strong>Thông tin thanh toán</Text>
        <Text className="order-detail-main-info-title-type">
          Phương thức thanh toán:{" "}
          {Mocks.ORDER.getPaymentGatewayDescription(
            orEmpty("paymentGateway", item)
          )}
        </Text>
      </div>
    );
  };

  const renderShippingFee = () => {
    if (shippingFeeCalculate) {
      return Helpers.currencyFormatVND(shippingFeeCalculate);
    }
    return Helpers.currencyFormatVND(orNumber("shippingFee", item));
  };

  const renderShipOption = () => {
    if (shippingFeeCalculate) {
      return;
    }
    if (orBoolean("isFreeShip", item)) {
      return "(Free Ship)";
    }
    if (!orBoolean("isFreeShip", item) && orEmpty("shippingFeeOption", item)) {
      return `(${orEmpty("shippingFeeOption.name", item)})`;
    }
    return "(Mặc định)";
  };

  function onConfirmPayment() {
    handleComfirmPayment(orEmpty("id", item));
    setIsConfirmPayment(false);
  }

  function handleConfirmPaymentFail() {
    onConfirmPaymentFail(orEmpty("id", item));
    setIsConfirmPayment(false);
  }

  // function showPaymentConfirm() {
  //   confirm({
  //     title: "Xác nhận thanh toán !",
  //     icon: <ExclamationCircleOutlined />,
  //     content:
  //       "Bạn xác nhận thanh toán cho đơn hàng này? Phần thanh toán này sẽ được hệ thống ghi nhận lại !",
  //     okText: "Xác nhận",
  //     okType: "primary",
  //     cancelText: "Hủy",
  //     onOk() {
  //       onConfirmPayment();
  //     },
  //     onCancel() {
  //       console.log("Cancel");
  //     },
  //   });
  // }

  const renderEditFee = () => {
    if (
      orBoolean("isSellerProcessCompleted", item) ||
      orBoolean("isFreeShip", item)
    ) {
      return;
    }
    if (orEmpty("paymentStatus", item) === "PAID") {
      return;
    }
    return (
      <span
        onClick={() => setIsEditShippingFee(true)}
        style={{ marginLeft: 5, cursor: "pointer" }}
      >
        <EditOutlined />
      </span>
    );
  };

  async function getShippingFee(params) {
    try {
      const response = await OrdersAPI.getShippingFee(params);
      if (response) {
        setShippingFeeCalculate(orNumber("data.data", response));
      }
    } catch (error) {
      console.log(error);
    }
  }

  useMemo(() => {
    if (campaignMoneyDiscount) {
      const params = {
        provinceId: orEmpty("shippingAddress.provinceId", item),
        totalItemPrice: orNumber("totalPayment", campaignMoneyDiscount),
      };
      getShippingFee(params);
      return;
    }
    setShippingFeeCalculate(0);
  }, [campaignMoneyDiscount]);

  const renderDiscountPrice = () => {
    if (campaignMoneyDiscount) {
      return Helpers.currencyFormatVND(
        orNumber("discountPrice", campaignMoneyDiscount)
      );
    }
    return Helpers.currencyFormatVND(orNumber("discountPrice", item));
  };

  const renderTotalPrice = () => {
    if (campaignMoneyDiscount) {
      return Helpers.currencyFormatVND(
        orNumber("totalPayment", campaignMoneyDiscount) + shippingFeeCalculate
      );
    }
    return Helpers.currencyFormatVND(
      orNumber("totalPrice", item) + shippingFeeCalculate
    );
  };

  const renderWarningForSeller = () => {
    const statusShow = ["PENDING", "FAILED"];
    const checkShow = statusShow.includes(orEmpty("paymentStatus", item));
    if (orEmpty("paymentGateway", item) === "VNPAY" && checkShow) {
      return (
        <div style={{ color: "red" }}>
          Đơn hàng chưa được thanh toán qua VNPAY. Yêu cầu ADMIN/SALE ADMIN xác
          nhận thanh toán
        </div>
      );
    }
  };

  const renderButtonConfirmPayment = () => {
    const roleShow = ["ADMIN", "SALE_ADMIN"];
    const statusShow = ["PENDING", "FAILED"];
    const checkShow = statusShow.includes(orEmpty("paymentStatus", item));
    const checkRole = roleShow.includes(roleUser);
    if (checkRole && orEmpty("paymentGateway", item) === "VNPAY" && checkShow) {
      return (
        <Row gutter={24}>
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "flex-end",
              marginTop: 15,
            }}
          >
            <Button
              disabled={checkStatusOrder() || orBoolean("isSapoOrder", item)}
              onClick={() => setIsConfirmPayment(true)}
              className="form-main-info-button-payment"
              type="primary"
              icon={<CreditCardFilled />}
            >
              Thanh toán
            </Button>
          </div>
        </Row>
      );
    }
  };

  return (
    <Card title={<TitleCard />} className="order-detail-main-info">
      <Row gutter={24} style={{ marginBottom: 8 }}>
        <Col span={16}>
          <Space className="order-detail-main-info-space" direction="vertical">
            <div className="order-detail-main-info-space-item">
              <Text>Tổng số lượng sản phẩm</Text>
              <Text>{orArray("orderItems", item).length}</Text>
            </div>
            <div className="order-detail-main-info-space-item">
              <Text>Tổng tiền hàng</Text>
              <Text>
                {Helpers.currencyFormatVND(orNumber("totalItemPrice", item))}
              </Text>
            </div>
          </Space>
        </Col>
      </Row>
      <Row gutter={24}>
        <Col span={16}>
          <Space className="order-detail-main-info-space" direction="vertical">
            <div className="order-detail-main-info-space-item">
              <Text>Giảm giá</Text>
              <Text>
                {renderDiscountPrice()}
                {/* {Helpers.currencyFormatVND(orNumber("discountPrice", item))} */}
              </Text>
            </div>
            <div className="order-detail-main-info-space-item">
              <Text>Phí vận chuyển</Text>
              {isEditShippingFee ? (
                <div>
                  <Select
                    className="select-shipping-fee"
                    defaultValue={shippingFee}
                    style={{ width: 360 }}
                    placeholder="Lựa chọn phí vận chuyển"
                    optionLabelProp="label"
                    onChange={handleChangeShippingFee}
                  >
                    {shippingFeeOptions.map((item, index) => {
                      return (
                        <Option
                          key={index}
                          value={item.id}
                          label={Helpers.currencyFormatVND(item.shippingFee)}
                        >
                          {item.name}{" "}
                          {Helpers.currencyFormatVND(item.shippingFee)}
                        </Option>
                      );
                    })}
                  </Select>
                  <span
                    onClick={() => setIsEditShippingFee(false)}
                    style={{ marginLeft: 5, cursor: "pointer" }}
                  >
                    <CloseCircleOutlined />
                  </span>
                </div>
              ) : (
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-end",
                  }}
                >
                  <Text>
                    {renderShippingFee()}
                    {renderEditFee()}
                  </Text>
                  <div style={{ fontSize: 12 }}>{renderShipOption()}</div>
                </div>
              )}
            </div>
            <div className="order-detail-main-info-space-item">
              <Text>Tổng thanh toán</Text>
              <Text>
                {renderTotalPrice()}
                {/* {Helpers.currencyFormatVND(orNumber("totalPrice", item))} */}
              </Text>
            </div>
            <div className="order-detail-main-info-space-item">
              <div>
                <Text>Đã thanh toán</Text>
                {renderWarningForSeller()}
              </div>
              <Text>
                {orEmpty("paymentStatus", item) === "PAID"
                  ? Helpers.currencyFormatVND(orNumber("totalPrice", item))
                  : Helpers.currencyFormatVND(0)}
              </Text>
            </div>
            {orNumber("totalPriceReturn", item) ? (
              <div className="order-detail-main-info-space-item">
                <div>
                  <Text>Tổng tiền hàng trả</Text>
                </div>
                <Text>
                  {Helpers.currencyFormatVND(
                    orNumber("totalPriceReturn", item)
                  )}
                </Text>
              </div>
            ) : null}
          </Space>
        </Col>
      </Row>

      {renderButtonConfirmPayment()}

      <Modal
        visible={isConfirmPayment}
        title="Xác nhận thanh toán!"
        onCancel={() => setIsConfirmPayment(false)}
        footer={[
          <Button key="3" type="primary" onClick={onConfirmPayment}>
            Xác nhận đã thanh toán
          </Button>,
          <Button key="2" onClick={handleConfirmPaymentFail}>
            Chuyển sang COD
          </Button>,
          <Button key="1" danger onClick={() => setIsConfirmPayment(false)}>
            Huỷ
          </Button>,
        ]}
      >
        <p>
          Bạn xác nhận thanh toán cho đơn hàng này? Phần thanh toán này sẽ được
          hệ thống ghi nhận lại!
        </p>
      </Modal>

      {/* {orEmpty("paymentGateway", item) === "COD" ? null : orEmpty(
        "paymentStatus",
        item
      ) === "PENDING" || orEmpty("paymentStatus", item) === "FAILED" ? (
        <Row gutter={24}>
          <div
            style={{
              width: "100%",
              display: "flex",
              justifyContent: "flex-end",
              marginTop: 15,
            }}
          >
            <Button
              disabled={checkStatusOrder() || orBoolean("isSapoOrder", item)}
              onClick={showPaymentConfirm}
              className="form-main-info-button-payment"
              type="primary"
              icon={<CreditCardFilled />}
            >
              Thanh toán
            </Button>
          </div>
        </Row>
      ) : null} */}
    </Card>
  );
}
