import { Card, Space, Typography } from "antd";
import { EditOutlined } from "@ant-design/icons";
import { orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import { useEffect, useState } from "react";
import { CreateCustomer } from "components";
import { Orders as OrdersAPI } from "api";
const { Text } = Typography;

export default function DeliveryInfo(props) {
  const {
    item,
    handleUpdateOrder,
    customer,
    shippingFeeOptions,
    onSaveShippingFee,
    user,
  } = props;
  const [isCustomer, setIsCustomer] = useState({
    isOpenForm: false,
    customer: null,
  });

  const [infoCustomer, setInfoCustomer] = useState({
    customerId: null,
    customerName: "",
    customerPhone: "",
  });

  useEffect(() => {
    if (customer) {
      setInfoCustomer({
        customerId: customer.userId,
        customerName: customer.userName,
        customerPhone: customer.phoneNumber,
      });
    }
  }, [customer]);

  function checkUser() {
    return orEmpty("username", user) === orEmpty("seller.username", item);
  }

  function checkStatusOrder() {
    const listStatus = ["COMPLETED", "DELIVERING"];
    if (
      orBoolean("isSapoOrder", item) &&
      listStatus.includes(orEmpty("status", item))
    ) {
      return false;
    }
    if (checkUser()) {
      if (!orBoolean("isConfirmed", item)) {
        return true;
      }
      if (orBoolean("isSellerProcessCompleted", item)) {
        return true;
      }
      return false;
    }
    return true;
  }

  useEffect(() => {
    if (orNull("shippingAddress", item)) {
      setIsCustomer((prevState) => ({
        ...prevState,
        customer: orNull("shippingAddress", item),
      }));
    }
  }, [orNull("shippingAddress", item)]);

  const onEditCustomer = () => {
    setIsCustomer((prevState) => ({
      ...prevState,
      isOpenForm: true,
    }));
  };

  const renderTitle = () => {
    return (
      <div className="form-sidebar-customer-item-detail-title">
        <div>Thông tin giao hàng</div>
        {!checkStatusOrder() ? (
          <EditOutlined
            onClick={onEditCustomer}
            className="form-sidebar-customer-item-detail-title-icon"
          />
        ) : null}
      </div>
    );
  };

  const onCancel = () => {
    setIsCustomer((prevState) => ({
      ...prevState,
      isOpenForm: false,
    }));
  };

  // async function getShippingFee(params, values) {
  //   try {
  //     const response = await OrdersAPI.getShippingFee(params);
  //     if (response) {
  //       const params = {
  //         shippingFee: orNumber("data.data", response),
  //         cashByRecipient: false,
  //       };
  //       if (params) {
  //         handleUpdateOrder({
  //           id: orEmpty("id", item),
  //           shippingAddress: values,
  //           ...params,
  //         });
  //       }
  //     }
  //   } catch (error) {
  //     console.log(error);
  //   }
  // }

  async function onUpdateOrder(params) {
    try {
      const { id, ...body } = params;
      const response = await OrdersAPI.updateOrder(id, body);
      const { status } = response;
      if (status === 200) {
        const body = {
          id: orEmpty("id", item),
          shippingFeeAction: "OPTION",
          shippingFeeOption: orEmpty("shippingFeeOption", item),
        };
        onSaveShippingFee(body);
      }
    } catch (error) {}
  }

  const onSubmit = (values) => {
    // if (!orBoolean("cashByRecipient", item)) {
    //   const params = {
    //     provinceId: orEmpty("provinceId", values),
    //     totalItemPrice: orNumber("totalItemPrice", item),
    //   };
    //   getShippingFee(params, values);
    //   setIsCustomer({
    //     customer: values,
    //     isOpenForm: false,
    //   });
    //   return;
    // }
    if (orBoolean("isFreeShip", item)) {
      handleUpdateOrder({ id: orEmpty("id", item), shippingAddress: values });
      setIsCustomer({
        customer: values,
        isOpenForm: false,
      });
      return;
    }
    if (!orBoolean("isFreeShip", item) && orNull("shippingFeeOption", item)) {
      onUpdateOrder({ id: orEmpty("id", item), shippingAddress: values });
      setIsCustomer({
        customer: values,
        isOpenForm: false,
      });
      return;
    }
    handleUpdateOrder({ id: orEmpty("id", item), shippingAddress: values });
    setIsCustomer({
      customer: values,
      isOpenForm: false,
    });
  };

  return (
    <Card title={renderTitle()} className="order-detail-sidebar-card">
      <Space direction="vertical">
        <div
          style={{
            flexDirection: "column",
            display: "flex",
            fontWeight: "bold",
          }}
        >
          <Text className="form-sidebar-customer-item-detail-info-text">
            {orEmpty("customer.customerName", isCustomer)}
          </Text>
          <Text
            copyable
            className="form-sidebar-customer-item-detail-info-text"
          >
            {orEmpty("customer.customerPhone", isCustomer)}
          </Text>
          <Text className="form-sidebar-customer-item-detail-info-text">
            {orEmpty("customer.customerEmail", isCustomer)}
          </Text>
        </div>
        <Text className="form-sidebar-customer-item-detail-info-text">
          {`${
            orEmpty("customer.address", isCustomer) != ""
              ? orEmpty("customer.address", isCustomer) + ","
              : ""
          } ${orEmpty("customer.wardName", isCustomer)}, ${orEmpty(
            "customer.districtName",
            isCustomer
          )}, ${orEmpty("customer.provinceName", isCustomer)}`}
        </Text>
      </Space>
      {isCustomer.isOpenForm ? (
        <CreateCustomer
          customer={infoCustomer}
          item={isCustomer.customer}
          visible={isCustomer.isOpenForm}
          onCancel={onCancel}
          onSubmit={onSubmit}
          isUpdateOrder={true}
          // order={item}
        />
      ) : null}
    </Card>
  );
}
