import React, { useState, useEffect } from "react";
import {
  Button,
  Card,
  Col,
  Form,
  Input,
  Row,
  Space,
  message,
  Avatar,
  Table,
  notification,
  Typography,
} from "antd";
import { Selector } from "components";
import { orArray, orBoolean, orEmpty, orNull } from "utils/Selector";

const { Item } = Form;
const { Text } = Typography;

export default function ForwardSeller(props) {
  const {
    sellerOptions,
    handleForwardSeller,
    item,
    user,
    onRejectForward,
    onAcceptForward,
    // isRoleSaleHotline,
  } = props;
  const [form] = Form.useForm();
  const isRoleSaleHotline = orEmpty("role", user) === "SELLER_HOTLINE";
  function checkStatusOrder() {
    return orEmpty("status", item) === "CANCELLED";
  }

  function checkUser() {
    return (
      orEmpty("username", user) !== orEmpty("sellerForward.username", item)
    );
  }

  function handleRejectForward() {
    onRejectForward(orEmpty("id", item));
  }

  function handleAcceptForward() {
    onAcceptForward(orEmpty("id", item));
  }

  const renderChooseSellerForm = () => {
    return (
      <Form
        layout="vertical"
        form={form}
        className="order-detail-main-note-form"
      >
        <Text>Đơn hàng được chuyển tiếp từ seller: </Text>
        <br />
        <Text strong>{orEmpty("seller.name", item)}</Text>

        <div>
          <Text>Vui lòng xác nhận xử lý</Text>
        </div>

        {!checkStatusOrder() ? (
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              marginTop: 15,
            }}
          >
            <Button
              disabled={
                checkUser() ||
                isRoleSaleHotline ||
                orBoolean("isSapoOrder", item)
              }
              onClick={handleRejectForward}
            >
              Không nhận
            </Button>
            <Button
              disabled={
                checkUser() ||
                isRoleSaleHotline ||
                orBoolean("isSapoOrder", item)
              }
              onClick={handleAcceptForward}
              type="primary"
            >
              Nhận xử lý
            </Button>
          </div>
        ) : null}
      </Form>
    );
  };

  return (
    <Card
      title="Xác nhận đơn chuyển tiếp"
      className="order-detail-main-note order-detail-sidebar-card"
    >
      {renderChooseSellerForm()}
    </Card>
  );
}
