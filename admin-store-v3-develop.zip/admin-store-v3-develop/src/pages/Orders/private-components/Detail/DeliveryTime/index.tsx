import { Card, Space, Typography, Form, Radio, Button } from "antd";
import { EditOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";
import { Helpers, Mocks } from "utils";
import { orBoolean, orEmpty } from "utils/Selector";
const { Text } = Typography;

const { Item } = Form;

export default function DeliveryTime(props) {
  const { item, handleUpdateOrder, user } = props;
  const [form] = Form.useForm();
  const [isUpdateTime, setIsUpdateTime] = useState(false);

  function onFinish(values) {
    handleUpdateOrder({ id: orEmpty("id", item), ...values });
    setIsUpdateTime(false);
  }

  function checkUser() {
    return orEmpty("username", user) === orEmpty("seller.username", item);
  }

  function checkStatusOrder() {
    if (checkUser()) {
      if (!orBoolean("isConfirmed", item)) {
        return true;
      }
      if (orBoolean("isSellerProcessCompleted", item)) {
        return true;
      }
      return false;
    }
    return true;
  }

  function onSetupForm() {
    if (orEmpty("shippingType", item)) {
      form.setFieldsValue({
        shippingType: orEmpty("shippingType", item),
      });
      return;
    }
  }

  useEffect(() => {
    onSetupForm();
  }, [orEmpty("shippingType", item)]);

  const onEditCustomer = () => {
    setIsUpdateTime(true);
  };

  const renderTitle = () => {
    return (
      <div className="form-sidebar-customer-item-detail-title">
        <div>Thời gian giao hàng</div>
        {!checkStatusOrder() ? (
          <EditOutlined
            onClick={onEditCustomer}
            className="form-sidebar-customer-item-detail-title-icon"
          />
        ) : null}
      </div>
    );
  };

  return (
    <Card
      title={renderTitle()}
      className="order-detail-sidebar-selectTime order-detail-sidebar-card"
    >
      {isUpdateTime ? (
        <Form layout="vertical" form={form} onFinish={onFinish}>
          <Item name="shippingType">
            <Radio.Group>
              <Space direction="vertical">
                <Radio value="IN_OFFICE_HOURS">
                  <Text>Chỉ giao trong giờ hành chính</Text>
                  <Text type="secondary">
                    (phù hợp với địa chỉ văn phòng/cơ quan)
                  </Text>
                </Radio>
                <Radio value="FREE_TIME">
                  <Text>Tất cả các ngày trong tuần</Text>
                  <Text type="secondary">
                    (phù hợp với địa chỉ nhà riêng luôn có người nhận hàng)
                  </Text>
                </Radio>
                <Radio value="IN_TWO_HOURS">
                  <Text>Giao nhanh trong 2h</Text>
                  <Text type="secondary">
                    (Áp dụng địa chỉ giao hàng tại Hà Nội và Hồ Chí Minh)
                  </Text>
                </Radio>
              </Space>
            </Radio.Group>
          </Item>
          <Item className="order-detail-main-note-form-item">
            <Button
              style={{ marginRight: 10 }}
              onClick={() => setIsUpdateTime(false)}
            >
              Hủy
            </Button>
            <Button htmlType="submit" type="primary">
              Lưu
            </Button>
          </Item>
        </Form>
      ) : (
        <Space direction="vertical">
          <Text>
            {orEmpty(
              "label",
              Mocks.ORDER.getDeliveryTime(orEmpty("shippingType", item))
            )}
          </Text>
          <Text
            className="order-detail-sidebar-selectTime-desc"
            type="secondary"
          >
            {orEmpty(
              "description",
              Mocks.ORDER.getDeliveryTime(orEmpty("shippingType", item))
            )}
          </Text>
        </Space>
      )}
    </Card>
  );
}
