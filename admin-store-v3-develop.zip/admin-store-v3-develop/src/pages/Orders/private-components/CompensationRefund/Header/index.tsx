import React, { useEffect, useRef, useState } from 'react';
import { Button, Col, Row, Space, Typography, Divider, notification } from 'antd';
import { orEmpty, orBoolean } from 'utils/Selector';
import { Mocks } from 'utils';
import moment from 'moment';
import OrderStatus from 'components/Status/OrderStatus';
import { useParams } from 'react-router';
import PaymentStatus from 'components/Status/PaymentStatus';
const { Title, Text } = Typography;

export default function Header(props) {
	const { handleBack, item, user } = props;
	const params: any = useParams();

	function onDetailOrder(value) {
		const itemMenuOrder = Mocks.MENUS.getRoleMenusDefine(orEmpty('role', user)).find(
			(item) => item.key === 'orders'
		);
		if (itemMenuOrder) {
			const isMenuUser = itemMenuOrder.nested.find((item) => item);
			window.open(`${isMenuUser.path}/detail/${value}`, '_blank');
			return;
		}
		notification['warning']({
			message: 'Thông báo',
			description: 'Bạn không đủ quyền để truy cập đường dẫn này!',
		});
	}

	return (
		<Row gutter={24} className="order-detail-header">
			<Col span={16} className="order-detail-header-title">
				<Title level={4}>
					Tạo {params?.type === 'compensation' ? 'vận đơn bù ' : 'vận đơn trả hàng '}
					{orEmpty('code', item)}
				</Title>
			</Col>
			<Col span={8} className="order-detail-header-action">
				<Button onClick={handleBack} className="order-detail-header-action-back">
					Quay lại
				</Button>
			</Col>
			<Col span={14} className="order-detail-header-info">
				<Space
					className="order-detail-header-info-space"
					split={<Divider type="vertical" />}
				>
					<div className="order-detail-header-info-space-item">
						<Text type="secondary">Mã đơn hàng</Text>
						<Text strong>
							<span
								className="cursor-pointer"
								onClick={() => onDetailOrder(orEmpty('code', item))}
							>
								{orEmpty('code', item)}
							</span>
						</Text>
					</div>
					<div className="order-detail-header-info-space-item">
						<Text type="secondary">Trạng thái giao hàng</Text>
						<OrderStatus value={orEmpty('status', item)} />
					</div>
					<div className="order-detail-header-info-space-item">
						<Text type="secondary">Trạng thái thanh toán</Text>
						<PaymentStatus value={orEmpty('paymentStatus', item)} />
					</div>
				</Space>
			</Col>
			<Col span={14} className="order-detail-header-info-2">
				<Space size={20}>
					<div>
						Thời gian đặt:{' '}
						{moment(orEmpty('createdAt', item)).format('DD/MM/YYYY hh:mm A')}
					</div>
					<div>Kênh bán hàng: {orEmpty('source', item)}</div>
				</Space>
			</Col>
		</Row>
	);
}
