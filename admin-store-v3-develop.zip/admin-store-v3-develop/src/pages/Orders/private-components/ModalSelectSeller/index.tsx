import React, { useState, useEffect } from "react";
import { Modal, Button, Form } from 'antd';
import { Selector } from "components"

export default function ModalSelectSeller(props) {
    const [form] = Form.useForm();
    const { visible, onSubmit, handleCancel, listSeller } = props
    const [sellerOptions, setSellerOptions] = useState([]);

    useEffect(() => {
        if (listSeller) {
            const listSellerOption = listSeller.map((item) => ({
                label: item.name,
                value: item.username
            }))
            setSellerOptions(listSellerOption)
        }
    }, [listSeller])

    const handleSubmit = (values) => {
        onSubmit(values)
        form.setFieldsValue({
            seller: null,
        });
    }

    return (
        <Modal
            visible={visible}
            title="Chọn Seller"
            // onOk={handleSubmit}
            onCancel={handleCancel}
            footer={[
                <Button key="back" onClick={handleCancel}>
                    Hủy
                </Button>,
                <Button key="submit" type="primary" onClick={form.submit}>
                    Lưu
                </Button>
            ]}
        >
            <Form
                layout="vertical"
                form={form}
                onFinish={handleSubmit}
            >
                <Form.Item
                    name="seller"
                    required
                    rules={[{ required: true, message: 'Vui lòng chọn Seller' }]}
                >
                    <Selector options={sellerOptions} placeholder="Chọn Seller" />
                </Form.Item>
            </Form>

        </Modal>
    );
}
