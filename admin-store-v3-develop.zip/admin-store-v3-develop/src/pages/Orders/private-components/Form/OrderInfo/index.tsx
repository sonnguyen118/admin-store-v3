import {
  Col,
  Row,
  Space,
  Typography,
  Card,
  InputNumber,
  Button,
  Form,
  Checkbox,
} from "antd";
import { CreditCardFilled } from "@ant-design/icons";
import { orEmpty, orNumber } from "utils/Selector";
import { Helpers } from "utils";
import { useEffect, useState } from "react";
import { useMemo } from "react";
import { Orders as OrdersAPI } from "api";

const { Text } = Typography;
const { Item } = Form;

export default function OrderInfo(props) {
  const { listItemOrder, form, customer } = props;
  const [shippingFee, setShippingFee] = useState(0);

  useEffect(() => {
    if (shippingFee) {
      form.setFieldsValue({
        shippingFee: shippingFee,
      });
      return;
    }
    form.setFieldsValue({
      shippingFee: 0,
    });
  }, [shippingFee]);

  async function getShippingFee(params) {
    try {
      const response = await OrdersAPI.getShippingFee(params);
      if (response) {
        setShippingFee(orNumber("data.data", response));
      }
    } catch (error) {
      console.log(error);
    }
  }

  useMemo(() => {
    if (customer) {
      const params = {
        provinceId: orEmpty("provinceId", customer),
        totalItemPrice: listItemOrder.reduce(
          (acc, item) => acc + orEmpty("price", item) * item.quantity,
          0
        ),
      };
      getShippingFee(params);
    }
  }, [customer, listItemOrder]);

  const TitleCard = () => {
    return (
      <div className="order-detail-main-info-title">
        <Text strong>Thông tin thanh toán</Text>
        <Text className="order-detail-main-info-title-type">
          Phương thức thanh toán: Thanh toán khi nhận hàng (COD)
        </Text>
      </div>
    );
  };

  return (
    <Card
      title={<TitleCard />}
      className="order-detail-main-info form-main-info"
    >
      <Row gutter={24}>
        <Col span={12}>
          <Space className="order-detail-main-info-space" direction="vertical">
            <div className="order-detail-main-info-space-item">
              <Text>Số lượng sản phẩm</Text>
              <Text>{listItemOrder.length}</Text>
            </div>
            <div className="order-detail-main-info-space-item">
              <Text>Tổng tiền hàng</Text>
              <Text>
                {Helpers.currencyFormatVND(
                  listItemOrder.reduce(
                    (acc, item) => acc + orEmpty("price", item) * item.quantity,
                    0
                  )
                )}
              </Text>
            </div>
            <div className="order-detail-main-info-space-item">
              <Text>Phí vận chuyển</Text>
              <Item name="shippingFee" style={{ marginBottom: 0 }}>
                <Text>{Helpers.currencyFormatVND(shippingFee)}</Text>
              </Item>
            </div>
            <div className="order-detail-main-info-space-item">
              <Text>Tổng thanh toán</Text>
              <Text>
                {Helpers.currencyFormatVND(
                  listItemOrder.reduce(
                    (acc, item) => acc + orEmpty("price", item) * item.quantity,
                    0
                  ) + shippingFee
                )}
              </Text>
            </div>
          </Space>
        </Col>
      </Row>
      {/* <div className="form-main-info-button">
                <Button className="form-main-info-button-payment" type="primary" icon={<CreditCardFilled />}>
                    Thanh toán
                </Button>
                <Button>Thanh toán sau</Button>
            </div> */}
    </Card>
  );
}
