import React, { useState, useEffect } from "react";
import {
  Card,
  Form as FormBase,
  Input,
  Avatar,
  Table,
  InputNumber,
  Tag,
  Typography,
} from "antd";
import { CloseOutlined, SearchOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { ChooseProductsTable } from "components";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import { Helpers } from "utils";

const { Item } = FormBase;
const { Text } = Typography;

export default function Products(props) {
  const { form, setListItemOrder, item } = props;
  const [searchValue, setSearchValue] = useState("");
  const inputDebounce = useDebounce(searchValue, 300);
  const [chooseProduct, setChooseProduct] = useState({
    status: false,
    data: [],
  });

  useEffect(() => {
    if (orNull("orderItems", item)) {
      const listChooseProduct = item.orderItems.map((item) => ({
        id: item.variantId,
        key: item.variantId,
        name: item.variantName,
        price: item.price,
        product: {
          id: item.productId,
          name: item.productName,
          image: item.productImage.url,
        },
        isOutOfStock: item.isOutOfStock,
        isActive: item.isActive,
        quantity: item.quantity,
        totalMoney: item.price * item.quantity,
        inventoryProduct: item.inventoryProduct,
      }));
      setChooseProduct((prevState) => ({
        ...prevState,
        data: listChooseProduct,
      }));
    }
  }, [orNull("orderItems", item)]);

  useEffect(() => {
    if (inputDebounce) {
      setChooseProduct({
        ...chooseProduct,
        status: true,
      });
      return;
    }
  }, [inputDebounce]);

  function onRemoveItem(value) {
    setChooseProduct((prevState) => ({
      ...prevState,
      data: chooseProduct.data.filter((item) => item.key != value),
    }));
  }

  const onChangeQuantity = (value, record, index) => {
    const array = [...chooseProduct.data];
    array[index]["quantity"] = value;
    array[index]["totalMoney"] = record.price * value;
    array[index]["isValidQuantity"] = !value
      ? true
      : value === 0
      ? true
      : false;
    setChooseProduct((prevState) => ({
      ...prevState,
      data: array,
    }));
  };

  const renderTag = (node) => {
    if (!node.isActive) {
      return (
        <Tag style={{ marginLeft: 5 }} color="error">
          <span>Ngừng bán</span>
        </Tag>
      );
    }
    if (node.isOutOfStock) {
      return (
        <Tag style={{ marginLeft: 5 }} color="error">
          <span>Hết hàng</span>
        </Tag>
      );
    }
  };

  const columnsChooseTable = [
    {
      title: "Ảnh",
      dataIndex: "product",
      key: "product",
      render(value, record) {
        return {
          props: {
            style: { padding: "0" },
          },
          children: (
            <Avatar
              style={{ marginRight: 10 }}
              shape="square"
              size={48}
              src={orEmpty("image", value)}
            />
          ),
        };
      },
    },
    {
      title: "Tên Sản phẩm",
      dataIndex: "name",
      key: "name",
      render(value, record) {
        const totalAvailable = orArray("inventoryProduct", record).reduce(
          (a, { available }) => a + available,
          0
        );
        return {
          props: {
            style: { padding: "0" },
          },
          children: (
            <div style={{ cursor: "pointer", display: "flex" }}>
              <div style={{ display: "flex", flexDirection: "column" }}>
                {orEmpty("product.name", record)}
                <div style={{ display: "flex" }}>
                  Phiên bản:{" "}
                  <Text style={{ marginLeft: 5 }} strong>
                    {value}
                  </Text>
                  <span>{renderTag(record)}</span>
                </div>
                {orArray("inventoryProduct", record).map((item) => (
                  <div style={{ display: "flex" }}>
                    <Text strong>- {orEmpty("inventory.name", item)}:</Text>
                    <div style={{ marginLeft: 5 }}>
                      Tồn: {orNumber("onhand", item)} | Có thể bán:{" "}
                      {orNumber("available", item)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ),
        };
      },
    },
    {
      title: "Giá",
      dataIndex: "price",
      key: "price",
      render: (price: string) => <div>{Helpers.currencyFormatVND(price)}</div>,
    },
    {
      title: "Số lượng",
      dataIndex: "quantity",
      key: "quantity",
      render(value, record, index) {
        return {
          children: (
            <div style={{ display: "flex", flexDirection: "column" }}>
              <InputNumber
                // name={`quantity`}
                defaultValue={value}
                onChange={(value) => onChangeQuantity(value, record, index)}
              />
              {orBoolean("isValidQuantity", record) ? (
                <Text type="danger">Yêu cầu SL tối thiểu là: 1</Text>
              ) : null}
            </div>
          ),
        };
      },
      width: "25%",
    },
    {
      title: "T. Tiền",
      dataIndex: "totalMoney",
      key: "totalMoney",
      render: (price: string) => <div>{Helpers.currencyFormatVND(price)}</div>,
    },
    {
      title: "",
      dataIndex: "key",
      render: (value) => (
        <div>
          <CloseOutlined onClick={() => onRemoveItem(value)} />
        </div>
      ),
    },
  ];

  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value);
  };

  const onSearchProduct = () => {
    setChooseProduct({
      ...chooseProduct,
      status: true,
    });
  };

  function handleConfirmChooseProduct(datas) {
    setChooseProduct({
      status: false,
      data: datas,
    });
  }

  useEffect(() => {
    if (chooseProduct.data.length) {
      setListItemOrder(chooseProduct.data);
      const listOrderItem = chooseProduct.data.map((item) => ({
        productId: item.product.id,
        variantId: item.id,
        quantity: item.quantity,
        isOutOfStock: item.isOutOfStock,
        isActive: item.isActive,
        isValidQuantity: item.isValidQuantity,
      }));
      form.setFieldsValue({
        orderItems: listOrderItem,
      });
      return;
    }
    setListItemOrder([]);
    form.setFieldsValue({
      orderItems: null,
    });
  }, [chooseProduct.data]);

  return (
    <Card title={null} style={{ marginTop: 15 }}>
      <Input.Search
        placeholder="Tìm kiếm sản phẩm"
        allowClear
        onChange={onChangeSearchValue}
        value={searchValue}
        enterButton="Tìm kiếm"
        prefix={<SearchOutlined />}
        onSearch={onSearchProduct}
      />

      <Item
        name="orderItems"
        className="form-sidebar-customer-item"
        required
        rules={[{ required: true, message: "Vui lòng chọn sản phẩm" }]}
      ></Item>
      {chooseProduct.data.length > 0 && (
        <Table columns={columnsChooseTable} dataSource={chooseProduct.data} />
      )}

      <ChooseProductsTable
        searchValueCustom={searchValue}
        visible={chooseProduct.status}
        listItemChoose={chooseProduct.data}
        handleCancel={() =>
          setChooseProduct((prevState) => ({ ...prevState, status: false }))
        }
        handleConfirm={handleConfirmChooseProduct}
        isVariant
      />
    </Card>
  );
}
