import React, { useState, useEffect } from 'react';
import {
    Button,
    Card,
    Col,
    Form , 
    Input, 
    Row, 
    Space,
    message,
    Avatar,
    Table,
    Radio,
    Typography
  } from "antd";
  import { Selector } from "components"
  import { SearchOutlined } from '@ant-design/icons';

  const { Item } = Form;
  const { Text, Link } = Typography;

export default function DeliveryTime(props) {

    return (
        <Card title="Thời gian giao hàng" className="order-detail-main-note order-detail-sidebar-card form-sidebar-delivery-time">
            <Item
                name="shippingType"
            >
                <Radio.Group>
                    <Space direction="vertical">
                        <Radio value="IN_OFFICE_HOURS">
                            <Text>Chỉ giao trong giờ hành chính</Text>
                            <Text type="secondary">(phù hợp với địa chỉ văn phòng/cơ quan)</Text>
                        </Radio>
                        <Radio value="FREE_TIME">
                            <Text>Tất cả các ngày trong tuần</Text>
                            <Text type="secondary">(phù hợp với địa chỉ nhà riêng luôn có người nhận hàng)</Text>
                        </Radio>
                        <Radio value="IN_TWO_HOURS">
                            <Text>Giao nhanh trong 2h</Text>
                            <Text type="secondary">(Áp dụng địa chỉ giao hàng tại Hà Nội và Hồ Chí Minh)</Text>
                        </Radio>
                    </Space>
                </Radio.Group>
            </Item>
        </Card>
    );
}
