import React, { useEffect, useState } from "react";
import "./styled.scss";
import AffixAction from "./AffixAction";
import { Col, Form as FormBase, Modal, Row, Space } from "antd";
import Products from "./Products";
import OrderInfo from "./OrderInfo";
import OrderNote from "./OrderNote";
import Channel from "./Channel";
import Customer from "./Customer";
import DeliveryTime from "./DeliveryTime";
import OrderTags from "./OrderTags";
import { Mocks } from "utils";
import { orEmpty, orArray } from "utils/Selector";

export default function Form(props) {
  const { user, onCancelClick, onSave, item, listOrderTag, listOrderSource } =
    props;
  const [listItemOrder, setListItemOrder] = useState([]);
  const [customer, setCustomer] = useState(null);
  const [handlebutton, setHandleButton] = useState("");
  const [form] = FormBase.useForm();
  const [tags, setTags] = useState([]);
  const [sources, setSources] = useState([]);

  useEffect(() => {
    if (listOrderTag) {
      const listOrderTagOption = listOrderTag.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setTags(listOrderTagOption);
    }
  }, [listOrderTag]);

  useEffect(() => {
    if (listOrderSource) {
      const listOrderSourceOption = listOrderSource.map((item) => ({
        label: item,
        value: item,
      }));
      setSources(listOrderSourceOption);
    }
  }, [listOrderSource]);

  function onSetupForm() {
    if (item) {
      const defaultTags = orArray("tags", item).map((item) => ({
        label: item.name,
        value: item.id,
      }));
      form.setFieldsValue({
        shippingType: item.shippingType,
        source: item.source,
        shippingFee: item.shippingFee,
        cashByRecipient: item.cashByRecipient,
        customerNote: item.customerNote,
        tags: defaultTags,
      });
      return;
    }
    form.setFieldsValue({
      shippingType: "IN_OFFICE_HOURS",
      source: "WEB",
      shippingFee: 0,
      cashByRecipient: false,
    });
  }

  useEffect(() => {
    onSetupForm();
  }, [item]);

  function onFinish(values) {
    const itemError = [];
    orArray("orderItems", values).forEach((item) => {
      if (!item.productId || !item.variantId) {
        itemError.push(item);
        return;
      }
      if (!item.isActive || item.isOutOfStock) {
        itemError.push(item);
        return;
      }
    });
    if (itemError.length) {
      Modal.warning({
        title: "Thông báo",
        content:
          "Một vài sản phẩm đã hết hàng hoặc ngừng bán vui lòng kiểm tra và thử lại.",
        okText: "Xác nhận",
      });
      return;
    }
    const orderItemError = orArray("orderItems", values).find(
      (item) => item.isValidQuantity
    );
    if (orderItemError) {
      return;
    }
    const tags = orArray("tags", values).map((item) => item.value);
    const orderItems = orArray("orderItems", values).map((item) => ({
      productId: item.productId,
      variantId: item.variantId,
      quantity: item.quantity,
    }));

    if (orEmpty("id", item)) {
      if (handlebutton === "create") {
        onSave(
          Mocks.ORDER.getBodyOrder({
            ...values,
            orderItems: orderItems,
            tags: tags,
            seller: orEmpty("username", user),
            refOrderId: orEmpty("id", item),
            refOrderCode: orEmpty("code", item),
            refOrderAction: "CREATE_NEW_ONLY",
          })
        );
        return;
      }
      onSave(
        Mocks.ORDER.getBodyOrder({
          ...values,
          orderItems: orderItems,
          tags: tags,
          seller: orEmpty("username", user),
          refOrderId: orEmpty("id", item),
          refOrderCode: orEmpty("code", item),
          refOrderAction: "CANCEL_REF_ORDER",
        })
      );
      return;
    }
    onSave(
      Mocks.ORDER.getBodyOrder({
        ...values,
        orderItems: orderItems,
        tags: tags,
        seller: orEmpty("username", user),
      })
    );
  }

  function onFinishFailed() {}

  function headerActions() {
    return (
      <AffixAction
        onCancelClick={onCancelClick}
        item={item}
        setHandleButton={setHandleButton}
      />
    );
  }

  function renderProducts() {
    return (
      <Products item={item} form={form} setListItemOrder={setListItemOrder} />
    );
  }

  function renderInfoPayment() {
    return (
      <OrderInfo
        form={form}
        listItemOrder={listItemOrder}
        customer={customer}
      />
    );
  }

  function renderChanel() {
    return <Channel sources={sources} />;
  }

  function renderCustomer() {
    return <Customer form={form} item={item} setCustomer={setCustomer} />;
  }

  function renderNoteOrder() {
    return <OrderNote />;
  }

  function renderDeliveryTime() {
    return <DeliveryTime />;
  }

  function renderOrderTags() {
    return <OrderTags form={form} item={item} tags={tags} setTags={setTags} />;
  }

  return (
    <FormBase
      layout="vertical"
      form={form}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
    >
      {headerActions()}
      <Row gutter={24}>
        <Col span={18}>
          <Space className="form-main" direction="vertical">
            {renderProducts()}
            {renderInfoPayment()}
            {renderNoteOrder()}
          </Space>
        </Col>
        <Col span={6}>
          <Space className="form-sidebar" direction="vertical">
            {renderChanel()}
            {renderCustomer()}
            {renderDeliveryTime()}
            {renderOrderTags()}
          </Space>
        </Col>
      </Row>
    </FormBase>
  );
}
