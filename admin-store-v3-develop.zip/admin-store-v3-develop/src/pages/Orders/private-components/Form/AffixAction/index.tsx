import React, { useEffect, useState } from 'react';
import {
  Typography,
  Affix,
  Row,
  Col,
  Button,
  Form as FormBase,
} from "antd";
import { orBoolean } from 'utils/Selector';

const { Title } = Typography;
const { Item } = FormBase;

function AffixAction(props): JSX.Element {
  const { onCancelClick, item, setHandleButton } = props
  const [isShow, setIsShow] = useState(false);

  function onChangeAffix(affixed) {
    setIsShow(affixed);
  }

  return (
    <Affix offsetTop={0} onChange={onChangeAffix}>
      <Row style={{ padding: "0 15px" }} className="actions">
        <Col span={12}>
          {isShow
            ?
            <Title style={{ marginBottom: 0 }} level={2}>{item ? "Đặt lại đơn" : "Tạo mới chưa được lưu"} </Title>
            :
            <Title style={{ marginBottom: 0 }} level={2}>{item ? "Đặt lại đơn" : "Tạo đơn hàng"}</Title>
          }
        </Col>
        <Col style={{ display: "flex", alignItems: "center" }} span={8} offset={4} className="action-right">
          <Button style={{ marginRight: 10 }} onClick={onCancelClick} className="btn">
            {item ? "Quay lại đơn hàng cũ" : "Hủy"}
          </Button>
          {item && !orBoolean("isSellerProcessCompleted", item) ?
            <Item style={{ display: "flex", alignItems: "center", marginRight: 10, marginBottom: 0 }}>
              <Button
                onClick={() => setHandleButton("createAndRemove")}
                htmlType="submit"
                className="btn"
                type="primary"
              >
                Tạo mới và hủy đơn hàng cũ
              </Button>
            </Item> : null
          }
          {!orBoolean("sellerProcessStep.isUpSale", item)
            ?
            <Item style={{ display: "flex", alignItems: "center", marginBottom: 0 }}>
              <Button
                onClick={() => setHandleButton("create")}
                htmlType="submit"
                className="btn"
                type="primary"
              >
                Tạo mới đơn hàng
              </Button>
            </Item>
            :
            null
          }

        </Col>
      </Row>
    </Affix>
  );
};

export default AffixAction;