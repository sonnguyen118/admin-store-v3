import { Card, Form } from "antd";
import { Selector } from "components";
import { Mocks } from "utils";

const { Item } = Form;

export default function Channel(props) {
  const { sources } = props;

  return (
    <Card
      title="Kênh bán"
      className="order-detail-main-note order-detail-sidebar-card"
    >
      <Item name="source">
        <Selector placeholder="Chọn kênh bán" options={sources} />
      </Item>
    </Card>
  );
}
