import React, { useState, useEffect, useMemo } from "react";
import { Card, Form, Input, Typography, Divider, Avatar } from "antd";
import { CreateCustomer } from "components";
import {
  SearchOutlined,
  PlusCircleOutlined,
  EditOutlined,
  UserOutlined,
} from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { orEmpty, orNull, orNumber } from "utils/Selector";
import { withReducer } from "hoc";
import orderReducer from "../../../Reducer";

const { Title, Text } = Typography;

const { Item } = Form;

function Customer(props) {
  const { form, item, state, action, dispatch, setCustomer } = props;
  const [phoneValue, setPhoneValue] = useState("");
  const [isShowPopup, setIsShowPopup] = useState(false);
  const phoneDebounce = useDebounce(phoneValue.length === 10, 100);
  const [isSearchCustomer, setIsSearchCustomer] = useState(false);
  const [isCustomer, setIsCustomer] = useState({
    isOpenForm: false,
    customer: null,
  });
  const [searchCustomer, setSearchCustomer] = useState({
    isCustomer: false,
    customer: null,
  });

  useEffect(() => {
    if (orNull("shippingAddress", item)) {
      setIsCustomer((prevState) => ({
        ...prevState,
        customer: orNull("shippingAddress", item),
      }));
    }
  }, [orNull("shippingAddress", item)]);

  useEffect(() => {
    if (phoneDebounce) {
      const params = {
        phone: phoneValue,
      };
      setIsSearchCustomer(true);
      action.customerOrderReducer.getSeachCustomer(
        params,
        dispatch.customerOrderReducer
      );
      return;
    }
    setIsShowPopup(false);
  }, [phoneDebounce]);

  useEffect(() => {
    if (orNull("customerOrderReducer.searchCustomer", state)) {
      if (orNumber("customerOrderReducer.searchCustomer.userId", state) !== 0) {
        setSearchCustomer((prevState) => ({
          ...prevState,
          isCustomer: true,
          customer: {
            customerId: orEmpty(
              "customerOrderReducer.searchCustomer.userId",
              state
            ),
            customerName: orEmpty(
              "customerOrderReducer.searchCustomer.userName",
              state
            ),
            customerPhone: orEmpty(
              "customerOrderReducer.searchCustomer.phoneNumber",
              state
            ),
          },
        }));
        setIsShowPopup(isSearchCustomer);
        return;
      }
      setSearchCustomer((prevState) => ({
        ...prevState,
        isCustomer: false,
        customer: null,
      }));
      setIsShowPopup(true);
      return;
    }
  }, [orNull("customerOrderReducer.searchCustomer", state)]);

  const onChangePhone = (e) => {
    setPhoneValue(e.target.value);
  };

  const onClickNewCustomer = () => {
    setIsShowPopup(false);
    setPhoneValue("");
    setIsCustomer((prevState) => ({
      ...prevState,
      isOpenForm: true,
      customer: null,
    }));
  };

  const onClickChooseCustomer = () => {
    setIsShowPopup(false);
    setPhoneValue("");
    setIsCustomer((prevState) => ({
      ...prevState,
      isOpenForm: true,
      customer: null,
    }));
  };

  const onCancel = () => {
    setIsCustomer((prevState) => ({
      ...prevState,
      isOpenForm: false,
    }));
  };

  const onSubmit = (values) => {
    setIsCustomer({
      isOpenForm: false,
      customer: values,
    });
    // setSearchCustomer({
    //     isCustomer: false,
    //     customer: values
    // })
  };

  const onEditCustomer = () => {
    setIsCustomer((prevState) => ({
      ...prevState,
      isOpenForm: true,
    }));
  };

  useMemo(() => {
    if (searchCustomer.customer) {
      form.setFieldsValue({
        customerId: orNumber("customer.customerId", searchCustomer),
        customerPhone: orEmpty("customer.customerPhone", searchCustomer),
      });
    } else {
      form.setFieldsValue({
        customerId: null,
        customerPhone: "",
      });
    }
  }, [searchCustomer.customer]);

  useEffect(() => {
    if (isCustomer.customer) {
      form.setFieldsValue({
        shippingAddress: isCustomer.customer,
      });
      const params = {
        phone: orEmpty("customer.customerPhone", isCustomer),
      };
      action.customerOrderReducer.getSeachCustomer(
        params,
        dispatch.customerOrderReducer
      );
      setCustomer(isCustomer.customer);
      setIsSearchCustomer(false);
      setIsShowPopup(false);
    }
  }, [isCustomer.customer]);

  return (
    <Card
      title="Khách hàng"
      className="order-detail-main-note order-detail-sidebar-card form-sidebar-customer"
    >
      <Item style={{ marginBottom: 0 }}>
        <Input
          placeholder="Tìm kiếm số điện thoại"
          allowClear
          value={phoneValue}
          onChange={onChangePhone}
          prefix={<SearchOutlined />}
        />
      </Item>
      {isShowPopup ? (
        <>
          <div className="form-sidebar-customer-popup">
            {searchCustomer.isCustomer ? (
              <div
                onClick={onClickChooseCustomer}
                style={{ display: "flex", cursor: "pointer" }}
              >
                <Avatar icon={<UserOutlined />} />
                <div style={{ marginLeft: 10 }}>
                  <Text strong>
                    {orEmpty("customer.customerName", searchCustomer)}
                  </Text>
                  <br />
                  <Text type="secondary">
                    {orEmpty("customer.customerPhone", searchCustomer)}
                  </Text>
                </div>
              </div>
            ) : (
              <div
                className="form-sidebar-customer-popup-create"
                onClick={onClickNewCustomer}
              >
                <PlusCircleOutlined className="form-sidebar-customer-popup-create-icon" />{" "}
                Tạo mới địa chỉ giao hàng
              </div>
            )}
          </div>
          <div
            onClick={() => setIsShowPopup(false)}
            className="form-sidebar-customer-popup-bg"
          ></div>
        </>
      ) : null}

      <Item name="customerId" className="form-sidebar-customer-item"></Item>
      <Item name="customerPhone" className="form-sidebar-customer-item"></Item>
      <Item
        name="shippingAddress"
        className="form-sidebar-customer-item"
        required
        rules={[{ required: true, message: "Vui lòng chọn khách hàng" }]}
      >
        {isCustomer.customer ? (
          <>
            <Divider className="form-sidebar-customer-item-driver" />
            <div className="form-sidebar-customer-item-detail">
              <div className="form-sidebar-customer-item-detail-title">
                <Title level={4}>Thông tin giao hàng</Title>
                <EditOutlined
                  onClick={onEditCustomer}
                  className="form-sidebar-customer-item-detail-title-icon"
                />
              </div>
              <div className="form-sidebar-customer-item-detail-info">
                <Text className="form-sidebar-customer-item-detail-info-text">
                  {orEmpty("customer.customerName", isCustomer)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                  {orEmpty("customer.customerPhone", isCustomer)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                  {orEmpty("customer.customerEmail", isCustomer)}
                </Text>
                <Text className="form-sidebar-customer-item-detail-info-text">
                  {`${
                    orEmpty("customer.address", isCustomer) != ""
                      ? orEmpty("customer.address", isCustomer) + ","
                      : ""
                  } ${orEmpty("customer.wardName", isCustomer)}, ${orEmpty(
                    "customer.districtName",
                    isCustomer
                  )}, ${orEmpty("customer.provinceName", isCustomer)}`}
                </Text>
              </div>
            </div>
          </>
        ) : null}
      </Item>
      {isCustomer.isOpenForm ? (
        <CreateCustomer
          customer={searchCustomer.customer}
          item={isCustomer.customer}
          visible={isCustomer.isOpenForm}
          onCancel={onCancel}
          onSubmit={onSubmit}
        />
      ) : null}
    </Card>
  );
}

export default withReducer({
  key: "customerOrderReducer",
  ...orderReducer,
})(Customer);
