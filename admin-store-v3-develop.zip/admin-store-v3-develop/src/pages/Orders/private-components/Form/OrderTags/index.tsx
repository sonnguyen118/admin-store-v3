import {
    Button,
    Card,
    Form,
    notification
} from "antd";
import CreatableSelect from "react-select/creatable";
import { OrderTags as OrderTagsAPI } from "api";
import { useEffect, useState } from "react";
import { orArray } from "utils/Selector";

const { Item } = Form;

export default function OrderTags(props) {
    const { form, tags, setTags } = props

    const [isLoadingTag, setIsLoadingTag] = useState(false)

    // useEffect(() => {
    //     if (orArray("tags", item)) {
    //         const defaultTags = orArray("tags", item).map((item) => ({
    //             label: item.name,
    //             value: item.id
    //         }))
    //         form.setFieldsValue({
    //             tags: defaultTags
    //         });
    //     }
    // }, [orArray("tags", item)])

    const formatCreateLabel = (inputValue) => `Thêm mới... ${inputValue}`;

    async function handleCreate(inputValue: any) {
        try {
            setIsLoadingTag(true)
            const params = {
                name: inputValue,
                isActive: true
            }
            const response = await OrderTagsAPI.createOrderTag(params);
            const { data, status } = response;
            if (status === 200) {
                const listTag = []
                setIsLoadingTag(false)
                const tag = {
                    value: data.data.id,
                    label: data.data.name,
                }
                listTag.push(tag)
                setTags(prevState => prevState.concat(listTag))
                form.setFieldsValue({
                    tags: form.getFieldsValue()['tags'].concat(listTag)
                });
                // setTagValues(prevState => prevState.concat(listTag))
                return;
            }
        } catch (error) {
            setIsLoadingTag(false)
            notification['error']({
                message: 'Không thể tạo tag mới',
                description:
                    'Có lỗi xảy ra trong quá trình tạo mới tag, vui lòng kiểm tra và thử lại!',
            });
        }
    };


    return (
        <Card title="Nhãn" className="order-detail-main-note order-detail-sidebar-card">
            <Item
                name="tags"
            >
                <CreatableSelect
                    isClearable
                    options={tags}
                    isDisabled={isLoadingTag}
                    isLoading={isLoadingTag}
                    formatCreateLabel={formatCreateLabel}
                    onCreateOption={handleCreate}
                    isMulti
                    placeholder={'Chọn nhãn'}
                />
            </Item>
        </Card>
    );
}
