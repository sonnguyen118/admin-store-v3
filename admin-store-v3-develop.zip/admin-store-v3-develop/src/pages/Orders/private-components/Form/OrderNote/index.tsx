import {
    Button,
    Card,
    Form , 
    Input, 
  } from "antd";

  const { Item } = Form;

export default function OrderNote(props) {

    return (
        <Card title="Ghi chú đơn hàng" className="order-detail-main-note">
            <Item
                name="customerNote"
            >
                <Input.TextArea rows={4} placeholder="Thêm ghi chú cho đơn hàng" />
            </Item>
        </Card>
    );
}
