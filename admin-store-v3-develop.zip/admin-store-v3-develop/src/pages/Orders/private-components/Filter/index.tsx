import React, { useState, useEffect } from "react";
import { Selector } from "components";
import {
  Form,
  Row,
  Col,
  Input,
  Button,
  Popover,
  Tag,
  DatePicker,
  Modal,
  Radio,
  Space,
  notification,
  Divider,
  Checkbox,
} from "antd";
import { FilterOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { Helpers, Mocks } from "utils";
import moment from "moment";
import { orBoolean, orEmpty, orNull } from "utils/Selector";

const { RangePicker } = DatePicker;

export default function Filter(props) {
  const {
    filter,
    setFilter,
    filterOptions,
    optionMultiple,
    listSeller = [],
    sellerProcessStep = [],
    onChangePage,
    localFilterOrders,
    path,
    onReloadData,
    filterDefault,
    tabSelected,
    listOrderTag = [],
    listOrderSourceOption,
  } = props;
  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false);
  const [listFilter, setListFilter] = useState([]);
  const [filterType, setFilterType] = useState("status");
  const [searchValue, setSearchValue] = useState("");
  const [searchType, setSearchType] = useState("all");
  const [listSellerOption, setListSellerOption] = useState([]);
  const [listOrderTagOption, setListOrderTagOption] = useState([]);
  const inputDebounce = useDebounce(searchValue, 300);
  const [sellerProcessStepOption, setSellerProcessStepOption] = useState([]);
  const [isUpdateFilter, setIsUpdateFilter] = useState(false);
  const [dataFilter, setDataFilter] = useState({});

  const [isUpdate, setIsUpdate] = useState(false);

  useEffect(() => {
    if (listSeller.length) {
      const listSellers = listSeller.map((item) => ({
        label: item.name,
        value: item.username,
      }));
      setListSellerOption(listSellers);
    }
  }, [listSeller]);

  useEffect(() => {
    if (filterDefault) {
      setDataFilter((prevState) => ({
        ...prevState,
        ...filterDefault,
      }));
    }
  }, [filterDefault]);

  useEffect(() => {
    if (sellerProcessStep.length) {
      const arr = sellerProcessStep.filter((i) => !i.isGroupPendingPayment);
      const newArr = arr.concat(
        sellerProcessStep.find((i) => i.isGroupPendingPayment)
      );
      const sellerProcessSteps = newArr.map((item) => ({
        label: item.name,
        value: item.id,
        groupPendingPayment: item.groupPendingPayment.length
          ? item.groupPendingPayment
          : null,
      }));
      setSellerProcessStepOption(sellerProcessSteps);
    }
  }, [sellerProcessStep]);

  useEffect(() => {
    if (listOrderTag.length) {
      const sellerProcessSteps = listOrderTag.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setListOrderTagOption(sellerProcessSteps);
    }
  }, [listOrderTag]);

  useEffect(() => {
    const arr = [...listFilter];
    if (
      filterDefault &&
      sellerProcessStepOption.length &&
      listOrderTagOption.length
    ) {
      if (orNull("status", filterDefault)) {
        arr.push({
          value: "status",
          label: Mocks.ORDER.getLabelFilter(
            "status",
            orNull("status", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("paymentStatus", filterDefault)) {
        arr.push({
          value: "withPaymentStatus",
          label: Mocks.ORDER.getLabelFilter(
            "withPaymentStatus",
            orNull("paymentStatus", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("paymentGateway", filterDefault)) {
        arr.push({
          value: "withPaymentGateway",
          label: Mocks.ORDER.getLabelFilter(
            "withPaymentGateway",
            orNull("paymentGateway", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("seller", filterDefault)) {
        arr.push({
          value: "withNameSeller",
          label: Mocks.ORDER.getLabelFilter(
            "withNameSeller",
            orNull("seller", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("sellerProcessStep", filterDefault)) {
        arr.push({
          value: "withSellerStep",
          label: Mocks.ORDER.getLabelFilter(
            "withSellerStep",
            orNull("sellerProcessStep", filterDefault),
            sellerProcessStepOption,
            listOrderTagOption
          ),
        });
        setListFilter(arr);
      }
      if (orNull("sellerAcceptStatus", filterDefault)) {
        arr.push({
          value: "withSellerAcceptStatus",
          label: Mocks.ORDER.getLabelFilter(
            "withSellerAcceptStatus",
            orNull("sellerAcceptStatus", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("source", filterDefault)) {
        arr.push({
          value: "withSource",
          label: Mocks.ORDER.getLabelFilter(
            "withSource",
            orNull("source", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("tags", filterDefault)) {
        arr.push({
          value: "withTags",
          label: Mocks.ORDER.getLabelFilter(
            "withTags",
            orNull("tags", filterDefault),
            sellerProcessStepOption,
            listOrderTagOption
          ),
        });
        setListFilter(arr);
      }
      if (orNull("before", filterDefault) && orNull("after", filterDefault)) {
        arr.push({
          value: "withDateTime",
          label: `Ngày tạo từ ngày ${moment(
            orNull("after", filterDefault)
          ).format("DD-MM-YYYY")} đến ngày ${moment(
            orNull("before", filterDefault)
          )
            .subtract(1, "days")
            .format("DD-MM-YYYY")}`,
        });
        setListFilter(arr);
      }
      if (orNull("shippingType", filterDefault)) {
        arr.push({
          value: "withShippingType",
          label: Mocks.ORDER.getLabelFilter(
            "withShippingType",
            orNull("shippingType", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      const { isSellerProcessCompleted, isUpsale, isNotStatus, isRefund } = filterDefault;
      if (isSellerProcessCompleted && isNotStatus) {
        arr.push({
          value: "withOrderCompletedType",
          label: `Loại đơn hàng là đơn ${
            isUpsale ? "upsale thành công" : "thường"
          }`,
        });
        setListFilter(arr);
      }
      if (orNull("cancelReasonType", filterDefault)) {
        arr.push({
          value: "withCancelReason",
          label: Mocks.ORDER.getLabelFilter(
            "withCancelReason",
            orNull("cancelReasonType", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("withCompensationAndRefund", filterDefault)) {
        arr.push({
          value: "withCompensationAndRefund",
          label: Mocks.ORDER.getLabelFilter(
            "withCompensationAndRefund",
            orNull("shippingType", filterDefault)
          ),
        })
        setListFilter(arr)
      }
    }
  }, [filterDefault, sellerProcessStepOption, listOrderTagOption]);

  function handleAddFilterToLocal() {
    setIsUpdateFilter(true);
  }

  useEffect(() => {
    form2.setFieldsValue({
      isCreate: "create",
    });
  }, []);

  function onFinishModal(values) {
    const arr = [...localFilterOrders];
    const newFilter = {
      name: values.name,
      key: Helpers.getKey(values.name),
      filter: dataFilter,
    };
    if (values.isCreate === "update") {
      const itemUpdateIndex = arr.findIndex(
        (item) => item.key === newFilter.key
      );
      newFilter.name = arr[itemUpdateIndex].name;
      arr[itemUpdateIndex] = newFilter;
      Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
        return onReloadData(newFilter);
      });
      form2.resetFields();
      setIsUpdateFilter(false);
      return;
    }
    if (arr.find((item) => item.key === newFilter.key)) {
      notification["warning"]({
        message: "Thông báo",
        description: `Bộ lọc đã tồn tại vui lòng kiểm tra và thử lại`,
      });
      return;
    }
    arr.push(newFilter);
    Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
      return onReloadData(newFilter);
    });
    form2.resetFields();
    setIsUpdateFilter(false);
  }

  function handleCancel() {
    setIsUpdateFilter(false);
  }

  const onFilter = (filterType, filterValue) => {
    switch (filterType) {
      case "status":
        setDataFilter((prevState) => ({
          ...prevState,
          status: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          status: filterValue,
        }));
        return;
      case "withShippingType":
        setDataFilter((prevState) => ({
          ...prevState,
          shippingType: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          shippingType: filterValue,
        }));
        return;
      case "withOrderCompletedType":
        const filterWithType = Mocks.ORDER.OrderCompletedType.find(
          (item) => item.value === filterValue
        );
        setDataFilter((prevState) => ({
          ...prevState,
          ...filterWithType.filter,
        }));
        setFilter((prevState) => ({
          ...prevState,
          ...filterWithType.filter,
        }));
        return;
      case "withPaymentStatus":
        setDataFilter((prevState) => ({
          ...prevState,
          paymentStatus: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          paymentStatus: filterValue,
        }));
        return;
      case "withPaymentGateway":
        setDataFilter((prevState) => ({
          ...prevState,
          paymentGateway: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          paymentGateway: filterValue,
        }));
        return;
      case "withNameSeller":
        setDataFilter((prevState) => ({
          ...prevState,
          seller: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          seller: filterValue,
        }));
        return;
      case "withSellerStep":
        setDataFilter((prevState) => ({
          ...prevState,
          sellerProcessStep: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          sellerProcessStep: filterValue,
        }));
        return;
      case "withSellerAcceptStatus":
        setDataFilter((prevState) => ({
          ...prevState,
          sellerAcceptStatus: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          sellerAcceptStatus: filterValue,
        }));
        return;
      case "withSource":
        setDataFilter((prevState) => ({
          ...prevState,
          source: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          source: filterValue,
        }));
        return;
      case "withTags":
        setDataFilter((prevState) => ({
          ...prevState,
          tags: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          tags: filterValue,
        }));
        return;
      case "withDateTime":
        setDataFilter((prevState) => ({
          ...prevState,
          after: filterValue[0].format("YYYY-MM-DD"),
          before: moment(filterValue[1]).add(1, "days").format("YYYY-MM-DD"),
        }));
        setFilter((prevState) => ({
          ...prevState,
          after: filterValue[0].format("YYYY-MM-DD"),
          before: moment(filterValue[1]).add(1, "days").format("YYYY-MM-DD"),
        }));
        return;
      case "withCancelReason":
        setDataFilter((prevState) => ({
          ...prevState,
          cancelReasonType: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          cancelReasonType: filterValue,
        }))
        return
      case 'withCompensationAndRefund':
        let newFilter = {};
        Mocks.ORDER.CompensationAndRefundType.map((item) => {
          if (filterValue.includes(item.value)) {
            newFilter = item.filter;
          }
        });
        setDataFilter((prevState) => ({
          ...prevState,
          ...newFilter,
        }));
        setFilter((prevState) => ({
          ...prevState,
          ...newFilter,
        }));
        return;
      default:
        break;
    }
  };

  const checkListFilter = (filterType, filterValue, filterDate) => {
    handleCloseVisible();
    const arr = [...listFilter];
    const resultItem = listFilter.findIndex(
      (item) => item.value === filterType
    );
    if (resultItem === -1) {
      arr.push({
        value: filterType,
        label: Mocks.ORDER.getLabelFilter(
          filterType,
          filterValue || filterDate,
          sellerProcessStepOption,
          listOrderTagOption
        ),
      });
      setListFilter(arr);
    } else {
      listFilter[resultItem].label = Mocks.ORDER.getLabelFilter(
        filterType,
        filterValue || filterDate
      );
      setListFilter(arr);
    }
    return (
      form.setFieldsValue({
        filterType: filterType,
        filterValue: filterValue,
        filterDate: filterDate,
      }),
      onFilter(filterType, filterValue || filterDate),
      onChangePage(1)
    );
  };

  const onFinish = (values) => {
    checkListFilter(values.filterType, values.filterValue, values.filterDate);
  };

  useEffect(() => {
    if (inputDebounce) {
      if (searchType === "code") {
        setFilter((prevState) => ({
          ...prevState,
          code: searchValue,
        }));
        onChangePage(1);
        return;
      }
      setFilter((prevState) => ({
        ...prevState,
        s: searchValue,
      }));
      onChangePage(1);
      return;
    }
  }, [inputDebounce]);

  useEffect(() => {
    if (searchValue === "" && filter.s) {
      delete filter.s;
      setFilter({ ...filter });
      onChangePage(1);
      return;
    }
    if (searchValue === "" && filter.code) {
      delete filter.code;
      setFilter({ ...filter });
      onChangePage(1);
      return;
    }
  }, [searchValue, filter]);

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "status",
      filterValue: orNull("status", dataFilter)
        ? orNull("status", dataFilter)
        : [],
    });
  }

  useEffect(onSetupForm, [dataFilter]);

  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter((node) => node.value != item.value));
    if (item.value === "status") {
      delete filter.status;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.status;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withShippingType") {
      delete filter.shippingType;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.shippingType;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withPaymentStatus") {
      delete filter.paymentStatus;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.paymentStatus;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withDateTime") {
      delete filter.after;
      delete filter.before;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.after;
      // @ts-ignore
      delete dataFilter.before;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withPaymentGateway") {
      delete filter.paymentGateway;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.paymentGateway;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withSeller") {
      delete filter.withSeller;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.withSeller;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withNameSeller") {
      delete filter.seller;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.seller;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withSellerStep") {
      delete filter.sellerProcessStep;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.sellerProcessStep;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withSellerAcceptStatus") {
      delete filter.sellerAcceptStatus;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.sellerAcceptStatus;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withSource") {
      delete filter.source;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.source;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withTags") {
      delete filter.tags;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.tags;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withOrderCompletedType") {
      delete filter.isSellerProcessCompleted;
      delete filter.isUpsale;
      delete filter.isNotStatus;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.isSellerProcessCompleted;
      // @ts-ignore
      delete dataFilter.isUpsale;
      // @ts-ignore
      delete dataFilter.isNotStatus;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withCancelReason") {
      delete filter.cancelReasonType;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.cancelReasonType;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value ===  "withCompensationAndRefund"){
      delete filter.isRefund;
      delete filter.isCompensation;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.isRefund;
      // @ts-ignore
      delete dataFilter.isCompensation;
      // @ts-ignore
      setDataFilter({ ...dataFilter })
      onChangePage(1);
    }
  };

  const handleVisibleChange = (visible) => {
    setFilterVisible(visible);
  };

  const handleCloseVisible = () => {
    setFilterType("status");
    setFilterVisible(false);
  };

  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value);
  };

  const onChangeTypeFilter = (e) => {
    setFilterType(e);
  };

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "status":
        return Mocks.ORDER.OrderStatus;
      case "withPaymentStatus":
        return Mocks.ORDER.PaymentStatus;
      case "withShippingType":
        return Mocks.ORDER.ShippingType;
      case "withPaymentGateway":
        return Mocks.ORDER.PaymentGateway;
      case "withSeller":
        return Mocks.ORDER.SellerStatus;
      case "withNameSeller":
        return listSellerOption;
      case "withSellerStep":
        return sellerProcessStepOption;
      case "withSellerAcceptStatus":
        return Mocks.ORDER.sellerAcceptStatus;
      case "withOrderCompletedType":
        return Mocks.ORDER.OrderCompletedType;
      case "withSource":
        return listOrderSourceOption;
      case "withTags":
        return listOrderTagOption;
      case "withCancelReason":
        return Mocks.ORDER.CancelReasonOptions;
      case "withCompensationAndRefund":
        return Mocks.ORDER.CompensationAndRefundType
      default:
        break;
    }
  };

  useEffect(() => {
    if (filterType === "status") {
      form.setFieldsValue({
        filterType: "status",
        filterValue: orNull("status", dataFilter)
          ? orNull("status", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withShippingType") {
      form.setFieldsValue({
        filterType: "withShippingType",
        filterValue: orNull("shippingType", dataFilter)
          ? orNull("shippingType", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withPaymentStatus") {
      form.setFieldsValue({
        filterType: "withPaymentStatus",
        filterValue: orNull("paymentStatus", dataFilter)
          ? orNull("paymentStatus", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withPaymentGateway") {
      form.setFieldsValue({
        filterType: "withPaymentGateway",
        filterValue: orNull("paymentGateway", dataFilter)
          ? orNull("paymentGateway", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withNameSeller") {
      form.setFieldsValue({
        filterType: "withNameSeller",
        filterValue: orNull("seller", dataFilter)
          ? orNull("seller", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withSellerStep") {
      form.setFieldsValue({
        filterType: "withSellerStep",
        filterValue: orNull("sellerProcessStep", dataFilter)
          ? orNull("sellerProcessStep", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withSellerAcceptStatus") {
      form.setFieldsValue({
        filterType: "withSellerAcceptStatus",
        filterValue: orNull("sellerAcceptStatus", dataFilter)
          ? orNull("sellerAcceptStatus", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withOrderCompletedType") {
      const getFilterValue = () => {
        // @ts-ignore
        const { isSellerProcessCompleted, isUpsale, isNotStatus } = dataFilter;
        if (isSellerProcessCompleted && isUpsale && isNotStatus) {
          return "isUpsale";
        }
        if (isSellerProcessCompleted && !isUpsale && isNotStatus) {
          return "isNormal";
        }
        return null;
      };

      form.setFieldsValue({
        filterType: "withOrderCompletedType",
        filterValue: getFilterValue(),
      });
      return;
    }
    if (filterType === "withSource") {
      form.setFieldsValue({
        filterType: "withSource",
        filterValue: orNull("source", dataFilter)
          ? orNull("source", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withTags") {
      form.setFieldsValue({
        filterType: "withTags",
        filterValue: orNull("tags", dataFilter)
          ? orNull("tags", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withDateTime") {
      form.setFieldsValue({
        filterType: "withDateTime",
        filterDate:
          orNull("before", filterDefault) && orNull("after", filterDefault)
            ? [
                moment(orNull("after", filterDefault)),
                moment(orNull("before", filterDefault)).subtract(1, "days"),
              ]
            : null,
      });
      return;
    }
    if (filterType === "withCancelReason") {
      form.setFieldsValue({
        filterType: "withCancelReason",
        filterValue: orNull("cancelReasonType", dataFilter)
          ? orNull("cancelReasonType", dataFilter)
          : [],
      });
    }
    if (filterType === "withCompensationAndRefund") {
      const getFilterValue = () => {
        // @ts-ignore
        const { isRefund, isCompensation } = dataFilter;
        if (isRefund) {
          return "isRefund"
        }
        if (isCompensation) {
          return "isNormal"
        }
      }
      form.setFieldsValue({
        filterType: "withCompensationAndRefund",
        filterValue: getFilterValue(),
      });
      return;
    }
  }, [filterType, dataFilter]);

  const searchTypeOptions = [
    {
      label: "Tất cả",
      value: "all",
    },
    {
      label: "Mã đơn hàng",
      value: "code",
    },
  ];

  const onChangeSearchType = (value) => {
    setSearchValue("");
    setSearchType(value);
  };

  const handleChangeIsCreate = (e) => {
    if (e.target.value === "update") {
      setIsUpdate(true);
      form2.setFieldsValue({
        name: localFilterOrders.find((item) => item.key === tabSelected)
          ? tabSelected
          : null,
      });
      return;
    }
    setIsUpdate(false);
    form2.setFieldsValue({
      name: "",
    });
  };

  const content = (
    <Form form={form} onFinish={onFinish} style={{ width: 300, maxWidth: 300 }}>
      <p>Hiển thị tất cả sản phẩm theo</p>
      <Form.Item name="filterType" style={{ marginBottom: 0 }}>
        <Selector onChange={onChangeTypeFilter} options={filterOptions} />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      {filterType === "withDateTime" ? (
        <Form.Item
          name="filterDate"
          rules={[{ required: true, message: "Vui lòng lựa chọn thời gian" }]}
          required
        >
          <RangePicker format="DD-MM-YYYY" />
        </Form.Item>
      ) : (
        <Form.Item
          name="filterValue"
          rules={[
            { required: true, message: "Vui lòng chọn thông tin để lọc" },
          ]}
        >
          <Selector
            mode={optionMultiple.includes(filterType) ? "multiple" : null}
            options={getOptionFilter(filterType)}
            placeholder={"Lựa chọn điều kiện lọc"}
            dropdownRender={(menu) => {
              return (
                <div>
                  {optionMultiple.includes(filterType) ? (
                    <div
                      style={{ padding: "4px 8px 8px 8px", cursor: "pointer" }}
                      onMouseDown={(e) => e.preventDefault()}
                    >
                      <span
                        className="underline text-blue"
                        onClick={() => {
                          form.setFieldsValue({
                            filterValue: getOptionFilter(filterType).map(
                              (item) => item.value
                            ),
                          });
                        }}
                      >
                        Chọn tất cả
                      </span>
                      -
                      <span
                        className="underline text-blue ml-5"
                        onClick={() => {
                          form.setFieldsValue({
                            filterValue: [],
                          });
                        }}
                      >
                        Xóa
                      </span>
                    </div>
                  ) : null}
                  <Divider style={{ margin: "2px 0" }} />
                  {menu}
                </div>
              );
            }}
          />
        </Form.Item>
      )}

      <Form.Item style={{ display: "flex", justifyContent: "space-between" }}>
        <Button onClick={handleCloseVisible} style={{ marginRight: 10 }}>
          Huỷ
        </Button>
        <Button htmlType="submit" type="primary">
          Thêm điều kiện lọc
        </Button>
      </Form.Item>
    </Form>
  );

  return (
    <>
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title={"Thêm điều kiện lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>
              Thêm điều kiện lọc
            </Button>
          </Popover>
        </Col>
        <Col span={3}>
          <Selector
            onChange={onChangeSearchType}
            value={searchType}
            options={searchTypeOptions}
          />
        </Col>
        <Col span={listFilter.length ? 12 : 15}>
          <Input
            value={searchValue}
            onChange={onChangeSearchValue}
            allowClear
            placeholder={
              searchType === "code"
                ? "Nhập mã đơn hàng VD: ABC0123456, XYZ7891011"
                : "Tìm kiếm theo mã đơn hàng, số điện thoại, email, tên khách hàng ..."
            }
          />
        </Col>
        {listFilter.length ? (
          <Col span={3}>
            <Button
              onClick={handleAddFilterToLocal}
              style={{ width: "100%" }}
              icon={<FilterOutlined />}
            >
              Lưu bộ lọc
            </Button>
          </Col>
        ) : null}
      </Row>
      {listFilter.length ? (
        <Row style={{ margin: "15px 0" }} gutter={24}>
          <Col span={24}>
            {Helpers.getUnique(listFilter, "value").map((item, index) => {
              return (
                <Tag
                  key={index}
                  closable
                  onClose={(e) => handleRemoveFilter(e, item)}
                >
                  {item.label}
                </Tag>
              );
            })}
          </Col>
        </Row>
      ) : null}
      <Modal
        title="Lưu bộ lọc"
        visible={isUpdateFilter}
        onOk={form2.submit}
        onCancel={handleCancel}
      >
        <Form
          name="addFilter"
          form={form2}
          onFinish={onFinishModal}
          layout="vertical"
        >
          <Form.Item name="isCreate">
            <Radio.Group onChange={handleChangeIsCreate}>
              <Space direction="vertical">
                <Radio value="create">Tạo mới bộ lọc</Radio>
                <Radio value="update">Lưu đè lên bộ lọc đã tồn tại</Radio>
              </Space>
            </Radio.Group>
          </Form.Item>
          <Form.Item
            label={isUpdate ? "Chọn bộ lọc" : "Tên bộ lọc"}
            name="name"
            rules={[
              {
                required: true,
                message: `${
                  isUpdate ? "Vui lòng chọn bộ lọc" : "Vui lòng nhập tên bộ lọc"
                }`,
              },
            ]}
          >
            {isUpdate ? (
              <Selector
                options={localFilterOrders.map((item) => ({
                  label: item.name,
                  value: item.key,
                }))}
                placeholder="Chọn bộ lọc"
              />
            ) : (
              <Input placeholder="Nhập tên bộ lọc" />
            )}
          </Form.Item>
        </Form>
      </Modal>
    </>
  );
}
