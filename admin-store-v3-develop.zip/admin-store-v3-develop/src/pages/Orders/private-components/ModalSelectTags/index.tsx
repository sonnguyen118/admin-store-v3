import React, { useState, useEffect } from "react";
import { Modal, Button, Form, notification } from 'antd';
import CreatableSelect from "react-select/creatable";
import { OrderTags as OrderTagsAPI } from "api";

export default function ModalSelectTags(props) {
    const [form] = Form.useForm();
    const { visible, onSubmit, handleCancel, listOrderTag, title, isRemoveTags } = props
    const [isLoadingTag, setIsLoadingTag] = useState(false)
    const [tagValues, setTagValues] = useState([]);
    const [tags, setTags] = useState([]);

    useEffect(() => {
        if (listOrderTag) {
            const listOrderTagOption = listOrderTag.map((item) => ({
                label: item.name,
                value: item.id
            }))
            setTags(listOrderTagOption)
        }
    }, [listOrderTag])

    const handleSubmit = (values) => {
        onSubmit(values)
        form.resetFields()
    }

    const formatCreateLabel = (inputValue) => `Thêm mới... ${inputValue}`;

    async function handleCreate(inputValue: any) {
        try {
            setIsLoadingTag(true)
            const params = {
                name: inputValue,
                isActive: true
            }
            const response = await OrderTagsAPI.createOrderTag(params);
            const { data, status } = response;
            if (status === 200) {
                const listTag = []
                setIsLoadingTag(false)
                const tag = {
                    value: data.data.id,
                    label: data.data.name,
                }
                listTag.push(tag)
                setTags(prevState => prevState.concat(listTag))
                setTagValues(prevState => prevState.concat(listTag))
                return;
            }
        } catch (error) {
            setIsLoadingTag(false)
            notification['error']({
                message: 'Không thể tạo tag mới',
                description:
                    'Có lỗi xảy ra trong quá trình tạo mới tag, vui lòng kiểm tra và thử lại!',
            });
        }
    };

    const handleChange = (newValue: any) => {
        setTagValues(newValue)
    };

    function handleOnCancel() {
        form.resetFields()
        handleCancel()
    }

    return (
        <Modal
            visible={visible}
            title={title}
            onCancel={handleOnCancel}
            footer={[
                <Button key="back" onClick={handleOnCancel}>
                    Hủy
                </Button>,
                <Button key="submit" type="primary" onClick={form.submit}>
                    Lưu
                </Button>
            ]}
        >
            <Form
                layout="vertical"
                form={form}
                onFinish={handleSubmit}
            >
                <Form.Item
                    label="Nhãn"
                    name="tags"
                    required
                    rules={[{ required: true, message: 'Vui lòng chọn nhãn cho đơn hàng' }]}
                >
                    <CreatableSelect
                        isClearable
                        options={tags}
                        isDisabled={isLoadingTag}
                        isLoading={isLoadingTag}
                        formatCreateLabel={formatCreateLabel}
                        onCreateOption={handleCreate}
                        onChange={handleChange}
                        isMulti
                        placeholder={'Chọn nhãn'}
                        value={tagValues}
                        isValidNewOption={() => isRemoveTags ? false : true}
                    />
                </Form.Item>
            </Form>

        </Modal>
    );
}
