import React from "react";
import { Form } from "../../../../private-components";
import { useHistory } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import orderReducer from "../../../../Reducer";
function Create(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  function onCancelClick() {
    history.goBack();
  }

  function onSave(body) {
    action.sellerCreateOrderReducer.createOrder(
      body,
      dispatch.sellerCreateOrderReducer
    );
  }

  const onGetListOrderTag = () => {
    action.sellerCreateOrderReducer.onGetListOrderTag(
      {},
      dispatch.sellerCreateOrderReducer
    );
  };

  function onGetListOrderSource() {
    action.sellerCreateOrderReducer.onGetListOrderSource(
      dispatch.sellerCreateOrderReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean("sellerCreateOrderReducer.isRedirect", state)) {
      history.push(
        `/orders-seller/detail/${orEmpty(
          "sellerCreateOrderReducer.createData.code",
          state
        )}`
      );
    }
  };

  React.useEffect(onRedirect, [
    orBoolean("sellerCreateOrderReducer.isRedirect", state),
  ]);
  React.useEffect(onGetListOrderTag, []);
  React.useEffect(onGetListOrderSource, []);

  return (
    <Form
      listOrderSource={orArray(
        "sellerCreateOrderReducer.listOrderSource",
        state
      )}
      listOrderTag={orArray("sellerCreateOrderReducer.orderTags", state)}
      user={orNull("userReducer.user", state)}
      onCancelClick={onCancelClick}
      onSave={onSave}
    />
  );
}

export default withReducer({
  key: "sellerCreateOrderReducer",
  ...orderReducer,
})(Create);
