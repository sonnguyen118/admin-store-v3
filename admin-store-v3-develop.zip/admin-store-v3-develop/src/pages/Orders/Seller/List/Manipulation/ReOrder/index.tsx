import React, { useEffect } from "react";
import { DetailOrder } from "../../../../private-components";
import { useHistory, useParams } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import orderReducer from "../../../../Reducer";
import { Form } from "../../../../private-components";

function Detail(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();
  const params = useParams();

  function onSetup() {
    action.sellerReOrderReducer.getDetailReorder(
      orEmpty("id", params),
      dispatch.sellerReOrderReducer
    );
  }

  function onCancelClick() {
    history.goBack();
  }

  function onSave(body) {
    action.sellerReOrderReducer.createOrder(
      body,
      dispatch.sellerReOrderReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean("sellerReOrderReducer.isRedirect", state)) {
      history.push(
        `/orders-seller/detail/${orEmpty(
          "sellerReOrderReducer.createData.code",
          state
        )}`
      );
    }
  };

  const onGetListOrderTag = () => {
    action.sellerReOrderReducer.onGetListOrderTag(
      {},
      dispatch.sellerReOrderReducer
    );
  };

  function onGetListOrderSource() {
    action.sellerReOrderReducer.onGetListOrderSource(
      dispatch.sellerReOrderReducer
    );
  }

  React.useEffect(onRedirect, [
    orBoolean("sellerReOrderReducer.isRedirect", state),
  ]);

  useEffect(onSetup, [params]);
  React.useEffect(onGetListOrderTag, []);
  React.useEffect(onGetListOrderSource, []);

  return (
    <Form
      listOrderSource={orArray("sellerReOrderReducer.listOrderSource", state)}
      listOrderTag={orArray("sellerReOrderReducer.orderTags", state)}
      item={orNull("sellerReOrderReducer.detailOrder", state)}
      user={orNull("userReducer.user", state)}
      onCancelClick={onCancelClick}
      onSave={onSave}
    />
  );
}

export default withReducer({
  key: "sellerReOrderReducer",
  ...orderReducer,
})(Detail);
