import React, { useEffect } from "react";
import { DetailOrder } from "../../../../private-components";
import { useHistory, useParams } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray, orNumber } from "utils/Selector";
import orderReducer from "../../../../Reducer";
import { useMemo } from "react";
import { Modal } from "antd";

const { warning } = Modal;
interface RouteParams {
  id: string;
}
function Detail(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();
  const params = useParams<RouteParams>();

  function handleBack() {
    history.goBack();
  }

  function onSetup() {
    action.sellerDetailOrderReducer.getDetailOrder(
      orEmpty("id", params),
      dispatch.sellerDetailOrderReducer
    );
  }

  const onGetListSeller = () => {
    if (orEmpty("orderSellerReducer.sellers", state).length === 0) {
      action.sellerDetailOrderReducer.onGetListSeller(
        {},
        dispatch.sellerDetailOrderReducer
      );
    }
  };

  const onGetListOrderTag = () => {
    if (orEmpty("orderSellerReducer.orderTags", state).length === 0) {
      action.sellerDetailOrderReducer.onGetListOrderTag(
        {},
        dispatch.sellerDetailOrderReducer
      );
    }
  };

  const onGetShippingFeeOption = () => {
    action.sellerDetailOrderReducer.onGetShippingFeeOption(
      {},
      dispatch.sellerDetailOrderReducer
    );
  };

  function onAssigneeSeller(body) {
    const { id, ...params } = body;
    action.sellerDetailOrderReducer.onAssingneeSeller(
      id,
      params,
      dispatch.sellerDetailOrderReducer
    );
  }

  const onGetListInventory = () => {
    const { id } = params;
    action.sellerDetailOrderReducer.onGetListInventoryNew(
      id,
      { isSalonInventories: true, isOnlyShowInOrder: true },
      dispatch.sellerDetailOrderReducer
    );
  };

  function onAcceptProcess(id) {
    action.sellerDetailOrderReducer.onSellerAcceptProcess(
      id,
      dispatch.sellerDetailOrderReducer
    );
  }

  function onRejectProcess(id) {
    action.sellerDetailOrderReducer.onSellerRejectProcess(
      id,
      dispatch.sellerDetailOrderReducer
    );
  }

  function onProcessResult(values) {
    const { id, ...body } = values;
    action.sellerDetailOrderReducer.onSellerProcessResult(
      id,
      body,
      dispatch.sellerDetailOrderReducer
    );
  }

  const onCancelOrder = (params) => {
    const { id, ...body } = params;
    action.sellerDetailOrderReducer.onCancelOrder(
      id,
      body,
      dispatch.sellerDetailOrderReducer
    );
  };

  const onUpdateOrder = (values) => {
    const { id, ...body } = values;
    action.sellerDetailOrderReducer.updateOrder(
      id,
      body,
      dispatch.sellerDetailOrderReducer
    );
  };
  const onUpdateOrderNew = (values) => {
    const { id, ...body } = values;
    action.sellerDetailOrderReducer.updateOrderNew(
      id,
      body,
      dispatch.sellerDetailOrderReducer
    );
  };

  const onReOrder = (id) => {
    history.push(`/orders-seller/${id}/reorder`);
  };

  const onRefresh = () => {
    if (orBoolean("sellerDetailOrderReducer.isRefresh", state)) {
      onSetup();
    }
  };

  const onRedirect = () => {
    if (orBoolean("sellerDetailOrderReducer.isRedirect", state)) {
      history.push("/orders-seller");
    }
  };

  const onGetListOrderLogs = () => {
    if (orNull("sellerDetailOrderReducer.detailOrder", state)) {
      action.sellerDetailOrderReducer.onGetListOrderLogs(
        orEmpty("sellerDetailOrderReducer.detailOrder.id", state),
        dispatch.sellerDetailOrderReducer
      );
    }
    onGetListInventory();
  };

  const onGetCustomer = () => {
    if (orNull("sellerDetailOrderReducer.detailOrder", state)) {
      const params = {
        id: orEmpty("sellerDetailOrderReducer.detailOrder.customerId", state),
      };
      action.sellerDetailOrderReducer.getCustomer(
        params,
        dispatch.sellerDetailOrderReducer
      );
    }
  };

  useEffect(onGetCustomer, [
    orNull("sellerDetailOrderReducer.detailOrder.customerId", state),
  ]);

  const onGetListCampaign = () => {
    if (orNull("sellerDetailOrderReducer.detailOrder", state)) {
      if (
        orBoolean(
          "sellerDetailOrderReducer.detailOrder.isSellerProcessCompleted",
          state
        )
      ) {
        return;
      }
      const params = {
        customerId: orEmpty(
          "sellerDetailOrderReducer.detailOrder.customerId",
          state
        ),
        customerPhone: orEmpty(
          "sellerDetailOrderReducer.detailOrder.customerPhone",
          state
        ),
        campaigns: orArray(
          "sellerDetailOrderReducer.detailOrder.campaigns.campaigns",
          state
        ).map((item) => ({
          campaignId: orEmpty("campaignId", item),
          code: orEmpty("code", item),
        })),
        products: orArray(
          "sellerDetailOrderReducer.detailOrder.orderItems",
          state
        ).map((item) => ({
          productId: 0,
          sku: item.productSKU,
          quant: item.quantity,
          price: item.price,
        })),
      };
      action.sellerDetailOrderReducer.onGetListCampaign(
        params,
        dispatch.sellerDetailOrderReducer
      );
    }
  };

  const onGetListCampaignOrder = () => {
    if (
      orNull("sellerDetailOrderReducer.detailOrder", state) &&
      orArray("sellerDetailOrderReducer.listCampaign.listCampaign", state)
        .length
    ) {
      if (
        orBoolean(
          "sellerDetailOrderReducer.detailOrder.isSellerProcessCompleted",
          state
        )
      ) {
        return;
      }
      const params = {
        campaignIds: orArray(
          "sellerDetailOrderReducer.listCampaign.listCampaign",
          state
        ).map((item) => orNumber("descriptionCampaign.campaignId", item)),
      };
      action.sellerDetailOrderReducer.onGetListCampaignOrder(
        orEmpty("sellerDetailOrderReducer.detailOrder.customerId", state),
        params,
        dispatch.sellerDetailOrderReducer
      );
    }
  };
  useEffect(() => {
    onGetListInventory();
  }, [dispatch]);
  // useMemo(() => {
  //   if (orNull("sellerDetailOrderReducer.detailOrder", state)) {
  //     if (
  //       orBoolean(
  //         "sellerDetailOrderReducer.detailOrder.isSellerProcessCompleted",
  //         state
  //       )
  //     ) {
  //       return;
  //     }
  //     const params = {
  //       customerId: orEmpty(
  //         "sellerDetailOrderReducer.detailOrder.customerId",
  //         state
  //       ),
  //       listCampaign: orArray(
  //         "sellerDetailOrderReducer.detailOrder.campaigns.campaigns",
  //         state
  //       ).map((item) => ({
  //         voucherCode: orEmpty("voucherCode", item),
  //         campaignId: orEmpty("campaignId", item),
  //       })),
  //     };
  //     console.log("chạyyyyy")
  //     const params = orArray(
  //       "sellerDetailOrderReducer.detailOrder.campaigns.campaigns",
  //       state
  //     ).map((item) => orEmpty("campaignId", item));
  //     action.sellerDetailOrderReducer.onGetListCurrentCampaign(
  //       params,
  //       dispatch.sellerDetailOrderReducer
  //     );
  //   }
  // }, [orNull("sellerDetailOrderReducer.detailOrder", state)]);

  useMemo(() => {
    if (orArray("detailOrderReducer.campaignError", state).length) {
      warning({
        title: "Thông báo!",
        okText: "Xác nhận",
        content: (
          <div>
            {orArray("detailOrderReducer.campaignError", state).map(
              (dt, index) => {
                return <div key={index}>- {dt.message}</div>;
              }
            )}
          </div>
        ),
        width: 800,
      });
      return;
    }
  }, [orArray("detailOrderReducer.campaignError", state)]);

  useMemo(() => {
    onGetListCampaignOrder();
  }, [
    orNull("sellerDetailOrderReducer.detailOrder", state),
    orArray("sellerDetailOrderReducer.listCampaign", state),
  ]);

  useMemo(() => {
    onGetListCampaign();
  }, [orNull("sellerDetailOrderReducer.detailOrder", state)]);

  const handleCreateOrderLog = (values) => {
    const { id, ...body } = values;
    action.sellerDetailOrderReducer.createOrderLogs(
      id,
      body,
      dispatch.sellerDetailOrderReducer
    );
  };

  const onConfirmPayment = (id) => {
    action.sellerDetailOrderReducer.confirmPayment(
      id,
      dispatch.sellerDetailOrderReducer
    );
  };

  const onConfirmPaymentFail = (id) => {
    action.sellerDetailOrderReducer.confirmPaymentFail(
      id,
      dispatch.sellerDetailOrderReducer
    );
  };

  const onRejectForward = (id) => {
    const body = {
      isAccept: 0,
    };
    action.sellerDetailOrderReducer.onForwardConfirm(
      id,
      body,
      "onReject",
      dispatch.sellerDetailOrderReducer
    );
  };

  const onAcceptForward = (id) => {
    const body = {
      isAccept: 1,
    };
    action.sellerDetailOrderReducer.onForwardConfirm(
      id,
      body,
      "onAccept",
      dispatch.sellerDetailOrderReducer
    );
  };

  const onSaveShippingFee = (body) => {
    const { id, ...params } = body;
    action.sellerDetailOrderReducer.onUpdateShippingFee(
      id,
      params,
      dispatch.sellerDetailOrderReducer
    );
  };

  const onUpdateCampaignForOrder = (body) => {
    const { id, ...params } = body;
    action.sellerDetailOrderReducer.onPutCampaignForOrder(
      id,
      params,
      dispatch.sellerDetailOrderReducer
    );
  };

  useEffect(() => {
    onGetListSeller();
    onGetListOrderTag();
    onGetShippingFeeOption();
    onGetListInventory();
  }, []);
  useEffect(onRefresh, [
    orBoolean("sellerDetailOrderReducer.isRefresh", state),
  ]);
  useEffect(onRedirect, [
    orBoolean("sellerDetailOrderReducer.isRedirect", state),
  ]);
  useEffect(onSetup, [params]);
  useEffect(onGetListOrderLogs, [
    orNull("sellerDetailOrderReducer.detailOrder", state),
  ]);
  return (
    <DetailOrder
      orderLogs={orArray("sellerDetailOrderReducer.orderLogs", state)}
      user={orNull("userReducer.user", state)}
      item={orNull("sellerDetailOrderReducer.detailOrder", state)}
      handleBack={handleBack}
      listSeller={
        orArray("orderSellerReducer.sellers", state).length === 0
          ? orArray("orderSellerReducer.sellers", state)
          : orArray("sellerDetailOrderReducer.sellers", state)
      }
      listOrderTag={
        orArray("orderSellerReducer.orderTags", state).length
          ? orArray("orderSellerReducer.orderTags", state)
          : orArray("sellerDetailOrderReducer.orderTags", state)
      }
      customer={orNull("sellerDetailOrderReducer.customer", state)}
      listCampaign={orNull("sellerDetailOrderReducer.listCampaign", state)}
      shippingFeeOptions={orArray(
        "sellerDetailOrderReducer.shippingFeeList",
        state
      )}
      listCampaignOrder={orArray(
        "sellerDetailOrderReducer.listCampaignOrder",
        state
      )}
      listCurrentCampaign={orArray(
        "sellerDetailOrderReducer.listCurrentCampaign",
        state
      )}
      listInventory={orArray("sellerDetailOrderReducer.inventories", state)}
      onAssigneeSeller={onAssigneeSeller}
      onAcceptProcess={onAcceptProcess}
      onRejectProcess={onRejectProcess}
      onProcessResult={onProcessResult}
      onCancelOrder={onCancelOrder}
      onReOrder={onReOrder}
      onUpdateOrderNew={onUpdateOrderNew}
      onUpdateOrder={onUpdateOrder}
      handleCreateOrderLog={handleCreateOrderLog}
      onConfirmPayment={onConfirmPayment}
      onConfirmPaymentFail={onConfirmPaymentFail}
      onRejectForward={onRejectForward}
      onAcceptForward={onAcceptForward}
      onSaveShippingFee={onSaveShippingFee}
      onUpdateCampaignForOrder={onUpdateCampaignForOrder}
    />
  );
}

export default withReducer({
  key: "sellerDetailOrderReducer",
  ...orderReducer,
})(Detail);
