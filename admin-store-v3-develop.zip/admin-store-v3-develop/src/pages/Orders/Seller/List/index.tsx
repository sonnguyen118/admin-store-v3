import React, { useState, useEffect, useMemo } from "react";
import "./styled.scss";
import { orArray, orNumber } from "utils/Selector";
import { Mocks } from "utils";
import Search from "../Search";
import { Table, ModalSelectTags } from "../../private-components";
import { useHistory } from "react-router-dom";
import queryString from "query-string";

function List(props) {
  const {
    keySelectTed,
    dispatch,
    action,
    state,
    onReloadData,
    filterDefault,
    query,
    localFilterOrders,
    tabSelected,
  } = props;
  const history = useHistory();

  const [rows, setRows] = useState([]);
  const [listItemSelected, setListItemSelected] = useState([]);

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize,
    ...filterDefault,
  });
  const [visible, setVisible] = useState({
    isSeller: false,
    isAddTags: false,
    isRemoveTags: false,
  });

  const onGetListOrder = () => {
    if (
      keySelectTed === "isWaitingProduct" ||
      keySelectTed === "isFullProduct"
    ) {
      delete filter.page;
      delete filter.pageSize;
      action.orderSellerReducer.onGetListOrderWaitingProduct(
        filter,
        dispatch.orderSellerReducer
      );
    } else {
      action.orderSellerReducer.onGetListOrderSeller(
        filter,
        dispatch.orderSellerReducer
      );
    }
  };

  const onGetListSellerStep = () => {
    if (orArray("orderSellerReducer.sellerProcessStep", state).length === 0) {
      action.orderSellerReducer.onGetListSellerProcessStep(
        {},
        dispatch.orderSellerReducer
      );
    }
  };

  const onGetListOrderTag = () => {
    if (orArray("orderSellerReducer.orderTags", state).length === 0) {
      action.orderSellerReducer.onGetListOrderTag(
        {},
        dispatch.orderSellerReducer
      );
    }
  };

  const listOrderSourceOption = useMemo(() => {
    const list = orArray("orderSellerReducer.listOrderSource", state).map(
      (item) => ({
        value: item,
        label: item,
      })
    );
    return list;
  }, [state.orderSellerReducer]);

  function onGetListOrderSource() {
    action.orderSellerReducer.onGetListOrderSource(dispatch.orderSellerReducer);
  }

  useEffect(() => {
    onGetListOrderSource();
  }, []);

  useEffect(() => {
    onGetListOrder();
  }, [filter]);

  useEffect(onGetListSellerStep, []);

  useEffect(() => {
    onGetListOrderTag();
  }, []);

  function onUpdateData(): void {
    const listOrder = orArray("orderSellerReducer.sellerOrders", state);
    if (listOrder) {
      const r = [] as any;

      listOrder.forEach((node): void => {
        r.push({
          key: node.id,
          orderStatus: Mocks.ORDER.getOrderStatus(node.status),
          ...node,
        });
      });

      setRows(r);
    }
  }

  function onRefreshData() {
    onGetListOrder();
  }

  function onVisible(isSeller, isAddTags, isRemoveTags) {
    setVisible({ isSeller, isAddTags, isRemoveTags });
  }

  function handleCancel() {
    setVisible({
      isSeller: false,
      isAddTags: false,
      isRemoveTags: false,
    });
  }

  const handleSubmitTag = (values) => {
    const orderIds = listItemSelected.map((item) => item.id);
    const tags = values.tags.map((item) => item.value);
    const body = {
      action: visible.isRemoveTags
        ? "ADMIN_REMOVE_ORDER_TAG"
        : "ADMIN_ADD_ORDER_TAG",
      tags: tags,
      orderIds: orderIds,
    };
    action.orderSellerReducer.onManagerTagsMutipleOrder(
      body,
      dispatch.orderSellerReducer
    );
    handleCancel();
  };

  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "orders-seller",
        search: queryString.stringify({
          ...query,
          page: query.page,
          type: tabSelected,
        }),
      });
      setFilter((prevState) => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize,
        };
      });
    }
  }, [query]);

  function onChangePage(page, type) {
    history.push({
      pathname: "orders-seller",
      search: queryString.stringify({
        ...query,
        page,
        type: type ? type : tabSelected,
      }),
    });
  }

  function onDetailOrder(e, id) {
    e.preventDefault();
    history.push(`/orders-seller/detail/${id}`);
  }

  useEffect(onUpdateData, [orArray("orderSellerReducer.sellerOrders", state)]);

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        onVisible={onVisible}
        listItemSelected={listItemSelected}
        sellerProcessStep={orArray(
          "orderSellerReducer.sellerProcessStep",
          state
        )}
        listOrderTag={orArray("orderSellerReducer.orderTags", state)}
        onChangePage={onChangePage}
        localFilterOrders={localFilterOrders}
        path="/orders-seller"
        onReloadData={onReloadData}
        filterDefault={filterDefault}
        tabSelected={tabSelected}
        listOrderSourceOption={listOrderSourceOption}
        keySelectTed={keySelectTed}
      />
      <Table
        tabSelected={tabSelected}
        rows={rows}
        filter={filter}
        total={orNumber("orderSellerReducer.sellerOrderMeta.total", state)}
        setListItemSelected={setListItemSelected}
        listSeller={orArray("orderSellerReducer.sellers", state)}
        listOrderTag={orArray("orderSellerReducer.orderTags", state)}
        onRefreshData={onRefreshData}
        isSeller={true}
        onChangePage={onChangePage}
        onDetailOrder={onDetailOrder}
        keySelectTed={keySelectTed}
      />
      <ModalSelectTags
        visible={visible.isAddTags}
        title={
          visible.isRemoveTags
            ? "Xóa nhãn đơn hàng đã chọn"
            : "Thêm nhãn đơn hàng đã chọn"
        }
        onSubmit={handleSubmitTag}
        handleCancel={handleCancel}
        isRemoveTags={visible.isRemoveTags}
        listOrderTag={orArray("orderSellerReducer.orderTags", state)}
      />
    </div>
  );
}

export default List;
