import React, { useCallback, useEffect, useMemo, useState } from "react";
import { EditTabs } from "components";
import { Typography, Row, Col, Button, Modal } from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List";
import { useHistory } from "react-router-dom";
import { Helpers, Mocks } from "utils";
import queryString from "query-string";
import orderReducer from "../Reducer";
import { withReducer } from "hoc";
import { orNumber } from "utils/Selector";
import { Orders as ORDER_API } from "api";

const { Title } = Typography;
const { confirm } = Modal;

function Seller(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  const [localFilterOrders, setLocalFilterOrders] = useState([]);
  const [initialState, setInitialState] = useState(true);

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: !data.type
        ? 1
        : data.type && data.page
        ? parseInt(data.page as string)
        : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15,
      type: data.type ? data.type : "isPending",
    };
  }, [history.location.search]);

  const tabSelected: any = useMemo(() => {
    return query.type ? query.type : "isPending";
  }, [query.type]);

  const [isRefresh, setIsRefresh] = useState(true);
  const [fullProductOrderQuantity, setFullProductOrderQuantity] = useState(0);

  async function FetchingData() {
    try {
      const response = await ORDER_API.getWaitingProductFetching({
        isSeller: true,
      });
      if (response) {
        setIsRefresh(false);
        setFullProductOrderQuantity(orNumber("data.data", response));
      }
    } catch (error) {}
  }

  useEffect(() => {
    if (isRefresh) {
      FetchingData();
      setTimeout(() => {
        setIsRefresh(true);
      }, 1000 * 180);
    }
  }, [isRefresh]);

  useMemo(() => {
    if (initialState) {
      Helpers.localStorageGetItem("/orders-seller").then(function (value) {
        setLocalFilterOrders(JSON.parse(value) || []);
        if (value) {
          if (
            !JSON.parse(value).find((item) => item.key === tabSelected) &&
            !Mocks.ORDER.defaultSellerFilters.find(
              (item) => item.key === tabSelected
            )
          ) {
            history.push({
              pathname: "orders-seller",
              search: queryString.stringify({ ...query, type: "all" }),
            });
          }
          return;
        }
        if (
          !Mocks.ORDER.defaultSellerFilters.find(
            (item) => item.key === tabSelected
          )
        ) {
          history.push({
            pathname: "orders-seller",
            search: queryString.stringify({ ...query, type: "all" }),
          });
        }
      });
    }
    return setInitialState(false);
  }, [initialState]);

  const onReloadData = (newFilter) => {
    setInitialState(true);
    history.push({
      pathname: "orders-seller",
      search: queryString.stringify({ ...query, type: newFilter.key }),
    });
  };

  const getTabItems = useCallback(() => {
    if (localFilterOrders.length) {
      const tabs = Mocks.ORDER.defaultSellerFilters
        .concat(localFilterOrders)
        .map((item) => ({
          title: item.name,
          closable: localFilterOrders.find((f) => f.key === item.key)
            ? true
            : false,
          key: item.key,
          component: (
            <List
              keySelectTed={item.key}
              dispatch={dispatch}
              action={action}
              state={state}
              localFilterOrders={localFilterOrders}
              query={query}
              tabSelected={tabSelected}
              filterDefault={item.filter}
              onReloadData={onReloadData}
            />
          ),
        }));
      return (
        <EditTabs
          activeKey={tabSelected}
          tabItems={tabs}
          onChangeTab={onChangeTab}
          onEdit={onEditTab}
          fullProductOrderQuantity={fullProductOrderQuantity}
        />
      );
    }
    const tabs = Mocks.ORDER.defaultSellerFilters.map((item) => ({
      title: item.name,
      closable: false,
      key: item.key,
      component: (
        <List
          keySelectTed={item.key}
          dispatch={dispatch}
          action={action}
          state={state}
          localFilterOrders={localFilterOrders}
          query={query}
          tabSelected={tabSelected}
          filterDefault={item.filter}
          onReloadData={onReloadData}
        />
      ),
    }));
    return (
      <EditTabs
        activeKey={tabSelected}
        tabItems={tabs}
        onChangeTab={onChangeTab}
        onEdit={onEditTab}
        fullProductOrderQuantity={fullProductOrderQuantity}
      />
    );
  }, [localFilterOrders, query, tabSelected, fullProductOrderQuantity]);

  function onCreateClick() {
    history.push("/orders-seller/create");
  }

  function onChangeTab(activeKey) {
    history.push({
      pathname: "orders-seller",
      search: queryString.stringify({ ...query, page: 1, type: activeKey }),
    });
  }

  function onConfirmRemoveFilter(targetKey) {
    Helpers.localStorageSetItem(
      "/orders-seller",
      JSON.stringify(localFilterOrders.filter((f) => f.key != targetKey))
    ).then(function () {
      return setInitialState(true);
    });
  }

  function onEditTab(targetKey, action) {
    switch (action) {
      case "remove":
        confirm({
          closable: true,
          title: "Thông báo!",
          okText: "Xác nhận",
          cancelText: "Hủy",
          content:
            "Bạn chắc chẳn muốn xóa bộ lọc này? Bộ lọc bị xóa sẽ không thể hoàn tác lại!",
          okType: "primary",
          onOk() {
            onConfirmRemoveFilter(targetKey);
          },
        });
        return;
      default:
        return;
    }
  }

  return (
    <div>
      <Row>
        <Col span={8}>
          <Title level={2}>Đơn hàng</Title>
        </Col>
        <Col span={8} offset={8}>
          <Row>
            <Col span={10} offset={14}>
              <Button
                onClick={onCreateClick}
                type="primary"
                icon={<PlusCircleOutlined />}
              >
                Tạo đơn hàng
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
      {getTabItems()}
    </div>
  );
}

export default withReducer({
  key: "orderSellerReducer",
  ...orderReducer,
})(Seller);
