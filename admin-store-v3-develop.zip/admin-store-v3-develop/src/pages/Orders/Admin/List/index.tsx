import React, { useState, useEffect, useMemo } from "react";
import "./styled.scss";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import { Mocks } from "utils";
import Search from "../Search";
import {
  Table,
  ModalSelectSeller,
  ModalSelectTags,
} from "../../private-components";
import { useHistory } from "react-router-dom";
import queryString from "query-string";

function List(props) {
  const history = useHistory();

  const {
    keySelectTed,
    dispatch,
    action,
    state,
    onReloadData,
    filterDefault,
    query,
    localFilterOrders,
    tabSelected,
  } = props;
  const [rows, setRows] = useState([]);
  const [listItemSelected, setListItemSelected] = useState([]);
  const [visible, setVisible] = useState({
    isSeller: false,
    isAddTags: false,
    isRemoveTags: false,
    isForwardSeller: false,
  });

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize,
    ...filterDefault,
  });

  const onGetListOrder = () => {
    if (
      keySelectTed === "isWaitingProduct" ||
      keySelectTed === "isFullProduct"
    ) {
      delete filter.page;
      delete filter.pageSize;
      action.orderReducer.onGetListOrderWaitingProduct(
        filter,
        dispatch.orderReducer
      );
    } else {
      action.orderReducer.onGetListOrder(filter, dispatch.orderReducer);
    }
  };

  const onGetListSeller = () => {
    if (orEmpty("orderReducer.sellers", state).length === 0) {
      action.orderReducer.onGetListSeller({}, dispatch.orderReducer);
    }
  };

  const onGetAllSeller = () => {
    if (orEmpty("orderReducer.allSellers", state).length === 0) {
      action.orderReducer.onGetListAllSeller(
        { isFilter: true },
        dispatch.orderReducer
      );
    }
  };

  const onGetListOrderTag = () => {
    if (orEmpty("orderReducer.orderTags", state).length === 0) {
      action.orderReducer.onGetListOrderTag({}, dispatch.orderReducer);
    }
  };

  const onGetListSellerStep = () => {
    if (orEmpty("orderReducer.sellerProcessStep", state).length === 0) {
      action.orderReducer.onGetListSellerProcessStep({}, dispatch.orderReducer);
    }
  };

  const listOrderSourceOption = useMemo(() => {
    const list = orArray("orderReducer.listOrderSource", state).map((item) => ({
      value: item,
      label: item,
    }));
    return list;
  }, [state.orderReducer]);

  function onGetListOrderSource() {
    action.orderReducer.onGetListOrderSource(dispatch.orderReducer);
  }

  useEffect(() => {
    onGetListOrderSource();
  }, []);

  function onUpdateData(): void {
    const listOrder = orArray("orderReducer.orders", state);
    if (listOrder) {
      const r = [] as any;

      listOrder.forEach((node): void => {
        r.push({
          key: node.id,
          orderStatus: Mocks.ORDER.getOrderStatus(node.status),
          ...node,
        });
      });
      setRows(r);
    }
  }

  function onRefreshData() {
    onGetListOrder();
  }

  function handleSubmit(values) {
    const orderIds = listItemSelected.map((item) => item.id);
    const body = {
      action: "ADMIN_ASSIGNEE_SELLER",
      seller: values.seller,
      orderIds: orderIds,
    };
    action.orderReducer.onAssingneeSellerMutipleOrder(
      body,
      dispatch.orderReducer
    );
    handleCancel();
  }

  function handleForwardSeller(values) {
    const orderIds = listItemSelected.map((item) => item.id);
    const body = {
      seller: values.seller,
      orderIds: orderIds,
    };
    action.orderReducer.onForwardSellerMultipleOrder(
      body,
      dispatch.orderReducer
    );
    handleCancel();
  }

  const handleSubmitTag = (values) => {
    const orderIds = listItemSelected.map((item) => item.id);
    const tags = values.tags.map((item) => item.value);
    const body = {
      action: visible.isRemoveTags
        ? "ADMIN_REMOVE_ORDER_TAG"
        : "ADMIN_ADD_ORDER_TAG",
      tags: tags,
      orderIds: orderIds,
    };
    action.orderReducer.onManagerTagsMutipleOrder(body, dispatch.orderReducer);
    handleCancel();
  };

  function isRefreshListData() {
    if (orBoolean("orderReducer.isRefresh", state)) {
      onGetListOrder();
    }
  }

  function onVisible(isSeller, isAddTags, isRemoveTags, isForwardSeller) {
    setVisible({ isSeller, isAddTags, isRemoveTags, isForwardSeller });
  }

  function handleCancel() {
    setVisible({
      isSeller: false,
      isAddTags: false,
      isRemoveTags: false,
      isForwardSeller: false,
    });
  }

  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "orders",
        search: queryString.stringify({
          ...query,
          page: query.page,
          type: tabSelected,
        }),
      });
      setFilter((prevState) => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize,
        };
      });
    }
  }, [query]);

  function onChangePage(page, type) {
    history.push({
      pathname: "orders",
      search: queryString.stringify({
        ...query,
        page,
        type: type ? type : tabSelected,
      }),
    });
  }

  function onDetailOrder(e, id) {
    e.preventDefault();
    history.push(`/orders/detail/${id}`);
  }

  useEffect(onUpdateData, [orArray("orderReducer.orders", state)]);
  useEffect(onGetListOrder, [filter]);
  useEffect(onGetListSellerStep, []);
  useEffect(onGetListSeller, []);
  useEffect(onGetAllSeller, []);
  useEffect(onGetListOrderTag, []);
  useEffect(isRefreshListData, [orBoolean("orderReducer.isRefresh", state)]);

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        onVisible={onVisible}
        localFilterOrders={localFilterOrders}
        listItemSelected={listItemSelected}
        listSeller={orArray("orderReducer.allSellers", state)}
        sellerProcessStep={orArray("orderReducer.sellerProcessStep", state)}
        onChangePage={onChangePage}
        path="/orders"
        onReloadData={onReloadData}
        filterDefault={filterDefault}
        tabSelected={tabSelected}
        listOrderTag={orArray("orderReducer.orderTags", state)}
        listOrderSourceOption={listOrderSourceOption}
        keySelectTed={keySelectTed}
      />
      <Table
        tabSelected={tabSelected}
        setListItemSelected={setListItemSelected}
        rows={rows}
        filter={filter}
        total={orNumber("orderReducer.orderMeta.total", state)}
        listSeller={orArray("orderReducer.sellers", state)}
        listOrderTag={orArray("orderReducer.orderTags", state)}
        onRefreshData={onRefreshData}
        onChangePage={onChangePage}
        onDetailOrder={onDetailOrder}
        user={orNull("userReducer.user", state)}
        keySelectTed={keySelectTed}
      />
      <ModalSelectSeller
        visible={visible.isSeller}
        onSubmit={handleSubmit}
        handleCancel={handleCancel}
        listSeller={orArray("orderReducer.sellers", state)}
      />
      <ModalSelectSeller
        visible={visible.isForwardSeller}
        onSubmit={handleForwardSeller}
        handleCancel={handleCancel}
        listSeller={orArray("orderReducer.sellers", state)}
      />
      <ModalSelectTags
        visible={visible.isAddTags}
        title={
          visible.isRemoveTags
            ? "Xóa nhãn đơn hàng đã chọn"
            : "Thêm nhãn đơn hàng đã chọn"
        }
        onSubmit={handleSubmitTag}
        handleCancel={handleCancel}
        isRemoveTags={visible.isRemoveTags}
        listOrderTag={orArray("orderReducer.orderTags", state)}
      />
    </div>
  );
}

export default List;
