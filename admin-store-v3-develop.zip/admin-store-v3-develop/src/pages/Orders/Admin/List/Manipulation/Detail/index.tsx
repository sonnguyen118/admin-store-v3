import React, { useEffect, useMemo } from "react";
import { DetailOrder } from "../../../../private-components";
import { useHistory, useParams } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import orderReducer from "../../../../Reducer";
import { Modal } from "antd";
const { warning } = Modal;
interface RouteParams {
  id: string;
}
function Detail(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();
  const params = useParams<RouteParams>();
  function handleBack() {
    history.goBack();
  }

  function onSetup() {
    if (orEmpty("id", params)) {
      action.detailOrderReducer.getDetailOrder(
        orEmpty("id", params),
        dispatch.detailOrderReducer
      );
    }
  }

  const onGetListSeller = () => {
    if (orEmpty("orderReducer.sellers", state).length === 0) {
      action.detailOrderReducer.onGetListSeller(
        {},
        dispatch.detailOrderReducer
      );
    }
  };

  const onGetListInventory = () => {
    const { id } = params;
    action.detailOrderReducer.onGetListInventoryNew(
      id,
      { isSalonInventories: true, isOnlyShowInOrder: true },
      dispatch.detailOrderReducer
    );
  };

  const onGetListOrderTag = () => {
    if (orEmpty("orderReducer.orderTags", state).length === 0) {
      action.detailOrderReducer.onGetListOrderTag(
        {},
        dispatch.detailOrderReducer
      );
    }
  };

  const onGetShippingFeeOption = () => {
    action.detailOrderReducer.onGetShippingFeeOption(
      {},
      dispatch.detailOrderReducer
    );
  };

  function onAssigneeSeller(body) {
    const { id, ...params } = body;
    action.detailOrderReducer.onAssingneeSeller(
      id,
      params,
      dispatch.detailOrderReducer
    );
  }

  function onAcceptProcess(id) {
    action.detailOrderReducer.onSellerAcceptProcess(
      id,
      dispatch.detailOrderReducer
    );
  }

  function onRejectProcess(id) {
    action.detailOrderReducer.onSellerRejectProcess(
      id,
      dispatch.detailOrderReducer
    );
  }

  function onProcessResult(values) {
    const { id, ...body } = values;
    action.detailOrderReducer.onSellerProcessResult(
      id,
      body,
      dispatch.detailOrderReducer
    );
  }

  const onCancelOrder = (params) => {
    const { id, ...body } = params;
    action.detailOrderReducer.onCancelOrder(
      id,
      body,
      dispatch.detailOrderReducer
    );
  };

  const onUpdateOrder = (values) => {
    const { id, ...body } = values;
    action.detailOrderReducer.updateOrder(
      id,
      body,
      dispatch.detailOrderReducer
    );
  };

  const onUpdateOrderNew = (values) => {
    const { id, ...body } = values;
    action.detailOrderReducer.updateOrderNew(
      id,
      body,
      dispatch.detailOrderReducer
    );
  };

  const handleCreateOrderLog = (values) => {
    const { id, ...body } = values;
    action.detailOrderReducer.createOrderLogs(
      id,
      body,
      dispatch.detailOrderReducer
    );
  };

  const onConfirmPayment = (id) => {
    action.detailOrderReducer.confirmPayment(id, dispatch.detailOrderReducer);
  };

  const onConfirmPaymentFail = (id) => {
    action.detailOrderReducer.confirmPaymentFail(
      id,
      dispatch.detailOrderReducer
    );
  };

  const onGetListOrderLogs = () => {
    if (orNull("detailOrderReducer.detailOrder", state)) {
      action.detailOrderReducer.onGetListOrderLogs(
        orEmpty("detailOrderReducer.detailOrder.id", state),
        dispatch.detailOrderReducer
      );
    }
    onGetListInventory();
  };

  const onGetCustomer = () => {
    if (orNull("detailOrderReducer.detailOrder", state)) {
      const params = {
        id: orEmpty("detailOrderReducer.detailOrder.customerId", state),
      };
      action.detailOrderReducer.getCustomer(
        params,
        dispatch.detailOrderReducer
      );
    }
  };

  const onGetListCampaign = () => {
    if (orNull("detailOrderReducer.detailOrder", state)) {
      if (
        orBoolean(
          "detailOrderReducer.detailOrder.isSellerProcessCompleted",
          state
        )
      ) {
        return;
      }
      // function getVoucherCodes() {
      //   if (
      //     orArray("detailOrderReducer.detailOrder.refCampaigns", state).length >
      //     0
      //   ) {
      //     return orArray(
      //       "detailOrderReducer.detailOrder.refCampaigns",
      //       state
      //     ).map((item) => item.voucherCode);
      //   }
      //   return orArray(
      //     "detailOrderReducer.detailOrder.campaigns.voucherCodes",
      //     state
      //   );
      // }
      if (orEmpty("detailOrderReducer.detailOrder.customerId", state)) {
        const params = {
          customerId: orEmpty(
            "detailOrderReducer.detailOrder.customerId",
            state
          ),
          customerPhone: orEmpty(
            "detailOrderReducer.detailOrder.customerPhone",
            state
          ),
          campaigns: orArray(
            "detailOrderReducer.detailOrder.campaigns.campaigns",
            state
          ).map((item) => ({
            campaignId: orEmpty("campaignId", item),
            code: orEmpty("code", item),
          })),
          products: orArray(
            "detailOrderReducer.detailOrder.orderItems",
            state
          ).map((item) => ({
            productId: 0,
            sku: item.productSKU,
            quant: item.quantity,
            price: item.price,
          })),
        };
        action.detailOrderReducer.onGetListCampaign(
          params,
          dispatch.detailOrderReducer
        );
      }
    }
  };

  const onGetListCampaignOrder = () => {
    if (
      orNull("detailOrderReducer.detailOrder", state) &&
      orArray("detailOrderReducer.listCampaign", state).length
    ) {
      if (
        orBoolean(
          "detailOrderReducer.detailOrder.isSellerProcessCompleted",
          state
        )
      ) {
        return;
      }
      const params = {
        campaignIds: orArray(
          "detailOrderReducer.listCampaign.listCampaign",
          state
        ).map((item) => item.mktCampaign.id),
      };
      action.detailOrderReducer.onGetListCampaignOrder(
        orEmpty("detailOrderReducer.detailOrder.customerId", state),
        params,
        dispatch.detailOrderReducer
      );
    }
  };

  useEffect(() => {
    onGetListInventory();
  }, [dispatch]);

  // useMemo(() => {
  //   if (orNull("detailOrderReducer.detailOrder", state)) {
  //     if (
  //       orBoolean(
  //         "detailOrderReducer.detailOrder.isSellerProcessCompleted",
  //         state
  //       )
  //     ) {
  //       return;
  //     }
  //     const params = {
  //       customerId: orEmpty("detailOrderReducer.detailOrder.customerId", state),
  //       listCampaign: orArray(
  //         "detailOrderReducer.detailOrder.campaigns.campaigns",
  //         state
  //       ).map((item) => ({
  //         voucherCode: orEmpty("voucherCode", item),
  //         campaignId: orEmpty("campaignId", item),
  //       })),
  //     };
  //     action.detailOrderReducer.onGetListCurrentCampaign(
  //       params,
  //       dispatch.detailOrderReducer
  //     );
  //   }
  // }, [orNull("detailOrderReducer.detailOrder", state)]);

  useMemo(() => {
    if (orArray("detailOrderReducer.campaignError", state).length) {
      warning({
        title: "Thông báo!",
        okText: "Xác nhận",
        content: (
          <div>
            {orArray("detailOrderReducer.campaignError", state).map(
              (dt, index) => {
                return <div key={index}>- {dt.message}</div>;
              }
            )}
          </div>
        ),
        width: 800,
      });
      return;
    }
  }, [orArray("detailOrderReducer.campaignError", state)]);

  useMemo(() => {
    onGetListCampaign();
  }, [orNull("detailOrderReducer.detailOrder", state)]);

  useMemo(() => {
    onGetListCampaignOrder();
  }, [
    orNull("detailOrderReducer.detailOrder", state),
    orArray("detailOrderReducer.listCampaign", state),
  ]);

  useEffect(onGetCustomer, [
    orNull("detailOrderReducer.detailOrder.customerId", state),
  ]);

  const onReOrder = (id) => {
    history.push(`/orders/${id}/reorder`);
  };

  const onRefresh = () => {
    if (orBoolean("detailOrderReducer.isRefresh", state)) {
      onSetup();
    }
  };

  const onRedirect = () => {
    if (orBoolean("detailOrderReducer.isRedirect", state)) {
      history.push("/orders");
    }
  };

  const onRejectForward = (id) => {
    const body = {
      isAccept: 0,
    };
    action.detailOrderReducer.onForwardConfirm(
      id,
      body,
      "onReject",
      dispatch.detailOrderReducer
    );
  };

  const onAcceptForward = (id) => {
    const body = {
      isAccept: 1,
    };
    action.detailOrderReducer.onForwardConfirm(
      id,
      body,
      "onAccept",
      dispatch.detailOrderReducer
    );
  };

  const onSaveShippingFee = (body) => {
    onGetListInventory();
    const { id, ...params } = body;
    action.detailOrderReducer.onUpdateShippingFee(
      id,
      params,
      dispatch.detailOrderReducer
    );
  };

  const onUpdateCampaignForOrder = (body) => {
    const { id, ...params } = body;
    action.detailOrderReducer.onPutCampaignForOrder(
      id,
      params,
      dispatch.detailOrderReducer
    );
  };

  useEffect(onSetup, [orEmpty("id", params)]);
  useEffect(() => {
    onGetListSeller();
    onGetListOrderTag();
    onGetShippingFeeOption();
    onGetListInventory();
  }, []);
  useEffect(onRefresh, [orBoolean("detailOrderReducer.isRefresh", state)]);
  useEffect(onRedirect, [orBoolean("detailOrderReducer.isRedirect", state)]);

  useEffect(onGetListOrderLogs, [
    orNull("detailOrderReducer.detailOrder", state),
  ]);

  return (
    <DetailOrder
      orderLogs={orArray("detailOrderReducer.orderLogs", state)}
      user={orNull("userReducer.user", state)}
      item={orNull("detailOrderReducer.detailOrder", state)}
      handleBack={handleBack}
      listSeller={
        orArray("orderReducer.sellers", state).length
          ? orArray("orderReducer.sellers", state)
          : orArray("detailOrderReducer.sellers", state)
      }
      listOrderTag={
        orArray("orderReducer.orderTags", state).length
          ? orArray("orderReducer.orderTags", state)
          : orArray("detailOrderReducer.orderTags", state)
      }
      customer={orNull("detailOrderReducer.customer", state)}
      shippingFeeOptions={orArray("detailOrderReducer.shippingFeeList", state)}
      listCampaign={orArray("detailOrderReducer.listCampaign", state)}
      listCampaignOrder={orArray("detailOrderReducer.listCampaignOrder", state)}
      listCurrentCampaign={orArray(
        "detailOrderReducer.listCurrentCampaign",
        state
      )}
      listInventory={orArray("detailOrderReducer.inventories", state)}
      onAssigneeSeller={onAssigneeSeller}
      onAcceptProcess={onAcceptProcess}
      onRejectProcess={onRejectProcess}
      onProcessResult={onProcessResult}
      onCancelOrder={onCancelOrder}
      onReOrder={onReOrder}
      onUpdateOrder={onUpdateOrder}
      onUpdateOrderNew={onUpdateOrderNew}
      handleCreateOrderLog={handleCreateOrderLog}
      onConfirmPayment={onConfirmPayment}
      onConfirmPaymentFail={onConfirmPaymentFail}
      isAdmin={true}
      onRejectForward={onRejectForward}
      onAcceptForward={onAcceptForward}
      onSaveShippingFee={onSaveShippingFee}
      onUpdateCampaignForOrder={onUpdateCampaignForOrder}
    />
  );
}

export default withReducer({
  key: "detailOrderReducer",
  ...orderReducer,
})(Detail);
