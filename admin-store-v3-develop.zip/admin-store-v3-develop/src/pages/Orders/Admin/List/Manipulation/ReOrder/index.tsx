import React, { useEffect } from "react";
import { DetailOrder } from "../../../../private-components";
import { useHistory, useParams } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import orderReducer from "../../../../Reducer";
import { Form } from "../../../../private-components";

function Detail(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();
  const params = useParams();

  function onSetup() {
    action.reOrderReducer.getDetailReorder(
      orEmpty("id", params),
      dispatch.reOrderReducer
    );
  }

  function onCancelClick() {
    history.replace(`/orders/detail/${orEmpty("id", params)}`);
  }

  function onSave(body) {
    action.reOrderReducer.createOrder(body, dispatch.reOrderReducer);
  }

  const onGetListOrderTag = () => {
    action.reOrderReducer.onGetListOrderTag({}, dispatch.reOrderReducer);
  };

  function onGetListOrderSource() {
    action.reOrderReducer.onGetListOrderSource(dispatch.reOrderReducer);
  }

  const onRedirect = () => {
    if (orBoolean("reOrderReducer.isRedirect", state)) {
      history.push(
        `/orders/detail/${orEmpty("reOrderReducer.createData.code", state)}`
      );
    }
  };

  React.useEffect(onRedirect, [orBoolean("reOrderReducer.isRedirect", state)]);

  useEffect(onSetup, [params]);
  React.useEffect(onGetListOrderTag, []);
  React.useEffect(onGetListOrderSource, []);

  return (
    <Form
      item={orNull("reOrderReducer.detailOrder", state)}
      listOrderTag={orArray("reOrderReducer.orderTags", state)}
      listOrderSource={orArray("reOrderReducer.listOrderSource", state)}
      user={orNull("userReducer.user", state)}
      onCancelClick={onCancelClick}
      onSave={onSave}
    />
  );
}

export default withReducer({
  key: "reOrderReducer",
  ...orderReducer,
})(Detail);
