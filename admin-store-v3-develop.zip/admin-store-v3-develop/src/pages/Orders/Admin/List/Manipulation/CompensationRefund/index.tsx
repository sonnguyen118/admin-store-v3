import { CompensationRefund } from '../../../../private-components';
import { useHistory, useParams } from 'react-router-dom';
import { withReducer } from 'hoc';
import { orBoolean, orEmpty, orNull, orArray, orNumber } from 'utils/Selector';
import detailOrderReducer from '../../../../Reducer';
import { useEffect } from 'react';

function Detail(props) {
	const { dispatch, action, state } = props;
	const history = useHistory();
	const params = useParams();

	function handleBack() {
		history.goBack();
	}

	function onSetup() {
		if (orEmpty('id', params)) {
			action.detailOrderReducer.getDetailOrder(
				orEmpty('id', params),
				dispatch.detailOrderReducer
			);
		}
	}

	const onUpdateTransport = (params) => {
		const { id, ...body } = params;
		action.detailOrderReducer.updateOrder(id, body, dispatch.detailOrderReducer);
	};

	const onGetListOrderTag = () => {
		action.detailOrderReducer.onGetListOrderTag({}, dispatch.detailOrderReducer);
	};

	const handleCreateLog = (params) => {
		const { id, ...body } = params;
		action.detailOrderReducer.createLogs(id, body, dispatch.detailOrderReducer);
	};

	const onRefresh = () => {
		if (orBoolean('detailOrderReducer.isRefresh', state)) {
			onSetup();
		}
	};

	const onRedirect = () => {
		if (orBoolean('detailOrderReducer.isRedirect', state)) {
			history.push(
				`/transports/detail/${orEmpty('detailOrderReducer.createData.code', state)}`
			);
		}
	};

	const onGetListFulfillmentCompany = () => {
		action.detailOrderReducer.onGetListFulfillmentCompany({}, dispatch.detailOrderReducer);
	};

	const handleCalculateShippingFee = (body) => {
		action.detailOrderReducer.calculateShippingFee(
			{ ...body, fulfillmentType: orEmpty('type', params).toUpperCase() },
			dispatch.detailOrderReducer
		);
	};

	const setShippingFeeToEmpty = () => {
		action.detailOrderReducer.setShippingFeeToEmpty(dispatch.detailOrderReducer);
	};

	const handleCreateCompensationOrder = (values) => {
		const { id, ...body } = values;
		action.detailOrderReducer.createCompensationRefundTransport(
			id,
			{ fulfillment: body, type: orEmpty('type', params).toUpperCase() },
			dispatch.detailOrderReducer
		);
	};
	const onGetCustomer = () => {
		if (orNull('detailOrderReducer.detailOrder', state)) {
			const params = {
				id: orEmpty('detailOrderReducer.detailOrder.customerId', state),
			};
			action.detailOrderReducer.getCustomer(params, dispatch.detailOrderReducer);
		}
	};
	useEffect(onGetCustomer, [orNull('detailOrderReducer.detailOrder.customerId', state)]);
	useEffect(onGetListOrderTag, []);
	useEffect(onSetup, []);
	useEffect(onGetListFulfillmentCompany, []);
	useEffect(onRefresh, [orBoolean('detailOrderReducer.isRefresh', state)]);
	useEffect(onRedirect, [orBoolean('detailOrderReducer.isRedirect', state)]);

	return (
		<CompensationRefund
			fullfillmentCompanies={orArray('detailOrderReducer.fullfillmentCompanies', state)}
			item={orNull('detailOrderReducer.detailOrder', state)}
			customerInfo={orNull('detailOrderReducer.customer', state)}
			user={orNull('userReducer.user', state)}
			logs={orNull('detailOrderReducer.logs', state)}
			handleBack={handleBack}
			onUpdateTransport={onUpdateTransport}
			handleCreateLog={handleCreateLog}
			handleCalculateShippingFee={handleCalculateShippingFee}
			shippingFeeCalculate={orNumber('detailOrderReducer.shippingFeeCalculate', state)}
			isGetShippingFee={orBoolean('detailOrderReducer.isGetShippingFee', state)}
			setShippingFeeToEmpty={setShippingFeeToEmpty}
			message={orBoolean('detailOrderReducer.shippingFeeMessage', state)}
			handleCreateCreateCompensationOrder={handleCreateCompensationOrder}
			listOrderTag={orArray('detailOrderReducer.orderTags', state)}
		/>
	);
}
export default withReducer({
	key: 'detailOrderReducer',
	...detailOrderReducer,
})(Detail);
