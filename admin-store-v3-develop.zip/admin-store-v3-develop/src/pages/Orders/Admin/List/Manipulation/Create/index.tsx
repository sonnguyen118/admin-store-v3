import React from "react";
import { Form } from "../../../../private-components";
import { useHistory } from "react-router-dom";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import orderReducer from "../../../../Reducer";
function Create(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  function onCancelClick() {
    history.goBack();
  }

  function onSave(body) {
    action.createOrderReducer.createOrder(body, dispatch.createOrderReducer);
  }

  const onGetListOrderTag = () => {
    action.createOrderReducer.onGetListOrderTag(
      {},
      dispatch.createOrderReducer
    );
  };

  function onGetListOrderSource() {
    action.createOrderReducer.onGetListOrderSource(dispatch.createOrderReducer);
  }

  const onRedirect = () => {
    if (orBoolean("createOrderReducer.isRedirect", state)) {
      history.push(
        `/orders/detail/${orEmpty("createOrderReducer.createData.code", state)}`
      );
    }
  };

  React.useEffect(onRedirect, [
    orBoolean("createOrderReducer.isRedirect", state),
  ]);
  React.useEffect(onGetListOrderTag, []);
  React.useEffect(onGetListOrderSource, []);

  return (
    <Form
      user={orNull("userReducer.user", state)}
      onCancelClick={onCancelClick}
      onSave={onSave}
      listOrderTag={orArray("createOrderReducer.orderTags", state)}
      listOrderSource={orArray("createOrderReducer.listOrderSource", state)}
    />
  );
}

export default withReducer({
  key: "createOrderReducer",
  ...orderReducer,
})(Create);
