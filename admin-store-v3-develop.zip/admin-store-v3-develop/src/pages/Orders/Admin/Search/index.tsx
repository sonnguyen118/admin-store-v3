import React, { useRef, useState } from "react";
import "./styled.scss";
import { Button, Menu, Dropdown } from "antd";
import { DownOutlined } from "@ant-design/icons";
import { Filter } from "../../private-components";
import ReactToPrint from "react-to-print";
import { orEmpty, orBoolean, orNumber, orArray } from "utils/Selector";
import { ComponentToPrint as PrintOrder } from "components";
import _ from "lodash";

const printPageStyle = `
  @page { size: auto;  margin: 5mm; }
  @media print {
    body { 
      -webkit-print-color-adjust: exact;
      page-break-after: auto;
    }
    html, body { 
      -webkit-print-color-adjust: exact;
      height: initial !important; 
      overflow: initial !important; 
    }
  }
  @media print { body { -webkit-print-color-adjust: exact; } }
`;

function Search(props) {
  const {
    filter,
    setFilter,
    onVisible,
    listItemSelected,
    listSeller,
    sellerProcessStep,
    onChangePage,
    localFilterOrders,
    path,
    onReloadData,
    filterDefault,
    tabSelected,
    listOrderTag,
    listOrderSourceOption,
    keySelectTed,
  } = props;

  const [printItems, setPrintItems]: any = useState({
    listOrder: [],
    listProduct: [],
  });

  const [sortValue, setSortValue] = useState("");

  const filterOptions = [
    {
      label: "Trạng thái đơn hàng",
      value: "status",
    },
    {
      label: "Loại đơn chốt thành công",
      value: "withOrderCompletedType",
    },
    {
      label: "Thời gian khách nhận hàng",
      value: "withShippingType",
    },
    {
      label: "Lý do hủy đơn",
      value: "withCancelReason",
    },
    {
      label: "Trạng thái thanh toán",
      value: "withPaymentStatus",
    },
    {
      label: "Phương thức thanh toán",
      value: "withPaymentGateway",
    },
    {
      label: "Tên Seller",
      value: "withNameSeller",
    },
    {
      label: "Tác Nghiệp Seller",
      value: "withSellerStep",
    },
    {
      label: "Trạng thái nhận đơn",
      value: "withSellerAcceptStatus",
    },
    {
      label: "Kênh bán hàng",
      value: "withSource",
    },
    {
      label: "Tags",
      value: "withTags",
    },
    {
      label: "Ngày tạo",
      value: "withDateTime",
    },
    {
      label: "Loại đơn trả hàng, bù hàng",
      value: "withCompensationAndRefund",
    },
  ];

  const optionMultiple = [
    "status",
    "withShippingType",
    "withCancelReason",
    "withPaymentStatus",
    "withPaymentGateway",
    "withNameSeller",
    "withSellerStep",
    "withSellerAcceptStatus",
    "withSource",
    "withTags",
    "withCompensationAndRefund",
  ];

  function handleMenuClick({ key }) {
    switch (key) {
      case "assigneeSeller":
        onVisible(true, false, false, false);
        return;
      case "forwardSeller":
        onVisible(false, false, false, true);
        return;
      case "addTag":
        onVisible(false, true, false, false);
        return;
      case "removeTag":
        onVisible(false, true, true, false);
        return;
      default:
        return;
    }
  }

  const componentRef = useRef<HTMLDivElement>(null);

  const ComponentToPrint = () => {
    return printItems.listOrder.map((item, key) => {
      const itemPrint = {
        orderCode: item.code,
        customerName: orEmpty("shippingAddress.customerName", item),
        address: orEmpty("shippingAddress.address", item),
        wardName: orEmpty("shippingAddress.wardName", item),
        districtName: orEmpty("shippingAddress.districtName", item),
        provinceName: orEmpty("shippingAddress.provinceName", item),
        customerPhone: orEmpty("shippingAddress.customerPhone", item),
        fulfillmentCompany: orEmpty(
          "fulfillmentOrder.fulfillmentCompany",
          item
        ),
        shippingType: orEmpty("shippingType", item),
        cashByRecipient: orBoolean("fulfillmentOrder.cashByRecipient", item),
        enableReviewBefore: orBoolean(
          "fulfillmentOrder.enableReviewBefore",
          item
        ),
        paymentGateway: orEmpty("paymentGateway", item),
        totalPrice: orNumber("totalPrice", item),
        orderItems: orArray("orderItems", item),
        customerNote: orEmpty("customerNote", item),
      };
      return <PrintOrder key={key} item={itemPrint} />;
    });
  };

  const handleBeforeGetContent = () => {
    setPrintItems((prevState) => ({
      ...prevState,
      listOrder: listItemSelected,
    }));
    return Promise.resolve();
  };

  const menu = (
    <Menu onClick={handleMenuClick}>
      <Menu.Item key="assigneeSeller">Gán đơn cho Seller</Menu.Item>
      <Menu.Item key="forwardSeller">Chuyển tiếp đơn cho Seller</Menu.Item>
      <Menu.Item key="addTag">Thêm nhãn đơn hàng đã chọn</Menu.Item>
      <Menu.Item key="removeTag">Xóa nhãn đơn hàng đã chọn</Menu.Item>
      <Menu.Item key="printOrder">
        <ReactToPrint
          pageStyle={printPageStyle}
          onAfterPrint={() =>
            setPrintItems((prevState) => ({ ...prevState, listOrder: [] }))
          }
          removeAfterPrint={true}
          trigger={() => <span>In đơn hàng đã chọn</span>}
          onBeforeGetContent={handleBeforeGetContent}
          content={() => componentRef.current}
        />
      </Menu.Item>
    </Menu>
  );

  function handleMenuSortClick({ key }) {
    switch (key) {
      case "default":
        delete filter.sort;
        setFilter({ ...filter });
        setSortValue("Mặc định");
        return;
      case "waitingDesc":
        setFilter((prevState) => ({
          ...prevState,
          sort: "waitingProductAt",
        }));
        setSortValue("Ngày chờ hàng từ cao đến thấp");
        return;
      case "waitingAsc":
        setFilter((prevState) => ({
          ...prevState,
          sort: "-waitingProductAt",
        }));
        setSortValue("Ngày chờ hàng từ thấp đến cao");
        return;
      default:
        return;
    }
  }

  const menuSort = (
    <Menu onClick={handleMenuSortClick}>
      <Menu.Item key="default">Mặc định</Menu.Item>
      <Menu.Item key="waitingDesc">Ngày chờ hàng từ cao đến thấp</Menu.Item>
      <Menu.Item key="waitingAsc">Ngày chờ hàng từ thấp đến cao</Menu.Item>
    </Menu>
  );

  return (
    <div className="search-wrapper">
      <Filter
        filter={filter}
        setFilter={setFilter}
        filterOptions={filterOptions}
        optionMultiple={optionMultiple}
        listSeller={listSeller}
        sellerProcessStep={sellerProcessStep}
        onChangePage={onChangePage}
        localFilterOrders={localFilterOrders}
        path={path}
        onReloadData={onReloadData}
        filterDefault={filterDefault}
        tabSelected={tabSelected}
        listOrderTag={listOrderTag}
        listOrderSourceOption={listOrderSourceOption}
      />
      <div
        style={{
          display: "flex",
          marginTop: 10,
        }}
      >
        {keySelectTed === "isWaitingProduct" ||
        keySelectTed === "isFullProduct" ? (
          <div style={{ marginRight: 10 }}>
            <Dropdown overlay={menuSort} trigger={["click"]}>
              <Button>
                {sortValue ? sortValue : "Sắp xếp"}
                <DownOutlined />
              </Button>
            </Dropdown>
          </div>
        ) : null}

        {listItemSelected.length ? (
          <Dropdown overlay={menu} trigger={["click"]}>
            <Button>
              Chọn thao tác ({listItemSelected.length} đơn hàng){" "}
              <DownOutlined />
            </Button>
          </Dropdown>
        ) : null}
      </div>

      <div ref={componentRef}>
        <ComponentToPrint />
      </div>
    </div>
  );
}

export default Search;
