import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  GET_LIST_ORDER,
  CREATE_ORDER,
  GET_LIST_ORDER_SELLER,
  GET_LIST_SELLER,
  GET_LIST_ORDER_TAGS,
  ASSIGNEE_SELLER,
  ASSIGNEE_SELLER_MUTIPLE_ORDER,
  MANAGER_TAGS_MUTIPLE_ORDER,
  UPDATE_ORDER_NOTE_TAGS,
  DETAIL_ORDER,
  SELLER_ACCEPT_PROCESS,
  SELLER_REJECT_PROCESS,
  SELLER_PROCESS_RESULT,
  CANCEL_ORDER,
  UPDATE_ORDER,
  LIST_ORDER_LOGS,
  CREATE_ORDER_LOGS,
  CONFIRM_PAYMENT,
  CONFIRM_PAYMENT_FAIL,
  GET_CUSTOMER,
  SEARCH_CUSTOMER,
  SELLER_PROCESS_STEP,
  FORWARD_SELLER,
  FORWARD_CONFIRM,
  ORDER_SELLER_PROCESS_STEP,
  SHIPPING_FEE_OPTION,
  UPDATE_SHIPPING_FEE,
  LIST_CAMPAIGN,
  PUT_CAMPAIGN_ORDER,
  LIST_CAMPAIGN_ORDER,
  LIST_CURRENT_CAMPAIGN,
  GET_LIST_INVENTORY,
  SET_LIST_ORDER_SOURCE,
  LIST_WAITING_PRODUCTS,
  GET_LIST_FULFILLMENT_COMPANY,
  CREATE_COMPENSATION_OR_REFUND_TRANSPORT,
  SHIPPING_FEE_CALCULATE
} from "./action-type";

const initialState = {
  isLoading: false,
  counter: 0,
  orders: [],
  sellerOrders: [],
  sellers: [],
  orderTags: [],
  sellerOrderMeta: null,
  orderMeta: null,
};

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload,
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null,
      };
    case GET_LIST_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_ORDER_SELLER:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_SELLER:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_ORDER_TAGS:
      return {
        ...state,
        ...action.payload,
      };
    case ASSIGNEE_SELLER:
      return {
        ...state,
        ...action.payload,
      };
    case ASSIGNEE_SELLER_MUTIPLE_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case MANAGER_TAGS_MUTIPLE_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_ORDER_NOTE_TAGS:
      return {
        ...state,
        ...action.payload,
      };
    case DETAIL_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case SELLER_ACCEPT_PROCESS:
      return {
        ...state,
        ...action.payload,
      };
    case SELLER_REJECT_PROCESS:
      return {
        ...state,
        ...action.payload,
      };
    case SELLER_PROCESS_RESULT:
      return {
        ...state,
        ...action.payload,
      };
    case ORDER_SELLER_PROCESS_STEP:
      const { detailOrder } = action.payload;
      delete action.payload.detailOrder;
      return {
        ...state,
        ...action.payload,
        detailOrder: {
          ...state.detailOrder,
          ...detailOrder,
        },
      };
    case CANCEL_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_ORDER_LOGS:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_ORDER_LOGS:
      return {
        ...state,
        ...action.payload,
      };
    case CONFIRM_PAYMENT:
      return {
        ...state,
        ...action.payload,
      };
    case CONFIRM_PAYMENT_FAIL:
      return {
        ...state,
        ...action.payload,
      };
    case GET_CUSTOMER:
      return {
        ...state,
        ...action.payload,
      };
    case SEARCH_CUSTOMER:
      return {
        ...state,
        ...action.payload,
      };
    case SELLER_PROCESS_STEP:
      return {
        ...state,
        ...action.payload,
      };
    case FORWARD_SELLER:
      return {
        ...state,
        ...action.payload,
      };
    case FORWARD_CONFIRM:
      return {
        ...state,
        ...action.payload,
      };
    case SHIPPING_FEE_OPTION:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_SHIPPING_FEE:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_CAMPAIGN:
      return {
        ...state,
        ...action.payload,
      };
    case PUT_CAMPAIGN_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_CAMPAIGN_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case LIST_CURRENT_CAMPAIGN:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_INVENTORY:
      return {
        ...state,
        ...action.payload,
      };
    case SET_LIST_ORDER_SOURCE:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_FULFILLMENT_COMPANY:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_COMPENSATION_OR_REFUND_TRANSPORT:
      return {
        ...state,
        ...action.payload,
      };
    case SHIPPING_FEE_CALCULATE:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer,
};
