export const INCREMENT_LOADING = "orders/INCREMENT_LOADING";
export const DECREMENT_LOADING = "orders/DECREMENT_LOADING";
export const GET_LIST_ORDER = "orders/GET_LIST_ORDER";
export const GET_LIST_ORDER_SELLER = "orders/GET_LIST_ORDER_SELLER";
export const GET_LIST_SELLER = "orders/GET_LIST_SELLER";
export const GET_LIST_ORDER_TAGS = "orders/GET_LIST_ORDER_TAGS";
export const CREATE_ORDER = "orders/CREATE_ORDER";
export const ASSIGNEE_SELLER = "orders/ASSIGNEE_SELLER";
export const ASSIGNEE_SELLER_MUTIPLE_ORDER = "orders/ASSIGNEE_SELLER_MUTIPLE_ORDER";
export const MANAGER_TAGS_MUTIPLE_ORDER = "orders/MANAGER_TAGS_MUTIPLE_ORDER";
export const UPDATE_ORDER_NOTE_TAGS = "orders/UPDATE_ORDER_NOTE_TAGS";
export const DETAIL_ORDER = "orders/DETAIL_ORDER";
export const SELLER_ACCEPT_PROCESS = "orders/SELLER_ACCEPT_PROCESS";
export const SELLER_REJECT_PROCESS = "orders/SELLER_REJECT_PROCESS";
export const SELLER_PROCESS_RESULT = "orders/SELLER_PROCESS_RESULT";
export const CANCEL_ORDER = "orders/CANCEL_ORDER";
export const UPDATE_ORDER = "orders/UPDATE_ORDER";
export const LIST_ORDER_LOGS = "orders/LIST_ORDER_LOGS";
export const CREATE_ORDER_LOGS = "orders/CREATE_ORDER_LOGS";
export const CONFIRM_PAYMENT = "orders/CONFIRM_PAYMENT";
export const CONFIRM_PAYMENT_FAIL = "orders/CONFIRM_PAYMENT_FAIL";
export const GET_CUSTOMER = "orders/GET_CUSTOMER";
export const SEARCH_CUSTOMER = "orders/SEARCH_CUSTOMER";
export const SELLER_PROCESS_STEP = "orders/SELLER_PROCESS_STEP";
export const ORDER_SELLER_PROCESS_STEP = "orders/ORDER_SELLER_PROCESS_STEP";
export const FORWARD_SELLER = "orders/FORWARD_SELLER";
export const FORWARD_CONFIRM = "orders/FORWARD_CONFIRM";
export const SHIPPING_FEE_OPTION = "orders/SHIPPING_FEE_OPTION";
export const UPDATE_SHIPPING_FEE = "orders/UPDATE_SHIPPING_FEE";
export const LIST_CAMPAIGN = "orders/LIST_CAMPAIGN";
export const PUT_CAMPAIGN_ORDER = "orders/PUT_CAMPAIGN_ORDER";
export const LIST_CAMPAIGN_ORDER = "orders/LIST_CAMPAIGN_ORDER";
export const LIST_CURRENT_CAMPAIGN = "orders/LIST_CURRENT_CAMPAIGN";
export const GET_LIST_INVENTORY = "orders/GET_LIST_INVENTORY";
export const SET_LIST_ORDER_SOURCE = "orders/SET_LIST_ORDER_SOURCE";
export const LIST_WAITING_PRODUCTS = "orders/LIST_WAITING_PRODUCTS";
export const GET_LIST_FULFILLMENT_COMPANY= "orders/GET_LIST_FULFILLMENT_COMPANY";
export const CREATE_COMPENSATION_OR_REFUND_TRANSPORT =
	'orders/CREATE_COMPENSATION_OR_REFUND_TRANSPORT';
export const SHIPPING_FEE_CALCULATE = 'orders/SHIPPING_FEE_CALCULATE';

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListOrder = payload => {
  return {
    payload,
    type: GET_LIST_ORDER
  };
};

export const setListOrderSeller = payload => {
  return {
    payload,
    type: GET_LIST_ORDER_SELLER
  };
};

export const onCreateOrder = payload => {
  return {
    payload,
    type: CREATE_ORDER
  };
};

export const setListSeller = payload => {
  return {
    payload,
    type: GET_LIST_SELLER
  };
};

export const setListOrderTag = payload => {
  return {
    payload,
    type: GET_LIST_ORDER_TAGS
  };
};

export const setAssigneeSeller = payload => {
  return {
    payload,
    type: ASSIGNEE_SELLER
  };
};

export const setAssigneeSellerMutipleOrder = payload => {
  return {
    payload,
    type: ASSIGNEE_SELLER_MUTIPLE_ORDER
  };
};

export const setManagerTagMutipleOrder = payload => {
  return {
    payload,
    type: MANAGER_TAGS_MUTIPLE_ORDER
  };
};

export const setUpdateOrderNoteAndTags = payload => {
  return {
    payload,
    type: UPDATE_ORDER_NOTE_TAGS
  };
};

export const setDetailOrder = payload => {
  return {
    payload,
    type: DETAIL_ORDER
  };
};

export const setSellerAcceptProcess = payload => {
  return {
    payload,
    type: SELLER_ACCEPT_PROCESS
  };
};

export const setSellerRejectProcess = payload => {
  return {
    payload,
    type: SELLER_REJECT_PROCESS
  };
};

export const setSellerProcessResult = payload => {
  return {
    payload,
    type: SELLER_PROCESS_RESULT
  };
};

export const setCancelOrder = payload => {
  return {
    payload,
    type: CANCEL_ORDER
  };
};

export const setUpdateOrder = payload => {
  return {
    payload,
    type: UPDATE_ORDER
  };
};

export const setListOrderLogs = payload => {
  return {
    payload,
    type: LIST_ORDER_LOGS
  };
};

export const setCreateOrderLogs = payload => {
  return {
    payload,
    type: CREATE_ORDER_LOGS
  };
};

export const setComfirmPayment = payload => {
  return {
    payload,
    type: CONFIRM_PAYMENT
  };
};

export const setComfirmPaymentFail = payload => {
  return {
    payload,
    type: CONFIRM_PAYMENT_FAIL
  };
};



export const setCustomer = payload => {
  return {
    payload,
    type: GET_CUSTOMER
  };
};

export const setSeatchCustomer = payload => {
  return {
    payload,
    type: SEARCH_CUSTOMER
  };
};

export const setSellerProcessStep = payload => {
  return {
    payload,
    type: SELLER_PROCESS_STEP
  };
};

export const setOrderSellerProcessStep = payload => {
  return {
    payload,
    type: ORDER_SELLER_PROCESS_STEP
  };
};

export const setForwardSeller = payload => {
  return {
    payload,
    type: FORWARD_SELLER
  };
};

export const setForwardConfirm = payload => {
  return {
    payload,
    type: FORWARD_CONFIRM
  };
};

export const setShippingFeeOption = payload => {
  return {
    payload,
    type: SHIPPING_FEE_OPTION
  };
};

export const setUpdateShippingFee = payload => {
  return {
    payload,
    type: UPDATE_SHIPPING_FEE
  };
};

export const setListCampaign = payload => {
  return {
    payload,
    type: LIST_CAMPAIGN
  };
};

export const setCampaignOrder = payload => {
  return {
    payload,
    type: PUT_CAMPAIGN_ORDER
  };
};

export const setListCampaignOrder = payload => {
  return {
    payload,
    type: LIST_CAMPAIGN_ORDER
  };
};

export const setCurrentCampaign = payload => {
  return {
    payload,
    type: LIST_CURRENT_CAMPAIGN
  };
};

export const setListInventory = payload => {
  return {
    payload,
    type: GET_LIST_INVENTORY
  };
};

export const setListOrderSource = (payload) => {
  return {
    payload,
    type: SET_LIST_ORDER_SOURCE,
  };
};

export const setListOrderWaitingProducts = (payload) => {
  return {
    payload,
    type: LIST_WAITING_PRODUCTS,
  };
};


export const setListFulfillmentCompany = payload => {
  return {
    payload,
    type: GET_LIST_FULFILLMENT_COMPANY
  };
};

export const setCreateCompensationRefundTransport = (payload) => {
	return {
		payload,
		type: CREATE_COMPENSATION_OR_REFUND_TRANSPORT,
	};
};

export const setShippingFeeCalculate = (payload) => {
	return {
		payload,
		type: SHIPPING_FEE_CALCULATE,
	};
};














































