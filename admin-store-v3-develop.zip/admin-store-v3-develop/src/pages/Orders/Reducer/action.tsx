import {
  Orders as OrdersAPI,
  Users as UsersAPI,
  OrderTags as OrderTagsAPI,
  FullfillmentOrders as FullfillmentOrdersAPI,
  Common as CommonAPI,
} from "api";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import {
  IncrementLoading,
  DecrementLoading,
  setListOrder,
  onCreateOrder,
  setListOrderSeller,
  setListSeller,
  setListOrderTag,
  setAssigneeSeller,
  setAssigneeSellerMutipleOrder,
  setManagerTagMutipleOrder,
  setUpdateOrderNoteAndTags,
  setDetailOrder,
  setSellerAcceptProcess,
  setSellerRejectProcess,
  setSellerProcessResult,
  setCancelOrder,
  setUpdateOrder,
  setListOrderLogs,
  setCreateOrderLogs,
  setComfirmPayment,
  setComfirmPaymentFail,
  setCustomer,
  setSeatchCustomer,
  setSellerProcessStep,
  setForwardSeller,
  setForwardConfirm,
  setOrderSellerProcessStep,
  setShippingFeeOption,
  setUpdateShippingFee,
  setListCampaign,
  setCampaignOrder,
  setListCampaignOrder,
  setCurrentCampaign,
  setListInventory,
  setListOrderSource,
  setListFulfillmentCompany,
  setCreateCompensationRefundTransport,
  setShippingFeeCalculate,
} from "./action-type";

export const onGetListOrder = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getListOrder(params);
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      };
      dispatch(
        setListOrder({
          orders: data.data.datas,
          orderMeta: meta,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrder({
        orders: [],
        orderMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau 1",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderSeller = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getListOrderSeller(params);
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      };
      dispatch(
        setListOrderSeller({
          sellerOrders: data.data.datas,
          sellerOrderMeta: meta,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrderSeller({
        sellerOrders: [],
        sellerOrderMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau 2",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createOrder = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.createOrder(body);
    const { status, data } = response;
    if (status === 200) {
      dispatch(
        onCreateOrder({
          type: "success",
          isRedirect: true,
          createData: data.data,
          message: "Tạo mới thành công",
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      onCreateOrder({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListSeller = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await UsersAPI.getListSeller(params);
    const responseFullSeller = await UsersAPI.getListSeller({
      ...params,
      isFilter: true,
    });
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListSeller({
          sellers: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListSeller({
        sellers: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau 3",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListAllSeller = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await UsersAPI.getListSeller(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListSeller({
          allSellers: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListSeller({
        allSellers: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau 4",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderTag = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrderTagsAPI.getListOrderTags(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListOrderTag({
          orderTags: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrderTag({
        orderTags: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau 5",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onAssingneeSeller = async (id, params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.assigneeSeller(id, params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setAssigneeSeller({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setAssigneeSeller({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setAssigneeSeller({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 6",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onAssingneeSellerMutipleOrder = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.assigneeSellerMutipleOrder(params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setAssigneeSellerMutipleOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setAssigneeSellerMutipleOrder({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setAssigneeSellerMutipleOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 7",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onForwardSellerMultipleOrder = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.forwardSellerMultipleOrder(params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setAssigneeSellerMutipleOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setAssigneeSellerMutipleOrder({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setAssigneeSellerMutipleOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 8",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onManagerTagsMutipleOrder = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.managerTagsMutipleOrder(params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setManagerTagMutipleOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setManagerTagMutipleOrder({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setManagerTagMutipleOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 9",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onUpdateOrderNoteAndTag = async (id, params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.updateOrderNoteAndTags(id, params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setUpdateOrderNoteAndTags({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setUpdateOrderNoteAndTags({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateOrderNoteAndTags({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 10",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getDetailOrder = async (id, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setDetailOrder({
      message: null,
      isRefresh: false,
      type: null,
    })
  );
  try {
    const response = await OrdersAPI.detailOrder(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setDetailOrder({
          detailOrder: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setDetailOrder({
        detailOrder: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau 11",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getDetailReorder = async (id, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setDetailOrder({
      message: null,
      isRefresh: false,
      type: null,
    })
  );
  try {
    const response = await OrdersAPI.detailReorder(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setDetailOrder({
          detailOrder: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setDetailOrder({
        detailOrder: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau 12",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onSellerAcceptProcess = async (id, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.sellerAcceptProcess(id);
    const { status, data } = response;
    if (status === 200) {
      dispatch(
        setSellerAcceptProcess({
          type: "success",
          isRefresh: false,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setOrderSellerProcessStep({
          detailOrder: {
            status: "CONFIRMED",
            isConfirmed: true,
            sellerAcceptStatus: "ACCEPTED",
            sellerProcessStep: data.data,
          },
        })
      );
    }
  } catch (error) {
    dispatch(
      setSellerAcceptProcess({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 13",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onSellerRejectProcess = async (id, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.sellerRejectProcess(id);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setSellerRejectProcess({
          type: "success",
          isRedirect: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setSellerRejectProcess({
          isRedirect: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setSellerRejectProcess({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 14",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onSellerProcessResult = async (id, body, dispatch) => {
  // dispatch(IncrementLoading);

  try {
    const response = await OrdersAPI.sellerProcessResult(id, body);
    console.log(response, "response");
    if (response) {
      switch (orNumber("data.meta.status", response)) {
        case 200:
          dispatch(
            setSellerProcessResult({
              type: "success",
              isRefresh: true,
              message: "Cập nhật thành công",
            })
          );
          dispatch(DecrementLoading);
          return dispatch(
            setSellerProcessResult({
              isRefresh: false,
            })
          );
        default:
          dispatch(
            setSellerProcessResult({
              type: "error",
              message: orEmpty("data.meta.internalMessage", response),
              campaignError: orArray("data.data", response),
            })
          );
          return dispatch(DecrementLoading);
      }
    }
    // if (status === 200) {
    //   dispatch(
    //     setSellerProcessResult({
    //       type: "success",
    //       isRefresh: true,
    //       message: "Cập nhật thành công",
    //     })
    //   );
    //   dispatch(DecrementLoading);
    //   return dispatch(
    //     setSellerProcessResult({
    //       isRefresh: false,
    //     })
    //   );
    // }
  } catch (error) {
    // console.log(error.response, "error");
    if (error.response.data) {
      dispatch(
        setSellerProcessResult({
          message: error.response.data.meta.internalMessage,
          type: "error",
        })
      );
    } else {
      dispatch(
        setSellerProcessResult({
          message: "Đã xảy ra lỗi vui lòng quay lại sau",
          type: "error",
        })
      );
    }

    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onCancelOrder = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.cancelOrder(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setCancelOrder({
          type: "success",
          isRefresh: true,
          message: "Hủy đơn thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setCancelOrder({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setCancelOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 16",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateOrderNew = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.updateOrder(id, body.body);
    const { status, data } = response;
    if (status === 200) {
      dispatch(
        setUpdateOrder({
          type: "success",
          isRefresh: false,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setDetailOrder({
          detailOrder: data.data,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 17",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateOrder = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.updateOrder(id, body);
    const { status, data } = response;
    if (status === 200) {
      dispatch(
        setUpdateOrder({
          type: "success",
          isRefresh: false,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);

      return dispatch(
        setDetailOrder({
          detailOrder: data.data,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 18",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderLogs = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getOrderLogs(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListOrderLogs({
          orderLogs: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrderLogs({
        orderLogs: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau 19",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createOrderLogs = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.createOrderLogs(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setCreateOrderLogs({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setCreateOrderLogs({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setCreateOrderLogs({
        message: "Đã xảy ra lỗi vui lòng quay lại sau 20",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const confirmPayment = async (id, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.confirmPayment(id);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setComfirmPayment({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setComfirmPayment({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setComfirmPayment({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const confirmPaymentFail = async (id, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.confirmPaymentFail(id);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setComfirmPaymentFail({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setComfirmPaymentFail({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setComfirmPaymentFail({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getCustomer = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await UsersAPI.getCustomer(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setCustomer({
          customer: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setCustomer({
        customer: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getSeachCustomer = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await UsersAPI.searchCustomer(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setSeatchCustomer({
          searchCustomer: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setSeatchCustomer({
        customer: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListSellerProcessStep = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.sellerProcessStep(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setSellerProcessStep({
          sellerProcessStep: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setSellerProcessStep({
        customer: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onForwardSeller = async (id, params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.forwardSeller(id, params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setForwardSeller({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setForwardSeller({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setForwardSeller({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onForwardConfirm = async (id, params, onConfirm, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.forwardConfirm(id, params);
    const { status } = response;
    if (status === 200) {
      if (onConfirm === "onReject") {
        dispatch(
          setForwardConfirm({
            type: "success",
            isRedirect: true,
            message: "Cập nhật thành công",
          })
        );
        dispatch(DecrementLoading);
        return dispatch(
          setForwardConfirm({
            isRedirect: false,
          })
        );
      } else {
        dispatch(
          setForwardConfirm({
            type: "success",
            isRefresh: true,
            message: "Cập nhật thành công",
          })
        );
        dispatch(DecrementLoading);
        return dispatch(
          setForwardConfirm({
            isRefresh: false,
          })
        );
      }
    }
  } catch (error) {
    dispatch(
      setForwardConfirm({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetShippingFeeOption = async (params, dispatch) => {
  // dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getShippingFeeOption(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setShippingFeeOption({
          shippingFeeList: data.data,
        })
      );
      // dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setShippingFeeOption({
        shippingFeeList: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    // dispatch(DecrementLoading);
  }
  // dispatch(DecrementLoading);
};

export const onUpdateShippingFee = async (id, params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.updateShippingFee(id, params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setUpdateShippingFee({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setUpdateShippingFee({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateShippingFee({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListCampaign = async (params, dispatch) => {
  // dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getListCampaignNew(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListCampaign({
          listCampaign: {
            listCampaign: orNull("data", data),
            isShineMember: orBoolean("shineMember", data),
          },
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListCampaign({
        listCampaign: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    // dispatch(DecrementLoading);
  }
};

export const onPutCampaignForOrder = async (id, params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.putCampaignOrder(id, params);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setCampaignOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setCampaignOrder({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setCampaignOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListCampaignOrder = async (customerId, params, dispatch) => {
  // dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getCampaignOrder(customerId, params);
    const { status, data } = response;
    if (status === 200) {
      dispatch(
        setListCampaignOrder({
          listCampaignOrder: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListCampaignOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    // dispatch(DecrementLoading);
  }
  // dispatch(DecrementLoading);
};

export const onGetListCurrentCampaign = async (params, dispatch) => {
  if (params.length === 0) {
    return dispatch(
      setCurrentCampaign({
        listCurrentCampaign: [],
      })
    );
  }
  // dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getCurrentCampaignNew(params);
    const { status, data } = response;
    if (status === 200) {
      dispatch(
        setCurrentCampaign({
          listCurrentCampaign: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setCurrentCampaign({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    // dispatch(DecrementLoading);
  }
  // dispatch(DecrementLoading);
};

export const onGetListInventory = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListInventorySelecter(
      params
    );
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListInventory({
          inventories: data.data,
          // inventories: data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListInventory({
        inventories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListInventoryNew = async (orderCode, params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListInventorySelecter(
      orderCode,
      params
    );
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListInventory({
          inventories: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListInventory({
        inventories: [],
      })
    );
    dispatch(DecrementLoading);
    return;
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderSource = async (dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await CommonAPI.getListOrderSource();
    const { data } = response;
    return dispatch(
      setListOrderSource({
        listOrderSource: orArray("data", data),
      })
    );
  } catch (error) {
    return dispatch(
      setListOrderSource({
        listOrderSource: [],
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};

export const onGetListOrderWaitingProduct = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrdersAPI.getWaitingProduct(params);
    const { data, status } = response;
    if (status === 200) {
      if (orBoolean("isSeller", params)) {
        dispatch(
          setListOrderSeller({
            sellerOrders: data.data,
            sellerOrderMeta: null,
          })
        );
      } else {
        dispatch(
          setListOrder({
            orders: data.data,
            orderMeta: null,
          })
        );
      }
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrder({
        orders: [],
        orderMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListFulfillmentCompany = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListFulfillmentCompany(
      params
    );
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListFulfillmentCompany({
          fullfillmentCompanies: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListFulfillmentCompany({
        fullfillmentCompanies: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createCompensationRefundTransport = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response: any =
      await FullfillmentOrdersAPI.createOrderTransportCompensation(id, body);
    const { status, data } = response;
    if (status === 200) {
      if (data.meta.status === 200) {
        dispatch(
          setCreateCompensationRefundTransport({
            type: "success",
            isRedirect: true,
            createData: data.data,
            message: "Tạo thành công!",
          })
        );
      } else {
        dispatch(
          setCreateCompensationRefundTransport({
            type: "error",
            message: data.meta.internalMessage,
          })
        );
      }
    }
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setCreateCompensationRefundTransport({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
};

export const setShippingFeeToEmpty = (dispatch) => {
  return dispatch(
    setShippingFeeCalculate({
      shippingFeeCalculate: 0,
    })
  );
};

export const calculateShippingFee = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.shippingFeeCalculate(body);
    const { data, status } = response;
    if (response && data.meta.success) {
      dispatch(
        setShippingFeeCalculate({
          shippingFeeCalculate: data.data,
        })
      );
      return;
    }
    return dispatch(
      setShippingFeeCalculate({
        isGetShippingFee: false,
        shippingFeeMessage: data.meta.internalMessage,
      })
    );
  } catch (error) {
    dispatch(
      setShippingFeeCalculate({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error",
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};
