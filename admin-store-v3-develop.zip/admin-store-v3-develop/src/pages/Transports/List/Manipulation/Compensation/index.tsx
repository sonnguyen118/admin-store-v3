import { CompensationTransport } from '../../../private-components';
import { useHistory, useParams } from 'react-router-dom';
import { withReducer } from 'hoc';
import { orBoolean, orEmpty, orNull, orArray, orNumber } from 'utils/Selector';
import transportDetailReducer from '../../../Reducer';
import { useEffect } from 'react';

function Detail(props) {
	const { dispatch, action, state } = props;
	const history = useHistory();
	const params = useParams();

	function handleBack() {
		history.goBack();
	}

	function onSetup() {
		if (orEmpty('id', params)) {
			action.transportDetailReducer.getDetailTransportOrder(
				orEmpty('id', params),
				dispatch.transportDetailReducer
			);
		}
	}

	const onUpdateTransport = (params) => {
		const { id, ...body } = params;
		action.transportDetailReducer.updateTransportOrder(
			id,
			body,
			dispatch.transportDetailReducer
		);
	};

	const onUpdateTransportData = (params) => {
		const { id, ...body } = params;
		action.transportDetailReducer.updateTransportOrderData(
			id,
			body,
			dispatch.transportDetailReducer
		);
	};

	const onGetListOrderTag = () => {
		action.transportDetailReducer.onGetListOrderTag(
			{},
			dispatch.transportDetailReducer
		);
	};

	const handleCreateLog = (params) => {
		const { id, ...body } = params;
		action.transportDetailReducer.createLogs(id, body, dispatch.transportDetailReducer);
	};

	const onRefresh = () => {
		if (orBoolean('transportDetailReducer.isRefresh', state)) {
			onSetup();
		}
	};

	const onRedirect = () => {
		if (orBoolean('transportDetailReducer.isRedirect', state)) {
			history.push(
				`/transports/detail/${orEmpty('transportDetailReducer.createData.code', state)}`
			);
		}
	};

	const onGetListFulfillmentCompany = () => {
		action.transportDetailReducer.onGetListFulfillmentCompany(
			{},
			dispatch.transportDetailReducer
		);
	};

	const handleCalculateShippingFee = (body) => {
		action.transportDetailReducer.calculateShippingFee(
			{ ...body, fulfillmentType: orEmpty('type', params).toUpperCase() },
			dispatch.transportDetailReducer
		);
	};

	const setShippingFeeToEmpty = () => {
		action.transportDetailReducer.setShippingFeeToEmpty(dispatch.transportDetailReducer);
	};

	const handleCreateCompensationOrder = (values) => {
		const { id, ...body } = values;
		action.transportDetailReducer.createCompensationRefundTransport(
			id,
			{ fulfillment: body, type: orEmpty('type', params).toUpperCase() },
			dispatch.transportDetailReducer
		);
	};
	useEffect(onGetListOrderTag, []);
	useEffect(onSetup, []);
	useEffect(onGetListFulfillmentCompany, []);
	useEffect(onRefresh, [orBoolean('transportDetailReducer.isRefresh', state)]);
	useEffect(onRedirect, [orBoolean('transportDetailReducer.isRedirect', state)]);

	return (
		<CompensationTransport
			fullfillmentCompanies={orArray('transportDetailReducer.fullfillmentCompanies', state)}
			item={orNull('transportDetailReducer.detailTransportOrder', state)}
			user={orNull('userReducer.user', state)}
			logs={orNull('transportDetailReducer.logs', state)}
			handleBack={handleBack}
			onUpdateTransport={onUpdateTransport}
			onUpdateTransportData={onUpdateTransportData}
			handleCreateLog={handleCreateLog}
			handleCalculateShippingFee={handleCalculateShippingFee}
			shippingFeeCalculate={orNumber('transportDetailReducer.shippingFeeCalculate', state)}
			isGetShippingFee={orBoolean('transportDetailReducer.isGetShippingFee', state)}
			setShippingFeeToEmpty={setShippingFeeToEmpty}
			message={orBoolean('transportDetailReducer.shippingFeeMessage', state)}
			handleCreateCreateCompensationOrder={handleCreateCompensationOrder}
			listOrderTag={orArray('transportDetailReducer.orderTags', state)}
		/>
	);
}
export default withReducer({
	key: 'transportDetailReducer',
	...transportDetailReducer,
})(Detail);
