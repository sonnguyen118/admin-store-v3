import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { Radio, Typography, notification, Table, Modal } from "antd";
import { Helpers, Mocks } from "utils";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import { useHistory } from "react-router-dom";
import Search from "../Search";
import "./styled.scss";
import queryString from "query-string";
import moment from "moment";
import FulfillmentStatus from "components/Status/FulfillmentStatus";
import CODStatus from "components/Status/CODStatus";
import { ExportExcelCollationAll } from "../private-components";

const { Text, Link } = Typography;

function List(props) {
  const {
    dispatch,
    action,
    state,
    onReloadData,
    filterDefault,
    query,
    localFilterOrders,
    tabSelected,
  } = props;
  const history = useHistory();
  const [selectedItems, setSelectedItems] = useState([]);
  const [isExportDataCollation, setIsExportDataCollation] = useState(false);
  const roleDisable = ["SELLER", "SELLER_HOTLINE", "ACCOUNTING"];
  const roleUsed = ["ADMIN", "ACCOUNTING"];
  const roleUser = orEmpty("userReducer.user.role", state);

  const [filter, setFilter]: any = useState({
    page: 1,
    pageSize: 15,
    ...filterDefault,
  });

  const onGetListTransporterOrder = () => {
    action.transportOrdersReducer.onGetListTransportOrder(
      filter,
      dispatch.transportOrdersReducer
    );
  };

  function handleImportAllDataCollation() {
    setIsExportDataCollation(true);
    const copyFilter = { ...filter };
    delete copyFilter.page;
    delete copyFilter.pageSize;
    action.transportOrdersReducer.onCacheDataExportCollation(
      copyFilter,
      dispatch.transportOrdersReducer
    );
  }

  useMemo(() => {
    if (!isExportDataCollation) {
      action.transportOrdersReducer.onRemoveCacheDataExportCollation(
        dispatch.transportOrdersReducer
      );
    }
  }, [isExportDataCollation]);

  useMemo(() => {
    if (
      orArray("transportOrdersReducer.cacheDataExportCollation", state)
        .length &&
      isExportDataCollation
    ) {
      Modal.info({
        title: "Thông báo",
        content: (
          <div>
            <ExportExcelCollationAll
              orders={orArray(
                "transportOrdersReducer.cacheDataExportCollation",
                state
              )}
            />
          </div>
        ),
        okText: "Đóng",
        okType: "default",
        afterClose() {
          setIsExportDataCollation(false);
        },
      });
    }
  }, [
    orArray("transportOrdersReducer.cacheDataExportCollation", state),
    isExportDataCollation,
  ]);

  useMemo(() => {
    if (orBoolean("transportOrdersReducer.isRefresh", state)) {
      onGetListTransporterOrder();
    }
  }, [orBoolean("transportOrdersReducer.isRefresh", state)]);

  useEffect(() => {
    onGetListTransporterOrder();
  }, [filter]);

  const onGetListFulfillmentCompany = () => {
    action.transportOrdersReducer.onGetListFulfillmentCompany(
      {},
      dispatch.transportOrdersReducer
    );
  };

  const onGetListInventory = () => {
    action.transportOrdersReducer.onGetListInventory(
      {},
      dispatch.transportOrdersReducer
    );
  };

  useEffect(() => {
    onGetListFulfillmentCompany();
    onGetListInventory();
  }, []);

  function onDetailOrder(value) {
    const itemMenuOrder = Mocks.MENUS.getRoleMenusDefine(
      orEmpty("userReducer.user.role", state)
    ).find((item) => item.key === "orders");
    if (itemMenuOrder) {
      const isMenuUser = itemMenuOrder.nested.find((item) => item);
      window.open(`${isMenuUser.path}/detail/${value}`, "_blank");
      return;
    }
    notification["warning"]({
      message: "Thông báo",
      description: "Bạn không đủ quyền để truy cập đường dẫn này!",
    });
  }

  function onDetailTransport(e, code) {
    e.preventDefault();
    history.push(`/transports/detail/${code}`);
  }

  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "transports",
        search: queryString.stringify({
          ...query,
          page: query.page,
          type: tabSelected,
        }),
      });
      setFilter((prevState) => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize,
        };
      });
    }
  }, [query]);

  function onChangePage(page, type) {
    history.push({
      pathname: "transports",
      search: queryString.stringify({
        ...query,
        page,
        type: type ? type : tabSelected,
      }),
    });
  }

  function onConfirmPrintItems(orders) {
    action.transportOrdersReducer.confirmPrintItems(
      orders,
      dispatch.transportOrdersReducer
    );
  }

  function checkStatus(statusValue) {
    const isCancelled = ["CANCELLED", "REFUNDED"].includes(statusValue);
    if (isCancelled) {
      return "transport-cancel-color";
    }
    return "transport-normal-color";
  }

  const columns = [
    {
      title: "Mã vận chuyển",
      dataIndex: "code",
      render: (value, record) => (
        <a
          style={{ display: "flex", flexDirection: "column" }}
          className={checkStatus(record.status)}
          onClick={(e) => onDetailTransport(e, value)}
          href={`/transports/detail/${value}`}
        >
          {value}
          <div>
            <Text
              style={
                record.status === "CANCELLED" || record.status === "REFUNDED"
                  ? { color: "rgba(0, 0, 0, 0.45)" }
                  : { color: "#5BC983" }
              }
            >
              {record.isPrinted ? "Đã in vận đơn" : null}
            </Text>
          </div>
        </a>
      ),
    },
    {
      title: "Mã đơn hàng",
      dataIndex: "orderCode",
      render: (value, record) => (
        <div
          style={{ cursor: "pointer" }}
          className={checkStatus(record.status)}
          onClick={() => onDetailOrder(value)}
        >
          {value}
        </div>
      ),
    },
    {
      title: "Khách hàng",
      dataIndex: "shippingAddress",
      render: (value, record) => (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Text className={checkStatus(record.status)}>
            {record.fulfillmentType === "REFUND"
              ? record?.fromAddressRefund?.customerName
              : value?.customerName}
          </Text>
          <Text className={checkStatus(record.status)}>
            {record.fulfillmentType === "REFUND"
              ? record?.fromAddressRefund?.customerPhone
              : value?.customerPhone}
          </Text>
        </div>
      ),
    },
    {
      title: "Ngày tạo",
      dataIndex: "createdAt",
      render: (value, record) => (
        <div style={{ display: "flex", flexDirection: "column" }}>
          <Text className={checkStatus(record.status)}>
            {value ? moment(value).format("DD/MM/YYYY") : "---"}
          </Text>
          <Text className={checkStatus(record.status)}>
            {value ? moment(value).format("LT") : ""}
          </Text>
        </div>
      ),
    },
    {
      title: "Nhà vận chuyển",
      dataIndex: "fulfillmentCompany",
      render: (value) => (
        <Text style={{ color: value.color }} strong>
          {value.name}
        </Text>
      ),
    },
    {
      title: "TT giao hàng",
      dataIndex: "status",
      render: (value) => <FulfillmentStatus value={value} />,
    },
    {
      title: "COD",
      dataIndex: "isCOD",
      render: (value, record) => (
        <CODStatus
          value={value}
          isFulfillmentReceipt={record.isFulfillmentReceipt}
        />
      ),
    },
    {
      title: "Thu hộ",
      dataIndex: "totalPrice",
      render: (value) => Helpers.currencyFormatVND(value),
    },
  ];

  const [rows, setRows] = useState([]);

  function onUpdateData(): void {
    const listInventoryOrder = orArray(
      "transportOrdersReducer.transportOrders",
      state
    );
    if (listInventoryOrder) {
      const r = [] as any;

      listInventoryOrder.forEach((node): void => {
        r.push({
          key: node.id,
          ...node,
          shippingAddress: node.toAddress,
          statusValue: node.status,
          totalPrice: node.codAmount,
          deliveryCompany: orEmpty("fulfillmentCompany.name", node),
        });
      });
      setRows(r);
    }
  }

  useEffect(onUpdateData, [
    orArray("transportOrdersReducer.transportOrders", state),
  ]);

  function showTotal(total) {
    return `Tổng: ${total}`;
  }

  const rowSelection = {
    selectedRowKeys: selectedItems.map((item) => orEmpty("key", item)),
    getCheckboxProps: () => ({
      disabled: roleDisable.includes(roleUser),
    }),
    onSelect: (record, selected) => {
      if (selected) {
        const r = selectedItems.slice();
        r.push(record);
        setSelectedItems(r);
        return;
      } else {
        setSelectedItems((prevState) =>
          prevState.filter((item) => item.id != record.id)
        );
      }
    },
    onSelectAll: (selected, selectedRows, changeRows) => {
      if (selected) {
        const r = selectedItems.slice();
        setSelectedItems(r.concat(selectedRows).filter((item) => item));
        return;
      } else {
        const r = selectedItems.slice();
        const data = [];
        r.forEach((e) => {
          const result = changeRows.find((item) => item.key === e.key);
          if (!result) {
            data.push(e);
            return;
          }
        });
        setSelectedItems(data);
      }
    },
  };

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        listFulFillmentCompany={orArray(
          "transportOrdersReducer.fullfillmentCompanies",
          state
        )}
        listinventory={orArray("transportOrdersReducer.inventories", state)}
        onChangePage={onChangePage}
        selectedItems={selectedItems}
        setSelectedItems={setSelectedItems}
        onConfirmPrintItems={onConfirmPrintItems}
        localFilterOrders={localFilterOrders}
        path="/transports"
        onReloadData={onReloadData}
        filterDefault={filterDefault}
        tabSelected={tabSelected}
        roleUser={roleUser}
        roleUsed={roleUsed}
        totalRecord={orNumber(
          "transportOrdersReducer.transportOrderMeta.total",
          state
        )}
        handleImportAllDataCollation={handleImportAllDataCollation}
      />
      <Table
        rowSelection={rowSelection}
        columns={columns}
        dataSource={rows}
        rowClassName={(record) =>
          record.statusValue === "CANCELLED" ||
          record.statusValue === "REFUNDED"
            ? "transport-cancel-row"
            : "transport-normal-row"
        }
        pagination={{
          defaultPageSize: filter.pageSize,
          defaultCurrent: filter.page,
          current: filter.page,
          showSizeChanger: false,
          total: orNumber(
            "transportOrdersReducer.transportOrderMeta.total",
            state
          ),
          onChange: (page) => onChangePage(page, tabSelected),
          showTotal: showTotal,
        }}
      />
    </div>
  );
}

export default List;
