import React, { useEffect, useRef, useState } from "react";
import {
  Button,
  Col,
  Row,
  Space,
  Typography,
  Divider,
  notification,
  Menu,
  Dropdown,
} from "antd";
import { DownOutlined, PrinterFilled } from "@ant-design/icons";
import { orEmpty, orArray, orBoolean, orNumber, orNull } from "utils/Selector";
import { Mocks } from "utils";
import moment from "moment";
import ReactToPrint from "react-to-print";
import FulfillmentStatus from "components/Status/FulfillmentStatus";
import { ComponentToPrint as PrintOrder } from "components";
import { useHistory } from "react-router";
const { Title, Text } = Typography;

const printPageStyle = `
  @page { size: auto;  margin: 5mm; }
  @media print {
    body { 
      -webkit-print-color-adjust: exact;
      page-break-after: auto;
    }
    html, body { 
      -webkit-print-color-adjust: exact;
      height: initial !important; 
      overflow: initial !important; 
    }
  }
  @media print { body { -webkit-print-color-adjust: exact; } }
`;

export default function Header(props) {
  const componentRef = useRef<HTMLDivElement>(null);
  const { handleBack, item, user } = props;
  const history = useHistory();
  const ComponentToPrint = () => {
    if (item) {
      const itemPrint = {
        orderCode: orEmpty("orderCode", item),
        fulfillmentCode: orEmpty("fulfillmentCode", item),
        customerName: orEmpty("toAddress.customerName", item),
        address: orEmpty("toAddress.address", item),
        wardName: orEmpty("toAddress.wardName", item),
        districtName: orEmpty("toAddress.districtName", item),
        provinceName: orEmpty("toAddress.provinceName", item),
        customerPhone: orEmpty("toAddress.customerPhone", item),
        fulfillmentCompany: orNull("fulfillmentCompany", item),
        shippingType: orEmpty("shippingType", item),
        cashByRecipient: orBoolean("cashByRecipient", item),
        enableReviewBefore: orBoolean("enableReviewBefore", item),
        paymentGateway: orEmpty("paymentGateway", item),
        totalPrice: orNumber("totalPrice", item),
        orderItems: orArray("items", item),
        customerNote: orEmpty("customerNote", item),
        isCOD: orEmpty("isCOD", item),
        sortCode: orEmpty("sortCode", item),
        ...item
      };
      return <PrintOrder item={itemPrint} />;
    }
    return <div></div>;
  };

  function onDetailOrder(value) {
    const itemMenuOrder = Mocks.MENUS.getRoleMenusDefine(
      orEmpty("role", user)
    ).find((item) => item.key === "orders");
    if (itemMenuOrder) {
      const isMenuUser = itemMenuOrder.nested.find((item) => item);
      window.open(`${isMenuUser.path}/detail/${value}`, "_blank");
      return;
    }
    notification["warning"]({
      message: "Thông báo",
      description: "Bạn không đủ quyền để truy cập đường dẫn này!",
    });
  }

  const handleMenuClick = ({ key }) => {
    if (orEmpty("fulfillmentType", item) === "REFUND") {
      notification["warning"]({
        message: "Thông báo",
        description: "Vận đơn là đơn trả hàng!",
      });
      return;
    }
    if (orEmpty("fulfillmentType", item) === "COMPENSATION") {
      notification["warning"]({
        message: "Thông báo",
        description: "Vận đơn là đơn bù hàng!",
      });
      return;
    }
    switch (key) {
      case "createReturns":
        if (orBoolean("hasFulfillmentRefund", item)) {
          notification["warning"]({
            message: "Thông báo",
            description: "Đã có vận đơn trả hàng!",
          });
          return;
        }
        const now = moment(moment(new Date()).format("YYYY-MM-DDT00:00:00"));
        const end = moment(
          moment(orEmpty("processCompletedAt", item)).format(
            "YYYY-MM-DDT00:00:00"
          )
        );
        const days = now.diff(end, "days");
        if (days > 60) {
          notification["warning"]({
            message: "Thông báo",
            description: "Chỉ có thể trả lại đơn hàng trong vòng 60 ngày",
          });
          return;
        }
        history.push(`/transports/${item.code}/create/refund`);

        break;
      case "createCompensation":
        if (orBoolean("hasFulfillmentCompensation", item)) {
          notification["warning"]({
            message: "Thông báo",
            description: "Đã có vận đơn bù hàng!",
          });
          return;
        }
        history.push(`/transports/${item.code}/create/compensation`);

        break;
      default:
        break;
    }
  };

  const checkStatusCompensation = () => {
    const listStatus = ["DELIVERED", "DELIVERING"];
    return listStatus.includes(orEmpty("status", item));
  };

  const checkStatusCreateReturn = () => {
    return orEmpty("status", item) === "DELIVERED";
  };

  const menu = (
    <Menu onClick={handleMenuClick}>
      {checkStatusCreateReturn() ? (
        <Menu.Item key="createReturns">
          <Text strong>Tạo vận đơn trả hàng</Text>
        </Menu.Item>
      ) : null}
      {checkStatusCompensation() ? (
        <Menu.Item key="createCompensation">
          <Text strong>Tạo vận đơn bù</Text>
        </Menu.Item>
      ) : null}
    </Menu>
  );

  return (
    <Row gutter={24} className="bill-order-detail-header">
      <Col span={16} className="bill-order-detail-header-title">
        <Title level={4}>Mã vận chuyển {orEmpty("code", item)}</Title>
      </Col>
      <Col span={8} className="bill-order-detail-header-action">
        {checkStatusCompensation() || checkStatusCreateReturn() ? (
          <Dropdown
            className="bill-order-detail-header-action-dropdown"
            overlay={menu}
            trigger={["click"]}
          >
            <Text strong>
              Thao tác <DownOutlined />
            </Text>
          </Dropdown>
        ) : null}
        <ReactToPrint
          removeAfterPrint={true}
          pageStyle={printPageStyle}
          trigger={() => (
            <Button ghost className="bill-order-detail-header-action-print">
              <PrinterFilled /> In phiếu giao hàng
            </Button>
          )}
          content={() => componentRef.current}
        />
        <Button
          onClick={handleBack}
          className="bill-order-detail-header-action-back"
        >
          Quay lại
        </Button>
      </Col>
      <Col span={14} className="bill-order-detail-header-info">
        <Space
          className="bill-order-detail-header-info-space"
          split={<Divider type="vertical" />}
        >
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Mã đơn hàng</Text>
            <Text strong>
              <span
                className="cursor-pointer"
                onClick={() => onDetailOrder(orEmpty("orderCode", item))}
              >
                {orEmpty("orderCode", item)}
              </span>
            </Text>
          </div>
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái giao hàng</Text>
            <FulfillmentStatus value={orEmpty("status", item)} />
          </div>
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái thu hộ</Text>
            <Text
              strong
              type={
                orEmpty("codStatus", item) === "RECEIPTED"
                  ? "success"
                  : "secondary"
              }
            >
              {!orEmpty("isCOD", item)
                ? "Không thu"
                : Mocks.TRANSPORTS.getCodStatus(orEmpty("codStatus", item))}
            </Text>
          </div>
          <div className="bill-order-detail-header-info-space-item">
            <Text type="secondary">Trạng thái đối soát</Text>
            <Text
              strong
              type={
                orBoolean("isFulfillmentReceipt", item)
                  ? `success`
                  : "secondary"
              }
            >
              {orBoolean("isFulfillmentReceipt", item)
                ? "Đã đối soát"
                : "Chưa đối soát"}
            </Text>
          </div>
        </Space>
      </Col>
      <Col span={14} className="bill-order-detail-header-info-2">
        <Space size={20}>
          <div>
            Ngày tạo:{" "}
            {moment(orEmpty("createdAt", item)).format("DD/MM/YYYY hh:mm A")}
          </div>
        </Space>
      </Col>
      <div ref={componentRef}>
        <ComponentToPrint />
      </div>
    </Row>
  );
}
