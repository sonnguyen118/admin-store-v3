import {
  Button,
  Card,
  Col,
  Divider,
  Form,
  Input,
  Row,
  Space,
  InputNumber,
  Checkbox,
  Typography,
  notification,
} from "antd";
import { useEffect, useState } from "react";
import { orBoolean, orEmpty, orNull } from "utils/Selector";
import { Selector } from "components";
import { Helpers, Mocks } from "utils";
import moment from "moment";

const { Item } = Form;
const { Text } = Typography;

const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const tailLayout = {
  wrapperCol: { span: 24 },
};

export default function ShippingNote(props) {
  const { item, handleUpdateTransport, onReorderFulfillment, user } = props;
  const [form] = Form.useForm();
  const [editing, setEditing] = useState(false);
  const [service, setService] = useState(null);
  const [shippingFee, setShippingFee] = useState(0);
  const roleDisable = ["SELLER", "SELLER_HOTLINE"];
  const roleUser = orEmpty("role", user);
  const isReturnOrCompensationTransport =
    orEmpty("fulfillmentType", item) === "COMPENSATION" ||
    orEmpty("fulfillmentType", item) === "REFUND";

  function onFinish(values) {
    const newValues = {
      weight: values.weight,
      cashByRecipient: values.cashByRecipient,
      size: {
        width: values.width,
        height: values.height,
        depth: values.depth,
      },
    };
    if (!orBoolean("fulfillmentCompany.isAutoShippingFee", item)) {
      handleUpdateTransport({
        id: orEmpty("id", item),
        shippingFee: shippingFee,
        ...newValues,
      });
      setEditing(false);
      return;
    }
    handleUpdateTransport({ id: orEmpty("id", item), ...newValues });
    setEditing(false);
  }

  function onSetupForm() {
    if (item) {
      const service = item.fulfillmentCompany.services.find(
        (i) => i.id === item.service
      );
      setService(service);
      setShippingFee(orEmpty("shippingFee", item));
      form.setFieldsValue({
        depth: orEmpty("size.depth", item),
        height: orEmpty("size.height", item),
        width: orEmpty("size.width", item),
        weight: orEmpty("weight", item),
        enableReviewBefore: orBoolean("enableReviewBefore", item),
        shippingFee: orEmpty("shippingFee", item),
        cashByRecipient: orBoolean("cashByRecipient", item),
      });
    }
  }

  function checkStatusTransport() {
    return orEmpty("status", item) === "CANCELLED";
  }

  function checkStatusOrder() {
    return orEmpty("order.status", item) === "CANCELLED";
  }

  useEffect(() => {
    onSetupForm();
  }, [item]);

  const reg = /^-?\d*(\.\d*)?$/;

  const renderButtonReorder = () => {
    const arr = ["CANCELLED", "READY_TO_PICK", "REFUNDED", "PICKING"];
    const fulfillmentCompany = ["GIAOHANGNHANH"];
    if (!editing) {
      if (isReturnOrCompensationTransport) return null;
      if (arr.includes(orEmpty("status", item))) {
        if (
          orEmpty("status", item) === "PICKING" &&
          fulfillmentCompany.includes(orEmpty("fulfillmentCompany.slug", item))
        ) {
          return (
            <Button
              disabled={checkStatusOrder()}
              onClick={() => onReorderFulfillment(orEmpty("orderCode", item))}
              style={{ marginRight: 10 }}
            >
              Tạo lại phiếu vận chuyển
            </Button>
          );
        }
        return (
          <Button
            disabled={checkStatusOrder()}
            onClick={() => onReorderFulfillment(orEmpty("orderCode", item))}
            style={{ marginRight: 10 }}
          >
            Tạo lại phiếu vận chuyển
          </Button>
        );
      }
      return null;
    }
    return null;
  };

  function onDetailOrder(value) {
    const itemMenuOrder = Mocks.MENUS.getRoleMenusDefine(
      orEmpty("role", user)
    ).find((item) => item.key === "orders");
    if (itemMenuOrder) {
      const isMenuUser = itemMenuOrder.nested.find((item) => item);
      window.open(`${isMenuUser.path}/detail/${value}`, "_blank");
      return;
    }
    notification["warning"]({
      message: "Thông báo",
      description: "Bạn không đủ quyền để truy cập đường dẫn này!",
    });
  }

  return (
    <Card
      title="Thông tin phiếu vận chuyển"
      className="bill-order-detail-main-shipingNote"
    >
      <Form
        name="basic"
        onFinish={onFinish}
        form={form}
        {...layout}
        className="bill-order-detail-main-shipingNote-form"
      >
        <Row gutter={24}>
          <Col span={10}>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Mã đơn hàng"
            >
              <Text strong>
                <span
                  className="cursor-pointer"
                  onClick={() => onDetailOrder(orEmpty("orderCode", item))}
                >
                  {orEmpty("orderCode", item)}
                </span>
              </Text>
            </Form.Item>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Mã vận đơn"
            >
              <Text copyable strong>
                {orEmpty("fulfillmentCode", item)}
              </Text>
            </Form.Item>
            {orEmpty("estimateDeliveryDate", item) ? (
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Dự kiến giao hàng"
              >
                <Text copyable strong>
                  {moment(orEmpty("estimateDeliveryDate", item)).format(
                    "DD-MM-YYYY"
                  )}
                </Text>
              </Form.Item>
            ) : null}

            <Form.Item valuePropName="checked" wrapperCol={{ span: 24 }}>
              <Text strong>
                {orBoolean("enableReviewBefore", item)
                  ? "Sản phẩm được kiểm tra trước khi thanh toán"
                  : "Sản phẩm không được kiểm tra trước khi thanh toán"}
              </Text>
            </Form.Item>
          </Col>
          <Col span={14}>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Nhà vận chuyển"
            >
              <Text strong>{orEmpty("fulfillmentCompany.name", item)}</Text>
            </Form.Item>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Phương thức TT"
            >
              <Text strong>
                {orEmpty("paymentMethod", item) === "BALANCE"
                  ? "Tài khoản AhaMove"
                  : "Tiền mặt"}
              </Text>
            </Form.Item>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Gói vận chuyển"
            >
              <Text strong>
                {orEmpty("fulfillmentCompany.slug", item) === "VIETTELPOST"
                  ? `${orEmpty("id", service)} - `
                  : null}{" "}
                {orEmpty("name", service)}
              </Text>
            </Form.Item>

            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Ghi chú giao hàng"
            >
              <Text strong>{orEmpty("shippingNote", item)}</Text>
            </Form.Item>

            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label={
                orEmpty("fulfillmentType", item) === "REFUND"
                  ? "Kho nhận hàng"
                  : "Kho xuất hàng"
              }
            >
              <Text strong>{orEmpty("inventory.name", item)}</Text>
            </Form.Item>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Số điện thoại kho (salon)"
            >
              <Text strong>
                {orEmpty("inventoryUpdatePhone", item)
                  ? orEmpty("inventoryUpdatePhone", item)
                  : orEmpty("inventory.phone", item)}
              </Text>
            </Form.Item>
          </Col>
        </Row>
        <Divider />
        <Row gutter={24}>
          <Col span={12}>
            {editing ? (
              <div className="editing-form-height-width">
                <div>kích thước:</div>
                <Space>
                  <Form.Item
                    className="bill-order-detail-main-shipingNote-form-item"
                    name="depth"
                    rules={[
                      {
                        validator: (_, value) =>
                          !value
                            ? Promise.resolve()
                            : reg.test(value)
                            ? Promise.resolve()
                            : Promise.reject(new Error("Chiều dài phải là số")),
                      },
                    ]}
                  >
                    <Input placeholder="dài" />
                  </Form.Item>
                  <Form.Item
                    className="bill-order-detail-main-shipingNote-form-item"
                    name="width"
                    rules={[
                      {
                        validator: (_, value) =>
                          !value
                            ? Promise.resolve()
                            : reg.test(value)
                            ? Promise.resolve()
                            : Promise.reject(
                                new Error("Chiều rộng phải là số")
                              ),
                      },
                    ]}
                  >
                    <Input placeholder="rộng" />
                  </Form.Item>
                  <Form.Item
                    className="bill-order-detail-main-shipingNote-form-item"
                    name="height"
                    rules={[
                      {
                        validator: (_, value) =>
                          !value
                            ? Promise.resolve()
                            : reg.test(value)
                            ? Promise.resolve()
                            : Promise.reject(new Error("Chiều cao phải là số")),
                      },
                    ]}
                  >
                    <Input placeholder="cao" />
                  </Form.Item>
                  cm
                </Space>
              </div>
            ) : (
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Kích thước"
              >
                <Text strong>
                  {orNull("size.depth", item) &&
                    `${orNull("size.depth", item)}x`}
                  {orNull("size.width", item) &&
                    `${orNull("size.width", item)}x`}
                  {orNull("size.height", item) &&
                    `${orNull("size.height", item)}cm`}
                </Text>
              </Form.Item>
            )}

            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Tổng khối lượng"
              name="weight"
              rules={[
                { required: editing, message: "Vui lòng nhập khối lượng" },
                {
                  validator: (_, value) =>
                    reg.test(value)
                      ? Promise.resolve()
                      : Promise.reject(
                          new Error("Khối lượng chỉ được nhập ký tự là số")
                        ),
                },
              ]}
            >
              {editing ? (
                <Input placeholder="Tổng khối lượng" suffix="Kg" />
              ) : (
                <Text strong>{orEmpty("weight", item)} kg</Text>
              )}
            </Form.Item>
          </Col>
          <Col span={12}>
            {isReturnOrCompensationTransport ? null : (
              <>
                {orBoolean("order.isFreeShip", item) ? null : orBoolean(
                    "cashByRecipient",
                    item
                  ) ? (
                  <Form.Item className="bill-order-detail-main-shipingNote-form-item">
                    <Text strong type="danger">
                      {orBoolean("cashByRecipient", item)
                        ? "Người nhận trả phí"
                        : null}
                    </Text>
                  </Form.Item>
                ) : null}
              </>
            )}
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Tổng tiền hàng"
            >
              <Text strong>
                {Helpers.currencyFormatVND(orEmpty("totalPrice", item))}
              </Text>
            </Form.Item>

            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Tiền thu hộ"
            >
              <Text strong>
                {Helpers.currencyFormatVND(orEmpty("codAmount", item))}
              </Text>
            </Form.Item>
            <Form.Item
              className="bill-order-detail-main-shipingNote-form-item"
              label="Phí vận chuyển"
              name="shippingFee"
            >
              {editing ? (
                <div>
                  {orBoolean("fulfillmentCompany.isAutoShippingFee", item) ? (
                    <Input placeholder="Tự cập nhật" disabled />
                  ) : (
                    <InputNumber
                      style={{ width: "100%" }}
                      value={shippingFee}
                      onChange={(value) => setShippingFee(value)}
                      placeholder={"Nhập phí vận chuyển"}
                      formatter={(value) =>
                        `${value ? value : 0} đ`.replace(
                          /\B(?=(\d{3})+(?!\d))/g,
                          ","
                        )
                      }
                    />
                  )}
                </div>
              ) : (
                <Text strong>
                  {Helpers.currencyFormatVND(orEmpty("orderShippingFee", item))}
                </Text>
              )}
            </Form.Item>
          </Col>
        </Row>

        {!roleDisable.includes(roleUser) ? (
          <Form.Item
            className="bill-order-detail-main-shipingNote-form-action"
            {...tailLayout}
          >
            {editing ? (
              <Button
                onClick={() => setEditing(false)}
                style={{ marginRight: 10 }}
              >
                Hủy
              </Button>
            ) : null}
            {editing ? (
              <Button htmlType="submit" type="primary">
                Lưu
              </Button>
            ) : null}

            {renderButtonReorder()}

            {!editing ? (
              <Button
                disabled={checkStatusTransport()}
                onClick={() => setEditing(true)}
                type="primary"
              >
                Chỉnh sửa phiếu
              </Button>
            ) : null}
          </Form.Item>
        ) : null}
      </Form>
    </Card>
  );
}
