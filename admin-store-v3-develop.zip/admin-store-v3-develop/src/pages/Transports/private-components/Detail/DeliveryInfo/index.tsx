import { Card, Space, Typography } from 'antd';
import { EditOutlined } from '@ant-design/icons';
import { orEmpty, orNull } from 'utils/Selector';
import { useEffect, useState } from 'react';
import { CreateCustomer } from 'components';
const { Text } = Typography;

export default function DeliveryInfo(props) {
	const { item } = props;
	const [customer, setCustomer] = useState(null);
	const [title, setTitle] = useState('');

	useEffect(() => {
		if (item) {
			if (orEmpty('fulfillmentType', item) === 'REFUND') {
				setCustomer(orEmpty('fromAddressRefund', item));
				setTitle('Thông tin trả hàng');
			} else {
				setCustomer(orEmpty('toAddress', item));
				setTitle('Thông tin giao hàng');
			}
		}
	}, [item]);

	return (
		<Card title={title} className="bill-order-detail-sidebar-card">
			<Space direction="vertical">
				<Text className="form-sidebar-customer-item-detail-info-text">
					{orEmpty('customerName', customer)}
				</Text>
				<Text copyable className="form-sidebar-customer-item-detail-info-text">
					{orEmpty('customerPhone', customer)}
				</Text>
				<Text className="form-sidebar-customer-item-detail-info-text">
					{orEmpty('customerEmail', customer)}
				</Text>
				<Text className="form-sidebar-customer-item-detail-info-text">
					{`${
						orEmpty('address', customer) != '' ? orEmpty('address', customer) + ',' : ''
					} ${orEmpty('wardName', customer)}, ${orEmpty(
						'districtName',
						customer
					)}, ${orEmpty('provinceName', customer)}`}
				</Text>
			</Space>
		</Card>
	);
}
