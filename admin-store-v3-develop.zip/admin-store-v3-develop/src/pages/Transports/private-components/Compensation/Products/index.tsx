import { useState, useEffect } from 'react';
import { Card, Table, Avatar, InputNumber } from 'antd';
import { orArray, orNull, orEmpty, orNumber } from 'utils/Selector';
import { CloseOutlined } from '@ant-design/icons';
import { Helpers } from 'utils';
import config from 'configs/env';

export default function Products(props) {
	const { item, setListProduct } = props;
	const listOrderProduct = orNull('order.orderItems', item);
	const [rows, setRows] = useState([]);

	const onRemoveItem = (id) => {
		const filterItems = [...item.items].filter((row) => row.id !== id);
		setListProduct(filterItems);
	};

	const onChangeQuantity = (value, record, index) => {
		if (value > 0) {
			const arrayNew = [...item.items];
			arrayNew[index]['quantity'] = value;
			arrayNew[index]['totalPrice'] = Helpers.currencyFormatVND(record.price * value);
			setListProduct(arrayNew);
		}
	};

	const columns = [
		{
			title: 'Sản phẩm',
			dataIndex: 'name',
			render(value, record) {
				return {
					props: {
						style: { padding: '0' },
					},
					children: (
						<div
							onClick={(e) => onPreviewProduct(e, orEmpty('slug', record))}
							style={{ cursor: 'pointer', display: 'flex' }}>
							{orNull('image', record) ? (
								<Avatar
									style={{ marginRight: 10 }}
									shape="square"
									size={48}
									src={orEmpty('image', record)}
								/>
							) : null}
							<div style={{ display: 'flex', flexDirection: 'column' }}>
								<a
									href={`${config.base_url}/chi-tiet-san-pham/${record.slug}`}
									target="_blank">
									{value}
								</a>
								<div>Phiên bản: {orEmpty('variantName', record)}</div>
							</div>
						</div>
					),
				};
			},
		},
		{
			title: 'Đơn giá',
			dataIndex: 'price',
		},
		{
			title: 'Số lượng',
			dataIndex: 'quantity',
			key: 'quantiy',
			render(value, record, index) {
				return {
					children: (
						<div style={{ display: 'flex', alignItems: 'center' }}>
							<InputNumber
								value={value}
								onChange={(value) => onChangeQuantity(value, record, index)}
								min={0}
								max={record.quantity}
								width={50}
							/>
							/ {record.quantity}
						</div>
					),
				};
			},
		},
		{
			title: 'Thành tiền',
			dataIndex: 'totalPrice',
		},
		,
		{
			title: '',
			dataIndex: 'key',
			render: (value) => (
				<div>
					<CloseOutlined onClick={() => onRemoveItem(value)} />
				</div>
			),
		},
	];

	function onPreviewProduct(e, slug) {
		e.preventDefault();
		if (slug) window.open(`${config.base_url}/chi-tiet-san-pham/${slug}`, '_blank').focus();
	}

	function onUpdateData(): void {
		if (orArray('items', item)) {
			const r = [] as any;
			orArray('items', item).forEach((node): void => {
				r.push({
					key: orEmpty('id', node),
					id: orEmpty('id', node),
					name: orEmpty('productName', node),
					slug: orEmpty('productSlug', node),
					image: orEmpty('productImage.url', node),
					price: Helpers.currencyFormatVND(orNumber('price', node)),
					quantity: orNumber('quantity', node),
					variantName: orEmpty('variantName', node),
					totalPrice: Helpers.currencyFormatVND(
						orNumber('price', node) * orNumber('quantity', node)
					),
				});
			});
			setRows(r);
		}
	}
	useEffect(onUpdateData, [orArray('items', item)]);

	return (
		<Card title={null} style={{ padding: 20 }} className="bill-order-detail-main-products">
			<Table columns={columns} dataSource={rows} />
		</Card>
	);
}
