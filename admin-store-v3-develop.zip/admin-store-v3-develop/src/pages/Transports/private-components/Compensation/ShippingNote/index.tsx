import {
  Button,
  Card,
  Col,
  Divider,
  Form,
  Input,
  Row,
  Space,
  Checkbox,
  DatePicker,
  Modal,
  Spin,
  InputNumber,
} from "antd";
import { useCallback, useEffect, useMemo, useState } from "react";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import { Selector } from "components";
import { Helpers } from "utils";
import moment from "moment";
import { FullfillmentOrders as FullfillmentOrdersAPI } from "api";
import useDebounce from "hook/useDebounce";
import { useParams } from "react-router";

const layout = {
  labelCol: { span: 8 },
  wrapperCol: { span: 16 },
};
const tailLayout = {
  wrapperCol: { span: 24 },
};

export default function ShippingNote(props) {
  const params: any = useParams();
  const {
    item,
    fullfillmentCompanies = [],
    handleCreateCreateCompensationOrder,
    handleCalculateShippingFee,
    shippingFeeCalculate,
    isGetShippingFee,
    message,
    customer,
  } = props;
  const [form] = Form.useForm();
  const [transporterOptions, setTransporterOptions] = useState([]);
  const [paymentMethodBillLandingOptions, setPaymentMethodBillLandingOptions] =
    useState([
      {
        label: "Tiền mặt",
        value: "CASH",
      },
      {
        label: "Tài khoản AhaMove",
        value: "BALANCE",
      },
    ]);
  const [inventoryOptions, setInventoryOptions] = useState([]);
  const [serviceOptions, setServiceOptions] = useState([]);
  const [transporter, setTransporter] = useState({
    isRetailShipping: false,
    isAutoShippingFee: true,
    shippingFee: null,
  });
  const [selectedTransporter, setSelectedTransporter] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [selectedInventory, setSelectedInventory] = useState("");
  const [weight, setWeight] = useState(0);
  const inputDebounce = useDebounce(weight, 300);
  const [isLoading, setIsLoading] = useState(false);
  const [isChoosePaymentMethod, setIsChoosePaymentMethod] = useState(false);

  useMemo(() => {
    if (!isGetShippingFee && message) {
      Modal.warning({
        title: "Thông báo",
        content: message,
        afterClose: () => {
          setSelectedService("");
          form.setFieldsValue({
            service: null,
          });
        },
      });
    }
  }, [isGetShippingFee, message]);

  async function onGetInventories(params) {
    setIsLoading(true);
    try {
      const response = await FullfillmentOrdersAPI.getListInventory(params);
      const { data } = response;
      if (data) {
        const opInventories = data.data.map((item) => ({
          ...item,
          label: item.name,
          value: item.id,
        }));
        setInventoryOptions(opInventories);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  }

  async function onGetCompanyServices(params) {
    setIsLoading(true);
    try {
      const response = await FullfillmentOrdersAPI.getCompanyServices(params);
      const { data } = response;
      if (data) {
        const services = data.data.map((item) => ({
          label: item.name,
          value: item.id,
        }));
        setServiceOptions(services);
      }
    } catch (error) {
      console.log(error);
    } finally {
      setIsLoading(false);
    }
  }

  const onChangeTransporter = (value) => {
    setSelectedTransporter(value);
    setSelectedService("");
    setServiceOptions([]);

    const transporter = fullfillmentCompanies.find((item) => item.id === value);

    const params = {
      weight,
      service: 0,
      company: value,
      inventory: orEmpty("id", selectedInventory),
      codAmount:
        orNumber("paymentGateway", item) === "COD"
          ? orEmpty("totalPrice", item)
          : 0,
      shippingAddress: customer,
      fulfillmentType: orEmpty("fulfillmentType", item),
    };
    onGetCompanyServices(params);
    setIsChoosePaymentMethod(orEmpty("slug", transporter) === "AHAMOVE");
    if (orEmpty("slug", transporter) === "SHIP-LE") {
      setTransporter((prevState) => ({
        ...prevState,
        isRetailShipping: true,
      }));
    } else {
      setTransporter((prevState) => ({
        ...prevState,
        isRetailShipping: false,
      }));
    }
    setTransporter((prevState) => ({
      ...prevState,
      isAutoShippingFee: transporter.isAutoShippingFee,
    }));
    if (orBoolean("isAutoShippingFee", transporter)) {
      form.setFieldsValue({
        ShippingFee: null,
      });
      return;
    }
    form.setFieldsValue({
      ShippingFee: 0,
    });
  };

  const onChangeService = (value) => {
    setSelectedService(value);
  };

  const onChangeInventory = (value) => {
    const inventorySelected = inventoryOptions.find(
      (item) => item.value === value
    );
    setSelectedService("");
    setSelectedTransporter("");
    setServiceOptions([]);
    setIsChoosePaymentMethod(false);
    setSelectedInventory(inventorySelected);
    form.setFieldsValue({
      service: null,
      fulfillmentCompany: null,
    });
    if (
      !orBoolean("isOnlyShowInOrder", inventorySelected) &&
      orBoolean("isSalonInventories", inventorySelected)
    ) {
      setTransporterOptions(
        fullfillmentCompanies
          .filter((item) => item.slug === "AHAMOVE")
          .map((i) => ({
            slug: i.slug,
            label: i.name,
            value: i.id,
          }))
      );
    } else {
      setTransporterOptions(
        fullfillmentCompanies.map((i) => ({
          slug: i.slug,
          label: i.name,
          value: i.id,
        }))
      );
    }
  };

  const onChangeWeight = (e) => {
    setWeight(e.target.value ? parseFloat(e.target.value) : 0);
  };

  function onFinish(values) {
    const newValues = {
      enableReviewBefore: values.enableReviewBefore,
      fulfillmentCompany: values.fulfillmentCompany,
      inventory: orEmpty("id", selectedInventory),
      service: values.service,
      shippingNote: values.shippingNote,
      weight: values.weight,
      cashByRecipient: orBoolean("cashByRecipient", values),
      paymentMethod: values.paymentMethod,
      size: {
        width: values.width,
        height: values.height,
        depth: values.depth,
      },
      estimateDeliveryDate: values.estimateDeliveryDate
        ? values.estimateDeliveryDate.format("YYYY-MM-DD")
        : null,
      items: orArray("items", item)
        ? orArray("items", item).map((item) => {
            return {
              productId: item.id,
              variantId: item.variantId,
              productName: item.productName,
              variantName: item.variantName,
              quantity: item.quantity,
            };
          })
        : [],
      shippingAddress: customer,
    };
    const transporter = [...fullfillmentCompanies].find(
      (item) => item.id === selectedTransporter
    );
    if (
      orEmpty("slug", transporter) === "AHAMOVE" &&
      orBoolean("isSalonInventories", selectedInventory) &&
      orEmpty("phone", selectedInventory) != values.inventoryUpdatePhone
    ) {
      //@ts-ignore
      newValues.inventoryUpdatePhone = values.inventoryUpdatePhone;
    }
    if (!orBoolean("isAutoShippingFee", transporter)) {
      handleCreateCreateCompensationOrder({
        id: orEmpty("id", item),
        shippingFee: transporter.shippingFee,
        ...newValues,
      });
      return;
    }
    handleCreateCreateCompensationOrder({
      id: orEmpty("id", item),
      ...newValues,
    });
  }

  function onSetupForm() {
    form.setFieldsValue({
      depth: "",
      height: "",
      width: "",
      shippingNote: "",
      enableReviewBefore: true,
      cashByRecipient: false,
      estimateDeliveryDate: null,
      inventory: item ? orEmpty("inventory.id", item) : null,
      inventoryUpdatePhone: "",
    });
    if (item) {
      setSelectedInventory(orNull("inventory", item));
    }
  }

  function disabledDate(current) {
    return current && current <= moment().endOf("day").subtract(1, "day");
  }

  const reg = /^-?\d*(\.\d*)?$/;

  function onValidPhone(phone) {
    const convertArr = phone.split("");
    if (phone.length < 10 || phone.length > 10) {
      return Promise.reject(new Error("Vui lòng nhập đúng số điện thoại"));
    }
    if (convertArr[0] != 0 || convertArr[1] == 0) {
      return Promise.reject(new Error("Vui lòng nhập đúng số điện thoại"));
    }
    return Promise.resolve();
  }

  const renderUpdatePhoneInventory = useCallback(() => {
    const transporter = fullfillmentCompanies.find(
      (item) => item.id === selectedTransporter
    );
    if (
      orEmpty("slug", transporter) === "AHAMOVE" &&
      orBoolean("isSalonInventories", selectedInventory)
    ) {
      return (
        <Form.Item
          className="bill-order-detail-main-shipingNote-form-item"
          label="Số điện thoại salon"
          name="inventoryUpdatePhone"
          rules={[
            {
              validator: (_, value) => onValidPhone(value),
            },
          ]}
        >
          <Input placeholder="Nhập số điện thoại salon" />
        </Form.Item>
      );
    }
    return null;
  }, [selectedTransporter, selectedInventory, item]);

  useEffect(() => {
    const params = {
      isSalonInventories: true,
    };
    onGetInventories(params);
  }, []);

  useEffect(() => {
    if (fullfillmentCompanies && item) {
      if (
        !orBoolean("inventory.isOnlyShowInOrder", item) &&
        orBoolean("inventory.isSalonInventories", item)
      ) {
        setTransporterOptions(
          fullfillmentCompanies
            .filter((item) => item.slug === "AHAMOVE")
            .map((i) => ({
              slug: i.slug,
              label: i.name,
              value: i.id,
            }))
        );
      } else {
        setTransporterOptions(
          fullfillmentCompanies.map((i) => ({
            slug: i.slug,
            label: i.name,
            value: i.id,
          }))
        );
      }
    }
  }, [fullfillmentCompanies, item]);

  useEffect(() => {
    if (
      selectedTransporter &&
      selectedService &&
      selectedInventory &&
      weight > 0 &&
      orBoolean("isAutoShippingFee", transporter) &&
      inputDebounce
    ) {
      handleCalculateShippingFee({
        weight,
        service: selectedService,
        company: selectedTransporter,
        inventory: orEmpty("id", selectedInventory),
        codAmount:
          orNumber("paymentGateway", item) === "COD"
            ? orEmpty("totalPrice", item)
            : 0,
        shippingAddress: customer,
        fulfillmentType: orEmpty("fulfillmentType", item),
      });
    }
  }, [
    selectedTransporter,
    selectedInventory,
    item,
    selectedService,
    weight,
    inputDebounce,
  ]);

  useEffect(() => {
    if (item) onSetupForm();
  }, [item]);

  useMemo(() => {
    const transporter = fullfillmentCompanies.find(
      (item) => item.id === selectedTransporter
    );
    if (
      orEmpty("slug", transporter) === "AHAMOVE" &&
      orBoolean("inventory.isSalonInventories", item)
    ) {
      form.setFieldsValue({
        inventoryUpdatePhone: orEmpty("inventory.phone", item),
      });
    }
  }, [item, selectedTransporter]);

  return (
    <Card
      title="Thông tin phiếu vận chuyển"
      className="bill-order-detail-main-shipingNote"
    >
      <Spin spinning={isLoading}>
        <Form
          name="basic"
          onFinish={onFinish}
          form={form}
          {...layout}
          className="bill-order-detail-main-shipingNote-form"
        >
          <Row gutter={24}>
            <Col span={12}>
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Mã đơn hàng"
              >
                {orEmpty("code", item)}
              </Form.Item>
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Mã vận đơn"
              >
                <Input placeholder="Tự cập nhật" disabled />
              </Form.Item>

              <Form.Item
                name="enableReviewBefore"
                valuePropName="checked"
                wrapperCol={{ span: 24 }}
              >
                <Checkbox>Kiểm tra sản phẩm trước khi thanh toán</Checkbox>
              </Form.Item>

              {orBoolean("isRetailShipping", transporter) ? (
                <Form.Item
                  className="bill-order-detail-main-shipingNote-form-item"
                  label="Dự kiến giao hàng"
                  name="estimateDeliveryDate"
                  rules={[
                    {
                      required: true,
                      message: "Vui lòng chọn thời gian dự kiến giao hàng",
                    },
                  ]}
                >
                  <DatePicker
                    disabledDate={disabledDate}
                    format={"DD-MM-YYYY"}
                    style={{ width: "100%" }}
                  />
                </Form.Item>
              ) : null}
            </Col>
            <Col span={12}>
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label={
                  orEmpty("type", params) === "refund"
                    ? "Kho nhận hàng"
                    : "Kho xuất hàng"
                }
                name="inventory"
              >
                {orBoolean("inventory.isOnlyShowInOrder", item) &&
                orBoolean("inventory.isSalonInventories", item) ? (
                  <Selector
                    onChange={onChangeInventory}
                    options={inventoryOptions}
                    placeholder="Chọn kho xuất hàng"
                  />
                ) : (
                  `${orEmpty("inventory.name", item)}`
                )}
              </Form.Item>

              {renderUpdatePhoneInventory()}

              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Nhà vận chuyển"
                name="fulfillmentCompany"
                rules={[
                  {
                    required: true,
                    message: "Vui lòng chọn nhà vận chuyển",
                  },
                ]}
              >
                <Selector
                  onChange={onChangeTransporter}
                  options={transporterOptions}
                  placeholder="Chọn nhà vận chuyển"
                />
              </Form.Item>

              {isChoosePaymentMethod &&
              !form.getFieldValue("cashByRecipient") ? (
                <Form.Item
                  className="bill-order-detail-main-shipingNote-form-item"
                  label="Phương thức TT"
                  name="paymentMethod"
                >
                  <Selector
                    defaultValue="CASH"
                    options={paymentMethodBillLandingOptions}
                    placeholder="Chọn phương thức thanh toán"
                  />
                </Form.Item>
              ) : null}

              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Gói vận chuyển"
                name="service"
                rules={[
                  {
                    required: true,
                    message: "Vui lòng chọn gói vận chuyển",
                  },
                ]}
              >
                <Selector
                  onChange={onChangeService}
                  disabled={serviceOptions.length === 0}
                  options={serviceOptions}
                  placeholder="Chọn gói vận chuyển"
                />
              </Form.Item>

              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Ghi chú giao hàng"
                name="shippingNote"
              >
                <Input.TextArea placeholder="Ghi chú giao hàng" />
              </Form.Item>
            </Col>
          </Row>
          <Divider />
          <Row gutter={24}>
            <Col span={12}>
              <div className="editing-form-height-width">
                <div>Kích thước:</div>
                <Space>
                  <Form.Item
                    className="bill-order-detail-main-shipingNote-form-item"
                    name="depth"
                    rules={[
                      {
                        validator: (_, value) =>
                          !value
                            ? Promise.resolve()
                            : reg.test(value)
                            ? Promise.resolve()
                            : Promise.reject(new Error("Chiều dài phải là số")),
                      },
                    ]}
                  >
                    <Input placeholder="dài" />
                  </Form.Item>
                  <Form.Item
                    className="bill-order-detail-main-shipingNote-form-item"
                    name="width"
                    rules={[
                      {
                        validator: (_, value) =>
                          !value
                            ? Promise.resolve()
                            : reg.test(value)
                            ? Promise.resolve()
                            : Promise.reject(
                                new Error("Chiều rộng phải là số")
                              ),
                      },
                    ]}
                  >
                    <Input placeholder="rộng" />
                  </Form.Item>
                  <Form.Item
                    className="bill-order-detail-main-shipingNote-form-item"
                    name="height"
                    rules={[
                      {
                        validator: (_, value) =>
                          !value
                            ? Promise.resolve()
                            : reg.test(value)
                            ? Promise.resolve()
                            : Promise.reject(new Error("Chiều cao phải là số")),
                      },
                    ]}
                  >
                    <Input placeholder="cao" />
                  </Form.Item>
                  cm
                </Space>
              </div>
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Tổng khối lượng"
                name="weight"
                rules={[
                  { required: true, message: "Vui lòng nhập khối lượng" },
                  {
                    validator: (_, value) =>
                      reg.test(value)
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error("Khối lượng chỉ được nhập ký tự là số")
                          ),
                  },
                ]}
              >
                <Input
                  onChange={onChangeWeight}
                  placeholder="Tổng khối lượng"
                  suffix="Kg"
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Tiền thu hộ"
              >
                {Helpers.currencyFormatVND(0)}
              </Form.Item>
              <Form.Item
                className="bill-order-detail-main-shipingNote-form-item"
                label="Phí vận chuyển"
                name="shippingFee"
              >
                <div>
                  {orBoolean("isAutoShippingFee", transporter) ? (
                    <div>
                      {shippingFeeCalculate > 0 ? (
                        <span>
                          {Helpers.currencyFormatVND(shippingFeeCalculate)}{" "}
                          <span style={{ fontSize: 12 }}>(tạm tính)</span>
                        </span>
                      ) : (
                        <Input placeholder="Tự cập nhật" disabled />
                      )}
                    </div>
                  ) : (
                    <InputNumber
                      style={{ width: "100%" }}
                      onChange={(value) =>
                        setTransporter((prevState) => ({
                          ...prevState,
                          shippingFee: value,
                        }))
                      }
                      placeholder={"Nhập phí vận chuyển"}
                      formatter={(value) =>
                        `${value ? value : 0} đ`.replace(
                          /\B(?=(\d{3})+(?!\d))/g,
                          ","
                        )
                      }
                    />
                  )}
                </div>
              </Form.Item>
            </Col>
          </Row>

          <Form.Item
            className="bill-order-detail-main-shipingNote-form-action"
            {...tailLayout}
          >
            <Button htmlType="submit" type="primary">
              Tạo phiếu
            </Button>
          </Form.Item>
        </Form>
      </Spin>
    </Card>
  );
}
