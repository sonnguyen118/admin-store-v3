import React, { useState, useEffect } from 'react';
import { Card, Form, Typography } from 'antd';
import { CreateCustomer } from 'components';
import { EditOutlined } from '@ant-design/icons';
import { orEmpty, orNull } from 'utils/Selector';
import { useParams } from 'react-router';

const { Title, Text } = Typography;

const { Item } = Form;

function DeliveryInfo(props) {
	const { form, item, setCustomer } = props;
	const [isCustomer, setIsCustomer] = useState({
		isOpenForm: false,
		customer: null,
	});
	const params: any = useParams();

	useEffect(() => {
		if (orNull('shippingAddress', item)) {
			setIsCustomer((prevState) => ({
				...prevState,
				customer: orNull('shippingAddress', item),
			}));
		}
	}, [orNull('shippingAddress', item)]);

	const onCancel = () => {
		setIsCustomer((prevState) => ({
			...prevState,
			isOpenForm: false,
		}));
	};

	const onSubmit = (values) => {
		setIsCustomer({
			isOpenForm: false,
			customer: values,
		});
	};

	const onEditCustomer = () => {
		setIsCustomer((prevState) => ({
			...prevState,
			isOpenForm: true,
		}));
	};

	useEffect(() => {
		if (isCustomer.customer) {
			form.setFieldsValue({
				shippingAddress: isCustomer.customer,
			});
			setCustomer(isCustomer.customer);
		}
	}, [isCustomer.customer]);

	return (
		<Card
			title="Khách hàng"
			className="order-detail-main-note order-detail-sidebar-card form-sidebar-customer"
		>
			<Item
				name="shippingAddress"
				className="form-sidebar-customer-item"
				required
				rules={[{ required: true, message: 'Vui lòng chọn khách hàng' }]}
			>
				{isCustomer.customer ? (
					<>
						<div className="form-sidebar-customer-item-detail">
							<div className="form-sidebar-customer-item-detail-title">
								<Title level={4}>
									{params?.type === 'compensation'
										? 'Thông tin giao hàng'
										: 'Thông tin trả hàng'}
								</Title>
								<EditOutlined
									onClick={onEditCustomer}
									className="form-sidebar-customer-item-detail-title-icon"
								/>
							</div>
							<div className="form-sidebar-customer-item-detail-info">
								<Text className="form-sidebar-customer-item-detail-info-text">
									{orEmpty('customer.customerName', isCustomer)}
								</Text>
								<Text className="form-sidebar-customer-item-detail-info-text">
									{orEmpty('customer.customerPhone', isCustomer)}
								</Text>
								<Text className="form-sidebar-customer-item-detail-info-text">
									{orEmpty('customer.customerEmail', isCustomer)}
								</Text>
								<Text className="form-sidebar-customer-item-detail-info-text">
									{`${
										orEmpty('customer.address', isCustomer) != ''
											? orEmpty('customer.address', isCustomer) + ','
											: ''
									} ${orEmpty('customer.wardName', isCustomer)}, ${orEmpty(
										'customer.districtName',
										isCustomer
									)}, ${orEmpty('customer.provinceName', isCustomer)}`}
								</Text>
							</div>
						</div>
					</>
				) : null}
			</Item>
			{isCustomer.isOpenForm ? (
				<CreateCustomer
					item={isCustomer.customer}
					visible={isCustomer.isOpenForm}
					onCancel={onCancel}
					onSubmit={onSubmit}
				/>
			) : null}
		</Card>
	);
}

export default DeliveryInfo;
