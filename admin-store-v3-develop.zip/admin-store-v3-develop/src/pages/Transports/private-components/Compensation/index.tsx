import './styled.scss';
import { Row, Col, Space, Form as FormBase } from 'antd';
import Header from './Header';
import ShippingNote from './ShippingNote';
import Products from './Products';
import DeliveryTime from './DeliveryTime';
import { useEffect, useState } from 'react';
import { orNull } from 'utils/Selector';
import SellerInfo from './SellerInfo';
import DeliveryInfo from './DeliveryInfo';
import Tags from './Tags';

export default function Detail(props) {
	const {
		setShippingFeeToEmpty,
		message,
		isGetShippingFee,
		shippingFeeCalculate,
		handleCalculateShippingFee,
		handleBack,
		user,
		fullfillmentCompanies,
		inventories,
		handleCreateCreateCompensationOrder,
		onUpdateTransport,
		listOrderTag,
	} = props;
	const [form] = FormBase.useForm();
	const [customer, setCustomer] = useState(null);
	const [item, setItem] = useState(props.item);
	const [tags, setTags] = useState([]);
	const renderHeader = () => {
		return <Header item={item} handleBack={handleBack} user={user} />;
	};

	const onHandleCalculateShippingFee = (params) => {
		handleCalculateShippingFee({ ...params, shippingAddress: customer });
	};

	const renderShippingNote = () => {
		return (
			<ShippingNote
				item={item}
				user={user}
				customer={customer}
				fullfillmentCompanies={fullfillmentCompanies}
				inventories={inventories}
				handleCreateCreateCompensationOrder={handleCreateCreateCompensationOrder}
				handleCalculateShippingFee={onHandleCalculateShippingFee}
				shippingFeeCalculate={shippingFeeCalculate}
				isGetShippingFee={isGetShippingFee}
				message={message}
				setShippingFeeToEmpty={setShippingFeeToEmpty}
			/>
		);
	};

	const renderProducts = () => {
		return (
			<Products
				item={item}
				setListProduct={(list) => {
					setItem({ ...item, items: list });
				}}
			/>
		);
	};

	const renderDeliveryInfo = () => {
		return <DeliveryInfo form={form} item={orNull('order', item)} setCustomer={setCustomer} />;
	};

	const renderSellerInfo = () => {
		return <SellerInfo item={item} />;
	};

	const renderDeliveryTime = () => {
		return <DeliveryTime item={item} />;
	};

	const renderTags = () => {
		return <Tags tags={tags} setTags={setTags} item={item} handleUpdateOrder={onUpdateTransport} />;
	};

	useEffect(() => {
		if (listOrderTag) {
			const listOrderTagOption = listOrderTag.map((item) => ({
				label: item.name,
				value: item.id,
			}));
			setTags(listOrderTagOption);
		}
	}, [listOrderTag]);
	
	useEffect(() => {
		if (props.item) {
			setItem(props.item);
		}
	}, [props.item]);

	return (
		<div className="bill-order-detail">
			{renderHeader()}
			<Row gutter={24}>
				<Col span={18}>
					<Space className="bill-order-detail-main" direction="vertical">
						{renderShippingNote()}
						{renderProducts()}
					</Space>
				</Col>
				<Col span={6}>
					<Space className="bill-order-detail-sidebar" direction="vertical">
						{renderDeliveryInfo()}
						{renderDeliveryTime()}
						{item && item.seller ? renderSellerInfo() : null}
						{renderTags()}
					</Space>
				</Col>
			</Row>
		</div>
	);
}
