import React, { useState, useEffect, useRef } from "react";
import {
  Selector,
  ComponentToPrint as PrintOrder,
  ComponentToPrintExportProduct,
} from "components";
import {
  Form,
  Row,
  Col,
  Input,
  Button,
  Popover,
  Tag,
  DatePicker,
  Dropdown,
  Menu,
  Modal,
  Radio,
  Space,
  notification,
} from "antd";
import { FilterOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { Helpers, Mocks } from "utils";
import moment from "moment";
import "./styled.scss";
import ReactToPrint from "react-to-print";
import { DownOutlined } from "@ant-design/icons";
import { orEmpty, orNull, orBoolean, orArray, orNumber } from "utils/Selector";
import {
  ExportExcel,
  ExportExcelCollation,
  ExportExcelCollationAll,
} from "../private-components";
import _ from "lodash";

const printPageStyle = `
  @page { size: auto;  margin: 5mm; }
  @media print {
    body { 
      -webkit-print-color-adjust: exact;
      page-break-after: auto;
    }
    html, body { 
      -webkit-print-color-adjust: exact;
      height: initial !important; 
      overflow: initial !important; 
    }
  }
  @media print { body { -webkit-print-color-adjust: exact; } }
`;

const { RangePicker } = DatePicker;

export default function Filter(props) {
  const {
    filter,
    setFilter,
    listFulFillmentCompany,
    listinventory,
    onChangePage,
    selectedItems,
    setSelectedItems,
    onConfirmPrintItems,
    localFilterOrders,
    path,
    onReloadData,
    filterDefault,
    tabSelected,
    roleUser,
    roleUsed,
    totalRecord,
    handleImportAllDataCollation,
  } = props;
  const componentRef = useRef<HTMLDivElement>(null);
  const componentExport = useRef<HTMLDivElement>(null);
  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false);
  const [listFilter, setListFilter] = useState([]);
  const [filterType, setFilterType] = useState("withStatus");
  const [searchValue, setSearchValue] = useState("");
  const [listFulFillmentCompanyOption, setListFulFillmentCompanyOption] =
    useState([]);
  const [listinventoryOption, setListinventoryOption] = useState([]);
  const inputDebounce = useDebounce(searchValue, 300);
  const [dataFilter, setDataFilter] = useState({});
  const [isUpdateFilter, setIsUpdateFilter] = useState(false);
  const [isUpdate, setIsUpdate] = useState(false);

  useEffect(() => {
    if (filterDefault) {
      setDataFilter((prevState) => ({
        ...prevState,
        ...filterDefault,
      }));
    }
  }, [filterDefault]);

  useEffect(() => {
    if (listFulFillmentCompany.length) {
      const listFulFillmentCompanyOption = listFulFillmentCompany.map(
        (item) => ({
          label: item.name,
          value: item.id,
        })
      );
      setListFulFillmentCompanyOption(listFulFillmentCompanyOption);
    }
  }, [listFulFillmentCompany]);

  useEffect(() => {
    if (listinventory.length) {
      const listinventoryOption = listinventory.map((item) => ({
        label: item.name,
        value: item.id,
      }));
      setListinventoryOption(listinventoryOption);
    }
  }, [listinventory]);

  useEffect(() => {
    form2.setFieldsValue({
      isCreate: "create",
    });
  }, []);

  useEffect(() => {
    const arr = [...listFilter];
    if (filterDefault) {
      if (orNull("status", filterDefault)) {
        arr.push({
          value: "withStatus",
          label: Mocks.TRANSPORTS.getLabelFilter(
            "withStatus",
            orNull("status", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("shippingType", filterDefault)) {
        arr.push({
          value: "withShippingType",
          label: Mocks.ORDER.getLabelFilter(
            "withShippingType",
            orNull("shippingType", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("isCOD", filterDefault)) {
        arr.push({
          value: "withCODStatus",
          label: Mocks.TRANSPORTS.getLabelFilter(
            "withCODStatus",
            orNull("isCOD", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("fulfillmentCompany", filterDefault)) {
        arr.push({
          value: "withTransporter",
          label: Mocks.TRANSPORTS.getLabelFilter(
            "withTransporter",
            orNull("fulfillmentCompany", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("inventory", filterDefault)) {
        arr.push({
          value: "withInventory",
          label: Mocks.TRANSPORTS.getLabelFilter(
            "withInventory",
            orNull("inventory", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("isPrinted", filterDefault)) {
        arr.push({
          value: "withPrinted",
          label: Mocks.TRANSPORTS.getLabelFilter(
            "withPrinted",
            orNull("isPrinted", filterDefault)
          ),
        });
        setListFilter(arr);
      }
      if (orNull("estimateDeliveryDate", filterDefault)) {
        arr.push({
          value: "withEstimateDeliveryDate",
          label: `Thời gian dự kiến giao hàng ngày ${moment(
            orNull("estimateDeliveryDate", filterDefault)
          ).format("DD-MM-YYYY")}`,
        });
        setListFilter(arr);
      }
      if (orNull("before", filterDefault) && orNull("after", filterDefault)) {
        arr.push({
          value: "withDateTime",
          label: `Ngày tạo từ ngày ${moment(
            orNull("after", filterDefault)
          ).format("DD-MM-YYYY")} đến ngày ${moment(
            orNull("before", filterDefault)
          )
            .subtract(1, "days")
            .format("DD-MM-YYYY")}`,
        });
        setListFilter(arr);
      }
    }
  }, [filterDefault]);

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "withStatus":
        return Mocks.TRANSPORTS.FulfillmentStatus;
      case "withShippingType":
        return Mocks.TRANSPORTS.ShippingType;
      case "withCODStatus":
        return Mocks.TRANSPORTS.CODStatus;
      case "withTransporter":
        return listFulFillmentCompanyOption;
      case "withInventory":
        return listinventoryOption;
      case "withPrinted":
        return Mocks.TRANSPORTS.PrintedStatus;
      case "withCompensationAndRefund":
        return Mocks.TRANSPORTS.CompensationAndRefundStatus;
      default:
        break;
    }
  };

  useEffect(() => {
    if (filterType === "withStatus") {
      form.setFieldsValue({
        filterType: "withStatus",
        filterValue: orNull("status", dataFilter)
          ? orNull("status", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withShippingType") {
      form.setFieldsValue({
        filterType: "withShippingType",
        filterValue: orNull("shippingType", dataFilter)
          ? orNull("shippingType", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withCODStatus") {
      form.setFieldsValue({
        filterType: "withCODStatus",
        filterValue: orNull("isCOD", dataFilter)
          ? orNull("isCOD", dataFilter)
          : null,
      });
      return;
    }
    if (filterType === "withTransporter") {
      form.setFieldsValue({
        filterType: "withTransporter",
        filterValue: orNull("fulfillmentCompany", dataFilter)
          ? orNull("fulfillmentCompany", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withInventory") {
      form.setFieldsValue({
        filterType: "withInventory",
        filterValue: orNull("inventory", dataFilter)
          ? orNull("inventory", dataFilter)
          : [],
      });
      return;
    }
    if (filterType === "withPrinted") {
      form.setFieldsValue({
        filterType: "withPrinted",
        filterValue: orNull("isPrinted", dataFilter)
          ? orNull("isPrinted", dataFilter)
          : null,
      });
      return;
    }
    if (filterType === "withDateTime") {
      form.setFieldsValue({
        filterType: "withDateTime",
        filterDate:
          orNull("before", filterDefault) && orNull("after", filterDefault)
            ? [
                moment(orNull("after", filterDefault)),
                moment(orNull("before", filterDefault)).subtract(1, "days"),
              ]
            : null,
      });
      return;
    }
    if (filterType === "withEstimateDeliveryDate") {
      form.setFieldsValue({
        filterType: "withEstimateDeliveryDate",
        filterDate2: orNull("estimateDeliveryDate", filterDefault)
          ? moment(orNull("estimateDeliveryDate", filterDefault))
          : null,
      });
      return;
    }
  }, [filterType]);

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withStatus",
      filterValue: orNull("status", dataFilter)
        ? orNull("status", dataFilter)
        : [],
    });
  }

  useEffect(onSetupForm, [dataFilter]);

  const onFilter = (filterType, filterValue, filterDate) => {
    switch (filterType) {
      case "withStatus":
        setDataFilter((prevState) => ({
          ...prevState,
          status: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          status: filterValue,
        }));
        return;
      case "withShippingType":
        setDataFilter((prevState) => ({
          ...prevState,
          shippingType: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          shippingType: filterValue,
        }));
        return;
      case "withTransporter":
        setDataFilter((prevState) => ({
          ...prevState,
          fulfillmentCompany: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          fulfillmentCompany: filterValue,
        }));
        return;
      case "withCODStatus":
        setDataFilter((prevState) => ({
          ...prevState,
          isCOD: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          isCOD: filterValue,
        }));
        return;
      case "withInventory":
        setDataFilter((prevState) => ({
          ...prevState,
          inventory: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          inventory: filterValue,
        }));
        return;
      case "withPrinted":
        setDataFilter((prevState) => ({
          ...prevState,
          isPrinted: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          isPrinted: filterValue,
        }));
        return;
      case "withEstimateDeliveryDate":
        setDataFilter((prevState) => ({
          ...prevState,
          estimateDeliveryDate: filterDate.format("YYYY-MM-DD"),
        }));
        setFilter((prevState) => ({
          ...prevState,
          estimateDeliveryDate: filterDate.format("YYYY-MM-DD"),
        }));
        return;
      case "withDateTime":
        setDataFilter((prevState) => ({
          ...prevState,
          after: filterDate[0].format("YYYY-MM-DD"),
          before: moment(filterDate[1]).add(1, "days").format("YYYY-MM-DD"),
        }));
        setFilter((prevState) => ({
          ...prevState,
          after: filterDate[0].format("YYYY-MM-DD"),
          before: moment(filterDate[1]).add(1, "days").format("YYYY-MM-DD"),
        }));
        return;
      case "withCompensationAndRefund":
        setDataFilter((prevState) => ({
          ...prevState,
          fulfillmentType: filterValue,
        }));
        setFilter((prevState) => ({
          ...prevState,
          fulfillmentType: filterValue,
        }));
        return;
      default:
        break;
    }
  };

  const checkListFilter = (
    filterType,
    filterValue,
    filterDate,
    filterDate2
  ) => {
    handleCloseVisible();
    const arr = [...listFilter];
    const resultItem = listFilter.findIndex(
      (item) => item.value === filterType
    );
    if (resultItem === -1) {
      arr.push({
        value: filterType,
        label: Mocks.TRANSPORTS.getLabelFilter(
          filterType,
          filterValue || filterDate || filterDate2,
          listFulFillmentCompanyOption,
          listinventoryOption
        ),
      });
      setListFilter(arr);
    } else {
      listFilter[resultItem].label = Mocks.TRANSPORTS.getLabelFilter(
        filterType,
        filterValue || filterDate || filterDate2,
        listFulFillmentCompanyOption,
        listinventoryOption
      );
      setListFilter(arr);
    }
    return (
      form.setFieldsValue({
        filterType: filterType,
        filterValue: filterValue,
        filterDate2: filterDate2,
        filterDate: filterDate,
      }),
      onFilter(filterType, filterValue, filterDate || filterDate2),
      onChangePage(1)
    );
  };

  const onFinish = (values) => {
    checkListFilter(
      values.filterType,
      values.filterValue,
      values.filterDate,
      values.filterDate2
    );
  };

  useEffect(() => {
    if (inputDebounce) {
      setFilter((prevState) => ({
        ...prevState,
        s: searchValue,
      }));
      onChangePage(1);
      return;
    }
  }, [inputDebounce]);

  useEffect(() => {
    if (searchValue === "" && filter.s) {
      delete filter.s;
      setFilter({ ...filter });
      onChangePage(1);
      return;
    }
  }, [searchValue, filter]);

  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter((node) => node.value != item.value));
    if (item.value === "withStatus") {
      delete filter.status;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.status;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withShippingType") {
      delete filter.shippingType;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.shippingType;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withDateTime") {
      delete filter.after;
      delete filter.before;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.after;
      // @ts-ignore
      delete dataFilter.before;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withCODStatus") {
      delete filter.isCOD;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.isCOD;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withTransporter") {
      delete filter.fulfillmentCompany;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.fulfillmentCompany;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withInventory") {
      delete filter.inventory;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.inventory;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withEstimateDeliveryDate") {
      delete filter.estimateDeliveryDate;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.estimateDeliveryDate;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withPrinted") {
      delete filter.isPrinted;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.isPrinted;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
    if (item.value === "withCompensationAndRefund") {
      delete filter.fulfillmentType;
      setFilter({ ...filter });
      // @ts-ignore
      delete dataFilter.fulfillmentType;
      setDataFilter({ ...dataFilter });
      onChangePage(1);
      return;
    }
  };

  const handleVisibleChange = (visible) => {
    setFilterVisible(visible);
  };

  const handleCloseVisible = () => {
    setFilterType("withStatus");
    setFilterVisible(false);
  };

  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value);
  };

  const onChangeTypeFilter = (e) => {
    setFilterType(e);
  };

  const content = (
    <Form form={form} onFinish={onFinish} style={{ width: 300, maxWidth: 300 }}>
      <p>Hiển thị tất cả sản phẩm theo</p>
      <Form.Item name="filterType" style={{ marginBottom: 0 }}>
        <Selector
          onChange={onChangeTypeFilter}
          options={Mocks.TRANSPORTS.filterOptions}
        />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      {filterType === "withDateTime" ? (
        <Form.Item
          name="filterDate"
          rules={[{ required: true, message: "Vui lòng lựa chọn thời gian" }]}
          required
        >
          <RangePicker />
        </Form.Item>
      ) : filterType === "withEstimateDeliveryDate" ? (
        <Form.Item
          name="filterDate2"
          rules={[{ required: true, message: "Vui lòng lựa chọn thời gian" }]}
          required
        >
          <DatePicker style={{ width: "100%" }} />
        </Form.Item>
      ) : (
        <Form.Item
          name="filterValue"
          rules={[
            { required: true, message: "Vui lòng chọn thông tin để lọc" },
          ]}
        >
          <Selector
            mode={
              Mocks.TRANSPORTS.optionMultiple.includes(filterType)
                ? "multiple"
                : null
            }
            options={getOptionFilter(filterType)}
            placeholder="Chọn điều kiện lọc"
          />
        </Form.Item>
      )}

      <Form.Item style={{ display: "flex", justifyContent: "space-between" }}>
        <Button onClick={handleCloseVisible} style={{ marginRight: 10 }}>
          Huỷ
        </Button>
        <Button htmlType="submit" type="primary">
          Thêm điều kiện lọc
        </Button>
      </Form.Item>
    </Form>
  );

  const [printItems, setPrintItems]: any = useState({
    listOrder: [],
    listProduct: [],
  });

  function dedup_and_sum(arr) {
    const ans = _.chain(arr)
      // Group the elements of Array based on `color` property
      .groupBy("variantId")
      // `key` is group's name (color), `value` is the array of objects
      .map((value, key) => {
        return {
          variantId: key,
          productName: value[0].productName,
          variantName: value[0].variantName,
          productSKU: value[0].productSKU,
          quantity: _.sumBy(value, "quantity"),
        };
      })
      .value();
    return ans;
  }

  const ComponentToPrint = () => {
    return printItems.listOrder.map((item, key) => {
      const itemPrint = {
        orderCode: orEmpty("orderCode", item),
        fulfillmentCode: orEmpty("fulfillmentCode", item),
        customerName: orEmpty("shippingAddress.customerName", item),
        address: orEmpty("shippingAddress.address", item),
        wardName: orEmpty("shippingAddress.wardName", item),
        districtName: orEmpty("shippingAddress.districtName", item),
        provinceName: orEmpty("shippingAddress.provinceName", item),
        customerPhone: orEmpty("shippingAddress.customerPhone", item),
        fulfillmentCompany: orNull("fulfillmentCompany", item),
        shippingType: orEmpty("shippingType", item),
        cashByRecipient: orBoolean("cashByRecipient", item),
        enableReviewBefore: orBoolean("enableReviewBefore", item),
        paymentGateway: orEmpty("paymentGateway", item),
        totalPrice: orNumber("totalPrice", item)
          ? orNumber("totalPrice", item)
          : orNumber("order.totalPrice", item),
        orderItems: orArray("items", item),
        customerNote: orEmpty("customerNote", item),
        isCOD: orEmpty("isCOD", item),
        sortCode: orEmpty("sortCode", item),
        ...item
      };
      return <PrintOrder key={key} item={itemPrint} />;
    });
  };

  const ComponentToPrintExportFile = React.useCallback(() => {
    return (
      <ComponentToPrintExportProduct listProduct={printItems.listProduct} />
    );
  }, [orArray("listProduct", printItems)]);

  const handleBeforeGetContentExportProduct = () => {
    const arr = [];
    selectedItems.forEach((item) => {
      item.items.forEach((e) => {
        arr.push(e);
      });
    });
    const unique = dedup_and_sum(arr).sort((a, b) =>
      orEmpty("productName", a).localeCompare(orEmpty("productName", b))
    );
    setPrintItems((prevState) => ({ ...prevState, listProduct: unique }));
    return Promise.resolve();
  };

  const handleBeforeGetContent = () => {
    setPrintItems((prevState) => ({ ...prevState, listOrder: selectedItems }));
    return Promise.resolve();
  };

  const handleChangeIsCreate = (e) => {
    if (e.target.value === "update") {
      setIsUpdate(true);
      form2.setFieldsValue({
        name: localFilterOrders.find((item) => item.key === tabSelected)
          ? tabSelected
          : null,
      });
      return;
    }
    setIsUpdate(false);
    form2.setFieldsValue({
      name: "",
    });
  };

  function onFinishModal(values) {
    const arr = [...localFilterOrders];
    const newFilter = {
      name: values.name,
      key: Helpers.getKey(values.name),
      filter: dataFilter,
    };
    if (values.isCreate === "update") {
      const itemUpdateIndex = arr.findIndex(
        (item) => item.key === newFilter.key
      );
      newFilter.name = arr[itemUpdateIndex].name;
      arr[itemUpdateIndex] = newFilter;
      Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
        return onReloadData(newFilter);
      });
      form2.resetFields();
      setIsUpdateFilter(false);
      return;
    }
    if (arr.find((item) => item.key === newFilter.key)) {
      notification["warning"]({
        message: "Thông báo",
        description: `Bộ lọc đã tồn tại vui lòng kiểm tra và thử lại`,
      });
      return;
    }
    arr.push(newFilter);
    Helpers.localStorageSetItem(path, JSON.stringify(arr)).then(function () {
      return onReloadData(newFilter);
    });
    form2.resetFields();
    setIsUpdateFilter(false);
  }

  function handleCancel() {
    setIsUpdateFilter(false);
  }

  function handleAddFilterToLocal() {
    setIsUpdateFilter(true);
  }

  const menu = (
    <Menu>
      <Menu.Item key="printOrder">
        <ReactToPrint
          pageStyle={printPageStyle}
          removeAfterPrint={true}
          onAfterPrint={() => {
            setPrintItems((prevState) => ({ ...prevState, listOrder: [] }));
            if (printItems.listOrder.find((item) => !item.isPrinted)) {
              Modal.confirm({
                title: "Thông báo",
                content: `Xác nhận ${printItems.listOrder.length} đơn đã in thành công`,
                cancelText: "Hủy",
                okText: "Xác nhận",
                onOk: () =>
                  onConfirmPrintItems(
                    printItems.listOrder.map((item) => item.id)
                  ),
              });
            }
          }}
          trigger={() => <span>In đơn hàng đã chọn</span>}
          onBeforeGetContent={handleBeforeGetContent}
          content={() => componentRef.current}
        />
      </Menu.Item>
      <Menu.Item key="printExportProduct">
        <ReactToPrint
          pageStyle={printPageStyle}
          onAfterPrint={() =>
            setPrintItems((prevState) => ({ ...prevState, listProduct: [] }))
          }
          trigger={() => <span>In phiếu xuất hàng</span>}
          onBeforeGetContent={handleBeforeGetContentExportProduct}
          removeAfterPrint={true}
          content={() => componentExport.current}
        />
      </Menu.Item>
      <Menu.Item key="exportExcel">
        <ExportExcel orders={selectedItems} />
      </Menu.Item>
      {roleUsed.includes(roleUser) ? (
        <Menu.Item key="exportExcelCollation">
          <ExportExcelCollation orders={selectedItems} />
        </Menu.Item>
      ) : null}
    </Menu>
  );

  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title={"Thêm điều kiện lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>
              Thêm điều kiện lọc
            </Button>
          </Popover>
        </Col>
        <Col span={listFilter.length ? 15 : 18}>
          <Input
            value={searchValue}
            onChange={onChangeSearchValue}
            allowClear
            placeholder={
              "Tìm kiếm theo mã đơn hàng, số điện thoại, email, tên khách hàng ..."
            }
          />
        </Col>
        {listFilter.length ? (
          <Col span={3}>
            <Button
              onClick={handleAddFilterToLocal}
              style={{ width: "100%" }}
              icon={<FilterOutlined />}
            >
              Lưu bộ lọc
            </Button>
          </Col>
        ) : null}
      </Row>
      {listFilter.length ? (
        <Row style={{ margin: "15px 0" }} gutter={24}>
          <Col span={24}>
            {Helpers.getUnique(listFilter, "value").map((item, index) => {
              return (
                <Tag
                  key={index}
                  closable
                  onClose={(e) => handleRemoveFilter(e, item)}
                >
                  {item.label}
                </Tag>
              );
            })}
          </Col>
        </Row>
      ) : null}

      <Modal
        title="Lưu bộ lọc"
        visible={isUpdateFilter}
        onOk={form2.submit}
        onCancel={handleCancel}
      >
        <Form
          name="addFilter"
          form={form2}
          onFinish={onFinishModal}
          layout="vertical"
        >
          <Form.Item name="isCreate">
            <Radio.Group onChange={handleChangeIsCreate}>
              <Space direction="vertical">
                <Radio value="create">Tạo mới bộ lọc</Radio>
                <Radio value="update">Lưu đè lên bộ lọc đã tồn tại</Radio>
              </Space>
            </Radio.Group>
          </Form.Item>
          <Form.Item
            label={isUpdate ? "Chọn bộ lọc" : "Tên bộ lọc"}
            name="name"
            rules={[
              {
                required: true,
                message: `${
                  isUpdate ? "Vui lòng chọn bộ lọc" : "Vui lòng nhập tên bộ lọc"
                }`,
              },
            ]}
          >
            {isUpdate ? (
              <Selector
                options={localFilterOrders.map((item) => ({
                  label: item.name,
                  value: item.key,
                }))}
                placeholder="Chọn bộ lọc"
              />
            ) : (
              <Input placeholder="Nhập tên bộ lọc" />
            )}
          </Form.Item>
        </Form>
      </Modal>

      <div style={{ marginTop: 10, display: "flex" }}>
        {selectedItems.length ? (
          <div style={{ marginRight: 10 }}>
            <Dropdown overlay={menu} trigger={["click"]}>
              <Button>
                Chọn thao tác ({selectedItems.length} đơn hàng) <DownOutlined />
              </Button>
            </Dropdown>
            <Button
              onClick={() => setSelectedItems([])}
              style={{ marginLeft: 10 }}
            >
              Bỏ chọn tất cả
            </Button>
          </div>
        ) : null}
        {/* {roleUsed.includes(roleUser) ? <ExportExcelCollationAll orders={dataExportCollation} /> : null} */}
        {roleUsed.includes(roleUser) ? (
          <Button onClick={handleImportAllDataCollation}>
            Xuất file đối soát (tất cả {totalRecord} đơn)
          </Button>
        ) : null}
      </div>

      <div ref={componentRef}>
        <ComponentToPrint />
      </div>
      <div ref={componentExport}>
        <ComponentToPrintExportFile />
      </div>
    </div>
  );
}
