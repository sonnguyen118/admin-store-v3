import * as action from './action';
import {
	INCREMENT_LOADING,
	DECREMENT_LOADING,
	GET_LIST_TRANSPORT_ORDER,
	DETAIL_TRANSPORT_ORDER,
	UPDATE_TRANSPORT_ORDER,
	UPDATE_TRANSPORT_ORDER_DATA,
	RECEIPT_COD,
	LIST_LOGS,
	CREATE_LOGS,
	GET_LIST_FULFILLMENT_COMPANY,
	GET_LIST_INVENTORY,
	CONFIRM_PRINT_ITEMS,
	CACHE_DATA_EXPORT_COLLATION,
	SHIPPING_FEE_OPTION,
	SHIPPING_FEE_CALCULATE,
	CREATE_COMPENSATION_OR_REFUND_TRANSPORT,
	SEARCH_CUSTOMER,
	GET_LIST_ORDER_TAGS,
} from './action-type';

const initialState = {
	isLoading: false,
	counter: 0,
	logs: [],
};

const reducer = (state, action) => {
	switch (action.type) {
		case INCREMENT_LOADING:
			return {
				...state,
				counter: state.counter + action.payload,
			};
		case DECREMENT_LOADING:
			return {
				...state,
				counter: state.counter - action.payload < 0 ? 0 : state.counter - action.payload,
				type: null,
				actionName: null,
				message: null,
			};
		case GET_LIST_TRANSPORT_ORDER:
			return {
				...state,
				...action.payload,
			};
		case DETAIL_TRANSPORT_ORDER:
			return {
				...state,
				...action.payload,
			};
		case UPDATE_TRANSPORT_ORDER:
			return {
				...state,
				...action.payload,
			};
		case UPDATE_TRANSPORT_ORDER_DATA:
			return {
				...state,
				...action.payload,
			};
		case RECEIPT_COD:
			return {
				...state,
				...action.payload,
			};
		case LIST_LOGS:
			return {
				...state,
				...action.payload,
			};
		case CREATE_LOGS:
			return {
				...state,
				...action.payload,
			};
		case GET_LIST_FULFILLMENT_COMPANY:
			return {
				...state,
				...action.payload,
			};
		case GET_LIST_INVENTORY:
			return {
				...state,
				...action.payload,
			};
		case CONFIRM_PRINT_ITEMS:
			return {
				...state,
				...action.payload,
			};
		case CACHE_DATA_EXPORT_COLLATION:
			return {
				...state,
				...action.payload,
			};
		case CREATE_COMPENSATION_OR_REFUND_TRANSPORT:
			return {
				...state,
				...action.payload,
			};
		case SHIPPING_FEE_OPTION:
			return {
				...state,
				...action.payload,
			};
		case SHIPPING_FEE_CALCULATE:
			return {
				...state,
				...action.payload,
			};
		case SEARCH_CUSTOMER:
			return {
				...state,
				...action.payload,
			};
		case GET_LIST_ORDER_TAGS:
			return {
				...state,
				...action.payload,
			};
		default:
			return state;
	}
};

export default {
	action,
	initialState,
	reducer,
};
