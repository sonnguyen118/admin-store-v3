export const INCREMENT_LOADING = 'orders/INCREMENT_LOADING';
export const DECREMENT_LOADING = 'orders/DECREMENT_LOADING';
export const GET_LIST_TRANSPORT_ORDER = 'orders/GET_LIST_TRANSPORT_ORDER';
export const DETAIL_TRANSPORT_ORDER = 'orders/DETAIL_TRANSPORT_ORDER';
export const UPDATE_TRANSPORT_ORDER = 'orders/UPDATE_TRANSPORT_ORDER';
export const UPDATE_TRANSPORT_ORDER_DATA = 'orders/UPDATE_TRANSPORT_ORDER_DATA';
export const RECEIPT_COD = 'orders/RECEIPT_COD';
export const LIST_LOGS = 'orders/LIST_LOGS';
export const CREATE_LOGS = 'orders/CREATE_LOGS';
export const GET_LIST_FULFILLMENT_COMPANY = 'orders/GET_LIST_FULFILLMENT_COMPANY';
export const GET_LIST_INVENTORY = 'orders/GET_LIST_INVENTORY';
export const CONFIRM_PRINT_ITEMS = 'orders/CONFIRM_PRINT_ITEMS';
export const CACHE_DATA_EXPORT_COLLATION = 'orders/CACHE_DATA_EXPORT_COLLATION';
export const SHIPPING_FEE_OPTION = 'orders/SHIPPING_FEE_OPTION';
export const SHIPPING_FEE_CALCULATE = 'orders/SHIPPING_FEE_CALCULATE';
export const CREATE_COMPENSATION_OR_REFUND_TRANSPORT =
	'orders/CREATE_COMPENSATION_OR_REFUND_TRANSPORT';
export const SEARCH_CUSTOMER = 'orders/SEARCH_CUSTOMER';
export const GET_LIST_ORDER_TAGS = 'orders/GET_LIST_ORDER_TAGS';

export const IncrementLoading = {
	payload: 1,
	type: INCREMENT_LOADING,
};

export const DecrementLoading = {
	payload: 1,
	type: DECREMENT_LOADING,
};

export const setListTransportOrder = (payload) => {
	return {
		payload,
		type: GET_LIST_TRANSPORT_ORDER,
	};
};

export const setDetailTransportOrder = (payload) => {
	return {
		payload,
		type: DETAIL_TRANSPORT_ORDER,
	};
};

export const setUpdateTransportOrder = (payload) => {
	return {
		payload,
		type: UPDATE_TRANSPORT_ORDER,
	};
};

export const setUpdateTransportOrderData = (payload) => {
	return {
		payload,
		type: UPDATE_TRANSPORT_ORDER_DATA,
	};
};

export const setReceiptCod = (payload) => {
	return {
		payload,
		type: RECEIPT_COD,
	};
};

export const setListLogs = (payload) => {
	return {
		payload,
		type: LIST_LOGS,
	};
};

export const setCreateLogs = (payload) => {
	return {
		payload,
		type: CREATE_LOGS,
	};
};

export const setListFulfillmentCompany = (payload) => {
	return {
		payload,
		type: GET_LIST_FULFILLMENT_COMPANY,
	};
};

export const setListInventory = (payload) => {
	return {
		payload,
		type: GET_LIST_INVENTORY,
	};
};

export const setConfirmPrintItems = (payload) => {
	return {
		payload,
		type: CONFIRM_PRINT_ITEMS,
	};
};

export const cacheDataExportCollation = (payload) => {
	return {
		payload,
		type: CACHE_DATA_EXPORT_COLLATION,
	};
};

export const setShippingFeeOption = (payload) => {
	return {
		payload,
		type: SHIPPING_FEE_OPTION,
	};
};

export const setShippingFeeCalculate = (payload) => {
	return {
		payload,
		type: SHIPPING_FEE_CALCULATE,
	};
};

export const setCreateCompensationRefundTransport = (payload) => {
	return {
		payload,
		type: CREATE_COMPENSATION_OR_REFUND_TRANSPORT,
	};
};

export const setSearchCustomer = (payload) => {
	return {
		payload,
		type: SEARCH_CUSTOMER,
	};
};

export const setListOrderTag = (payload) => {
	return {
		payload,
		type: GET_LIST_ORDER_TAGS,
	};
};
