import {
  TransportOrders as TransportOrdersAPI,
  FullfillmentOrders as FullfillmentOrdersAPI,
  OrderTags as OrderTagsAPI,
  Users as UsersAPI,
} from "api";

import {
  IncrementLoading,
  DecrementLoading,
  setListTransportOrder,
  setDetailTransportOrder,
  setUpdateTransportOrder,
  setUpdateTransportOrderData,
  setReceiptCod,
  setListLogs,
  setCreateLogs,
  setListFulfillmentCompany,
  setListInventory,
  setConfirmPrintItems,
  cacheDataExportCollation,
  setShippingFeeCalculate,
  setCreateCompensationRefundTransport,
  setSearchCustomer,
  setListOrderTag,
} from "./action-type";

export const onGetListTransportOrder = async (params, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setListTransportOrder({
      message: null,
      isRefresh: false,
      type: null,
    })
  );
  try {
    const response = await TransportOrdersAPI.getListTransportOrder(params);
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      };
      dispatch(
        setListTransportOrder({
          transportOrders: data.data.datas,
          transportOrderMeta: meta,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListTransportOrder({
        transportOrders: [],
        transportOrderMeta: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onCacheDataExportCollation = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.getListTransportOrder(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        cacheDataExportCollation({
          cacheDataExportCollation: data.data.datas,
        })
      );
      return;
    }
  } catch (error) {
    console.log(error);
  } finally {
    dispatch(DecrementLoading);
  }
};

export const onRemoveCacheDataExportCollation = async (dispatch) => {
  dispatch(
    cacheDataExportCollation({
      cacheDataExportCollation: [],
    })
  );
};

export const getDetailTransportOrder = async (id, dispatch) => {
  dispatch(IncrementLoading);
  dispatch(
    setDetailTransportOrder({
      message: null,
      isRefresh: false,
      type: null,
    })
  );
  try {
    const response = await TransportOrdersAPI.detailTransportOrder(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setDetailTransportOrder({
          detailTransportOrder: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setDetailTransportOrder({
        detailTransportOrder: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateTransportOrder = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.updateTransportOrder(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setUpdateTransportOrder({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return setUpdateTransportOrder({
        isRefresh: false,
      });
    }
  } catch (error) {
    dispatch(
      setUpdateTransportOrder({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateTransportOrderData = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.updateTransportOrderData(
      id,
      body
    );
    const { status } = response;
    if (status === 200) {
      dispatch(
        setUpdateTransportOrderData({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setUpdateTransportOrderData({
          message: null,
          isRefresh: false,
          type: null,
        })
      );
    }
  } catch (error) {
    dispatch(
      setUpdateTransportOrderData({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getReceiptCod = async (id, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.onReceiptCod(id);
    const { data } = response;
    if (data.meta.status === 200) {
      dispatch(
        setReceiptCod({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setReceiptCod({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setReceiptCod({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getListLogs = async (id, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.getListLog(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListLogs({
          logs: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListLogs({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createLogs = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.createLog(id, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setCreateLogs({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setCreateLogs({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      setCreateLogs({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListFulfillmentCompany = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListFulfillmentCompany(
      params
    );
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListFulfillmentCompany({
          fullfillmentCompanies: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListFulfillmentCompany({
        fullfillmentCompanies: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListInventory = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.getListInventory(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListInventory({
          inventories: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListInventory({
        inventories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const confirmPrintItems = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await TransportOrdersAPI.confirmPrintItems(body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        setConfirmPrintItems({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công",
        })
      );
      dispatch(DecrementLoading);
      return dispatch(
        setConfirmPrintItems({
          message: null,
          isRefresh: false,
          type: null,
        })
      );
    }
  } catch (error) {
    dispatch(
      setConfirmPrintItems({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const calculateShippingFee = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await FullfillmentOrdersAPI.shippingFeeCalculate(body);
    const { data, status } = response;
    if (response && data.meta.success) {
      dispatch(
        setShippingFeeCalculate({
          shippingFeeCalculate: data.data,
        })
      );
      return;
    }
    return dispatch(
      setShippingFeeCalculate({
        isGetShippingFee: false,
        shippingFeeMessage: data.meta.internalMessage,
      })
    );
  } catch (error) {
    dispatch(
      setShippingFeeCalculate({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error",
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};

export const setShippingFeeToEmpty = (dispatch) => {
  return dispatch(
    setShippingFeeCalculate({
      shippingFeeCalculate: 0,
    })
  );
};

export const createCompensationRefundTransport = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response: any = await FullfillmentOrdersAPI.createOrderCompensation(
      id,
      body
    );
    const { status, data } = response;
    if (status === 200) {
      if (data.meta.status === 200) {
        dispatch(
          setCreateCompensationRefundTransport({
            type: "success",
            isRedirect: true,
            createData: data.data,
            message: "Tạo thành công!",
          })
        );
      } else {
        dispatch(
          setCreateCompensationRefundTransport({
            type: "error",
            message: data.meta.internalMessage,
          })
        );
      }
    }
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setCreateCompensationRefundTransport({
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
};

export const getSearchCustomer = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await UsersAPI.searchCustomer(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setSearchCustomer({
          searchCustomer: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setSearchCustomer({
        customer: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListOrderTag = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OrderTagsAPI.getListOrderTags(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setListOrderTag({
          orderTags: data.data,
        })
      );
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setListOrderTag({
        orderTags: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};
