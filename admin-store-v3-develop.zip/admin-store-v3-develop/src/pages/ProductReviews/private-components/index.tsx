export { default as TableProductReviews } from "./TableProductReviews";
export { default as DetailProductReviews } from "./DetailProductReviews";
