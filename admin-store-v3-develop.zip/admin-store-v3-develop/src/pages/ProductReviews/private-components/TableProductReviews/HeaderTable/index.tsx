import { Button, Popover, Rate } from "antd";
import { FilterOutlined } from "@ant-design/icons";
import { useState } from "react";

const HeaderTable = ({filter, setFilter, onChangePage }) => {
    const [filterVisible, setFilterVisible] = useState(false)
    const [rateValue, setRateValue] = useState(0)

    function handleVisibleChange(visible) {
        setFilterVisible(visible);
    };

    function onFilter() {
        setFilter((prevState) => ({
            ...prevState,
            ratingScore: rateValue,
        }));
        onChangePage(1);
        setFilterVisible(false)
    }

    function onReset() {
        delete filter.ratingScore;
        setFilter({ ...filter });
        onChangePage(1);
        setRateValue(0)
        setFilterVisible(false)
    }

    const content = (
        <div style={styles.contentWrapper}>
            <Rate value={rateValue} onChange={(value) => setRateValue(value)} />
            <div style={styles.buttonWrapper}>
                <Button onClick={() => setFilterVisible(false)} style={{ marginRight: 10 }}>
                    Huỷ
                </Button>
                <Button onClick={onFilter} type="primary" style={{ marginRight: 10 }}>
                    Xác nhận
                </Button>
                <Button onClick={onReset} type="primary">
                    Reset
                </Button>
            </div>

        </div>
    );
    return (
        <Popover
            placement="bottom"
            title={"Lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
        >
            <FilterOutlined />
        </Popover>
    )
}


export default HeaderTable;

const styles = {
    contentWrapper: {
        display: "flex",
        flexDirection: "column"
    } as React.CSSProperties,
    buttonWrapper: {
        display: "flex",
        marginTop: 15,
    } as React.CSSProperties
}