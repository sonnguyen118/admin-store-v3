import { useCallback, useMemo } from 'react';
import { Rate, Table, Typography } from 'antd';
import { orEmpty } from 'utils/Selector';
import moment from 'moment';
import HeaderTable from "./HeaderTable"

const { Text, Link } = Typography;

const TableProductReviews = ({ productReviews, productReviewsMeta, onChangePage, onDetail,filter, setFilter }) => {

    const columns = useMemo(() => {
        return [
            {
                key: "author",
                title: "Khách hàng",
                dataIndex: "author",
                width: 100,
                fixed: 'left',
                render: (value, record) => <Link onClick={(e) => onDetail(e, orEmpty("id", record))} href={`/product-reviews/${orEmpty("id", record)}`}>{orEmpty("name", value) ? orEmpty("name", value) : "Chưa xác định"}</Link>
            },
            {
                key: "content",
                title: "Nội dung",
                dataIndex: "content",
                width: 300,
                render: (value, record) => <Link onClick={(e) => onDetail(e, orEmpty("id", record))} href={`/product-reviews/${orEmpty("id", record)}`}>{value}</Link>
            },
            {
                key: "ratingScore",
                title: <div style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center" }}>Đánh giá <HeaderTable filter={filter} setFilter={setFilter} onChangePage={onChangePage} /></div>,
                dataIndex: "ratingScore",
                width: 130,
                render: (value) => <Rate disabled value={value} />,
            },
            {
                key: "createdAt",
                title: "Thời gian",
                dataIndex: "createdAt",
                width: 100,
                render: (value) => moment(value).format("DD/MM/YYYY")
            },
            {
                key: "product",
                title: "Sản phẩm",
                dataIndex: "product",
                width: 300,
                render: (value) => <Link href={`/products/update/${orEmpty("id", value)}`} target="_blank">{orEmpty("name", value)}</Link>
            },
            {
                key: "isPublished",
                title: "Trạng thái",
                dataIndex: "isPublished",
                width: 100,
                fixed: 'right',
                render: (value) => <div>{value ? <Text strong>Đã kích hoạt</Text> : <Text strong type="warning">Chưa kích hoạt</Text>}</div>,
            },
        ]
    }, [productReviews])

    const showTotal = (total) => {
        return `Tổng: ${total}`;
    }

    const renderTable = useCallback(() => {
        return (
            <Table
                //@ts-ignore
                columns={columns}
                dataSource={productReviews}
                scroll={{ x: 1500 }}
                pagination={{
                    defaultPageSize: productReviewsMeta.pageSize,
                    defaultCurrent: productReviewsMeta.page,
                    current: productReviewsMeta.page,
                    showSizeChanger: false,
                    total: productReviewsMeta.total,
                    onChange: (page) => onChangePage(page),
                    showTotal: showTotal
                }}
            />
        )
    }, [columns, productReviews, productReviewsMeta])

    return (
        <div>
            {renderTable()}
        </div>
    );
}

export default TableProductReviews
