import { Typography, Affix, Row, Col, Button, Popconfirm } from 'antd';
import { orBoolean, orEmpty } from 'utils/Selector';
const { Title } = Typography;

function Header(props): JSX.Element {
	const { item, onCancelClick, onPublishedReview, onDeleteReview } = props;

	function handleIsPublished(isPublished) {
		const params = {
			id: orEmpty("id", item),
			isPublish: isPublished
		}
		onPublishedReview(params)
	}

	function handleDeleteReview(id) {
		onDeleteReview(id)
	}

	return (
		<Affix offsetTop={0}>
			<Row style={{ padding: '0 15px' }} className="actions">
				<Col span={12}>
					<Title style={{ marginBottom: 0 }} level={4}>
						Thông tin liên hệ
					</Title>
				</Col>
				<Col
					style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}
					span={12}
					className="action-right"
				>
					<Popconfirm
						title="Bạn chắc chắn muốn xóa đánh giá này?"
						onConfirm={() => handleDeleteReview(orEmpty("id", item))}
						okText="Đồng ý"
						cancelText="Hủy"
					>
						<Button type="primary" danger style={{ marginRight: 10 }} className="btn">
							Xóa đánh giá
						</Button>
					</Popconfirm>
					{orBoolean("isPublished", item)
						?
						<Popconfirm
							title="Bạn chắc chắn muốn hủy kích hoạt đánh giá này?"
							onConfirm={() => handleIsPublished(!orBoolean("isPublished", item))}
							okText="Đồng ý"
							cancelText="Hủy"
						>
							<Button className="btn">
								Hủy kích hoạt
							</Button>
						</Popconfirm>
						:
						<Popconfirm
							title="Bạn chắc chắn muốn kích hoạt đánh giá này?"
							onConfirm={() => handleIsPublished(!orBoolean("isPublished", item))}
							okText="Đồng ý"
							cancelText="Hủy"
						>
							<Button className="btn">
								Kích hoạt
							</Button>
						</Popconfirm>
					}
					<Button onClick={onCancelClick} style={{ marginLeft: 10 }} className="btn">
						Quay lại
					</Button>
				</Col>
			</Row>
		</Affix>
	);
}

export default Header;
