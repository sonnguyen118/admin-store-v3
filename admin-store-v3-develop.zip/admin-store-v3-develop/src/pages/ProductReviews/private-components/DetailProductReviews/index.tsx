import React from 'react';
import { Space, Card, Typography, Row, Col, Avatar, Rate } from 'antd';
import Header from './Header';
import { orEmpty, orNumber } from 'utils/Selector';
import moment from 'moment';
import './styled.scss';

const { Meta } = Card
const { Link } = Typography

export default function DetailProductReviews(props) {
    const { item, onCancelClick, onPublishedReview, onDeleteReview } = props;

    const renderHeaderAction = () => {
        return <Header onCancelClick={onCancelClick} item={item} onPublishedReview={onPublishedReview} onDeleteReview={onDeleteReview} />;
    };

    const renderProductReview = () => {
        return (
            <Card title="Sản phẩm đánh giá" bordered={false}>
                <Meta
                    avatar={<Avatar src={orEmpty("product.featuredImage.url", item)} />}
                    title={<Link target='_blank' href={`/products/update/${orEmpty("product.id", item)}`}>{orEmpty("product.name", item)}</Link>}
                    description={<Rate disabled defaultValue={orNumber("ratingScore", item)} />}
                />
            </Card>
        );
    };

    const renderContentCustomerReview = () => {
        return (
            <Card title="Nội dung đánh giá" bordered={false}>
                {item.content || '---'}
            </Card>
        );
    };



    const renderInfoCustomerReview = () => {
        return (
            <Card title="Thông tin khách hàng" bordered={true}>
                <Row gutter={[30, 30]}>
                    <Col span={12}>
                        <Row gutter={[16, 16]}>
                            <Col span={8}>
                                <b>Họ và tên:</b>
                            </Col>
                            <Col span={16}>{orEmpty("author.name", item) || '---'}</Col>
                        </Row>
                        <Row gutter={[16, 16]}>
                            <Col span={8}>
                                <b>Số điện thoại:</b>
                            </Col>
                            <Col span={16}>{orEmpty("author.phone", item) || '---'}</Col>
                        </Row>
                    </Col>
                    <Col span={12}>
                        <Row gutter={[16, 16]}>
                            <Col span={8}>
                                <b>Email:</b>
                            </Col>
                            <Col span={16}>{orEmpty("author.email", item) || '---'}</Col>
                        </Row>
                        <Row gutter={[16, 16]}>
                            <Col span={8}>
                                <b>Ngày gửi:</b>
                            </Col>
                            <Col span={16}>{moment(item.createdAt).format('DD/MM/YYYY hh:mm A') || '---'}</Col>
                        </Row>
                    </Col>
                </Row>
            </Card>
        );
    };

    return (
        <div className="container-small">
            <Space style={{ width: '100%' }} direction="vertical">
                {item && (
                    <>
                        {renderHeaderAction()}
                        {renderInfoCustomerReview()}
                        {renderProductReview()}
                        {renderContentCustomerReview()}
                    </>
                )}
            </Space>
        </div>
    );
}
