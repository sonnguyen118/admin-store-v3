export const INCREMENT_LOADING = "product-reviews/INCREMENT_LOADING";
export const DECREMENT_LOADING = "product-reviews/DECREMENT_LOADING";
export const SET_LIST_PRODUCT_REVIEWS = "product-reviews/SET_LIST_PRODUCT_REVIEWS";
export const SET_DETAIL_PRODUCT_REVIEWS = "product-reviews/SET_DETAIL_PRODUCT_REVIEWS";
export const SET_IS_PUBLISHED_PRODUCT_REVIEWS = "product-reviews/SET_IS_PUBLISHED_PRODUCT_REVIEWS";
export const DELETE_PRODUCT_REVIEWS = "product-reviews/DELETE_PRODUCT_REVIEWS";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListProductReviews = payload => {
  return {
    payload,
    type: SET_LIST_PRODUCT_REVIEWS
  };
};

export const setDetailProductReviews = payload => {
  return {
    payload,
    type: SET_DETAIL_PRODUCT_REVIEWS
  };
};

export const setIsPublishedProductReviews = payload => {
  return {
    payload,
    type: SET_IS_PUBLISHED_PRODUCT_REVIEWS
  };
};

export const setDeleteProductReviews = payload => {
  return {
    payload,
    type: DELETE_PRODUCT_REVIEWS
  };
};



