import { ProductReviews as ProductReviewsAPI } from "api";
import { orArray } from "utils/Selector";
import {
    IncrementLoading,
    DecrementLoading,
    setListProductReviews,
    setDetailProductReviews,
    setIsPublishedProductReviews,
    setDeleteProductReviews
} from "./action-type";

export const getListProductReviews = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductReviewsAPI.listProductReviews(params)
        const { data, status } = response
        if (status === 200) {
            const meta = {
                page: data.data.page,
                pageSize: data.data.pageSize,
                total: data.data.total,
            }
            return dispatch(
                setListProductReviews({
                    productReviews: orArray("data.datas", data),
                    productReviewsMeta: meta
                })
            );
        }
    } catch (error) {
        setListProductReviews({
            productReviews: [],
            productReviewsMeta: null,
            message: "Đã xảy ra lỗi vui lòng quay lại sau",
            type: "error"
        })
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const detailProductReviews = async (params, dispatch) => {
    dispatch(
        setDetailProductReviews({
            type: null,
            isRefresh: false,
            message: null
        })
    )
    dispatch(IncrementLoading);
    try {
        const response = await ProductReviewsAPI.productReviewDetail(params)
        const { data, status } = response
        if (status === 200) {
            return dispatch(
                setDetailProductReviews({
                    detailProductReviews: orArray("data", data),
                })
            );
        }
    } catch (error) {
        setListProductReviews({
            detailProductReviews: null,
            message: "Đã xảy ra lỗi vui lòng quay lại sau",
            type: "error"
        })
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const isPublishedProductReviews = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductReviewsAPI.isActiveProductReview(params)
        const { status } = response
        if (status === 200) {
            dispatch(
                setIsPublishedProductReviews({
                    type: "success",
                    isRefresh: true,
                    message: "Cập nhật thành công"
                })
            )
        }
    } catch (error) {
        setIsPublishedProductReviews({
            message: "Đã xảy ra lỗi vui lòng quay lại sau",
            isRefresh: false,
            type: "error"
        })
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const deleteProductReviews = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductReviewsAPI.deleteProductReview(params)
        const { status } = response
        if (status === 200) {
            dispatch(
                setDeleteProductReviews({
                    type: "success",
                    isRedirect: true,
                    message: "Xóa đánh giá thành công"
                })
            )
        }
    } catch (error) {
        setDeleteProductReviews({
            message: "Đã xảy ra lỗi vui lòng quay lại sau",
            isRedirect: false,
            type: "error"
        })
    } finally {
        return dispatch(DecrementLoading);
    }
};