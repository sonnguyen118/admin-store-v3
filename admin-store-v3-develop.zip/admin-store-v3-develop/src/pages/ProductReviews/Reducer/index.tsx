import * as action from "./action";
import {
    INCREMENT_LOADING,
    DECREMENT_LOADING,
    SET_LIST_PRODUCT_REVIEWS,
    SET_DETAIL_PRODUCT_REVIEWS,
    SET_IS_PUBLISHED_PRODUCT_REVIEWS,
    DELETE_PRODUCT_REVIEWS
} from "./action-type";

const initialState = ({
    isLoading: false,
    counter: 0,
});

const reducer = (state, action) => {
    switch (action.type) {
        case INCREMENT_LOADING:
            return {
                ...state,
                counter: state.counter + action.payload
            };
        case DECREMENT_LOADING:
            return {
                ...state,
                counter:
                    state.counter - action.payload < 0
                        ? 0
                        : state.counter - action.payload,
                type: null,
                actionName: null,
                message: null
            };
        case SET_LIST_PRODUCT_REVIEWS:
            return {
                ...state,
                ...action.payload,
            };
        case SET_DETAIL_PRODUCT_REVIEWS:
            return {
                ...state,
                ...action.payload,
            };
        case SET_IS_PUBLISHED_PRODUCT_REVIEWS:
            return {
                ...state,
                ...action.payload,
            };
        case DELETE_PRODUCT_REVIEWS
            :
            return {
                ...state,
                ...action.payload,
            };
        default:
            return state;
    }
};

export default {
    action,
    initialState,
    reducer
};
