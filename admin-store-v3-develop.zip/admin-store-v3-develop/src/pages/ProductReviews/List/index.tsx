import { useCallback, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import queryString from "query-string";
import { TableProductReviews } from "../private-components"
import { orArray } from "utils/Selector";


const List = (props) => {
    const { dispatch, action, state, filterDefault, query, tabSelected } = props;
    const history = useHistory()

    const [filter, setFilter] = useState({
        page: query.page,
        pageSize: query.pageSize,
        ...filterDefault,
    });

    const productReviews = useMemo(() => {
        return orArray("productReviewsReducer.productReviews", state)
    }, [state.productReviewsReducer])

    const productReviewsMeta = useMemo(() => {
        return orArray("productReviewsReducer.productReviewsMeta", state)
    }, [state.productReviewsReducer])


    useMemo(() => {
        if (filter) {
            action.productReviewsReducer.getListProductReviews(
                filter,
                dispatch.productReviewsReducer
            );
        }
    }, [filter])

    useMemo(() => {
        if (query.page || query.pageSize !== filter.pageSize) {
            history.push({
                pathname: 'product-reviews',
                search: queryString.stringify({ ...query, page: query.page, type: tabSelected }),
            });
            setFilter((prevState) => {
                return {
                    ...prevState,
                    page: query.page,
                    pageSize: query.pageSize,
                };
            });
        }
    }, [query]);

    function onChangePage(page) {
        history.push({
            pathname: "product-reviews",
            search: queryString.stringify({ ...query, page, type: tabSelected })
        })
    }
    function onDetail(e, id) {
        e.preventDefault();
        history.push(`product-reviews/${id}`);
    }

    const renderTable = useCallback(() => {
        return (
            <TableProductReviews
                filter={filter}
                setFilter={setFilter}
                onDetail={onDetail}
                productReviews={productReviews}
                productReviewsMeta={productReviewsMeta}
                onChangePage={onChangePage}
            />
        )
    }, [productReviews, productReviewsMeta])


    return (
        <div>
            {renderTable()}
        </div>
    );
}

export default List
