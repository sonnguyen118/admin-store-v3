
import { withReducer } from 'hoc';
import { orEmpty, orNull } from 'utils/Selector';
import detailProductReviewsReducer from '../../../Reducer';
import { useMemo } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import { DetailProductReviews } from "../../../private-components"

function Detail(props) {
    const { action, state, dispatch } = props;
    const history = useHistory();
    const params = useParams();

    const detailProductReviews = useMemo(() => {
        return orNull("detailProductReviewsReducer.detailProductReviews", state)
    }, [state.detailProductReviewsReducer])

    const isRefresh = useMemo(() => {
        return orNull("detailProductReviewsReducer.isRefresh", state)
    }, [state.detailProductReviewsReducer])

    const isRedirect = useMemo(() => {
        return orNull("detailProductReviewsReducer.isRedirect", state)
    }, [state.detailProductReviewsReducer])

    function onSetup() {
        action.detailProductReviewsReducer.detailProductReviews(orEmpty('id', params), dispatch.detailProductReviewsReducer);
    }

    function onCancelClick() {
        history.goBack();
    }

    const onRefresh = () => {
        if (isRefresh) {
            onSetup()
        }
    }

    const onRedirect = () => {
        if (isRedirect) {
            onCancelClick()
        }
    }

    function onPublishedReview(params) {
        action.detailProductReviewsReducer.isPublishedProductReviews(
            params,
            dispatch.detailProductReviewsReducer
        );
    }

    function onDeleteReview(id) {
        action.detailProductReviewsReducer.deleteProductReviews(
            id,
            dispatch.detailProductReviewsReducer
        );
    }

    useMemo(onSetup, [orEmpty('id', params)]);
    useMemo(onRefresh, [isRefresh]);
    useMemo(onRedirect, [isRedirect]);

    return (
        <DetailProductReviews
            item={detailProductReviews}
            onCancelClick={onCancelClick}
            onPublishedReview={onPublishedReview}
            onDeleteReview={onDeleteReview}
        />
    );
}

export default withReducer({
    key: 'detailProductReviewsReducer',
    ...detailProductReviewsReducer,
})(Detail);
