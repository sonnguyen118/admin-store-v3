import { Typography, Row, Col } from "antd";
import List from "./List"
import { useCallback, useMemo } from "react";
import { EditTabs } from "components";
import { Mocks } from "utils";
import { useHistory } from 'react-router';
import queryString from 'query-string';
import productReviewsReducer from "./Reducer";
import { withReducer } from "hoc";
const { Title } = Typography;

const Collation = (props) => {
    const history = useHistory();
    const { dispatch, action, state, } = props;

    const query: any = useMemo(() => {
        const data: any = queryString.parse(history.location.search);
        return {
            page: !data.type ? 1 : data.type && data.page ? parseInt(data.page as string) : 1,
            pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15,
            type: data.type ? data.type : "all",
        }
    }, [history.location.search]);

    const tabSelected: any = useMemo(() => {
        return query.type ? query.type : "all"
    }, [query.type])


    function onChangeTab(activeKey) {
        history.push({
            pathname: "product-reviews",
            search: queryString.stringify({ ...query, page: 1, type: activeKey })
        })
    }

    const renderHeader = useCallback(() => {
        return (
            <Row>
                <Col span={8}>
                    <Title level={2}>Đánh giá sản phẩm</Title>
                </Col>
            </Row>
        )
    }, [])

    const renderBody = useCallback(() => {
        const tabs = Mocks.PRODUCT_REVIEWS.defaultFilters.map(item => ({
            title: item.name,
            closable: false,
            key: item.key,
            component: <List dispatch={dispatch} action={action} state={state} query={query} tabSelected={tabSelected} filterDefault={item.filter} />
        }))
        return <EditTabs activeKey={tabSelected} tabItems={tabs} onChangeTab={onChangeTab} />
    }, [query, tabSelected])


    return (
        <div>
            {renderHeader()}
            {renderBody()}
        </div>
    );
}
export default withReducer({
    key: "productReviewsReducer",
    ...productReviewsReducer
})(Collation)
