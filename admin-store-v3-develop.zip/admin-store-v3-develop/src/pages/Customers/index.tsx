import { Col, Input, Row, Typography } from "antd";
import { SearchOutlined, PhoneOutlined } from '@ant-design/icons';
import "./styled.scss"
import { useMemo, useState } from "react";
import env from "configs/env";
import { Helpers } from "utils";
const { Title } = Typography;


export default function Customers() {
    const [customerPhone, setCustomerPhone] = useState("")
    const [error, setError] = useState("")

    const handleChangeCustomerPhone = (e) => {
        const { value } = e.target;
        const re = /^[0-9\.\b]+$/;
        if (value === "" || re.test(value)) {
            setCustomerPhone(Helpers.formatPhone(value))
        }
    }

    useMemo(() => {
        // @ts-ignore
        if (customerPhone && customerPhone.replaceAll(" ", "")[0] != "0" || customerPhone.replaceAll(" ", "")[1] === "0") {
            setError("Vui lòng nhập đúng định dạng số điện thoại.");
            return
        }
        setError("");
    }, [customerPhone])

    const handleOnBlurPhoneInput = () => {
        if (customerPhone.length > 0 && customerPhone.length < 12) {
            setError("Số điện thoại phải đủ 10 ký tự");
            return false;
        }
        // @ts-ignore
        if (customerPhone && customerPhone.replaceAll(" ", "")[0] != "0" || customerPhone.replaceAll(" ", "")[1] === "0") {
            setError("Vui lòng nhập đúng định dạng số điện thoại.");
            return false
        }
        return true;
    }

    const onPressEnter = () => {
        if (customerPhone.length === 0) {
            setError("Số điện thoại phải đủ 10 ký tự");
            return
        }
        if (handleOnBlurPhoneInput()) {
            // @ts-ignore
            window.open(`${env.customer_dashboard}/khach-hang/thong-tin-chung/${customerPhone.replaceAll(".", "")}`, '_blank');
            setCustomerPhone("");
            setError("");
        }
    }

    return (
        <div>
            <div className="w-full text-center">
                <Title level={2}>Tìm kiếm khách hàng</Title>
            </div>
            <div className="mt-50">
                <Row>
                    <Col span={24}>
                        <div className="wrapper-input-search-customer">
                            <Input
                                value={customerPhone}
                                onChange={handleChangeCustomerPhone}
                                onBlur={handleOnBlurPhoneInput}
                                onPressEnter={onPressEnter}
                                maxLength={12}
                                className="input-search-customer"
                                placeholder={"Nhập số điện thoại khách hàng"}
                                prefix={<PhoneOutlined />}
                                suffix={<SearchOutlined onClick={onPressEnter} className="cursor-pointer" />}
                                autoFocus
                            />
                            {error ? <div className="search-customer-error">{error}</div> : null}
                        </div>
                    </Col>
                </Row>
            </div>
        </div>
    );
}
