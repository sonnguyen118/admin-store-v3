import React, { useEffect, useState } from 'react';
import { Table as SimpleTable, Typography, Tag } from "antd";
import { orEmpty, orNull, orNumber } from 'utils/Selector';
import { useHistory } from "react-router-dom";
import { CaretRightOutlined } from '@ant-design/icons';

const { Link } = Typography

export default function Table(props) {
    const { categories, meta, onChangePage, selectedItems, setSelectedItems, onDetailProductCategory } = props
    const history = useHistory();
    const [rows, setRows] = useState([]);

    const columns = [
        {
            title: "Hình ảnh",
            dataIndex: "icon",
            render: (value, record) => (
                <Link onClick={(e) => onDetailProductCategory(e, record.id)} href={`/product-categories/update/${record.id}`}>
                    <img src={orEmpty("url", value) ? orEmpty("url", value) : "https://i.stack.imgur.com/y9DpT.jpg"} style={{ objectFit: "contain", width: 64, height: 64, borderRadius: 8 }} />
                </Link>

            ),
            width: "10%",
        },
        {
            title: "Tên danh mục",
            dataIndex: "name",
            render: (value, record) => <Link onClick={(e) => onDetailProductCategory(e, record.id)} href={`/product-categories/update/${record.id}`}>{value}</Link>
        },
        {
            title: "Danh mục cha",
            dataIndex: "parentCategory",
            render: (value) => <Link onClick={(e) => onDetailProductCategory(e, orEmpty("id", value))} href={`/product-categories/update/${orEmpty("id", value)}`}>{orEmpty("name", value)}</Link>
        },
        {
            title: "Trạng thái kích hoạt",
            dataIndex: "isActive",
            render: (value) => (value ? <Tag color="#108ee9">Đã kích hoạt</Tag> : <Tag>Chưa kích hoạt</Tag>)
        }
    ];

    function onUpdateData(): void {
        if (categories) {
            const r = [] as any;

            categories.forEach((node): void => {
                r.push({
                    key: node.id,
                    ...node
                });
            });
            setRows(r);
        }
    }

    const rowSelection = {
        selectedRowKeys: selectedItems.map((item) => orEmpty("key", item)),
        onSelect: (record, selected) => {
            if (selected) {
                const r = selectedItems.slice()
                r.push(record)
                setSelectedItems(r)
                return;
            } else {
                setSelectedItems(prevState => prevState.filter(item => item.id != record.id))
            }
        },
        onSelectAll: (selected, selectedRows, changeRows) => {
            if (selected) {
                const r = selectedItems.slice()
                setSelectedItems(r.concat(selectedRows).filter(item => item))
                return
            } else {
                const r = selectedItems.slice()
                const data = []
                r.forEach(e => {
                    const result = changeRows.find(item => item.key === e.key)
                    if (!result) {
                        data.push(e)
                        return
                    }
                })
                setSelectedItems(data)
            }
        },
    };

    function showTotal(total) {
        return `Tổng: ${total}`;
    }

    useEffect(onUpdateData, [categories]);

    return (
        <SimpleTable
            rowSelection={rowSelection}
            columns={columns}
            dataSource={rows}
            pagination={{
                defaultPageSize: 15,
                defaultCurrent: orNumber("page", meta),
                current: orNumber("page", meta),
                total: orNumber("total", meta),
                onChange: onChangePage,
                showSizeChanger: false,
                showTotal: showTotal
            }} />
    );
}
