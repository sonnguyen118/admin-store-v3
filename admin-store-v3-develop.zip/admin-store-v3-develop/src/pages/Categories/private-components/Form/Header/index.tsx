import React, { useState } from 'react';
import {
    Typography,
    Affix,
    Row,
    Col,
    Button,
    Form as FormBase,
    Popconfirm
} from "antd";
import { orBoolean, orEmpty } from 'utils/Selector';
const { Title } = Typography;
const { Item } = FormBase;

function Header(props): JSX.Element {
    const {
        item,
        onCancelClick,
        onClickActive
    } = props
    const [isShow, setIsShow] = useState(false);

    function onChangeAffix(affixed) {
        setIsShow(affixed);
    }

    return (
        <Affix offsetTop={0} onChange={onChangeAffix}>
            <Row style={{ padding: "0 15px" }} className="actions">
                <Col span={8}>
                    {isShow
                        ?
                        <Title style={{ marginBottom: 0 }} level={3}>{item ? "Cập nhật danh mục" : "Tạo mới chưa được lưu"} </Title>
                        :
                        <Title style={{ marginBottom: 0 }} level={3}>{item ? "Cập nhật danh mục" : "Tạo mới danh mục"}</Title>
                    }
                </Col>
                <Col style={{ display: "flex", alignItems: "center", justifyContent: "flex-end" }} span={8} offset={8} className="action-right">
                    {item
                        ?
                        <Popconfirm placement="bottom" title={orBoolean("isActive", item) ? "Bạn chắc chắn muốn hủy kích Hoạt" : "Bạn chắc chắn muốn kích hoạt"} onConfirm={() => onClickActive(!orBoolean("isActive", item))} okText="Xác nhận" cancelText="Hủy">
                            <Button
                                className="btn"
                                type="primary"
                            >
                                {orBoolean("isActive", item) ? "Hủy kích Hoạt" : "Kích hoạt"}
                            </Button>
                        </Popconfirm>
                        :
                        null}
                    <Button onClick={onCancelClick} style={{ marginLeft: 10 }} className="btn">
                        Hủy
                    </Button>
                    <Item style={{ display: "flex", alignItems: "center", marginBottom: 0, marginLeft: 10 }}>
                        <Button
                            htmlType="submit"
                            className="btn"
                            type="primary"
                        >
                            Lưu
                        </Button>
                    </Item>
                </Col>
            </Row>
        </Affix>
    );
};

export default Header;