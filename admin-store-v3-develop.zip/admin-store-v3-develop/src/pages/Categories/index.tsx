import React, { useState } from "react";
import { SimpleTabs } from "../../components";
import { Typography, Row, Col, Button } from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List"
import { useHistory } from "react-router-dom";

const { Title } = Typography;

export default function Categories() {
  const history = useHistory()
  const tabItems = [
    {
      title: "Tất cả danh mục",
      component: <List/>
    }
  ];

  function onCreateCategory() {
    history.push("/product-categories/create");
  }

  return (
    <div>
      <Row>
        <Col span={8}>
          <Title level={2}>Quản lý danh mục</Title>
        </Col>
        <Col span={8} offset={8}>
          <Row>
            <Col span={10} offset={14}>
              <Button onClick={onCreateCategory} type="primary" icon={<PlusCircleOutlined />}>
                Tạo danh mục
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
      <SimpleTabs tabItems={tabItems} />
    </div>
  );
}
