import { ProductCategories as ProductCategoriesAPI } from "api";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import {
    IncrementLoading,
    DecrementLoading,
    setListCategories,
    setCheckSlug,
    setCreateCategory,
    setDetailCategory,
    setUpdateCategory,
    setUpdateStatusCategories,
    setUpdateIsActiveCategory
} from "./action-type";

export const getListCategories = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductCategoriesAPI.getListProductCategories(params);
        const { data, status } = response;
        if (status === 200) {
            const meta = {
                page: data.data.page,
                pageSize: data.data.pageSize,
                total: data.data.total,
            };
            const listCategories = orArray("data.datas", data);
            return dispatch(
                setListCategories({
                    categories: listCategories,
                    categoriesMeta: meta,
                })
            );
        }
    } catch (error) {
        return dispatch(
            setListCategories({
                categories: [],
                categoriesMeta: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const slugCheck = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductCategoriesAPI.slugCheck(params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setCheckSlug({
                    statusSlug: orBoolean("data.status", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setCheckSlug({
                statusSlug: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const createCategory = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductCategoriesAPI.createCategory(params);
        if (response) {
            switch (orNumber("data.meta.status", response)) {
                case 3000:
                    return dispatch(
                        setCreateCategory({
                            type: "warning",
                            message: orEmpty("data.meta.internalMessage", response),
                        })
                    )
                default:
                    return dispatch(
                        setCreateCategory({
                            type: "success",
                            isRedirect: true,
                            message: "Tạo mới thành công"
                        })
                    )
            }
        }
    } catch (error) {
        return dispatch(
            setCreateCategory({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const detailCategory = async (id, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductCategoriesAPI.detailCategory(id);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setDetailCategory({
                    detailCategory: data.data
                })
            )
        }
    } catch (error) {
        return dispatch(
            setDetailCategory({
                detailCategory: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const updateCategory = async (id, params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductCategoriesAPI.updateCategory(id, params);
        const { data } = response;
        if (response) {
            switch (orNumber("data.meta.status", response)) {
                case 3000:
                    return dispatch(
                        setCreateCategory({
                            type: "warning",
                            message: orEmpty("data.meta.internalMessage", response),
                        })
                    )
                default:
                    return dispatch(
                        setUpdateCategory({
                            type: "success",
                            message: "Cập nhật thành công",
                            updateCategory: orNull("data", data)
                        })
                    )
            }
        }
    } catch (error) {
        return dispatch(
            setUpdateCategory({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const setSlugStatus = async (dispatch) => {
    return dispatch(
        setCheckSlug({
            statusSlug: null
        })
    )
};

export const updateStatusCategories = async (params, dispatch) => {
    dispatch(IncrementLoading);
    let isSuccess = false;
    try {
        const response = await ProductCategoriesAPI.updateStatusCategories(params);
        const { status } = response;
        if (status === 200) {
            isSuccess = true
            return dispatch(
                setUpdateStatusCategories({
                    isRefresh: true,
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateStatusCategories({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        dispatch(
            setUpdateStatusCategories({
                isRefresh: false,
                message: isSuccess && "Cập nhật thành công",
                type: isSuccess && "success",
            })
        )
        return dispatch(DecrementLoading);
    }
};

export const updateIsActiveCategory = async (id, params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductCategoriesAPI.updatIsActiveCategory(id, params);
        const { status, data } = response;
        if (status === 200) {
            return dispatch(
                setUpdateIsActiveCategory({
                    message: "Cập nhật thành công",
                    type: "success",
                    isActive: orBoolean("data.isActive", data),
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateStatusCategories({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};