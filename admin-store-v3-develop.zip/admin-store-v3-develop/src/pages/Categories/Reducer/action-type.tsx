export const INCREMENT_LOADING = "categories/INCREMENT_LOADING";
export const DECREMENT_LOADING = "categories/DECREMENT_LOADING";
export const LIST_CATEGORIES = "categories/LIST_CATEGORIES";
export const SLUG_CHECK = "categories/SLUG_CHECK";
export const CREATE_CATEGORY = "categories/CREATE_CATEGORY";
export const DETAIL_CATEGORY = "categories/DETAIL_CATEGORY";
export const UPDATE_CATEGORY = "categories/UPDATE_CATEGORY";
export const UPDATE_STATUS_CATEGORIES = "categories/UPDATE_STATUS_CATEGORIES";
export const UPDATE_ISACTIVE_CATEGORY = "categories/UPDATE_ISACTIVE_CATEGORY";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListCategories = payload => {
  return {
    payload,
    type: LIST_CATEGORIES
  };
};

export const setCheckSlug = payload => {
  return {
    payload,
    type: SLUG_CHECK
  };
};

export const setCreateCategory = payload => {
  return {
    payload,
    type: CREATE_CATEGORY
  };
};

export const setDetailCategory = payload => {
  return {
    payload,
    type: DETAIL_CATEGORY
  };
};

export const setUpdateCategory = payload => {
  return {
    payload,
    type: UPDATE_CATEGORY
  };
};

export const setUpdateStatusCategories = payload => {
  return {
    payload,
    type: UPDATE_STATUS_CATEGORIES
  };
};

export const setUpdateIsActiveCategory = payload => {
  return {
    payload,
    type: UPDATE_ISACTIVE_CATEGORY
  };
};



