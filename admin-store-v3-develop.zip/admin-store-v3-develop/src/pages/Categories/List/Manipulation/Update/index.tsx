import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orArray, orBoolean, orEmpty, orNull } from "utils/Selector";
import updateCategoryReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory, useParams } from "react-router-dom";

function Update(props) {
    const { action, state, dispatch } = props
    const history = useHistory();
    const params = useParams()

    function onSetup() {
        action.updateCategoryReducer.detailCategory(
            orEmpty('id', params),
            dispatch.updateCategoryReducer
        );
    }

    function onCancelClick() {
        history.push("/product-categories");
    }

    function onGetListCategories() {
        action.updateCategoryReducer.getListCategories(
          { isFull: true },
          dispatch.updateCategoryReducer
        );
      }

    function onSave(body) {
        const { id, ...ortherParams } = body
        action.updateCategoryReducer.updateCategory(
            id,
            ortherParams,
            dispatch.updateCategoryReducer
        );
    }

    const onRedirect = () => {
        if (orBoolean('updateCategoryReducer.isRedirect', state)) {
            onCancelClick()
        }
    }

    const onUpdateIsActive = (body) =>{
        const { id, ...ortherParams } = body
        action.updateCategoryReducer.updateIsActiveCategory(
            id,
            ortherParams,
            dispatch.updateCategoryReducer
        );
    }

    useMemo(onRedirect, [orBoolean('updateCategoryReducer.isRedirect', state)])
    useMemo(onSetup, [orEmpty('id', params)])
    useMemo(onGetListCategories, [])

    return <Form
        item={orNull("updateCategoryReducer.detailCategory", state)}
        parentCategories={orArray("updateCategoryReducer.categories", state).filter(item => item.isParent)}
        onSave={onSave}
        onCancelClick={onCancelClick}
        onUpdateIsActive={onUpdateIsActive}
    />;
}

export default withReducer({
    key: "updateCategoryReducer",
    ...updateCategoryReducer
})(Update);
