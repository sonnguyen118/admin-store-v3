import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orArray, orBoolean, orNull } from "utils/Selector";
import createCategoryReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory } from "react-router-dom";

function Create(props) {
  const { action, state, dispatch } = props
  const history = useHistory();

  function onCancelClick() {
    history.push("/product-categories");
  }

  function onSearchSlug(slug) {
    action.createCategoryReducer.slugCheck(
      { s: slug },
      dispatch.createCategoryReducer
    );
  }

  function onGetListCategories() {
    action.createCategoryReducer.getListCategories(
      { isFull: true },
      dispatch.createCategoryReducer
    );
  }

  function onSave(body) {
    action.createCategoryReducer.createCategory(
      body,
      dispatch.createCategoryReducer
    );
  }

  function setSlugStatusToNull() {
    action.createCategoryReducer.setSlugStatus(
      dispatch.createCategoryReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean('createCategoryReducer.isRedirect', state)) {
      onCancelClick()
    }
  }

  useMemo(onRedirect, [orBoolean('createCategoryReducer.isRedirect', state)])
  useMemo(onGetListCategories, [])

  return <Form
    onSearchSlug={onSearchSlug}
    statusSlug={orNull("createCategoryReducer.statusSlug", state)}
    parentCategories={orArray("createCategoryReducer.categories", state).filter(item => item.isParent)}
    onSave={onSave}
    onCancelClick={onCancelClick}
    setSlugStatusToNull={setSlugStatusToNull}
  />;
}

export default withReducer({
  key: "createCategoryReducer",
  ...createCategoryReducer
})(Create);
