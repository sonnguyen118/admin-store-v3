import React, { useCallback, useMemo } from 'react';
import { useHistory } from 'react-router';
import { EditTabs } from '../../components';
import { Typography } from 'antd';
import List from './List';
import queryString from 'query-string';
import { Mocks } from 'utils';
import contactsReducer from './Reducer';
import { withReducer } from 'hoc';

const { Title } = Typography;

function CustomerContact(props) {
	const history = useHistory();
	const { dispatch, action, state, } = props;

	const query: any = useMemo(() => {
		const data: any = queryString.parse(history.location.search);
		return {
			page: !data.type ? 1 : data.type && data.page ? parseInt(data.page as string) : 1,
			pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15,
			type: data.type ? data.type : "all",
		}
	}, [history.location.search]);

	const tabSelected: any = useMemo(() => {
		return query.type ? query.type : "all"
	}, [query.type])


	function onChangeTab(activeKey) {
		history.push({
			pathname: "customer-contacts",
			search: queryString.stringify({ ...query, page: 1, type: activeKey })
		})
	}

	const getTabItems = useCallback(() => {
		const tabs = Mocks.CONTACTS.defaultFilters.map(item => ({
			title: item.name,
			closable: false,
			key: item.key,
			component: <List dispatch={dispatch} action={action} state={state} query={query} tabSelected={tabSelected} filterDefault={item.filter} />
		}))
		return <EditTabs activeKey={tabSelected} tabItems={tabs} onChangeTab={onChangeTab} />
	}, [query, tabSelected])

	return (
		<div>
			<Title level={2}>Khách hàng liên hệ</Title>
			{getTabItems()}
		</div>
	);
}


export default withReducer({
	key: 'contactsReducer',
	...contactsReducer,
})(CustomerContact)
