import React, { useEffect, useState } from 'react';
import { Table, Typography, Tag } from 'antd';
import { orEmpty, orNumber } from 'utils/Selector';
import moment from 'moment';

const { Text, Link } = Typography;

export default function TableList(props) {
	const { contacts, meta, onChangePage, selectedItems, setSelectedItems, onDetailContact } = props;
	const [rows, setRows] = useState([]);

	const columns = [
		{
			title: 'Tên khách hàng',
			dataIndex: 'name',
			ellipsis: true,
			render: (value, record) => (
				<Link
					onClick={(e) => onDetailContact(e, record._id)}
					href={`/customer-contacts/update/${record._id}`}
					style={{ display: 'flex', flexDirection: 'column' }}
				>
					<Text className={"cursor-pointer hover-blue"}>{value || '---'}</Text>
				</Link>
			),
		},
		{
			title: 'Số điện thoại',
			dataIndex: 'phone',
			ellipsis: true,
			render: (value, record) => (
				<Link
					onClick={(e) => onDetailContact(e, record._id)}
					href={`/customer-contacts/update/${record._id}`}
					style={{ display: 'flex', flexDirection: 'column' }}
				>
					<Text className={"cursor-pointer hover-blue"}>{value || '---'}</Text>
				</Link>
			),
		},
		{
			title: 'Email',
			dataIndex: 'email',
			ellipsis: true,
		},
		{
			title: 'Nội dung liên hệ',
			dataIndex: 'message',
			ellipsis: true,
		},
		{
			title: 'Ngày gửi liên hệ',
			dataIndex: 'createdAt',
			render: (value, record) => (
				<Link
					onClick={(e) => onDetailContact(e, record._id)}
					href={`/customer-contacts/update/${record._id}`}
					style={{ display: 'flex', flexDirection: 'column' }}
				>
					<Text className={"cursor-pointer hover-blue"}>{value ? moment(value).format('DD/MM/YYYY') : '---'}<br/>{value ? moment(value).format('LT') : ''}</Text>
				</Link>
			),
		},
		{
			title: 'Trạng thái',
			dataIndex: 'isProcessed',
			render: (value, record) => (
				<Link
					onClick={(e) => onDetailContact(e, record._id)}
					href={`/customer-contacts/update/${record.id}`}
					style={{ display: 'flex', flexDirection: 'column' }}
				>
					<Text className={"cursor-pointer hover-blue"} type={value ? null : 'danger'}>
						<strong> {value ? 'Đã xử lý' : 'Chưa xử lý'}</strong>{' '}
					</Text>
				</Link>
			),
		},
	];

	function onUpdateData(): void {
		if (contacts) {
			const r = [] as any;

			contacts.forEach((node): void => {
				r.push({
					key: node._id,
					...node,
				});
			});
			setRows(r);
		}
	}

	const rowSelection = {
		selectedRowKeys: selectedItems.map((item) => orEmpty('key', item)),
		onSelect: (record, selected) => {
			if (selected) {
				const r = selectedItems.slice();
				r.push(record);
				setSelectedItems(r);
				return;
			} else {
				setSelectedItems((prevState) => prevState.filter((item) => item._id != record._id));
			}
		},
		onSelectAll: (selected, selectedRows, changeRows) => {
			if (selected) {
				const r = selectedItems.slice();
				setSelectedItems(r.concat(selectedRows).filter((item) => item));
				return;
			} else {
				const r = selectedItems.slice();
				const data = [];
				r.forEach((e) => {
					const result = changeRows.find((item) => item.key === e.key);
					if (!result) {
						data.push(e);
						return;
					}
				});
				setSelectedItems(data);
			}
		},
	};

	function showTotal(total) {
		return `Tổng: ${total}`;
	}

	useEffect(onUpdateData, [contacts]);

	return (
		<Table
			rowSelection={rowSelection}
			columns={columns}
			dataSource={rows}
			pagination={{
				defaultPageSize: 15,
				defaultCurrent: orNumber('page', meta),
				current: orNumber('page', meta),
				total: orNumber('total', meta),
				onChange: onChangePage,
				showSizeChanger: false,
				showTotal: showTotal,
			}}
		/>
	);
}
