export { default as Detail } from "./Detail";
export { default as Table } from "./Table";