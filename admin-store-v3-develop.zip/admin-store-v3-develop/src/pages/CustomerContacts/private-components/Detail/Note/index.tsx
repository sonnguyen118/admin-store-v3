import {
    Button,
    Card,
    Form,
    Input,
} from "antd";
import { useEffect } from "react";
import { orEmpty, orNull } from "utils/Selector";

const { Item } = Form;

export default function AdminNote(props) {
    const { item, handleUpdateNoteAdmin } = props
    const [form] = Form.useForm();

    function onFinish(values) {
        if (item) {
			const body = {
				id: orNull('_id', item),
				query: 'note',
				note: values.adminNote.trim(),
			};
			handleUpdateNoteAdmin(body);
		}
    }

    function onSetupForm() {
        if (item) {
            form.setFieldsValue({
                adminNote: item.adminNote,
            });
            return
        }
    }

    function checkStatus() {
        return orEmpty("status", item) === "CANCELLED"
    }

    useEffect(() => {
        onSetupForm()
    }, [item])



    return (
        <Card title="Ghi chú xử lý liên hệ">
            <Form
                layout="vertical"
                form={form}
                onFinish={onFinish}
            >
                <Item
                    name="adminNote"
                    required
                    rules={[{ required: true, message: 'Vui lòng thêm ghi chú cho xử lý liên hệ' }]}
                >
                    <Input.TextArea rows={4} placeholder="Thêm ghi chú cho xử lý liên hệ" />
                </Item>
                <Item className="" style={{textAlign: 'right'}}>
                    <Button disabled={checkStatus()} htmlType="submit">Lưu ghi chú</Button>
                </Item>
            </Form>
        </Card>
    );
}
