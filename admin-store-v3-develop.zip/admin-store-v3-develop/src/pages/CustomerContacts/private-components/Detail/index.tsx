import React from 'react';
import { Space, Card, Typography, Row, Col, Timeline } from 'antd';
import Header from './Header';
import { orNull } from 'utils/Selector';
import './styled.scss';
import Note from './Note';
import moment from 'moment';

export default function Form(props) {
	const { item, onSave, onCancelClick } = props;

	function onClickProcessed(isProcessed) {
		if (item) {
			const body = {
				id: orNull('_id', item),
				query: 'change-process',
				isProcessed: isProcessed,
			};
			onSave(body);
		}
	}

	const renderHeaderAction = () => {
		return <Header onCancelClick={onCancelClick} item={item} onClickProcessed={onClickProcessed} />;
	};

	const renderHistoryUpdate = () => {
		return item.userProcessed ? (
			<Col span={24}>
				<Card title="Lịch sử" bordered={false}>
					<Timeline>
						<Timeline.Item>
							<div style={{ display: 'flex' }}>
								<div>{item.userProcessed.name} Cập nhật trạng thái đã xử lý</div>
								<div style={{ marginLeft: 'auto' }}>
									{moment(item.updatedAt).format('DD/MM/YYYY hh:mm a')}
								</div>
							</div>
						</Timeline.Item>
					</Timeline>
				</Card>
			</Col>
		) : null;
	};
	const renderContentCustomerContact = () => {
		return (
			<Card title="Nội dung liên hệ" bordered={false}>
				{item.message || '---'}
			</Card>
		);
	};

	const renderInfoCustomerContact = () => {
		return (
			<Card title="Thông tin khách hàng" bordered={true}>
				<Row gutter={[30, 30]}>
					<Col span={12}>
						<Row gutter={[16, 16]}>
							<Col span={8}>
								<b>Họ và tên:</b>
							</Col>
							<Col span={16}>{item.name || '---'}</Col>
						</Row>
						<Row gutter={[16, 16]}>
							<Col span={8}>
								<b>Số điện thoại:</b>
							</Col>
							<Col span={16}>{item.phone || '---'}</Col>
						</Row>
					</Col>
					<Col span={12}>
						<Row gutter={[16, 16]}>
							<Col span={8}>
								<b>Email:</b>
							</Col>
							<Col span={16}>{item.email || '---'}</Col>
						</Row>
						<Row gutter={[16, 16]}>
							<Col span={8}>
								<b>Ngày gửi:</b>
							</Col>
							<Col span={16}>{moment(item.createdAt).format('DD/MM/YYYY hh:mm A') || '---'}</Col>
						</Row>
					</Col>
				</Row>
			</Card>
		);
	};

	return (
		<div className="container-small">
			<Space style={{ width: '100%' }} direction="vertical">
				{item && (
					<>
						{renderHeaderAction()}
						{renderInfoCustomerContact()}
						{renderContentCustomerContact()}
						<Note item={item} handleUpdateNoteAdmin={onSave}/>
						{renderHistoryUpdate()}
					</>
				)}
			</Space>
		</div>
	);
}
