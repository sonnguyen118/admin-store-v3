import React, { useState } from 'react';
import { Typography, Affix, Row, Col, Button, Popconfirm } from 'antd';
import { CheckCircleTwoTone } from '@ant-design/icons';
import { orBoolean } from 'utils/Selector';
const { Title, Text } = Typography;

function Header(props): JSX.Element {
	const { item, onClickProcessed, onCancelClick } = props;

	return (
		<Affix offsetTop={0}>
			<Row style={{ padding: '0 15px' }} className="actions">
				<Col span={12}>
					{' '}
					<Title style={{ marginBottom: 0 }} level={4}>
						Thông tin liên hệ
					</Title>
				</Col>
				<Col
					style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end' }}
					span={12}
					className="action-right"
				>
					{item ? (
						!orBoolean('isProcessed', item) ? (
							<Popconfirm
								placement="bottom"
								title={'Bạn chắc chắn muốn cập nhật trạng thái là Đã xử lý?'}
								onConfirm={() => onClickProcessed(!orBoolean('isProcessed', item))}
								okText="Xác nhận"
								cancelText="Hủy"
							>
								<Button className="btn" type="primary">
									Xác nhận xử lý
								</Button>
							</Popconfirm>
						) : (
							<Title style={{ marginBottom: 0 }} level={5}>
								<CheckCircleTwoTone style={{ marginRight: '10px' }} />
								Đã xử lý
							</Title>
						)
					) : null}
					<Button onClick={onCancelClick} style={{ marginLeft: 10 }} className="btn">
						Quay lại
					</Button>
				</Col>
			</Row>
		</Affix>
	);
}

export default Header;
