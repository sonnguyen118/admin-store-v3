import { Detail } from "../../../private-components";
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull } from "utils/Selector";
import updateContactReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory, useParams } from "react-router-dom";

function Update(props) {
  const { action, state, dispatch } = props;
  const history = useHistory();
  const params = useParams();

  function onSetup() {
    action.updateContactReducer.detailContact(
      orEmpty("id", params),
      dispatch.updateContactReducer
    );
  }

  function onCancelClick() {
    history.goBack();
  }

  function onSave(body) {
    action.updateContactReducer.updateContact(
      body,
      dispatch.updateContactReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean("updateContactReducer.isRedirect", state)) {
      onCancelClick();
    }
  };

  useMemo(onRedirect, [orBoolean("updateContactReducer.isRedirect", state)]);
  useMemo(onSetup, [orEmpty("id", params)]);

  return (
    <Detail
      item={orNull("updateContactReducer.detailContact", state)}
      onSave={onSave}
      onCancelClick={onCancelClick}
    />
  );
}

export default withReducer({
  key: "updateContactReducer",
  ...updateContactReducer,
})(Update);
