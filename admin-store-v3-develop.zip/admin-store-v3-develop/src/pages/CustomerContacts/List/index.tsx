import React, { useState, useMemo, useEffect } from 'react';
import Search from '../Search';
import contactsReducer from '../Reducer';
import { withReducer } from 'hoc';
import queryString from 'query-string';
import { useHistory } from 'react-router-dom';
import { Table } from '../private-components';
import { orArray, orBoolean, orNull } from 'utils/Selector';

function List(props) {
	const { dispatch, action, state, filterDefault, query, tabSelected } = props;
	const history = useHistory();

	const [selectedItems, setSelectedItems] = useState([]);

	const [filter, setFilter] = useState({
		page: query.page,
		pageSize: query.pageSize,
		...filterDefault,
	});

	function onGetListContacts() {
		action.contactsReducer.getListContacts(filter, dispatch.contactsReducer);
	}

	function onUpdateStatusContacts(params) {
		action.contactsReducer.updateStatusContacts(params, dispatch.contactsReducer);
	}

	function onSubmit() {
		const params = {
			payloads: selectedItems.map((item) => item._id),
		};
		onUpdateStatusContacts({ ...params, key: 'isProcessed', value: true });
	}

	function onDetailContact(e, id) {
		e.preventDefault();
		history.push(`customer-contacts/update/${id}`);
	}

	useEffect(() => {
		if (query.page || query.pageSize !== filter.pageSize) {
			history.push({
				pathname: 'customer-contacts',
				search: queryString.stringify({ ...query, page: query.page, type: tabSelected }),
			});
			setFilter((prevState) => {
				return {
					...prevState,
					page: query.page,
					pageSize: query.pageSize,
				};
			});
		}
	}, [query]);

	function onChangePage(page) {
		history.push({
			pathname: 'customer-contacts',
			search: queryString.stringify({ ...query, page, type: tabSelected }),
		});
	}

	useMemo(() => {
		onGetListContacts();
	}, [filter]);

	useMemo(() => {
		if (orBoolean('contactsReducer.isRefresh', state)) {
			onGetListContacts();
		}
	}, [orBoolean('contactsReducer.isRefresh', state)]);

	return (
		<div>
			<Search
				filter={filter}
				setFilter={setFilter}
				onChangePage={onChangePage}
				selectedItems={selectedItems}
				onSubmit={onSubmit}
			/>
			<Table
				contacts={orArray('contactsReducer.contacts', state)}
				meta={orNull('contactsReducer.contactsMeta', state)}
				onChangePage={onChangePage}
				selectedItems={selectedItems}
				setSelectedItems={setSelectedItems}
				onDetailContact={onDetailContact}
				onSubmit={onSubmit}
			/>
		</div>
	);
}

export default List;
