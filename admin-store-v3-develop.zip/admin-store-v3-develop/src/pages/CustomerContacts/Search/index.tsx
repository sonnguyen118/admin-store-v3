import React, { useState, useMemo } from 'react';
import { Input, Button, Popconfirm } from 'antd';
import useDebounce from 'hook/useDebounce';
import './styled.scss';

export default function Filter(props) {
	const { setFilter, filter, onChangePage, selectedItems, onSubmit } = props;
	const [searchValue, setSearchValue] = useState('');

	const inputDebounce = useDebounce(searchValue, 300);

	const onChangeSearchValue = (e) => {
		setSearchValue(e.target.value);
	};

	useMemo(() => {
		if (inputDebounce) {
			setFilter((prevState) => ({
				...prevState,
				s: searchValue,
			}));
			onChangePage(1);
			return;
		}
	}, [inputDebounce]);

	useMemo(() => {
		if (searchValue === '' && filter.s) {
			delete filter.s;
			setFilter({ ...filter });
			onChangePage(1);
		}
	}, [searchValue, filter]);

	return (
		<div className="search-wrapper">
			<Input
				value={searchValue}
				onChange={onChangeSearchValue}
				allowClear
				placeholder={'Tìm kiếm theo tên KH, SĐT, email, ... '}
			/>
			{selectedItems.length ? (
				<div style={{ marginTop: 10 }}>
					<Popconfirm
						placement="bottom"
						title={'Bạn xác nhận thay đổi trạng thái những liên hệ đã chọn là Đã xử lý!'}
						onConfirm={onSubmit}
						okText="Xác nhận"
						cancelText="Hủy"
					>
						<Button key="submit">
							Cập nhật trạng thái xử lý ({selectedItems.length} Liên Hệ)
						</Button>
					</Popconfirm>
				</div>
			) : null}
		</div>
	);
}
