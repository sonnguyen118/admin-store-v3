import { ContactsApi } from 'api';
import { orArray, orNull } from 'utils/Selector';
import {
	IncrementLoading,
	DecrementLoading,
	setListContacts,
	setDetailContact,
	setUpdateContact,
	setUpdateStatusContacts,
} from './action-type';

export const getListContacts = async (params, dispatch) => {
	dispatch(IncrementLoading);
	try {
		const response = await ContactsApi.getListContacts(params);
		const { data, status } = response;
		if (status === 200) {
			const meta = {
				page: data.data.page,
				pageSize: data.data.pageSize,
				total: data.data.total,
			};
			const listContacts = orArray('data.datas', data);
			return dispatch(
				setListContacts({
					contacts: listContacts,
					contactsMeta: meta,
				})
			);
		}
	} catch (error) {
		return dispatch(
			setListContacts({
				contacts: [],
				contactsMeta: null,
				message: 'Đã xảy ra lỗi vui lòng quay lại sau',
				type: 'error',
			})
		);
	} finally {
		return dispatch(DecrementLoading);
	}
};

export const detailContact = async (id, dispatch) => {
	dispatch(IncrementLoading);
	try {
		const response = await ContactsApi.detailContact(id);
		const { data, status } = response;
		if (status === 200) {
			return dispatch(
				setDetailContact({
					detailContact: data.data,
				})
			);
		}
	} catch (error) {
		return dispatch(
			setDetailContact({
				detailContact: null,
				message: 'Đã xảy ra lỗi vui lòng quay lại sau',
				type: 'error',
			})
		);
	} finally {
		return dispatch(DecrementLoading);
	}
};

export const updateContact = async (params, dispatch) => {
	dispatch(IncrementLoading);
	try {
		const response = await ContactsApi.updateContact(params);
		const { data, status } = response;
		if (status === 200) {
			return dispatch(
				setUpdateContact({
					type: 'success',
					message: 'Cập nhật thành công',
					updateContact: orNull('data', data),
				})
			);
		}
	} catch (error) {
		return dispatch(
			setUpdateContact({
				message: 'Đã xảy ra lỗi vui lòng quay lại sau',
				type: 'error',
			})
		);
	} finally {
		return dispatch(DecrementLoading);
	}
};

export const updateStatusContacts = async (params, dispatch) => {
	dispatch(IncrementLoading);
	let isSuccess = false;
	try {
		const response = await ContactsApi.updateStatusContacts(params);
		const { status } = response;
		if (status === 200) {
			isSuccess = true;
			return dispatch(
				setUpdateStatusContacts({
					isRefresh: true,
				})
			);
		}
	} catch (error) {
		return dispatch(
			setUpdateStatusContacts({
				message: 'Đã xảy ra lỗi vui lòng quay lại sau',
				type: 'error',
			})
		);
	} finally {
		dispatch(
			setUpdateStatusContacts({
				isRefresh: false,
				message: isSuccess && 'Cập nhật thành công',
				type: isSuccess && 'success',
			})
		);
		return dispatch(DecrementLoading);
	}
};
