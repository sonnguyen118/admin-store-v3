export const INCREMENT_LOADING = 'contacts/INCREMENT_LOADING';
export const DECREMENT_LOADING = 'contacts/DECREMENT_LOADING';
export const LIST_CONTACTS = 'contacts/LIST_CONTACTS';
export const DETAIL_CONTACT = 'contacts/DETAIL_CONTACT';
export const UPDATE_CONTACT = 'contacts/UPDATE_CONTACT';
export const UPDATE_STATUS_CONTACTS = 'contacts/UPDATE_STATUS_CONTACTS';

export const IncrementLoading = {
	payload: 1,
	type: INCREMENT_LOADING,
};

export const DecrementLoading = {
	payload: 1,
	type: DECREMENT_LOADING,
};

export const setListContacts = (payload) => {
	return {
		payload,
		type: LIST_CONTACTS,
	};
};

export const setDetailContact = (payload) => {
	return {
		payload,
		type: DETAIL_CONTACT,
	};
};

export const setUpdateContact = (payload) => {
	return {
		payload,
		type: UPDATE_CONTACT,
	};
};

export const setUpdateStatusContacts = (payload) => {
	return {
		payload,
		type: UPDATE_STATUS_CONTACTS,
	};
};
