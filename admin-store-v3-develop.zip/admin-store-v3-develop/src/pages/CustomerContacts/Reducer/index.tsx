import * as action from './action';
import {
	INCREMENT_LOADING,
	DECREMENT_LOADING,
	LIST_CONTACTS,
	DETAIL_CONTACT,
	UPDATE_CONTACT,
	UPDATE_STATUS_CONTACTS,
} from './action-type';

const initialState = {
	isLoading: false,
	counter: 0,
};

const reducer = (state, action) => {
	switch (action.type) {
		case INCREMENT_LOADING:
			return {
				...state,
				counter: state.counter + action.payload,
			};
		case DECREMENT_LOADING:
			return {
				...state,
				counter: state.counter - action.payload < 0 ? 0 : state.counter - action.payload,
				type: null,
				actionName: null,
				message: null,
			};
		case LIST_CONTACTS:
			return {
				...state,
				...action.payload,
			};
		case DETAIL_CONTACT:
			return {
				...state,
				...action.payload,
			};
		case UPDATE_CONTACT:
			const { updateContact } = action.payload;
			delete action.payload.detailContact;
			return {
				...state,
				...action.payload,
				detailContact: updateContact,
			};
		case UPDATE_STATUS_CONTACTS:
			return {
				...state,
				...action.payload,
			};

		default:
			return state;
	}
};

export default {
	action,
	initialState,
	reducer,
};
