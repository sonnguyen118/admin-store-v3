import {
  Product as ProductAPI,
  ProductCategories as ProductCategoriesAPI,
  ProductBrands as ProductBrandsAPI,
  ProductTags as ProductTagsAPI,
  ProductChannels as ProductChannelsAPI
} from "api";
import { orArray, orNumber } from "utils/Selector";
import {
  setListCategory,
  setListSubCategory,
  setListBrand,
  setListTag,
  setListProduct,
  setListChannels,
  onCreateProduct,
  onDeleteProduct,
  onDetailProduct,
  onUpdateProduct,
  onSlugCheck,
  activeProduct,
  deactiveProduct,
  onGetDetailVariant,
  onCreateVariant,
  onUpdateVariant,
  IncrementLoading,
  DecrementLoading,
  setRelatedProducts,
  updateRelatedProducts,
  updateOutOfStock
} from "./action-type";

export const onGetListProduct = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.getListProduct(params);
    const { data, status } = response;
    if (status === 200) {
      const meta = {
        page: data.data.page,
        pageSize: data.data.pageSize,
        total: data.data.total,
      }
      dispatch(
        setListProduct({
          products: data.data.datas,
          productMeta: meta
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      setListProduct({
        products: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setListProduct({
        products: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListCategory = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductCategoriesAPI.getListProductCategoriesParent(params);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setListCategory({
          categories: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      setListCategory({
        categories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setListCategory({
        categories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
  }
  dispatch(DecrementLoading);
};

export const onGetListSubCategory = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductCategoriesAPI.getListSubCategories(params);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setListSubCategory({
          subCategories: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      setListSubCategory({
        subCategories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setListSubCategory({
        subCategories: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
  }
  dispatch(DecrementLoading);
};

export const onGetListBrand = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductBrandsAPI.getListProductBrands(params);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setListBrand({
          brands: orArray("data.datas", data)
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      setListBrand({
        brands: [],
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setListBrand({
        brands: [],
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListTag = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductTagsAPI.getListProductTags(params);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setListTag({
          tags: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      setListTag({
        data: []
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setListTag({
        data: []
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onGetListChannels = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductChannelsAPI.getListProductChannels(params);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setListChannels({
          channels: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      setListChannels({
        data: []
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      setListChannels({
        data: []
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.getCreateProduct(body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        onCreateProduct({
          type: "success",
          isRedirect: true,
          message: "Tạo mới thành công"
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      onCreateProduct({
        type: "error",
        message: "Đã xảy ra lỗi vui lòng thử lại"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onCreateProduct({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const deleteProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.deleteProduct(body);
    const { status } = response;

    if (status === 200) {
      if (orNumber("data.meta.status", response) === 3000) {
        dispatch(
          onDeleteProduct({
            type: "warning",
            message: "Sản phẩm đang có phiên bản được kích hoạt"
          })
        )
        dispatch(DecrementLoading);
        return;
      }
      dispatch(
        onDeleteProduct({
          type: "success",
          isRedirect: true,
          message: "Xóa thành công"
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      onDeleteProduct({
        type: "error",
        message: "Đã xảy ra lỗi vui lòng thử lại"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onDeleteProduct({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const detailProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.getDetailProduct(body);
    const { data, status } = response;
    if (status === 200) {
      if (orNumber("data.meta.status", response) === 3000) {
        dispatch(
          onDetailProduct({
            isRedirect: true,
          })
        )
        // dispatch(DecrementLoading);
        return
      }
      dispatch(
        onDetailProduct({
          detailProduct: data.data
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      onDetailProduct({
        detailProduct: {},
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onDetailProduct({
        detailProduct: {},
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateProduct = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.updateProduct(body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        onUpdateProduct({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công"
        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        onUpdateProduct({
          type: null,
          isRefresh: false,
          message: null
        })
      )
    }

    dispatch(
      onUpdateProduct({
        type: "error",
        isRefresh: false,
        message: "Đã xảy ra lỗi vui lòng thử lại"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onUpdateProduct({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const slugCheck = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.slugCheck(body);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        onSlugCheck({
          statusSlug: data.data.status
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      onSlugCheck({
        statusSlug: null
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onSlugCheck({
        statusSlug: null
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onActiveProduct = async (id, dispatch) => {
  // dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.activeProduct(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        activeProduct({
          isRefresh: true,
          message: "Kích hoạt thành công",
          type: "success"

        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        activeProduct({
          type: null,
          isRefresh: false,
          message: null
        })
      )
    }
  } catch (error) {
    dispatch(
      activeProduct({
        isActive: null,
        message: "Kích hoạt không thành công, đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onDeactiveProduct = async (id, dispatch) => {
  // dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.deactiveProduct(id);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        deactiveProduct({
          isRefresh: true,
          message: "Hủy Kích hoạt thành công",
          type: "success"
        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        deactiveProduct({
          type: null,
          isRefresh: false,
          message: null
        })
      )
    }
  } catch (error) {
    dispatch(
      deactiveProduct({
        isActive: null,
        message: "Hủy kích hoạt không thành công, đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getDetailVariant = async (pid, vid, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.getDetailVariant(pid, vid);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        onGetDetailVariant({
          variant: data.data,
          message: null,
          type: null
        })
      )
      dispatch(DecrementLoading);
      return;
    }
    dispatch(
      onGetDetailVariant({
        variant: null,
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onGetDetailVariant({
        variant: null,
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const createVariant = async (pid, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.createVariant(pid, body);
    const { status } = response;
    if (status === 200) {
      dispatch(
        onCreateVariant({
          typeAction: "create-success",
          type: "success",
          message: "Thêm biến thể thành công"
        })
      )
      dispatch(DecrementLoading);
      dispatch(
        onCreateVariant({
          typeAction: null,
        })
      )
      return;
    }
    dispatch(
      onCreateVariant({
        typeAction: 'create-error',
        type: "error",
        message: "Đã xảy ra lỗi vui lòng thử lại"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onCreateVariant({
        typeAction: 'create-error',
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const updateVariant = async (pid, vid, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.updateVariant(pid, vid, body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        onUpdateVariant({
          typeAction: "update-success",
          type: "success",
          message: "Cập nhật thành công"
        })
      )
      dispatch(DecrementLoading);
      dispatch(
        onCreateVariant({
          typeAction: null,
        })
      )
      return;
    }
    dispatch(
      onUpdateVariant({
        typeAction: "update-error",
        type: "error",
        message: "Đã xảy ra lỗi vui lòng thử lại"
      })
    )
    dispatch(DecrementLoading);
  } catch (error) {
    dispatch(
      onUpdateVariant({
        typeAction: "update-error",
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const getListRelatedProducts = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.getRelatedProducts(body);
    const { data, status } = response;

    if (status === 200) {
      dispatch(
        setRelatedProducts({
          listRelatedProducts: data.data.relatedProducts
        })
      )
      dispatch(
        onDetailProduct({
          detailProduct: data.data.product
        })
      )
      dispatch(DecrementLoading);
      return;
    }
  } catch (error) {
    dispatch(
      setRelatedProducts({
        listRelatedProducts: {},
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onUpdateRelatedProducts = async (id, body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.updateRelatedProducts(id, body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        updateRelatedProducts({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công"
        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        updateRelatedProducts({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      updateRelatedProducts({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};

export const onUpdateOutOfStock = async (body, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await ProductAPI.updateOutOfStockVariant(body);
    const { status } = response;

    if (status === 200) {
      dispatch(
        updateOutOfStock({
          type: "success",
          isRefresh: true,
          message: "Cập nhật thành công"
        })
      )
      dispatch(DecrementLoading);
      return dispatch(
        updateOutOfStock({
          isRefresh: false,
        })
      );
    }
  } catch (error) {
    dispatch(
      updateOutOfStock({
        message: "Đã xảy ra lỗi vui lòng thử lại",
        type: "error"
      })
    )
    dispatch(DecrementLoading);
  }
  dispatch(DecrementLoading);
};


