export const GET_LIST_PRODUCT = "product/GET_LIST_PRODUCT";
export const GET_LIST_CATEGORY = "product/GET_LIST_CATEGORY";
export const GET_LIST_SUBCATEGORY = "product/GET_LIST_SUBCATEGORY";
export const GET_LIST_BRAND = "product/GET_LIST_BRAND";
export const GET_LIST_TAGS = "product/GET_LIST_TAGS";
export const GET_LIST_CHANNELS = "product/GET_LIST_CHANNELS";
export const ON_CREATE_PRODUCT = "product/ON_CREATE_PRODUCT";
export const DELETE_PRODUCT = "product/DELETE_PRODUCT";
export const DETAIL_PRODUCT = "product/DETAIL_PRODUCT";
export const UPDATE_PRODUCT = "product/UPDATE_PRODUCT";
export const SLUG_CHECK = "product/SLUG_CHECK";
export const ACTIVE_PRODUCT = "product/ACTIVE_PRODUCT";
export const DEACTIVE_PRODUCT = "product/DEACTIVE_PRODUCT";
export const GET_DETAIL_VARIANT = "product/GET_DETAIL_VARIANT";
export const CREATE_VARIANT = "product/CREATE_VARIANT";
export const UPDATE_VARIANT = "product/UPDATE_VARIANT";
export const INCREMENT_LOADING = "product/INCREMENT_LOADING";
export const DECREMENT_LOADING = "product/DECREMENT_LOADING";
export const GET_RELATED_PRODUCTS = "product/GET_RELATED_PRODUCTS";
export const UPDATE_RELATED_PRODUCTS = "product/UPDATE_RELATED_PRODUCTS";
export const UPDATE_OUT_OF_STOCK = "product/UPDATE_OUT_OF_STOCK";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListProduct = payload => {
  return {
    payload,
    type: GET_LIST_PRODUCT
  };
};

export const setListCategory = payload => {
  return {
    payload,
    type: GET_LIST_CATEGORY
  };
};

export const setListSubCategory = payload => {
  return {
    payload,
    type: GET_LIST_SUBCATEGORY
  };
};

export const setListBrand = payload => {
  return {
    payload,
    type: GET_LIST_BRAND
  };
};

export const setListTag = payload => {
  return {
    payload,
    type: GET_LIST_TAGS
  };
};

export const setListChannels = payload => {
  return {
    payload,
    type: GET_LIST_CHANNELS
  };
};

export const onCreateProduct = payload => {
  return {
    payload,
    type: ON_CREATE_PRODUCT
  };
};

export const onDeleteProduct = payload => {
  return {
    payload,
    type: DELETE_PRODUCT
  };
};

export const onDetailProduct = payload => {
  return {
    payload,
    type: DETAIL_PRODUCT
  };
};

export const onUpdateProduct = payload => {
  return {
    payload,
    type: UPDATE_PRODUCT
  };
};

export const onSlugCheck = payload => {
  return {
    payload,
    type: SLUG_CHECK
  };
};

export const activeProduct = payload => {
  return {
    payload,
    type: ACTIVE_PRODUCT
  };
};

export const deactiveProduct = payload => {
  return {
    payload,
    type: DEACTIVE_PRODUCT
  };
};

export const onGetDetailVariant = payload => {
  return {
    payload,
    type: GET_DETAIL_VARIANT
  };
};

export const onCreateVariant = payload => {
  return {
    payload,
    type: CREATE_VARIANT
  };
};

export const onUpdateVariant = payload => {
  return {
    payload,
    type: UPDATE_VARIANT
  };
};

export const setRelatedProducts = payload => {
  return {
    payload,
    type: GET_RELATED_PRODUCTS
  };
};

export const updateRelatedProducts = payload => {
  return {
    payload,
    type: UPDATE_RELATED_PRODUCTS
  };
};

export const updateOutOfStock = payload => {
  return {
    payload,
    type: UPDATE_OUT_OF_STOCK
  };
};






