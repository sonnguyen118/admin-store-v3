import * as action from "./action";
import {
  GET_LIST_CATEGORY,
  GET_LIST_SUBCATEGORY,
  GET_LIST_BRAND,
  GET_LIST_TAGS,
  GET_LIST_PRODUCT,
  GET_LIST_CHANNELS,
  ON_CREATE_PRODUCT,
  DELETE_PRODUCT,
  DETAIL_PRODUCT,
  UPDATE_PRODUCT,
  SLUG_CHECK,
  ACTIVE_PRODUCT,
  DEACTIVE_PRODUCT,
  GET_DETAIL_VARIANT,
  CREATE_VARIANT,
  UPDATE_VARIANT,
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  GET_RELATED_PRODUCTS,
  UPDATE_RELATED_PRODUCTS,
  UPDATE_OUT_OF_STOCK
} from "./action-type";

const initialState = ({
  imageUrl: null,
  products: [],
  productMeta: null,
  categories: [],
  subCategories: [],
  brands: [],
  priavtePromotions: [],
  tags: [],
  channels: [],
  isLoading: false,
  detailProduct: null,
  counter: 0,
  statusSlug: null,
  isActive: null,
  variant: null
});

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null
      };
    case GET_LIST_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_CATEGORY:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_SUBCATEGORY:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_BRAND:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_TAGS:
      return {
        ...state,
        ...action.payload,
      };
    case GET_LIST_CHANNELS:
      return {
        ...state,
        ...action.payload,
      };
    case ON_CREATE_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case DELETE_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case DETAIL_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case SLUG_CHECK:
      return {
        ...state,
        ...action.payload,
      };
    case ACTIVE_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case DEACTIVE_PRODUCT:
      return {
        ...state,
        ...action.payload,
      };
    case GET_DETAIL_VARIANT:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_VARIANT:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_VARIANT:
      return {
        ...state,
        ...action.payload,
      };
    case GET_RELATED_PRODUCTS:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_RELATED_PRODUCTS:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_OUT_OF_STOCK:
      return {
        ...state,
        ...action.payload,
      };

    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer
};
