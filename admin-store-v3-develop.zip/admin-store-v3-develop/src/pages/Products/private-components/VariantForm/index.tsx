import React, { useEffect, useState } from "react";
import "./styled.scss";
import { UploadSingle } from "components";
import { useParams } from "react-router-dom";
import productReducer from "../../Reducer";
import { withReducer } from "hoc";
import { orEmpty, orNull, orNumber, orBoolean } from "utils/Selector";
import { Mocks } from "utils";
import { Space, Card, Form as FormBase, Input, Row, Col, InputNumber, Button, Checkbox } from "antd";

const { Item } = FormBase;

function VariantForm(props) {
  const { action, dispatch, state, onReload } = props
  const params = useParams()
  const [form] = FormBase.useForm();
  const [image, setImage] = useState(null);
  const [variantId, setVariantId] = useState(null);
  const [listedPrice, setListedPrice] = useState(null);
  const [price, setPrice] = useState(null);

  function onSetupForm() {
    const variant = orNull('formVariantReducer.variant', state)
    setImage(orNull('image', variant))
    setListedPrice(orNumber('listedPrice', variant))
    setPrice(orNumber('price', variant))
    form.setFieldsValue({
      name: orEmpty('name', variant),
      weight: orEmpty('weight', variant),
      sku: orEmpty('sku', variant),
      price: orNumber('price', variant),
      listedPrice: orNumber('listedPrice', variant),
      isActive: orBoolean('isActive', variant),
      isOutOfStock: orBoolean('isOutOfStock', variant)
    });
  }

  function onGetDetailVariant() {
    if (orNull('id', params) && orNull('vid', params)) {
      setVariantId(orEmpty('vid', params))
      action.formVariantReducer.getDetailVariant(
        orEmpty('id', params), orEmpty('vid', params),
        dispatch.formVariantReducer
      );
      return
    }
  }

  useEffect(() => {
    onGetDetailVariant()
    setVariantId(null)
    setImage(null)
    form.setFieldsValue({
      name: "",
      weight: "",
      sku: "",
      isActive: false,
      isOutOfStock: false,
      price: 0,
      listedPrice: 0,
    });
  }, [params])

  function onFinish(values) {
    const body = Mocks.PRODUCT.getBodyVariant({ ...values, image, variantId })
    if (orNull('id', params) && orNull('vid', params)) {
      action.formVariantReducer.updateVariant(
        orEmpty('id', params), orEmpty('vid', params), body,
        dispatch.formVariantReducer
      );
      return
    }
    action.formVariantReducer.createVariant(
      orEmpty('id', params), body,
      dispatch.formVariantReducer
    );
  }

  useEffect(() => {
    if (orNull('formVariantReducer.typeAction', state) === 'create-success') {
      onReload();
      setVariantId(null)
      setImage(null)
      form.setFieldsValue({
        name: "",
        weight: "",
        sku: "",
        isActive: false,
        isOutOfStock: false,
        price: 0,
        listedPrice: 0,
      });
      return
    }
    if (orNull('formVariantReducer.typeAction', state) === 'update-success') {
      onGetDetailVariant()
      onReload();
    }
  }, [orNull('formVariantReducer.typeAction', state)]);

  useEffect(() => {
    if (image) {
      form.setFieldsValue({
        image
      });
    }
  }, [image]);

  function onValidListedPrice(value) {
    if (value <= 0) {
      return Promise.reject(new Error('Giá niêm yết không hợp lệ'))
    }
    if (value >= price) {
      return Promise.resolve()
    }
    return Promise.reject(new Error('Giá niêm yết cần lớn hơn hoặc bằng giá bán'))
  }

  function onValidPrice(value) {
    if (value <= 0) {
      return Promise.reject(new Error('Giá bán không hợp lệ'))
    }
    if (listedPrice >= value) {
      return Promise.resolve()
    }
    return Promise.reject(new Error('Giá bán cần nhỏ hơn hoặc bằng giá niêm yết'))
  }


  useEffect(onSetupForm, [form, orNull('formVariantReducer.variant', state)]);

  return (
    <FormBase layout="vertical" className="variant-content-wrapper" form={form} onFinish={onFinish}>
      <Space className="w-full content-space-wrapper" direction="vertical">
        <Card title="Các thuộc tính" className="w-full content-card-wrapper" extra={
          <Space>
            <Button htmlType="submit" type="primary">{orNull('vid', params) ? "Cập nhật" : "Thêm mới"}</Button>
          </Space>
        }>
          <Row gutter={24}>
            <Col span={19}>
              <Item
                label="Tên biến thể"
                name="name"
                required
                rules={[
                  { required: true, message: 'Vui lòng nhập tên biến thể' },
                ]}>
                <Input
                  placeholder={"Tên biến thể"}
                />
              </Item>
              <Space className="w-full info-space-wrapper">
                <Item
                  label="Mã Sku"
                  name="sku"
                  required
                  rules={[
                    { required: true, message: 'Vui lòng nhập mã sku' },
                  ]}>
                  <Input
                    placeholder={"Mã Sku"}
                  />
                </Item>
                <Item name="weight" label="Trọng lượng">
                  <Input
                    className="w-full"
                    placeholder={"trọng lượng"}
                    suffix="grams"
                    type="number"
                  />
                </Item>
              </Space>
              <Space className="w-full price-space-wrapper">
                <Item
                  label="Giá niêm yết"
                  name="listedPrice"
                  required
                  rules={[
                    { required: true, message: 'Vui lòng nhập giá niêm yết' },
                    {
                      validator: (_, value) => onValidListedPrice(value)
                    },
                  ]}>
                  <InputNumber
                    defaultValue={0}
                    className="w-full"
                    placeholder={"Giá niêm yết"}
                    onChange={(e) => setListedPrice(e)}
                    value={listedPrice}
                    formatter={value =>
                      `${value ? value : 0} đ`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    }
                  />
                </Item>
                <Item
                  className="w-full"
                  label="Giá bán"
                  name="price"
                  rules={[
                    {
                      validator: (_, value) => onValidPrice(value)
                    },
                  ]}>
                  <InputNumber
                    className="w-full"
                    placeholder={"Giá bán"}
                    onChange={(e) => setPrice(e)}
                    value={price}
                    formatter={value =>
                      `${value ? value : 0} đ`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                    }
                  /></Item>
              </Space>
              <Space className="w-full price-space-wrapper">
                <Item valuePropName="checked" name="isActive" className="info-checkbox-wrapper">
                  <Checkbox>Kích hoạt</Checkbox>
                </Item>

                {/* <Item valuePropName="checked" name="isOutOfStock" className="info-checkbox-wrapper">
                  <Checkbox>Hết hàng</Checkbox>
                </Item> */}
              </Space>
            </Col>
            <Col span={5}>
              <Item name={"image"}>
                <UploadSingle style={{ width: 135, height: 135 }} image={image} setImage={setImage} />
              </Item>
            </Col>
          </Row>

        </Card>
      </Space>
    </FormBase>
  );
}


export default withReducer({
  key: "formVariantReducer",
  ...productReducer
})(VariantForm);


