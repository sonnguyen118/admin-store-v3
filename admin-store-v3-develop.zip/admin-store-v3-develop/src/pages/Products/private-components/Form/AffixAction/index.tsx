import React, { useState } from 'react';
import {
  Typography,
  Affix,
  Row,
  Col,
  Button,
  Form as FormBase,
  Popconfirm
} from "antd";
import { orBoolean, orEmpty, orNull } from 'utils/Selector';
import env from "configs/env";
const { Title } = Typography;
const { Item } = FormBase;

function AffixAction(props): JSX.Element {
  const {
    item,
    onCancelClick,
    onClickActive,
    onDeleteProduct
  } = props
  const [isShow, setIsShow] = useState(false);

  function onChangeAffix(affixed) {
    setIsShow(affixed);
  }

  const staffToken = localStorage.getItem("AccessToken");

  function onPreviewProduct() {
    window.open(`${env.base_url}/chi-tiet-san-pham/${item.slug}?staffToken=${staffToken}`, '_blank').focus();
  }

  return (
    <Affix offsetTop={0} onChange={onChangeAffix}>
      <Row style={{ padding: "0 15px" }} className="actions">
        <Col span={8}>
          {isShow
            ?
            <Title style={{ marginBottom: 0 }} level={4}>{item ? "Cập nhật sản phẩm" : "Tạo mới chưa được lưu"} </Title>
            :
            <Title style={{ marginBottom: 0 }} level={2}>{item ? "Cập nhật sản phẩm" : "Tạo sản phẩm"}</Title>
          }
        </Col>
        <Col style={{ display: "flex", alignItems: "center" }} span={8} offset={8} className="action-right">
          {item ?
            <Popconfirm placement="bottom" title={"Bạn chắc chắn muốn xóa sản phẩm này!"} onConfirm={() => onDeleteProduct(orEmpty("id", item))} okText="Xác nhận" cancelText="Hủy">
              <Button
                className="btn"
                type="primary"
                danger
              >
                Xóa
              </Button>
            </Popconfirm> : null}
          {item
            ?
            <Popconfirm placement="bottom" title={orBoolean("isActive", item) ? "Bạn chắc chắn muốn hủy kích Hoạt" : "Bạn chắc chắn muốn kích hoạt"} onConfirm={() => onClickActive(orEmpty("id", item))} okText="Xác nhận" cancelText="Hủy">
              <Button
                className="btn"
                type="primary"
              >
                {orBoolean("isActive", item) ? "Hủy kích Hoạt" : "Kích hoạt"}
              </Button>
            </Popconfirm>
            :
            null}
          {item ? <Button onClick={onPreviewProduct} className="btn">Xem trước</Button> : null}
          <Button onClick={onCancelClick} className="btn">
            Hủy
          </Button>
          <Item style={{ display: "flex", alignItems: "center", marginBottom: 0 }}>
            <Button
              htmlType="submit"
              className="btn"
              type="primary"
            >
              Lưu
            </Button>
          </Item>
        </Col>
      </Row>
    </Affix>
  );
};

export default AffixAction;