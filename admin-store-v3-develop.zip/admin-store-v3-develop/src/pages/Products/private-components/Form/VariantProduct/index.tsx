import React, { useState } from 'react';
import {
    DeleteOutlined,
    PlusCircleOutlined,
} from "@ant-design/icons";
import {
    Button,
    Card,
    Form as FormBase,
    Input,
    Checkbox,
    Space,
    InputNumber,
} from "antd";

const { Item } = FormBase;

function VariantProduct(props): JSX.Element {
    const { variants, setVariants } = props
    const [isProperties, setIsProperties] = useState(false);

    function handleInputChange(e, index, name?: string) {
        const list = [...variants];
        if (e.target) {
            const { name, value } = e.target;
            list[index][name] = value;
            setVariants(list);
            return
        }
        list[index][name] = e;
        setVariants(list);
    }

    function handleRemoveClick(index) {
        const list = [...variants];
        list.splice(index, 1);
        setVariants(list);
    }

    function handleAddClick() {
        setVariants([...variants,
        {
            name: "",
            weight: "",
            sku: "",
            price: 0,
            listedPrice: 0
        }
        ]);
    }

    function onChangeIsProperties(e) {
        setIsProperties(e.target.checked);
    }

    function onValidListedPrice(value, price) {
        if (value <= 0) {
            return Promise.reject(new Error('Giá niêm yết không hợp lệ'))
        }
        if (value >= price) {
            return Promise.resolve()
        }
        return Promise.reject(new Error('Giá niêm yết cần lớn hơn hoặc bằng giá bán'))
    }

    function onValidPrice(value, listedPrice) {
        if (value <= 0) {
          return Promise.reject(new Error('Giá bán không hợp lệ'))
        }
        if (listedPrice >= value) {
          return Promise.resolve()
        }
        return Promise.reject(new Error('Giá bán cần nhỏ hơn hoặc bằng giá niêm yết'))
      }

    return (
        <Card title="Biến thể" className="wrapper">
            <Item valuePropName="checked" name="isVariant">
                <Checkbox onChange={onChangeIsProperties}>
                    Sản phẩm này có nhiều biến thể. Ví dụ như khác nhau về kích thước,
                    màu sắc.
                </Checkbox>
            </Item>
            {variants.map((x, i) => {
                return (
                    <div key={i} className="box">
                        <Space style={{ alignItems: "flex-start" }} className="wrapper">
                            <Item
                                name={`sku${i}`}
                                label="Mã SKU"
                                required
                                rules={[
                                    { required: true, message: 'Vui lòng nhập mã SKU' },
                                ]}
                            >
                                <Input
                                    name={`sku`}
                                    value={x.sku}
                                    onChange={e => handleInputChange(e, i)}
                                    placeholder={"Mã SKU"}
                                />
                            </Item>
                            <Item
                                name={`variantName${i}`}
                                label="Tên biến thể"
                                required
                                rules={[
                                    { required: true, message: 'Vui lòng nhập tên biến thể' },
                                ]}>
                                <Input
                                    name={`name`}
                                    className="full-input"
                                    value={x.name}
                                    onChange={e => handleInputChange(e, i)}
                                    placeholder={"Tên biến thể"}
                                />
                            </Item>
                            <Item name={`weight${i}`} label="Trọng lượng">
                                <Input
                                    name={`weight`}
                                    value={x.weight}
                                    onChange={e => handleInputChange(e, i)}
                                    placeholder={"Trọng lượng"}
                                    suffix="grams"
                                    type="number"
                                />
                            </Item>
                            <Item
                                name={`listedPrice${i}`}
                                label="Giá niêm yết"
                                required
                                rules={[
                                    { required: true, message: 'Vui lòng nhập giá niêm yết' },
                                    {
                                        validator: (_, value) => onValidListedPrice(value, x.price)
                                    },
                                ]}>
                                <InputNumber
                                    name={`listedPrice${i}`}
                                    defaultValue={0}
                                    value={x.listedPrice}
                                    onChange={e => handleInputChange(e, i, 'listedPrice')}
                                    className="full-input"
                                    placeholder={"Giá niêm yết"}
                                    formatter={value =>
                                        `${value ? value : 0} đ`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                                    }
                                />
                            </Item>
                            <Item
                                name={`price${i}`}
                                label="Giá bán"
                                rules={[
                                    {
                                        validator: (_, value) => onValidPrice(value, x.listedPrice)                
                                    },
                                ]}
                            >
                                <InputNumber
                                    name={`price${i}`}
                                    defaultValue={0}
                                    value={x.price}
                                    onChange={e => handleInputChange(e, i, 'price')}
                                    className="full-input"
                                    placeholder={"Giá tiền"}
                                    formatter={value =>
                                        `${value ? value : 0} đ`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                                    }
                                />
                            </Item>
                            {variants.length !== 1 && (
                                <Item label=" ">
                                    <Button
                                        danger
                                        onClick={() => handleRemoveClick(i)}
                                        icon={<DeleteOutlined />}
                                    />
                                </Item>
                            )}
                        </Space>
                    </div>
                );
            })}

            {isProperties && (
                <Button
                    type="primary"
                    onClick={handleAddClick}
                    icon={<PlusCircleOutlined />}
                >
                    Thêm biến thể
                </Button>
            )}
        </Card>
    )
}

export default VariantProduct;