import { UploadSingle, UploadMultiple } from "components";
import { Form as FormBase, Space } from "antd";
import { orArray, orEmpty, orNull } from 'utils/Selector';
import React, { useEffect, useState } from "react";

const { Item } = FormBase;

function Images(props): JSX.Element {
    const { form, item } = props;
    const [image, setImage] = useState(null);
    const [fileList, setFileList] = useState([]);

    useEffect(() => {
        if (item) {
            setImage(orEmpty("featuredImage", item))
            setFileList(orArray('images', item).map((item) => ({ uid: item.url, ...item })))
        }
    }, [item])

    useEffect(() => {
        if (image) {
            form.setFieldsValue({
                featuredImage: image
            });
        }
    }, [image])

    useEffect(() => {
        if (fileList) {
            const listImage = fileList.filter(item => item.url || item.percent === 100).map((item) => ({
                name: orEmpty("name", item),
                url: orNull("response", item) ? item.response[0] : orEmpty("url", item),
                alt: orEmpty("alt", item)
            }));
            form.setFieldsValue({
                images: listImage
            });
        }
    }, [fileList])

    return (
        <Space className="wrapper-image">
            <Item
                name="featuredImage"
                rules={[
                    { required: true, message: 'Vui lòng chọn ảnh đại diện' }
                ]}
                required
            >
                <UploadSingle style={{ width: 240, height: 240 }} image={image} setImage={setImage} />
            </Item>
            <Item
                name="images"
            >
                <UploadMultiple fileList={fileList} setFileList={setFileList} />
            </Item>

        </Space>
    );
};

export default Images;