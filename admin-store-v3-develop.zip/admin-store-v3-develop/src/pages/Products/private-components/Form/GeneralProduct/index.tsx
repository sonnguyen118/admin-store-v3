import { Editor, CheckSlug } from "components";
import { Card, Form as FormBase, Input, Tabs } from "antd";
import { Helpers } from "utils";
import { orNull } from "utils/Selector";
import env from "../../../../../configs/env";

const { Item } = FormBase;

function GeneralProduct(props): JSX.Element {
  const { state, slug, setSlug, onSearchSlug, form, setIsFinish, item } = props;

  function onChangeName(e) {
    form.setFieldsValue({
      pageSEO_title: e.target.value,
    });
    if (!orNull("id", item)) {
      setSlug(Helpers.getSlug(e.target.value));
      setIsFinish((prevState) => ({
        ...prevState,
        status: false,
      }));
      form.setFieldsValue({
        slug: Helpers.getSlug(e.target.value),
      });
      return;
    }
  }

  function onChangeShortDescription(e) {
    form.setFieldsValue({
      pageSEO_description: e.target.value,
    });
  }

  return (
    <Card title="Thông tin chung" className="space-general-wrapper">
      <Item
        name="name"
        label={
          <span style={{ color: "#6c798f", fontWeight: "bold" }}>
            Tên sản phẩm:
          </span>
        }
        rules={[{ required: true, message: "Vui lòng nhập tên sản phẩm" }]}
        required
      >
        <Input onChange={onChangeName} placeholder="Nhập tên sản phẩm" />
      </Item>
      <CheckSlug
        slug={slug}
        onChangeSlug={onChangeName}
        onSearchSlug={onSearchSlug}
        addonSlug={`${env.base_url}/chi-tiet-san-pham`}
        statusSlug={orNull("productReducer.statusSlug", state)}
        idItem={orNull("id", item)}
        isActive={orNull("isActive", item)}
      />
      <Item
        name="shortDescription"
        label={
          <span style={{ color: "#6c798f", fontWeight: "bold" }}>
            Mô tả ngắn:
          </span>
        }
        htmlFor="name"
      >
        <Input.TextArea
          onChange={onChangeShortDescription}
          rows={7}
          placeholder="Mô tả ngắn cho sản phẩm"
        />
      </Item>
      <Tabs defaultActiveKey="1">
        <Tabs.TabPane tab="Mô tả sản phẩm:" key="1">
          <Item
            name="description"
            // label={
            //   <span style={{ color: "#6c798f", fontWeight: "bold" }}>
            //     Mô tả sản phẩm:
            //   </span>
            // }
            required
            rules={[
              { required: true, message: "Vui lòng nhập mô tả sản phẩm" },
            ]}
          >
            <Editor />
          </Item>
        </Tabs.TabPane>
        <Tabs.TabPane tab="Thành phần" key="2">
          <Item name="productIngredients">
            <Editor />
          </Item>
        </Tabs.TabPane>
        <Tabs.TabPane tab="Hướng dẫn sử dụng" key="3">
          <Item name="productManual">
            <Editor />
          </Item>
        </Tabs.TabPane>
      </Tabs>
    </Card>
  );
}

export default GeneralProduct;
