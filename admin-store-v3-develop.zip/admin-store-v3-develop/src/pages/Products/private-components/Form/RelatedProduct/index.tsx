import { useHistory } from "react-router-dom";
import React, { useEffect, useState } from "react";
import { orArray, orEmpty } from "../../../../../utils/Selector";
import { Avatar, Card, Table, Tag } from "antd";
import helper from "../../../../../utils/Helpers";

function RelatedProduct({ item }) {
  const history = useHistory();
  const [rows, setRows] = useState([]);
  const columns = [
    {
      title: "Ảnh",
      dataIndex: "image",
      render(value, record) {
        return {
          props: {
            style: { padding: "0" }
          },
          children: (
            <div style={{ cursor: "pointer" }} onClick={() => onClickUpdate(record.id)}>
              <Avatar size={48} src={value} />
            </div>
          )
        };
      },
      width: "5%"
    },
    {
      title: "Tên sản phẩm",
      render: (record) => (
        <div>
          <a onClick={() => onClickUpdate(record.id)} style={{ cursor: "pointer", fontWeight: "bold", display: 'block' }}>{record.name}</a>
          <span style={{ fontSize: 12, color: "grey" }}>{record.totalVariant} biến thể</span>
        </div>
      ),
      width: '45%',
    },
    {
      title: "Trạng thái",
      dataIndex: "isActive",
      render: (value) => (value ? <Tag color="#108ee9">Hiển thị</Tag> : <Tag>Tạm khóa</Tag>),
      width: "15%"
    }
  ];

  function onClickUpdate(id) {
    if (id) {
      history.push(`/products/update/${id}`)
    }
  }

  function onUpdateData(): void {
    if (orArray("relatedProducts", item)) {
      const r = [] as any;
      orArray("relatedProducts", item).forEach((node, index): void => {
        r.push({
          key: index,
          id: node.id,
          name: node.name,
          image: node.featuredImage.url,
          isActive: node.isActive,
          price: orEmpty("staticPrice.minPrice", item) === orEmpty("staticPrice.maxPrice", item)
            ? helper.currencyFormatVND(orEmpty("staticPrice.maxPrice", item))
            : `${helper.currencyFormatVND(orEmpty("staticPrice.minPrice", item))} - ${helper.currencyFormatVND(orEmpty("staticPrice.maxPrice", item))}`,
          totalVariant: node.totalVariant
        });
      });
      setRows(r);
    }
  }

  useEffect(() => onUpdateData(), [orArray("relatedProducts", item)]);

  return (
    <Card
      title="Sản phẩm liên quan"
      className="wrapper"
      extra={<a className="variant-manager-btn" href={`/products/${orEmpty("id", item)}/related-products`} target="_blank">Cập nhật sản phẩm liên quan</a>}
    >
  <Table pagination={{ pageSize: 5, position: ["bottomRight"] }} columns={columns} dataSource={rows} />
    </Card >
  )
}

export default RelatedProduct;