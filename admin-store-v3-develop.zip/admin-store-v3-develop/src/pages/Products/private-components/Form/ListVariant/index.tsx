import React, { useState, useEffect } from 'react';
import { useHistory } from "react-router-dom";
import {
    Card,
    Checkbox,
    Table
} from "antd";
import { Helpers } from 'utils';
import { orArray, orEmpty } from 'utils/Selector';


function ListVariant({ item, onUpdateOutOfStock }) {
    const history = useHistory();
    const [rows, setRows] = useState([]);
    const columns = [
        {
            title: "STT",
            dataIndex: "key",
            render: value => `${value + 1}`
        },
        {
            title: "Tên thuộc tính",
            dataIndex: "name",
            render: (value, record) => (<a href={`/products/update/${orEmpty("id", item)}/variants/${record.id}`} target="_blank" style={{ cursor: "pointer", fontWeight: "bold", display: 'block' }}>{value}</a>),
        },
        {
            title: "Mã SKU",
            dataIndex: "sku"
        },
        {
            title: "Khối lượng",
            dataIndex: "weight"
        },

        {
            title: "Giá niêm yết",
            dataIndex: "listedPrice",
            render: (listedPrice: number) => <div>{Helpers.currencyFormatVND(listedPrice)}</div>,
        },
        {
            title: "Giá bán",
            dataIndex: "price",
            render: (price: number) => <div>{Helpers.currencyFormatVND(price)}</div>,
        },
        // {
        //     title: "Hết hàng",
        //     dataIndex: "isOutOfStock",
        //     render: (value, record) => {
        //         return (
        //             <div>
        //                 <Checkbox defaultChecked={value} onChange={(e) => onOutOfStockVariant(e, record)} />
        //             </div>
        //         )
        //     },
        // }
    ];

    const onOutOfStockVariant = (e, value) => {
        const body = {
            productId: orEmpty("id", item),
            variantId: orEmpty("id", value),
            isOutOfStock: e.target.checked
        }
        onUpdateOutOfStock(body)
    }


    function onUpdateData(): void {
        if (orArray("variants", item)) {
            const r = [] as any;
            orArray("variants", item).forEach((node, index): void => {
                r.push({
                    id: node.id,
                    key: index,
                    name: node.name,
                    weight: node.weight,
                    size: node.size,
                    sku: node.sku,
                    listedPrice: node.listedPrice,
                    price: node.price,
                    isOutOfStock: node.isOutOfStock
                });
            });
            setRows(r);
        }
    }

    useEffect(() => onUpdateData(), [orArray("variants", item)]);



    return (
        <Card
            title="Biến Thể"
            className="wrapper"
            extra={<a className="variant-manager-btn" href={`/products/${orEmpty("id", item)}/variants/create`} target="_blank">Thêm mới và cập nhật biến thể</a>}
        >
            <Table pagination={false} columns={columns} dataSource={rows} />
        </Card>
    )
}

export default ListVariant;