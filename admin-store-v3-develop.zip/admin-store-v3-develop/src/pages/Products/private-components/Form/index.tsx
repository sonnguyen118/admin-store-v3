import React, { useState, useEffect, useCallback } from "react";
import "./styled.scss";
import productReducer from "../../Reducer";
import { withReducer, withCompose, withToken } from "hoc";
import { Mocks } from "utils";
import {
  Row,
  Col,
  Card,
  Form as FormBase,
  Checkbox,
  Space,
  message,
  notification,
} from "antd";
import AffixAction from "./AffixAction";
import Tags from "./Tags";
import GeneralProduct from "./GeneralProduct";
import VariantProduct from "./VariantProduct";
import RelatedProduct from "./RelatedProduct";
import ListVariant from "./ListVariant";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import OptimalSEO from "./OptimalSEO";

import Images from "./Images";
import Brand from "./Brand";
import Category from "./Category";
import PrivatePromotion from "./PrivatePromotion";

const { Item } = FormBase;

function Form(props): JSX.Element {
  const {
    item,
    onCancelClick,
    dispatch,
    action,
    state,
    onSave,
    onClickActive,
    isUpdate,
    onUpdateOutOfStock,
    onDeleteProduct,
  } = props;
  const [form] = FormBase.useForm();
  const [tags, setTags]: any = useState([]);
  const [priavtePromotions, setPromotions]: any = useState([]);
  const [brands, setBrands]: any = useState([]);
  const [categories, setCategories]: any = useState([]);
  const [variants, setVariants]: any = useState([
    {
      name: "",
      weight: "",
      sku: "",
      price: 0,
      listedPrice: 0,
    },
  ]);
  const [channels, setChannels] = useState([]);
  const [slug, setSlug] = useState("");
  const [isFinish, setIsFinish] = useState({
    status: false,
    data: {},
  });

  function onSetupForm() {
    setSlug(orEmpty("slug", item));
    setPromotions(orEmpty("priavtePromotions", item));
    form.setFieldsValue({
      name: orEmpty("name", item),
      slug: orEmpty("slug", item),
      brand: orNull("brand.id", item),
      category: orNull("category.id", item),
      subCategory: orNull("subCategory", item),
      description: orEmpty("description", item),
      productIngredients: orEmpty("productIngredients", item),
      productManual: orEmpty("productManual", item),
      shortDescription: orEmpty("shortDescription", item),
      tags: orArray("tags", item).map((item) => ({
        value: item.id,
        label: item.name,
      })),
      channels: orArray("channels", item).map((item) => item.id),
      pageSEO_title: orEmpty("pageSEO.title", item),
      pageSEO_keywords: orEmpty("pageSEO.keywords", item),
      pageSEO_description: orEmpty("pageSEO.description", item),
      priavtePromotions: orEmpty("priavtePromotions", item),
    });
  }

  useEffect(onSetupForm, [item]);

  function onFinish(values) {
    setIsFinish({
      status: true,
      data: values,
    });
    if (orNull("id", item)) {
      if (
        !values.pageSEO_title &&
        !values.pageSEO_keywords &&
        !values.pageSEO_description
      ) {
        const newValues = {
          ...values,
          id: orEmpty("id", item),
          pageSEO_title: orEmpty("pageSEO.title", item),
          pageSEO_keywords: orEmpty("pageSEO.keywords", item),
          pageSEO_description: orEmpty("pageSEO.description", item),
          slug: orEmpty("slug", item),
        };
        onSave(Mocks.PRODUCT.getBodyProduct({ ...newValues, variants }));
        return;
      }
      onSave(
        Mocks.PRODUCT.getBodyProduct({
          ...values,
          id: orEmpty("id", item),
          slug: orEmpty("slug", item),
          variants,
        })
      );
      return;
    }
    if (orNull("productReducer.statusSlug", state) != null) {
      if (orBoolean("productReducer.statusSlug", state)) {
        onSave(Mocks.PRODUCT.getBodyProduct({ ...values, variants }));
      } else {
        notification["warning"]({
          message: "Không thể tạo mới nhóm sản phẩm",
          description:
            "Lỗi đường dẫn nhóm sản phẩm đã tồn tại, vui lòng kiểm tra và thử lại!",
        });
      }
      return;
    }
    onSearchSlug();
  }

  useEffect(() => {
    if (orNull("productReducer.statusSlug", state) != null) {
      if (isFinish.status && orBoolean("productReducer.statusSlug", state)) {
        onSave(Mocks.PRODUCT.getBodyProduct({ ...isFinish.data, variants }));
      } else if (
        isFinish.status &&
        !orBoolean("productReducer.statusSlug", state)
      ) {
        notification["warning"]({
          message: "Không thể tạo mới nhóm sản phẩm",
          description:
            "Lỗi đường dẫn nhóm sản phẩm đã tồn tại, vui lòng kiểm tra và thử lại!",
        });
      }
      return;
    }
  }, [orNull("productReducer.statusSlug", state)]);

  function onFinishFailed() {
    notification["warning"]({
      message: "Không thể tạo mới sản phẩm",
      description:
        "Lỗi do chưa cập nhật đủ thông tin, vui lòng kiểm tra và thử lại!",
    });
  }

  function headerActions() {
    return (
      <AffixAction
        item={item}
        onClickActive={onClickActive}
        onCancelClick={onCancelClick}
        onDeleteProduct={onDeleteProduct}
      />
    );
  }

  function onSetup() {
    action.productReducer.onGetListTag({}, dispatch.productReducer);
    action.productReducer.onGetListChannels({}, dispatch.productReducer);
    action.productReducer.onGetListBrand(
      { isFull: true },
      dispatch.productReducer
    );
    action.productReducer.onGetListCategory({}, dispatch.productReducer);
  }

  function onSetPromotions() {
    if (orArray("productReducer.priavtePromotions", state)) {
      setPromotions(orArray("productReducer.priavtePromotions", state));
    }
  }

  function onSetTags() {
    if (orArray("productReducer.tags", state)) {
      setTags(
        orArray("productReducer.tags", state).map((item) => ({
          value: item.id,
          label: item.name,
        }))
      );
    }
  }

  function onSetChannels() {
    if (orArray("productReducer.channels", state)) {
      setChannels(
        orArray("productReducer.channels", state).map((item) => ({
          value: item.id,
          label: item.name,
        }))
      );
    }
  }

  function onSetBrands() {
    if (orArray("productReducer.brands", state)) {
      setBrands(
        orArray("productReducer.brands", state).map((item) => ({
          value: item.id,
          label: item.name,
        }))
      );
    }
  }

  function onSetCategories() {
    if (orArray("productReducer.categories", state)) {
      setCategories(
        orArray("productReducer.categories", state).map((item) => ({
          value: item.id,
          label: item.name,
        }))
      );
    }
  }

  function onSearchSlug() {
    if (!orNull("id", item) && slug != "") {
      action.productReducer.slugCheck({ s: slug }, dispatch.productReducer);
      return;
    }
    message.warning("Vui lòng nhập tên sản phẩm hoặc đường dẫn để kiểm tra");
    return;
  }

  useEffect(onSetup, []);
  useEffect(onSetTags, [orArray("productReducer.tags", state)]);
  useEffect(onSetPromotions, [
    orArray("productReducer.priavtePromotions", state),
  ]);
  useEffect(onSetChannels, [orArray("productReducer.channels", state)]);
  useEffect(onSetBrands, [orArray("productReducer.brands", state)]);
  useEffect(onSetCategories, [orArray("productReducer.categories", state)]);

  useEffect(() => {
    form.setFieldsValue({
      priavtePromotions: priavtePromotions,
    });
  }, [priavtePromotions]);

  function renderInfoGeneral() {
    return (
      <GeneralProduct
        item={item}
        setIsFinish={setIsFinish}
        form={form}
        onSearchSlug={onSearchSlug}
        slug={slug}
        setSlug={setSlug}
        state={state}
      />
    );
  }

  function renderUploadThumb() {
    return <Images item={item} form={form} />;
  }

  function renderIsProperty() {
    return <VariantProduct variants={variants} setVariants={setVariants} />;
  }

  function renderListVariant() {
    return <ListVariant item={item} onUpdateOutOfStock={onUpdateOutOfStock} />;
  }

  function renderRelatedProduct() {
    return <RelatedProduct item={item} />;
  }

  function renderIsDisplay() {
    return (
      <Card title="Hiển thị" className="wrapper channels-wrapper">
        <Item name="channels" required>
          <Checkbox.Group options={channels} />
        </Item>
      </Card>
    );
  }

  function renderPrivatePromotion() {
    return (
      <PrivatePromotion
        priavtePromotions={priavtePromotions}
        setPromotions={setPromotions}
      />
    );
  }

  function renderTags() {
    return <Tags tags={tags} setTags={setTags} />;
  }

  function renderBrand() {
    return <Brand form={form} item={item} brands={brands} />;
  }

  function renderCategory() {
    return (
      <Category
        form={form}
        categoryOptions={categories}
        categories={orArray("productReducer.categories", state)}
        item={item}
      />
    );
  }

  function renderSEO() {
    return (
      <div>
        <OptimalSEO slug={slug} state={state} item={item} />
      </div>
    );
  }

  return (
    <FormBase
      layout="vertical"
      form={form}
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
    >
      {headerActions()}
      <Row gutter={24}>
        <Col span={17}>
          <Space className="space-main-wrapper" direction="vertical">
            {renderInfoGeneral()}
            {renderUploadThumb()}
            {!item ? renderIsProperty() : renderListVariant()}
            {item && renderRelatedProduct()}
            {renderSEO()}
          </Space>
        </Col>
        <Col span={7}>
          <Space className="wrapper" direction="vertical">
            {renderBrand()}
            {renderCategory()}
            {renderIsDisplay()}
            {renderTags()}
            {renderPrivatePromotion()}
          </Space>
        </Col>
      </Row>
    </FormBase>
  );
}
export default withCompose(
  withToken,
  withReducer({
    key: "productReducer",
    ...productReducer,
  })
)(Form);
