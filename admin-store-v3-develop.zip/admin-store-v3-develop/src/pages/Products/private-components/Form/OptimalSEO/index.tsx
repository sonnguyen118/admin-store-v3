import { Card, Form as FormBase, Input, Typography, Tooltip, message } from "antd";
import { useEffect, useState } from "react";
import { orArray, orBoolean, orEmpty, orNull } from 'utils/Selector';
import env from "../../../../../configs/env";
const { Title, Link } = Typography;
const { Item } = FormBase;

export default function OptimalSEO({ item, state, slug }) {

  const [isSEO, setIsSEO] = useState(false)

  useEffect(() => {
    if (!item) {
      setIsSEO(true)
      return
    }
    setIsSEO(false)
  }, [item])

  const renderPreviewSEO = () => {
    return (
      <div>
        <Link href={orBoolean('updateProductReducer.detailProduct.isActive', state) ? `${env.base_url}/chi-tiet-san-pham/${slug}` : null} target="_blank">
          {env.base_url}/chi-tiet-san-pham/{slug}
        </Link>
        <Title style={{ margin: 0 }} level={3}>{orEmpty('updateProductReducer.detailProduct.pageSEO.title', state)}</Title>
        <p>{orEmpty('updateProductReducer.detailProduct.pageSEO.description', state)}</p>
      </div>
    )
  }

  return (
    <Card
      title="Tối ưu SEO"
      className="wrapper"
      extra={item ? <div onClick={() => setIsSEO(!isSEO)} style={{ color: "blue", cursor: "pointer" }}>Chỉnh sửa SEO</div> : null}
    >
      {!isSEO ? renderPreviewSEO() : null}
      {isSEO &&
        (
          <div>
            <p>
              Thiết lập các thẻ mô tả giúp khách hàng dễ dàng tìm thấy danh mục này
              trên công cụ tìm kiếm như Google
            </p>
            <Item
              name="pageSEO_title"
              label="Tiêu đề trang"
            >
              <Input placeholder="Tiêu đề trang" />
            </Item>
            <Item
              name="pageSEO_keywords"
              label="Keywords trang"
            >
              <Input placeholder="Keywords trang" />
            </Item>
            <Item
              name="pageSEO_description"
              label="Mô tả trang"
            >
              <Input.TextArea rows={7} placeholder="Mô tả trang" />
            </Item>
          </div>
        )
      }

    </Card>
  );
}
