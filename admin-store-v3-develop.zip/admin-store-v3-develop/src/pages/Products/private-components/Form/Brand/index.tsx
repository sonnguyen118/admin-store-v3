import { Selector } from "components";
import { Card, Form as FormBase } from "antd";

const { Item } = FormBase;

function Brand(props): JSX.Element {
    const { brands } = props;

    return (
        <Card
            title="Thương hiệu"
            className="wrapper"
        >
            <Item
                name="brand"
                label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Thương hiệu:</span>}
                required
                rules={[
                    { required: true, message: 'Vui lòng chọn nhà cung cấp' }
                ]}
            >
                <Selector options={brands} placeholder={"Chọn nhà cung cấp"} />
            </Item>
        </Card>
    );
};

export default Brand;