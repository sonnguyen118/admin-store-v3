import { Button, Card, Form, Input, List, Select, Space, Tag } from "antd";
import { useState } from "react";
import ReactDragListView from "react-drag-listview";
import { DeleteFilled, DeleteOutlined } from "@ant-design/icons";

const { Item } = Form;

function PrivatePromotion(props) {
    const { priavtePromotions, setPromotions } = props;
    const [promotionValue, setPromotionValue] = useState("");

    function onFinishPromotion(e, promotionValue) {
        e.preventDefault()
        if (promotionValue) {
            const arr = [...priavtePromotions]
            arr.push(promotionValue);

            setPromotions(arr);

            setPromotionValue("");
        }
    }

    function onClose(item, e) {
        e.preventDefault();
        const arrTag = [...priavtePromotions].filter((value) => value.toString() !== item.toString());

        setPromotions(arrTag)
    }

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            onFinishPromotion(event, promotionValue)
        }
    }

    function onDragEnd(fromIndex, toIndex) {
        if (toIndex < 0) return; // Ignores if outside designated area

        const items = [...priavtePromotions];
        const item = items.splice(fromIndex, 1)[0];
        items.splice(toIndex, 0, item);
        setPromotions(items);
    };

    return (
        <Card
            title="Khuyến mãi riêng"
            className="wrapper"
        >
            <Item name="priavtePromotions" initialValue={priavtePromotions} hidden> </Item>
            <Space className="space-input-promotion" direction="horizontal" style={{ width: "100%", marginBottom: 24 }}>
                <Input value={promotionValue} onChange={(e) => setPromotionValue(e.target.value)} placeholder="Thêm nội dung khuyến mại" onKeyDown={handleKeyDown} style={{ width: "100%" }} />
                <Button disabled={false} onClick={(e) => onFinishPromotion(e, promotionValue)} type="primary" className="action-right" style={{ float: "right" }}>Thêm</Button>
            </Space>
            <span>Danh sách nội dung khuyến mãi :</span>
            <br />
            <span>(kéo thả để sắp xếp)</span>
            <ReactDragListView
                nodeSelector=".ant-list-item.draggble"
                onDragEnd={onDragEnd}
            >
                <List
                    size="small"
                    bordered
                    dataSource={priavtePromotions}
                    style={{ marginTop: 15 }}
                    renderItem={item => {
                        return (
                            <List.Item
                                extra={<DeleteOutlined className="cursor-pointer" onClick={(e) => onClose(item, e)} />}
                                className="draggble cursor-move"
                            >
                                <List.Item.Meta title={item} />
                            </List.Item>
                        );
                    }}
                />
            </ReactDragListView>
        </Card>
    );
};

export default PrivatePromotion;