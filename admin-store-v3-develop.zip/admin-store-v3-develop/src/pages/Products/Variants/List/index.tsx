import React, { useEffect, useState } from 'react';
import './styled.scss'
import { orArray, orEmpty, orNull } from "utils/Selector";
import { useHistory, useParams } from "react-router-dom";
import { Space, Card, Avatar, Menu } from "antd";
import {
  ArrowLeftOutlined
} from '@ant-design/icons';
const { Meta } = Card;

export default function List({ product }) {
  const [selected, setSelected] = useState([])
  const history = useHistory()
  const params = useParams()

  useEffect(() => {
    if (orNull('vid', params) && product) {
      const selectedDefault = orArray('variants', product).findIndex((item) => item.id == orEmpty('vid', params))
      setSelected([`${selectedDefault}`])
    }
  }, [params, product])

  function onBackDetail() {
    history.push(`/products/update/${orEmpty('id', product)}`)
  }

  function handleUpdateVariant(id, key) {
    // setSelected([`${key}`])
    history.push(`/products/update/${orEmpty('id', product)}/variants/${id}`)
  }

  function onCreateVariant(pid) {
    setSelected([])
    history.push(`/products/${pid}/variants/create`)
  }

  return (
    <div className="w-full variant-sidebar-wrapper">
      <Space className="w-full space-wrapper" direction="vertical">
        <Card className="w-full cart-product-wrapper" title={<div className="variant-manager-btn" onClick={onBackDetail}> <ArrowLeftOutlined /> Quay lại trang chi tiết sản phẩm</div>}>
          <Meta
            avatar={<Avatar shape={"square"} size={64} src={orEmpty('featuredImage.url', product)} />}
            title={orEmpty('name', product)}
            description={`Sản phẩm có ${orArray('variants', product).length} biến thể`}
          />
        </Card>
        <Card
          title="Danh sách biến thể"
          extra={<div className="variant-manager-btn" onClick={() => onCreateVariant(orEmpty('id', product))}>Thêm biến thể mới</div>}
          className="w-full list-variant-wrapper"
        >
          <Menu
            selectedKeys={selected}
            mode="inline"
          >
            {orArray('variants', product).map((item, index) => {
              return (
                <Menu.Item key={index} style={{ height: "auto", padding: 24 }} onClick={() => handleUpdateVariant(orEmpty('id', item), index)} >
                  <Meta
                    avatar={<Avatar size={64} shape={"square"} src={orEmpty('image.url', item)} />}
                    title={<div style={{display: 'flex', flexDirection: 'column'}}><a href="#" style={{lineHeight: "28px"}}>{orEmpty('name', item)}</a><span style={{fontSize: 12, color: "grey", lineHeight: "18px"}}>{`SKU: ${orEmpty("sku", item)}`}</span></div>}
                  />
                </Menu.Item>
              )
            })}
          </Menu>
        </Card>
      </Space>
    </div>
  );
}
