import React, { useEffect } from 'react';
import List from './List';
import Content from './Content';
import productReducer from "../Reducer";
import { withReducer } from "hoc";
import { orEmpty, orNull } from "utils/Selector";
import { useParams } from "react-router-dom";
import { Row, Col } from "antd";

function Variants(props) {
  const params = useParams()

  const { action, state, dispatch } = props

  function onSetup() {
    action.variantReducer.detailProduct(
      orEmpty('id', params),
      dispatch.variantReducer
    );
  }

  function onReload(){
    action.variantReducer.detailProduct(
      orEmpty('id', params),
      dispatch.variantReducer
    );
  }

  useEffect(onSetup, [params])

  return (
    <div>
      <Row gutter={24}>
        <Col span={8}>
          {/* <Title level={2}>{orNull('name', state.productReducer.getVariant()) ? `Biến thể: ${orNull('name', state.productReducer.getVariant())}` : null}</Title> */}
        </Col>
      </Row>
      <Row gutter={24}>
        <Col span={8}>
          <List product={orNull('variantReducer.detailProduct', state)} />
        </Col>
        <Col span={16}>
          <Content onReload={onReload} />
        </Col>
      </Row>
    </div>
  );
}

export default withReducer({
  key: "variantReducer",
  ...productReducer
})(Variants);
