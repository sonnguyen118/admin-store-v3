import React from 'react';
import './styled.scss'
import { VariantForm } from "../../private-components"

export default function Content({ onReload }) {
  return (
    <div className="wrapper">
      <VariantForm onReload={onReload} />
    </div>
  );
}