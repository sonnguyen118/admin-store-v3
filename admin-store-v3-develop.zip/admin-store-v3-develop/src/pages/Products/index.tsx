import React from 'react';
import { SimpleTabs } from "../../components";
import { Button, PageHeader} from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List"
import { useHistory } from "react-router-dom";

export default function Products() {

  const history = useHistory()

  const tabItems = [
    {
      title: "Tất cả sản phẩm",
      component: <List/>
    },
  ];

  function onCreateClick(){
    history.push("/products/create");
  }

  return (
    <div>
      <PageHeader
          style={{padding: 0}}
          ghost={true}
          title="Danh sách sản phẩm"
          extra={[
            <Button
                type="primary"
                onClick={onCreateClick}
                icon={<PlusCircleOutlined />}
            >
              Tạo sản phẩm
            </Button>
          ]}
      >
      </PageHeader>
      <SimpleTabs tabItems={tabItems} />
    </div>
  );
}
