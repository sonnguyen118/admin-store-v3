import React, { useState, useEffect } from "react";
import './styled.scss'
import { Selector } from "components";
import { Form, Row, Col, Input, Button, Popover, Tag } from 'antd';
import { FilterOutlined } from '@ant-design/icons';
import useDebounce from "../../../hook/useDebounce"
import productReducer from "../Reducer";
import { withReducer } from "hoc";
import { orArray, orNull } from 'utils/Selector';

function Search(props) {
  const { filter, setFilter, action, state, dispatch, onChangePage, listTag } = props
  const [form] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false)
  const [listFilter, setListFilter] = useState([])
  const [filterType, setFilterType] = useState("withIsActive")
  const [searchValue, setSearchValue] = useState("")
  const [categories, setCategories] = useState([])
  const [brands, setBrands] = useState([])
  const [tags, setTags] = useState([])
  const inputDebounce = useDebounce(searchValue, 300)

  function checkFilterValue(arr) {
    if (Array.isArray(arr)) {
      return arr
    }
    return [arr]
  }

  const onFinish = (values) => {
    const arr = [...listFilter];
    setFilterVisible(false);
    switch (values.filterType) {
      case "withIsActive":
        const resultItem = listFilter.findIndex(item => item.value === "withIsActive")
        if (resultItem === -1) {
          arr.push({
            value: "withIsActive",
            label: `Tình trạng là ${values.filterValue ? "Hiển thị" : "Tạm khoá"}`
          })
          setListFilter(arr)
        } else {
          listFilter[resultItem].label = `Tình trạng là ${values.filterValue ? "Hiển thị" : "Tạm khoá"}`
          setListFilter(arr)
        }
        return (
          form.setFieldsValue({
            filterType: "withIsActive",
            filterValue: values.filterValue
          }),
          setFilter(prevState => ({
            ...prevState,
            isActive: values.filterValue,
          })), onChangePage(1)
        );
      case "withCategory":
        const listCategoryFilter = []
        categories.forEach(item => {
          const result = checkFilterValue(values.filterValue).find(value => value === item.value)
          if (result) {
            listCategoryFilter.push(item)
            return
          }
        })
        const resultIndexCategory = listFilter.findIndex(item => item.value === "withCategory")
        if (resultIndexCategory === -1) {
          arr.push({
            value: "withCategory",
            label: `Loại sản phẩm là ${listCategoryFilter.map((item) => { return (item.label) })}`
          })
          setListFilter(arr)
        } else {
          listFilter[resultIndexCategory].label = `Loại sản phẩm là ${listCategoryFilter.map((item) => { return (item.label) })}`
          setListFilter(arr)
        }
        return (
          setFilter(prevState => ({
            ...prevState,
            category: values.filterValue,
          })),
          onChangePage(1)
        );
      case "withBrand":
        const listBrandFilter = []
        brands.forEach(item => {
          const result = checkFilterValue(values.filterValue).find(value => value === item.value)
          if (result) {
            listBrandFilter.push(item)
            return
          }
        })
        const resultIndexBrand = listFilter.findIndex(item => item.value === "withBrand")
        if (resultIndexBrand === -1) {
          arr.push({
            value: "withBrand",
            label: `Nhà cung cấp là ${listBrandFilter.map((item) => { return (item.label) })}`
          })
          setListFilter(arr)
        } else {
          listFilter[resultIndexBrand].label = `Nhà cung cấp là ${listBrandFilter.map((item) => { return (item.label) })}`
          setListFilter(arr)
        }
        return (
          setFilter(prevState => ({
            ...prevState,
            brand: values.filterValue,
          })),
          onChangePage(1)
        );
      case "withTags":
        const listTagsFilter = []
        tags.forEach(item => {
          const result = checkFilterValue(values.filterValue).find(value => value === item.value)
          if (result) {
            listTagsFilter.push(item)
            return
          }
        })
        const resultIndexTags = listFilter.findIndex(item => item.value === "withTags")
        if (resultIndexTags === -1) {
          arr.push({
            value: "withTags",
            label: `Tag sản phẩm là ${listTagsFilter.map((item) => { return (item.label) })}`
          })
          setListFilter(arr)
        } else {
          listFilter[resultIndexTags].label = `Tag sản phẩm là ${listTagsFilter.map((item) => { return (item.label) })}`
          setListFilter(arr)
        }
        return (
          setFilter(prevState => ({
            ...prevState,
            tags: values.filterValue,
          })),
          onChangePage(1)
        );
      default:
        break;
    }
  }

  useEffect(() => {
    if (inputDebounce) {
      setFilter(prevState => ({
        ...prevState,
        q: searchValue
      }));
      onChangePage(1);
      return
    }
  }, [inputDebounce])


  useEffect(() => {
    if (searchValue === "" && filter.q) {
      delete filter.q;
      setFilter({ ...filter })
      onChangePage(1);
    }

  }, [searchValue, filter])

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withIsActive",
      filterValue: null
    });
  }

  useEffect(onSetupForm, []);

  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter(node => node.value != item.value))
    if (item.value === 'withIsActive') {
      delete filter.isActive;
      setFilter({ ...filter })
    } else if (item.value === 'withCategory') {
      delete filter.category;
      setFilter({ ...filter })
    } else if (item.value === 'withBrand') {
      delete filter.brand;
      setFilter({ ...filter })
    } else if (item.value === 'withTags') {
      delete filter.tags;
      setFilter({ ...filter })
    }
    onChangePage(1);
  }

  const filterOptions = [
    {
      label: "Tình trạng hiển thị",
      value: "withIsActive"
    },
    {
      label: "Loại sản phẩm",
      value: "withCategory"
    },
    {
      label: "Nhà cung cấp",
      value: "withBrand"
    },
    {
      label: "Tags",
      value: "withTags"
    },
  ]

  const optionMultiple = ["withCategory", "withBrand", "withTags"]

  const valueOptions = [
    {
      label: "Hiển thị",
      value: true
    },
    {
      label: "Tạm khoá",
      value: false
    },
  ]

  const handleVisibleChange = (visible) => {
    setFilterVisible(visible)
  }

  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value)
  }

  const onChangeTypeFilter = (e) => {
    setFilterType(e)
    switch (e) {
      case "withCategory":
        action.searchProductReducer.onGetListCategory(
          {},
          dispatch.searchProductReducer
        );
        return;
      case "withBrand":
        action.searchProductReducer.onGetListBrand(
          { isFull: true },
          dispatch.searchProductReducer
        );
        return
      default:
        break;
    }
  }

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "withIsActive":
        return valueOptions
      case "withCategory":
        return categories
      case "withBrand":
        return brands
      case "withTags":
        return tags
      default:
        break;
    }
  }

  useEffect(() => {
    if (filterType === "withIsActive") {
      form.setFieldsValue({
        filterType: "withIsActive",
        filterValue: null
      });
    } else if (filterType === "withCategory") {
      form.setFieldsValue({
        filterType: "withCategory",
        filterValue: []
      });
    } else if (filterType === "withBrand") {
      form.setFieldsValue({
        filterType: "withBrand",
        filterValue: []
      });
    } else if (filterType === "withTags") {
      form.setFieldsValue({
        filterType: "withTags",
        filterValue: []
      });
    }
  }, [filterType, categories, brands, tags])

  function onSetCategories() {
    if (orArray('searchProductReducer.categories', state)) {
      setCategories(orArray('searchProductReducer.categories', state).map(
        (item) => ({ value: item.id, label: item.name })
      )
      );
    }
  }

  function onSetTags() {
    if (listTag) {
      setTags(listTag.map(
        (item) => ({ value: item.id, label: item.name })
      )
      );
    }
  }

  function onSetBrands() {
    if (orArray('searchProductReducer.brands', state)) {
      setBrands(orArray('searchProductReducer.brands', state).map(
        (item) => ({ value: item.id, label: item.name })
      )
      );
    }
  }

  useEffect(onSetCategories, [orArray('searchProductReducer.categories', state)])
  useEffect(onSetBrands, [orArray('searchProductReducer.brands', state)])
  useEffect(onSetTags, [listTag])

  const content = (
    <Form
      form={form}
      onFinish={onFinish}
      style={{ width: 300, maxWidth: 300 }}
    >
      <p>Hiển thị tất cả sản phẩm theo</p>
      <Form.Item
        name="filterType"
        style={{ marginBottom: 0 }}
      >
        <Selector onChange={onChangeTypeFilter} options={filterOptions} />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      <Form.Item
        name="filterValue"
        rules={[{ required: true, message: 'Vui lòng chọn thông tin để lọc' }]}
      >
        <Selector
          mode={optionMultiple.includes(filterType) ? "multiple" : null}
          options={getOptionFilter(filterType)}
          placeholder="Lựa chọn điều kiện lọc"
        />
      </Form.Item>
      <Form.Item>
        <Button onClick={() => setFilterVisible(false)} style={{ marginRight: 10 }}>Huỷ</Button>
        <Button htmlType="submit" type="primary">Thêm điều kiện lọc</Button>
      </Form.Item>
    </Form>
  );

  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title="Thêm điều kiện lọc"
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>Thêm điều kiện lọc</Button>
          </Popover>
        </Col>
        <Col span={18}>
          <Input value={searchValue} onChange={onChangeSearchValue} allowClear placeholder="Tìm kiếm theo tên sản phẩm ..." />
        </Col>
      </Row>
      <Row style={{ marginTop: 15 }} gutter={24}>
        <Col span={24}>
          {listFilter.map((item, index) => {
            return (
              <Tag key={index} closable onClose={(e) => handleRemoveFilter(e, item)}>
                {item.label}
              </Tag>
            )
          })}
        </Col>
      </Row>
    </div>
  );
}

export default withReducer({
  key: "searchProductReducer",
  ...productReducer
})(Search);
