import { useHistory, useParams } from "react-router-dom";
import productReducer from "../../../Reducer";
import { withReducer } from "hoc";
import React, { useEffect, useState } from "react";
import { orBoolean, orEmpty, orNull, orArray } from "utils/Selector";
import helper from "utils/Helpers";
import {
    Row,
    Col,
    Input,
    Button,
    Popconfirm,
    Typography,
    Divider,
    Table,
    Avatar, Tag, PageHeader
} from 'antd';
import { LeftCircleOutlined, PlusCircleOutlined } from "@ant-design/icons";
import { ChooseProductsTable } from 'components';
import useDebounce from "hook/useDebounce";

const { Title } = Typography;

function ListProduct(props) {
    const { dispatch, action, state, isHeader = true } = props
    const history = useHistory();
    const params = useParams()
    const [searchValue, setSearchValue] = useState("")
    const [cacheDataTable, setCacheDataTable] = useState([])
    const [dataTable, setDataTable] = useState([])
    const [chooseProduct, setChooseProduct] = useState({
        status: false,
        data: []
    })
    const [selectProducts, setSelectProducts] = useState({
        selectedKeys: [],
        selectedDatas: []
    })
    const inputDebounce = useDebounce(searchValue, 300)


    useEffect(() => {
        if (inputDebounce) {
            setDataTable(dataTable.filter((item) => item.name.toLowerCase().includes(searchValue.toLowerCase().replace(" ", ""))))
            return
        }
    }, [inputDebounce])

    useEffect(() => {
        if (searchValue === "") {
            setDataTable(cacheDataTable)
        }
    }, [searchValue])


    function onSetup() {
        action.listRelatedProduct.getListRelatedProducts(
            orEmpty('id', params),
            dispatch.listRelatedProduct
        );
    }

    const onChangeSearchValue = (e) => {
        setSearchValue(e.target.value)
    }

    function onCancelClick() {
        history.goBack()
    }

    function onClickUpdate(id) {
        if (id) {
            history.push(`/products/update/${id}`)
        }
    }

    const columns = [
        {
            title: "Ảnh",
            dataIndex: "image",
            render(value, record) {
                return {
                    props: {
                        style: { padding: "0" }
                    },
                    children: (
                      <div style={{ cursor: "pointer" }} onClick={() => onClickUpdate(record.id)}>
                          <Avatar size={48} src={value} />
                      </div>
                    )
                };
            },
            width: "5%"
        },
        {
            title: "Tên sản phẩm",
            render: (record) => (
              <div>
                  <a onClick={() => onClickUpdate(record.id)} style={{ cursor: "pointer", fontWeight: "bold", display: 'block' }}>{record.name}</a>
                  <span style={{fontSize: 12, color: "grey"}}>{record.totalVariant} biến thể</span>
              </div>
            ),
            width: '45%',
        },
        {
            title: "Trạng thái",
            dataIndex: "isActive",
            render: (value) => (value ? <Tag color="#108ee9">Hiển thị</Tag> : <Tag>Tạm khóa</Tag>),
            width: "15%"
        },
        {
            title: 'Giá sản phẩm',
            dataIndex: 'price',
            key: 'price',
            width: '15%',
        },
        {
            title: 'Danh mục',
            dataIndex: 'category',
            key: 'category',
            width: '20%',
        },
    ]

    const onUpdateData = () => {
        const related = orArray('listRelatedProduct.listRelatedProducts', state)
        if (related) {
            const result = related.map((item, index) => ({
                key: `${orEmpty("id", item)}--${index}`,
                id: orEmpty("id", item),
                name: orEmpty("name", item),
                image: orEmpty("featuredImage.url", item),
                price: orEmpty("staticPrice.minPrice", item) === orEmpty("staticPrice.maxPrice", item)
                    ? helper.currencyFormatVND(orEmpty("staticPrice.maxPrice", item))
                    : `${helper.currencyFormatVND(orEmpty("staticPrice.minPrice", item))} - ${helper.currencyFormatVND(orEmpty("staticPrice.maxPrice", item))}`,
                category: orEmpty("category.name", item),
                totalVariant: orEmpty("totalVariant", item)
            }))
            setDataTable(result)
            setCacheDataTable(result)
        }
    }

    const rowSelection = {
        selectedRowKeys: selectProducts.selectedKeys,
        onChange: (selectedkeys, selectedRows) => {
            setSelectProducts({
                selectedKeys: selectedkeys,
                selectedDatas: selectedRows
            })
        },
    };

    function onDeleteItems() {
        const listProduct = selectProducts.selectedDatas.map((item) => (
            item.id
        ))
        const body = {
            action: "DELETE",
            payloads: listProduct
        }
        action.listRelatedProduct.onUpdateRelatedProducts(
            orEmpty('id', params),
            body,
            dispatch.listRelatedProduct
        );
    }

    const onRefresh = () => {
        if (orBoolean('listRelatedProduct.isRefresh', state)) {
            onSetup()
            setSelectProducts({
                selectedKeys: [],
                selectedDatas: []
            })
        }
    }

    function handleConfirmChooseProduct(datas) {
        const listProduct = datas.map((item) => (
            item.id
        ))
        const body = {
            action: "ADD",
            payloads: listProduct
        }
        action.listRelatedProduct.onUpdateRelatedProducts(
            orEmpty('id', params),
            body,
            dispatch.listRelatedProduct
        );
        setChooseProduct({
            status: false,
            data: []
        })
    }

    const TableComponent = React.useCallback(() => {
        return (
            <Table
                className="product-table-wrapper"
                columns={columns}
                rowKey="key"
                rowSelection={{ ...rowSelection, checkStrictly: false }}
                dataSource={dataTable}
            />
        )
    }, [dataTable, selectProducts])

    useEffect(onRefresh, [orBoolean('listRelatedProduct.isRefresh', state)])
    useEffect(onSetup, [params])
    useEffect(onUpdateData, [orArray('listRelatedProduct.listRelatedProducts', state)])

    return (
        <div style={{ backgroundColor: "#fff", padding: 15 }} className="search-wrapper">
            {isHeader ?
              <PageHeader
                style={{padding: 0}}
                ghost={true}
                title={orEmpty("listRelatedProduct.detailProduct.name", state)}
                subTitle={"Danh sách sản phẩm liên quan"}
                extra={[
                    <Button onClick={() => onClickUpdate(orEmpty("listRelatedProduct.detailProduct.id", state))} icon={<LeftCircleOutlined />}>
                        Quay lại
                    </Button>
                ]}
              />
                : null}

            <Divider />
            <Row gutter={24}>
                <Col span={14}>
                    Hành động:
                    <Popconfirm
                        placement="bottom"
                        title={`Bạn chắc chắn muốn xoá ${selectProducts.selectedDatas.length} sản phẩm`}
                        onConfirm={onDeleteItems}
                        okText="Xác nhận"
                        cancelText="Hủy"
                    >
                        <Button
                            disabled={selectProducts.selectedDatas.length ? false : true}
                            style={{ marginLeft: 10 }}
                            type="primary"
                        >
                            Xoá {selectProducts.selectedDatas.length} sản phẩm
                        </Button>
                    </Popconfirm>
                    <Button
                        style={{ marginLeft: 10 }}
                        type="primary"
                        icon={<PlusCircleOutlined />}
                        onClick={() => setChooseProduct(prevState => ({ ...prevState, status: true }))}
                    >
                        Thêm sản phẩm
                    </Button>
                </Col>
                <Col
                    style={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center"
                    }}
                    span={10}
                >
                    <Input value={searchValue} onChange={onChangeSearchValue} allowClear placeholder="Tìm kiếm theo tên sản phẩm ..." />
                </Col>
            </Row>
            <Divider />
            <Row gutter={24}>
                <Col span={24}>
                    <TableComponent />
                </Col>
            </Row>
            {chooseProduct.status ?
                <ChooseProductsTable
                    visible={chooseProduct.status}
                    listItemChoose={chooseProduct.data}
                    itemReject={[orEmpty("listRelatedProduct.detailProduct.id", state)]}
                    itemDisable={orArray('listRelatedProduct.listRelatedProducts', state).map((item) => ({ product: item }))}
                    handleCancel={() => setChooseProduct(prevState => ({ ...prevState, status: false }))}
                    allowInactive={true}
                    handleConfirm={handleConfirmChooseProduct}
                />
                : null}
        </div>
    );
}

export default withReducer({
    key: "listRelatedProduct",
    ...productReducer
})(ListProduct);