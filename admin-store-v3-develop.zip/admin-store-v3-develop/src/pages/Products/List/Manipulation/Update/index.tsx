import { Form } from "../../../private-components"
import { useHistory, useParams } from "react-router-dom";
import productReducer from "../../../Reducer";
import { withReducer } from "hoc";
import { useEffect } from "react";
import { orBoolean, orEmpty, orNull } from "utils/Selector";

function Update(props) {
    const { dispatch, action, state } = props
    const history = useHistory();
    const params = useParams()

    function onSetup() {
        action.updateProductReducer.detailProduct(
            orEmpty('id', params),
            dispatch.updateProductReducer
        );
    }

    function onCancelClick() {
        history.push("/products");
    };

    function onSave(body) {
        action.updateProductReducer.updateProduct(
            body,
            dispatch.updateProductReducer
        );
    }

    const onRefresh = () => {
        if (orBoolean('updateProductReducer.isRefresh', state)) {
            onSetup()
        }
    }

    function onClickActive(value) {
        if (orBoolean('updateProductReducer.detailProduct.isActive', state)) {
            action.updateProductReducer.onDeactiveProduct(
                value,
                dispatch.updateProductReducer
            );
            return
        }
        action.updateProductReducer.onActiveProduct(
            value,
            dispatch.updateProductReducer
        );
    }

    function onUpdateOutOfStock(body) {
        action.updateProductReducer.onUpdateOutOfStock(
            body,
            dispatch.updateProductReducer
        );
    }

    function onDeleteProduct(id) {
        action.updateProductReducer.deleteProduct(
            id,
            dispatch.updateProductReducer
        );
    }

    const onRedirect = () => {
        if (orBoolean('updateProductReducer.isRedirect', state)) {
            onCancelClick()
        }
    }

    useEffect(onRedirect, [orBoolean('updateProductReducer.isRedirect', state)])

    useEffect(onSetup, [params])
    useEffect(onRefresh, [orBoolean('updateProductReducer.isRefresh', state)])

    return <Form
        item={orNull('updateProductReducer.detailProduct', state)}
        onRefreshDetail={onSetup}
        isUpdate={orEmpty('id', params)}
        onCancelClick={onCancelClick}
        onSave={onSave}
        onClickActive={onClickActive}
        onUpdateOutOfStock={onUpdateOutOfStock}
        onDeleteProduct={onDeleteProduct}
    />;
}

export default withReducer({
    key: "updateProductReducer",
    ...productReducer
})(Update);
