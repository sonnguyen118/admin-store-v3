import { Form } from "../../../private-components"
import { useHistory } from "react-router-dom";
import productReducer from "../../../Reducer";
import { withReducer } from "hoc";
import { useEffect } from "react";
import { orBoolean } from "utils/Selector";

function Create(props) {
  const { dispatch, action, state } = props
  const history = useHistory();

  function onCancelClick() {
    history.goBack();
  };

  function onSave(body) {
    action.createProductReducer.createProduct(
      body,
      dispatch.createProductReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean('createProductReducer.isRedirect', state)) {
      onCancelClick()
    }
  }

  useEffect(onRedirect, [orBoolean('createProductReducer.isRedirect', state)])

  return <Form onCancelClick={onCancelClick} onSave={onSave} />;
}

export default withReducer({
  key: "createProductReducer",
  ...productReducer
})(Create);
