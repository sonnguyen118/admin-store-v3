import React, { useState, useEffect, useMemo } from "react";
import { Table, Avatar, Checkbox, Popconfirm, Button, Space, Tag } from "antd";
import productReducer from "../Reducer";
import { withReducer } from "hoc";
import { EditOutlined } from '@ant-design/icons';
import { useHistory } from "react-router-dom";
import { orArray, orNumber, orEmpty } from "utils/Selector";
import Search from "../Search"
import helper from "utils/Helpers";
import queryString from "query-string";
import { onDetailProduct } from "../Reducer/action-type";

function List(props) {
  const history = useHistory();
  const { dispatch, action, state } = props;
  const [selectedListRow, setSelectedListRow] = useState([]);
  const [rows, setRows] = useState([]);
  const [checked, setChecked] = useState(false);

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: data.page ? parseInt(data.page as string) : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15
    }
  }, [history.location.search]);

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize
  })

  function onSetup() {
    action.productReducer.onGetListTag(
      {},
      dispatch.productReducer
    );
  }

  useEffect(() => { onSetup() }, [])

  useEffect(() => {
    action.productReducer.onGetListProduct(
      filter,
      dispatch.productReducer
    );
  }, [filter])

  function onDetailProduct(e, id): any {
    e.preventDefault();
    history.push(`/products/update/${id}`)
  }

  const columns = [
    {
      title: "Ảnh",
      dataIndex: "thumbUrl",
      render(value, record) {
        return {
          props: {
            style: { padding: "10px" }
          },
          children: (
            <a onClick={(e) => onDetailProduct(e, record.id)} rel="noreferrer" href={`/products/update/${record.id}`} style={{ cursor: "pointer" }}>
              <Avatar size={64} src={value} />
            </a>
          )
        };
      },
      width: "5%"
    },
    {
      title: "Tên sản phẩm",
      render: (record) => (
        <div>
          <div style={{ display: "flex" }}>
            <a onClick={(e) => onDetailProduct(e, record.id)} rel="noreferrer" href={`/products/update/${record.id}`} style={{ cursor: "pointer", fontWeight: "bold", display: 'block' }}>{record.name}</a>
            {record.isOutOfStock ?
              <Tag style={{ marginLeft: 5 }} color="#d1d1d1">
                <span style={{ color: "black" }}>Hết hàng</span>
              </Tag> :
              null}

          </div>
          <span style={{ fontSize: 12, color: "grey" }}>{record.totalVariant} biến thể</span>
        </div>
      ),
      width: '60%',
    },
    {
      title: "Trạng thái",
      dataIndex: "isActive",
      render: (value) => (value ? <Tag color="#108ee9">Kích hoạt</Tag> : <Tag>Chưa kích hoạt</Tag>),
      width: "10%"
    },
    {
      title: "Loại",
      dataIndex: "category",
      width: "15%"
    },
    {
      title: "Thương hiệu",
      dataIndex: "brand",
      width: "10%"
    }
  ];

  function onUpdateData(): void {
    const listProduct = orArray('productReducer.products', state)
    if (listProduct) {
      const r = [] as any;
      listProduct.forEach((node, index): void => {
        r.push({
          key: index,
          id: node.id,
          name: node.name,
          isActive: node.isActive,
          totalVariant: node.totalVariant,
          category: node.category.name,
          brand: node.brand.name,
          thumbUrl: node.featuredImage.url,
          isOutOfStock: node.isOutOfStock
        });
      });

      setRows(r);
    }
  }

  useEffect(() => {
    if (query.page !== filter.page || query.pageSize !== filter.pageSize) {
      setFilter(prevState => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize
        }
      })
    }
  }, [query]);

  function onChangePage(page) {
    history.push({
      pathname: "products",
      search: queryString.stringify({ ...query, page })
    })
  }

  function showTotal(total) {
    return `Tổng: ${total}`;
  }

  useEffect(() => onUpdateData(), [orArray('productReducer.products', state)]);

  return (
    <div className="list-wrapper">
      <Search
        filter={filter}
        setFilter={setFilter}
        onChangePage={onChangePage}
        listTag={orArray('productReducer.tags', state)}
      />
      <Table
        columns={columns}
        dataSource={rows}
        pagination={{
          defaultPageSize: filter.pageSize,
          defaultCurrent: filter.page,
          current: filter.page,
          total: orNumber('productReducer.productMeta.total', state),
          onChange: onChangePage,
          showSizeChanger: false,
          showTotal: showTotal
        }}
      />
    </div>
  );
}

export default withReducer({
  key: "productReducer",
  ...productReducer
})(List);
