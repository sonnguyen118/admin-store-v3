import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  LIST_BLOG_CATEGORIES,
  SLUG_CHECK,
  CREATE_BLOG_CATEGORY,
  DETAIL_BLOG_CATEGORY,
  UPDATE_BLOG_CATEGORY,
  UPDATE_STATUS_BLOG_CATEGORIES,
  UPDATE_ISACTIVE_BLOG_CATEGORY
} from "./action-type";

const initialState = ({
  isLoading: false,
  counter: 0,
  statusSlug: null,
});

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null
      };
    case LIST_BLOG_CATEGORIES:
      return {
        ...state,
        ...action.payload,
      };
    case SLUG_CHECK:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_BLOG_CATEGORY:
      return {
        ...state,
        ...action.payload,
      };
    case DETAIL_BLOG_CATEGORY:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_BLOG_CATEGORY:
      const { updateBlogCategory } = action.payload
      delete action.payload.detailBlogCategory;
      return {
        ...state,
        ...action.payload,
        detailBlogCategory: updateBlogCategory
      };
    case UPDATE_STATUS_BLOG_CATEGORIES:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_ISACTIVE_BLOG_CATEGORY:
      const { isActive, message, type } = action.payload
      return {
        detailBlogCategory: {
          ...state.detailBlogCategory,
          isActive: isActive
        },
        message: message,
        type: type
      }
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer
};
