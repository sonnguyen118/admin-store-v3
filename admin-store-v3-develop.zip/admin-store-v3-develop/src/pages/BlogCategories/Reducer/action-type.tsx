export const INCREMENT_LOADING = "blog-categories/INCREMENT_LOADING";
export const DECREMENT_LOADING = "blog-categories/DECREMENT_LOADING";
export const LIST_BLOG_CATEGORIES = "blog-categories/LIST_BLOG_CATEGORIES";
export const SLUG_CHECK = "blog-categories/SLUG_CHECK";
export const CREATE_BLOG_CATEGORY = "blog-categories/CREATE_BLOG_CATEGORY";
export const DETAIL_BLOG_CATEGORY = "blog-categories/DETAIL_BLOG_CATEGORY";
export const UPDATE_BLOG_CATEGORY = "blog-categories/UPDATE_BLOG_CATEGORY";
export const UPDATE_STATUS_BLOG_CATEGORIES = "blog-categories/UPDATE_STATUS_BLOG_CATEGORIES";
export const UPDATE_ISACTIVE_BLOG_CATEGORY = "blog-categories/UPDATE_ISACTIVE_BLOG_CATEGORY";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListBlogCategories = payload => {
  return {
    payload,
    type: LIST_BLOG_CATEGORIES
  };
};

export const setCheckSlug = payload => {
  return {
    payload,
    type: SLUG_CHECK
  };
};

export const setCreateBlogCategory = payload => {
  return {
    payload,
    type: CREATE_BLOG_CATEGORY
  };
};

export const setDetailBlogCategory = payload => {
  return {
    payload,
    type: DETAIL_BLOG_CATEGORY
  };
};

export const setUpdateBlogCategory = payload => {
  return {
    payload,
    type: UPDATE_BLOG_CATEGORY
  };
};

export const setUpdateStatusBlogCategories = payload => {
  return {
    payload,
    type: UPDATE_STATUS_BLOG_CATEGORIES
  };
};

export const setUpdateIsActiveBlogCategory = payload => {
  return {
    payload,
    type: UPDATE_ISACTIVE_BLOG_CATEGORY
  };
};



