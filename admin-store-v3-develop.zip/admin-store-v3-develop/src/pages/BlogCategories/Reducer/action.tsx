import { BlogCategories as BlogCategoriesAPI } from "api";
import { orArray, orBoolean, orEmpty, orNull, orNumber } from "utils/Selector";
import {
    IncrementLoading,
    DecrementLoading,
    setListBlogCategories,
    setCheckSlug,
    setCreateBlogCategory,
    setDetailBlogCategory,
    setUpdateBlogCategory,
    setUpdateStatusBlogCategories,
    setUpdateIsActiveBlogCategory
} from "./action-type";

export const getListBlogCategories = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.getListBlogCategories(params);
        const { data, status } = response;
        if (status === 200) {
            const meta = {
                page: data.data.page,
                pageSize: data.data.pageSize,
                total: data.data.total,
            };
            const listBlogCategories = orArray("data.datas", data);
            return dispatch(
                setListBlogCategories({
                    blogCategories: listBlogCategories,
                    blogCategoriesMeta: meta,
                })
            );
        }
    } catch (error) {
        return dispatch(
            setListBlogCategories({
                blogCategories: [],
                blogCategoriesMeta: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const slugCheck = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.slugCheckBlogCategory(params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setCheckSlug({
                    statusSlug: orBoolean("data.status", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setCheckSlug({
                statusSlug: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const createBlogCategory = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.createBlogCategory(params);
        if (response) {
            switch (orNumber("data.meta.status", response)) {
                case 3000:
                    return dispatch(
                        setCreateBlogCategory({
                            type: "warning",
                            message: orEmpty("data.meta.internalMessage", response),
                        })
                    )
                default:
                    return dispatch(
                        setCreateBlogCategory({
                            type: "success",
                            isRedirect: true,
                            message: "Tạo mới thành công"
                        })
                    )
            }
        }
    } catch (error) {
        return dispatch(
            setCreateBlogCategory({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const detailBlogCategory = async (id, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.detailBlogCategory(id);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setDetailBlogCategory({
                    detailBlogCategory: data.data
                })
            )
        }
    } catch (error) {
        return dispatch(
            setDetailBlogCategory({
                detailBlogCategory: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const updateBlogCategory = async (id, params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.updateBlogCategory(id, params);
        const { data } = response;
        if (response) {
            switch (orNumber("data.meta.status", response)) {
                case 3000:
                    return dispatch(
                        setCreateBlogCategory({
                            type: "warning",
                            message: orEmpty("data.meta.internalMessage", response),
                        })
                    )
                default:
                    return dispatch(
                        setUpdateBlogCategory({
                            type: "success",
                            message: "Cập nhật thành công",
                            updateBlogCategory: orNull("data", data)
                        })
                    )
            }
        }
    } catch (error) {
        return dispatch(
            setUpdateBlogCategory({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const setSlugStatus = async (dispatch) => {
    return dispatch(
        setCheckSlug({
            statusSlug: null
        })
    )
};

export const updateStatusBlogCategories = async (params, dispatch) => {
    dispatch(IncrementLoading);
    let isSuccess = false;
    try {
        const response = await BlogCategoriesAPI.updateStatusBlogCategories(params);
        const { status } = response;
        if (status === 200) {
            isSuccess = true
            return dispatch(
                setUpdateStatusBlogCategories({
                    isRefresh: true,
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateStatusBlogCategories({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        dispatch(
            setUpdateStatusBlogCategories({
                isRefresh: false,
                message: isSuccess && "Cập nhật thành công",
                type: isSuccess && "success",
            })
        )
        return dispatch(DecrementLoading);
    }
};

export const updateIsActiveBlogCategory = async (id, params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await BlogCategoriesAPI.updatIsActiveBlogCategory(id, params);
        const { status, data } = response;
        if (status === 200) {
            return dispatch(
                setUpdateIsActiveBlogCategory({
                    message: "Cập nhật thành công",
                    type: "success",
                    isActive: orBoolean("data.isActive", data),
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateStatusBlogCategories({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};