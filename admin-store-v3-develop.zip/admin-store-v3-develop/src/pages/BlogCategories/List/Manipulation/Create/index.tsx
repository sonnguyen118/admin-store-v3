import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orArray, orBoolean, orNull } from "utils/Selector";
import createBlogCategoryReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory } from "react-router-dom";

function Create(props) {
  const { action, state, dispatch } = props
  const history = useHistory();

  function onCancelClick() {
    history.push("/blog-categories");
  }

  function onSearchSlug(slug) {
    action.createBlogCategoryReducer.slugCheck(
      { s: slug },
      dispatch.createBlogCategoryReducer
    );
  }

  function onGetListBlogCategories() {
    action.createBlogCategoryReducer.getListBlogCategories(
      { isFull: true },
      dispatch.createBlogCategoryReducer
    );
  }

  function onSave(body) {
    action.createBlogCategoryReducer.createBlogCategory(
      body,
      dispatch.createBlogCategoryReducer
    );
  }

  function setSlugStatusToNull() {
    action.createBlogCategoryReducer.setSlugStatus(
      dispatch.createBlogCategoryReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean('createBlogCategoryReducer.isRedirect', state)) {
      onCancelClick()
    }
  }

  useMemo(onRedirect, [orBoolean('createBlogCategoryReducer.isRedirect', state)])
  useMemo(onGetListBlogCategories, [])

  return <Form
    onSearchSlug={onSearchSlug}
    statusSlug={orNull("createBlogCategoryReducer.statusSlug", state)}
    parentCategories={orArray("createBlogCategoryReducer.blogCategories", state).filter(item => item.isParent)}
    onSave={onSave}
    onCancelClick={onCancelClick}
    setSlugStatusToNull={setSlugStatusToNull}
  />;
}

export default withReducer({
  key: "createBlogCategoryReducer",
  ...createBlogCategoryReducer
})(Create);
