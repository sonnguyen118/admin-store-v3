import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orArray, orBoolean, orEmpty, orNull } from "utils/Selector";
import updateBlogCategoryReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory, useParams } from "react-router-dom";

function Update(props) {
    const { action, state, dispatch } = props
    const history = useHistory();
    const params = useParams()

    function onSetup() {
        action.updateBlogCategoryReducer.detailBlogCategory(
            orEmpty('id', params),
            dispatch.updateBlogCategoryReducer
        );
    }

    function onCancelClick() {
        history.push("/blog-categories");
    }

    function onGetListCategories() {
        action.updateBlogCategoryReducer.getListBlogCategories(
          { isFull: true },
          dispatch.updateBlogCategoryReducer
        );
      }

    function onSave(body) {
        const { id, ...ortherParams } = body
        action.updateBlogCategoryReducer.updateBlogCategory(
            id,
            ortherParams,
            dispatch.updateBlogCategoryReducer
        );
    }

    const onRedirect = () => {
        if (orBoolean('updateBlogCategoryReducer.isRedirect', state)) {
            onCancelClick()
        }
    }

    const onUpdateIsActive = (body) =>{
        const { id, ...ortherParams } = body
        action.updateBlogCategoryReducer.updateIsActiveBlogCategory(
            id,
            ortherParams,
            dispatch.updateBlogCategoryReducer
        );
    }

    useMemo(onRedirect, [orBoolean('updateBlogCategoryReducer.isRedirect', state)])
    useMemo(onSetup, [orEmpty('id', params)])
    useMemo(onGetListCategories, [])

    return <Form
    user={orNull("userReducer.user", state)}
        item={orNull("updateBlogCategoryReducer.detailBlogCategory", state)}
        parentCategories={orArray("updateBlogCategoryReducer.blogCategories", state).filter(item => item.isParent)}
        onSave={onSave}
        onCancelClick={onCancelClick}
        onUpdateIsActive={onUpdateIsActive}
    />;
}

export default withReducer({
    key: "updateBlogCategoryReducer",
    ...updateBlogCategoryReducer
})(Update);
