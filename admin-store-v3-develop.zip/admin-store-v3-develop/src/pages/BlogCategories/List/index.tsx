import React, { useState, useMemo } from "react";
import Search from "../Search"
import blogCategoriesReducer from "../Reducer";
import { withReducer } from "hoc";
import queryString from "query-string";
import { useHistory } from "react-router-dom";
import { Table, ModalActiveStatus } from "../private-components";
import { orArray, orBoolean, orNull } from "utils/Selector";

function List(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  const [selectedItems, setSelectedItems] = useState([]);
  const [visible, setVisible] = useState({
    isActive: false
  });

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: data.page ? parseInt(data.page as string) : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15
    }
  }, [history.location.search]);

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize,
  });

  function onGetListBlogCategories() {
    action.blogCategoriesReducer.getListBlogCategories(
      filter,
      dispatch.blogCategoriesReducer
    );
  }

  useMemo(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "blog-categories",
        search: queryString.stringify({ ...query, page: query.page })
      })
      setFilter(prevState => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize
        }
      })
    }
  }, [query]);

  function onChangePage(page) {
    history.push({
      pathname: "blog-categories",
      search: queryString.stringify({ ...query, page })
    })
  }

  function onUpdateStatusBlogCategories(params) {
    action.blogCategoriesReducer.updateStatusBlogCategories(
      params,
      dispatch.blogCategoriesReducer
    );
  }

  function onVisible(isActive) {
    setVisible({ isActive });
  }

  function onSubmit(values) {
    const params = {
      payloads: selectedItems.map(item => (item.id))
    }
    if (visible.isActive) {
      onUpdateStatusBlogCategories({ ...params, key: "isActive", value: values.isActive })
      handleCancel()
      return
    }
  }

  function handleCancel() {
    onVisible(false)
  }

  function onDetailProductCategory(e, id) {
    e.preventDefault()
    history.push(`/blog-categories/update/${id}`)
  }

  useMemo(() => {
    onGetListBlogCategories()
  }, [filter]);

  useMemo(() => {
    if (orBoolean("blogCategoriesReducer.isRefresh", state)) {
      onGetListBlogCategories()
    }
  }, [orBoolean("blogCategoriesReducer.isRefresh", state)]);

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        onChangePage={onChangePage}
        selectedItems={selectedItems}
        onVisible={onVisible}
      />
      <Table
        categories={orArray("blogCategoriesReducer.blogCategories", state)}
        meta={orNull("blogCategoriesReducer.blogCategoriesMeta", state)}
        onChangePage={onChangePage}
        selectedItems={selectedItems}
        setSelectedItems={setSelectedItems}
        onDetailProductCategory={onDetailProductCategory}
      />
      <ModalActiveStatus visible={visible.isActive} onSubmit={onSubmit} handleCancel={handleCancel} />
    </div>
  );
}

export default withReducer({
  key: "blogCategoriesReducer",
  ...blogCategoriesReducer,
})(List);
