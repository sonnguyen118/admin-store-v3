import { Modal, Button, Form, Radio, Popconfirm } from 'antd';

export default function ModalActiveStatus(props) {
    const [form] = Form.useForm();
    const { visible, onSubmit, handleCancel } = props

    const handleSubmit = (values) => {
        onSubmit(values)
        form.setFieldsValue({
            isActive: null,
        });
    }

    return (
        <Modal
            visible={visible}
            title="Thay đổi trạng thái kích hoạt"
            onCancel={handleCancel}
            footer={[
                <Button key="back" onClick={handleCancel}>
                    Hủy
                </Button>,
                <Popconfirm placement="bottom" title={"Bạn xác nhận thay đổi trạng thái những danh mục đã chọn!"} onConfirm={form.submit} okText="Xác nhận" cancelText="Hủy">
                    <Button key="submit" type="primary">
                        Lưu
                    </Button>
                </Popconfirm>

            ]}
        >
            <Form
                layout="vertical"
                form={form}
                onFinish={handleSubmit}
            >
                <Form.Item
                    name="isActive"
                    style={{ textAlign: "center" }}
                    rules={[
                        { required: true, message: 'Vui lòng chọn trạng thái' }
                    ]}
                    required
                >
                    <Radio.Group>
                        <Radio value={true}>Kích hoạt</Radio>
                        <Radio value={false}>Không kích hoạt</Radio>
                    </Radio.Group>
                </Form.Item>
            </Form>

        </Modal>
    );
}
