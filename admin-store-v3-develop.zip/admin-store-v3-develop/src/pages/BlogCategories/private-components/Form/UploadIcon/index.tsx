import React, { useState } from 'react';
import { Card, Form } from "antd";
import { UploadSingle } from "components";
const { Item } = Form;
function UploadIcon(props): JSX.Element {
    const { image, setImage } = props

    return (
        <Card title="Ảnh đại diện" className="space-thumb-wrapper">
            <Item
                name="icon"
                rules={[
                    { required: true, message: "Vui lòng chọn ảnh đại diện" },
                ]}
                required
            >
                <UploadSingle style={{ width: 240, height: 240 }} image={image} setImage={setImage} />
            </Item>
        </Card>
    );
};

export default UploadIcon;