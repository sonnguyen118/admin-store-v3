import React, { useState } from 'react';
import { Card, Form } from "antd";
import { Selector } from "components";
import { Mocks } from 'utils';
const { Item } = Form;

function SelectCategoryParent(props): JSX.Element {
    const { parentCategories, item } = props

    const listOptionCategories = () => {
        const defaultOption = [
            {
                value: 'none',
                label: 'Không có danh mục cha'
            }
        ]
        if (item) {
            return defaultOption.concat(parentCategories.filter(category => category.id != item.id).map(item => ({
                value: item.id,
                label: item.name
            })))
        }
        return defaultOption.concat(parentCategories.map(item => ({
            value: item.id,
            label: item.name
        })))
    }

    return (
        <Card title="Danh mục cha" className="space-general-wrapper">
            <Item label="Danh mục cha" name="parentCategory">
                <Selector options={listOptionCategories()} placeholder="lựa chọn danh mục cha" />
            </Item>
        </Card>
    );
};

export default SelectCategoryParent;