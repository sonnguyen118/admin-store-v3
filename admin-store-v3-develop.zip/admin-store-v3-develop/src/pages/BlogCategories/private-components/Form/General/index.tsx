import React, { useState } from 'react';
import {
    Typography,
    Card,
    Input,
    Form,
    message,
} from "antd";
import { CheckSlug, Editor } from "components";
import { orEmpty, orNull } from 'utils/Selector';
import { Helpers } from 'utils';
import env from "configs/env";
const { Item } = Form;

function General(props): JSX.Element {
    const { slug, setSlug, form, item, setIsFinish, onSearchSlug, statusSlug, setSlugStatusToNull } = props
    function onChangeSlug(e) {
        form.setFieldsValue({
            pageSEO_title: e.target.value,
        });
        if (!orNull("id", item)) {
            setSlugStatusToNull()
            setSlug(Helpers.getSlug(e.target.value));
            setIsFinish((prevState) => ({
                ...prevState,
                status: false,
            }));
            form.setFieldsValue({
                slug: Helpers.getSlug(e.target.value),
            });
            return;
        }
    }

    function handleOnSearchSlug() {
        if (!orNull("id", item) && slug != "") {
            onSearchSlug(slug)
            return;
        }
        message.warning("Vui lòng nhập tên danh mục hoặc đường dẫn để kiểm tra");
        return;
    }

    function onChangeShortDescription(e) {
        form.setFieldsValue({
            pageSEO_description: e.target.value
        });
    }

    return (
        <Card title="Thông tin chung" className="space-general-wrapper">
            <Item
                name="name"
                label={
                    <span style={{ color: "#6c798f", fontWeight: "bold" }}>
                        Tên danh mục:
                    </span>
                }
                rules={[
                    { required: true, message: "Vui lòng nhập tên danh mục" },
                ]}
                required
            >
                <Input onChange={onChangeSlug} placeholder="Nhập tên danh mục" />
            </Item>
            <CheckSlug
                slug={slug}
                onChangeSlug={onChangeSlug}
                onSearchSlug={handleOnSearchSlug}
                addonSlug={`${env.base_url}/blogs`}
                statusSlug={statusSlug}
                idItem={orNull("id", item)}
                isActive={orNull("isActive", item)}
            />
            <Item
                name="description"
                label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Mô tả:</span>}
                htmlFor="name"
            >
                <Input.TextArea onChange={onChangeShortDescription} rows={7} placeholder="Mô tả cho danh mục" />
            </Item>
        </Card>
    );
};

export default General;