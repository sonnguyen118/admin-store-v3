import React, { useMemo, useState } from "react";
import { SimpleTabs } from "../../components";
import { Typography, Row, Col, Button } from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List"
import { useHistory } from "react-router-dom";
import { withReducer } from "hoc";
import blogReducer from "./Reducer";
import { orEmpty } from "utils/Selector";


const { Title } = Typography;

function Categories(props) {
  const { state } = props
  const history = useHistory()

  const isCTV = useMemo(() => {
    return orEmpty("userReducer.user.role", state) === "COLLABORATOR"
  }, [state.userReducer])


  const tabItems = [
    {
      title: "Tất cả danh mục",
      component: <List />
    }
  ];

  function onCreateBlogCategory() {
    history.push("/blog-categories/create");
  }

  return (
    <div>
      <Row>
        <Col span={8}>
          <Title level={2}>Quản lý danh mục bài viết</Title>
        </Col>
        <Col span={8} offset={8}>
          {!isCTV ?
            <Row>
              <Col span={10} offset={14}>
                <Button onClick={onCreateBlogCategory} type="primary" icon={<PlusCircleOutlined />}>
                  Tạo danh mục bài viết
                </Button>
              </Col>
            </Row>
            : null}

        </Col>
      </Row>
      <SimpleTabs tabItems={tabItems} />
    </div>
  );
}

export default withReducer({
  key: "blogReducer",
  ...blogReducer,
})(Categories);

