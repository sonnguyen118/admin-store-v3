import React, { useState, useMemo, useEffect } from "react";
import Search from "../Search"
import brandsReducer from "../Reducer";
import { withReducer } from "hoc";
import queryString from "query-string";
import { useHistory } from "react-router-dom";
import { Table, ModalActiveStatus, ModalShowStatus } from "../private-components";
import { orArray, orBoolean, orNull } from "utils/Selector";

function List(props) {
  const { dispatch, action, state } = props;
  const history = useHistory();

  const [selectedItems, setSelectedItems] = useState([]);
  const [visible, setVisible] = useState({
    isActive: false,
    isShow: false
  });

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      page: data.page ? parseInt(data.page as string) : 1,
      pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15
    }
  }, [history.location.search]);

  const [filter, setFilter] = useState({
    page: query.page,
    pageSize: query.pageSize,
  });

  function onGetListBrands() {
    action.brandsReducer.getListBrands(
      filter,
      dispatch.brandsReducer
    );
  }

  useEffect(() => {
    if (query.page || query.pageSize !== filter.pageSize) {
      history.push({
        pathname: "product-brands",
        search: queryString.stringify({ ...query, page: query.page })
      })
      setFilter(prevState => {
        return {
          ...prevState,
          page: query.page,
          pageSize: query.pageSize
        }
      })
    }
  }, [query]);

  function onChangePage(page) {
    history.push({
      pathname: "product-brands",
      search: queryString.stringify({ ...query, page })
    })
  }

  function onUpdateStatusBrands(params) {
    action.brandsReducer.updateStatusBrands(
      params,
      dispatch.brandsReducer
    );
  }

  function onVisible(isActive, isShow) {
    setVisible({ isActive, isShow });
  }

  function onSubmit(values) {
    const params = {
      payloads: selectedItems.map(item => (item.id))
    }
    if (visible.isActive) {
      onUpdateStatusBrands({ ...params, key: "isActive", value: values.isActive })
      handleCancel()
      return
    }
    if (visible.isShow) {
      onUpdateStatusBrands({ ...params, key: "isShow", value: values.isShow })
      handleCancel()
      return
    }

  }

  function handleCancel() {
    onVisible(false, false)
  }

  function onDeatilProductBrand(e, id) {
    e.preventDefault()
    history.push(`/product-brands/update/${id}`)
  }

  useMemo(() => {
    onGetListBrands()
  }, [filter]);

  useMemo(() => {
    if (orBoolean("brandsReducer.isRefresh", state)) {
      onGetListBrands()
    }
  }, [orBoolean("brandsReducer.isRefresh", state)]);

  return (
    <div>
      <Search
        filter={filter}
        setFilter={setFilter}
        onChangePage={onChangePage}
        selectedItems={selectedItems}
        onVisible={onVisible}
      />
      <Table
        brands={orArray("brandsReducer.brands", state)}
        meta={orNull("brandsReducer.brandsMeta", state)}
        onChangePage={onChangePage}
        selectedItems={selectedItems}
        setSelectedItems={setSelectedItems}
        onDeatilProductBrand={onDeatilProductBrand}
      />
      <ModalActiveStatus visible={visible.isActive} onSubmit={onSubmit} handleCancel={handleCancel} />
      <ModalShowStatus visible={visible.isShow} onSubmit={onSubmit} handleCancel={handleCancel} />
    </div>
  );
}

export default withReducer({
  key: "brandsReducer",
  ...brandsReducer,
})(List);
