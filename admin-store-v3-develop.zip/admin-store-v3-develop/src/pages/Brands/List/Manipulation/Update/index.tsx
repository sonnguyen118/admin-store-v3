import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orBoolean, orEmpty, orNull } from "utils/Selector";
import updateBrandReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory, useParams } from "react-router-dom";

function Update(props) {
    const { action, state, dispatch } = props
    const history = useHistory();
    const params = useParams()

    function onSetup() {
        action.updateBrandReducer.detailBrand(
            orEmpty('id', params),
            dispatch.updateBrandReducer
        );
    }

    function onCancelClick() {
        history.push("/product-brands");
    }

    function onSave(body) {
        const { id, ...ortherParams } = body
        action.updateBrandReducer.updateBrand(
            id,
            ortherParams,
            dispatch.updateBrandReducer
        );
    }

    const onRedirect = () => {
        if (orBoolean('updateBrandReducer.isRedirect', state)) {
            onCancelClick()
        }
    }

    useMemo(onRedirect, [orBoolean('updateBrandReducer.isRedirect', state)])
    useMemo(onSetup, [orEmpty('id', params)])

    return <Form
        item={orNull("updateBrandReducer.detailBrand", state)}
        onSave={onSave}
        onCancelClick={onCancelClick}
    />;
}

export default withReducer({
    key: "updateBrandReducer",
    ...updateBrandReducer
})(Update);
