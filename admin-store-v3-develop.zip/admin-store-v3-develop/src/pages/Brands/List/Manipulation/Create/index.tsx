import { Form } from "../../../private-components"
import { withReducer } from "hoc";
import { orBoolean, orNull } from "utils/Selector";
import createBrandReducer from "../../../Reducer";
import { useMemo } from "react";
import { useHistory } from "react-router-dom";

function Create(props) {
  const { action, state, dispatch } = props
  const history = useHistory();

  function onCancelClick() {
    history.push("/product-brands");
  }

  function onSearchSlug(slug) {
    action.createBrandReducer.slugCheck(
      { s: slug },
      dispatch.createBrandReducer
    );
  }

  function onSave(body) {
    action.createBrandReducer.createBrand(
      body,
      dispatch.createBrandReducer
    );
  }

  function setSlugStatusToNull() {
    action.createBrandReducer.setSlugStatus(
      dispatch.createBrandReducer
    );
  }

  const onRedirect = () => {
    if (orBoolean('createBrandReducer.isRedirect', state)) {
      onCancelClick()
    }
  }

  useMemo(onRedirect, [orBoolean('createBrandReducer.isRedirect', state)])

  return <Form
    onSearchSlug={onSearchSlug}
    statusSlug={orNull("createBrandReducer.statusSlug", state)}
    onSave={onSave}
    onCancelClick={onCancelClick}
    setSlugStatusToNull={setSlugStatusToNull}
  />;
}

export default withReducer({
  key: "createBrandReducer",
  ...createBrandReducer
})(Create);
