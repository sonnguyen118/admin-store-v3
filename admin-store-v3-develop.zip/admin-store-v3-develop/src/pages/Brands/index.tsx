import { SimpleTabs } from "../../components";
import { Typography, Row, Col, Button } from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import List from "./List"
import { useHistory } from "react-router-dom";

const { Title } = Typography;

export default function Brands() {
  const history = useHistory()

  const tabItems = [
    {
      title: "Tất cả thương hiệu",
      component: <List />
    }
  ];

  function onCreateBrand() {
    history.push("/product-brands/create");
  }



  return (
    <div>
      <Row>
        <Col span={8}>
          <Title level={2}>Quản lý thương hiệu</Title>
        </Col>
        <Col span={8} offset={8}>
          <Row>
            <Col span={10} offset={14}
            >
              <Button onClick={onCreateBrand} type="primary" icon={<PlusCircleOutlined />}>
                Tạo thương hiệu
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
      <SimpleTabs tabItems={tabItems} />
    </div>
  );
}
