export const INCREMENT_LOADING = "brands/INCREMENT_LOADING";
export const DECREMENT_LOADING = "brands/DECREMENT_LOADING";
export const LIST_BRANDS = "brands/LIST_BRANDS";
export const SLUG_CHECK = "brands/SLUG_CHECK";
export const CREATE_BRAND = "brands/CREATE_BRAND";
export const DETAIL_BRAND = "brands/DETAIL_BRAND";
export const UPDATE_BRAND = "brands/UPDATE_BRAND";
export const UPDATE_STATUS_BRANDS = "brands/UPDATE_STATUS_BRANDS";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListBrands = payload => {
  return {
    payload,
    type: LIST_BRANDS
  };
};

export const setCheckSlug = payload => {
  return {
    payload,
    type: SLUG_CHECK
  };
};

export const setCreateBrand = payload => {
  return {
    payload,
    type: CREATE_BRAND
  };
};

export const setDetailBrand = payload => {
  return {
    payload,
    type: DETAIL_BRAND
  };
};

export const setUpdateBrand = payload => {
  return {
    payload,
    type: UPDATE_BRAND
  };
};

export const setUpdateStatusBrands = payload => {
  return {
    payload,
    type: UPDATE_STATUS_BRANDS
  };
};

