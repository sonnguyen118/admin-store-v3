import { ProductBrands as ProductBrandsAPI } from "api";
import { orArray, orBoolean, orNull } from "utils/Selector";
import {
    IncrementLoading,
    DecrementLoading,
    setListBrands,
    setCheckSlug,
    setCreateBrand,
    setDetailBrand,
    setUpdateBrand,
    setUpdateStatusBrands
} from "./action-type";

export const getListBrands = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductBrandsAPI.getListProductBrands(params);
        const { data, status } = response;
        if (status === 200) {
            const meta = {
                page: data.data.page,
                pageSize: data.data.pageSize,
                total: data.data.total,
            };
            const listBrands = orArray("data.datas", data);
            return dispatch(
                setListBrands({
                    brands: listBrands,
                    brandsMeta: meta,
                })
            );
        }
    } catch (error) {
        return dispatch(
            setListBrands({
                brands: [],
                brandsMeta: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const slugCheck = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductBrandsAPI.slugCheck(params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setCheckSlug({
                    statusSlug: orBoolean("data.status", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setCheckSlug({
                statusSlug: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const createBrand = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductBrandsAPI.createBrand(params);
        const { status } = response;
        if (status === 200) {
            return dispatch(
                setCreateBrand({
                    type: "success",
                    isRedirect: true,
                    message: "Tạo mới thành công"
                })
            )
        }
    } catch (error) {
        return dispatch(
            setCreateBrand({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const setSlugStatus = async (dispatch) => {
    return dispatch(
        setCheckSlug({
            statusSlug: null
        })
    )
};



export const detailBrand = async (id, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductBrandsAPI.detailBrand(id);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setDetailBrand({
                    detailBrand: data.data
                })
            )
        }
    } catch (error) {
        return dispatch(
            setDetailBrand({
                detailBrand: null,
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const updateBrand = async (id, params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await ProductBrandsAPI.updateBrand(id, params);
        const { data, status } = response;
        if (status === 200) {
            return dispatch(
                setUpdateBrand({
                    type: "success",
                    message: "Cập nhật thương hiệu thành công",
                    updateBrand: orNull("data", data)
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateBrand({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const updateStatusBrands = async (params, dispatch) => {
    dispatch(IncrementLoading);
    let isSuccess = false;
    try {
        const response = await ProductBrandsAPI.updateStatusBrands(params);
        const { status } = response;
        if (status === 200) {
            isSuccess = true
            return dispatch(
                setUpdateStatusBrands({
                    isRefresh: true,
                })
            )
        }
    } catch (error) {
        return dispatch(
            setUpdateStatusBrands({
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error",
            })
        );
    } finally {
        dispatch(
            setUpdateStatusBrands({
                isRefresh: false,
                message: isSuccess && "Cập nhật thành công",
                type: isSuccess && "success",
            })
        )
        return dispatch(DecrementLoading);
    }
};