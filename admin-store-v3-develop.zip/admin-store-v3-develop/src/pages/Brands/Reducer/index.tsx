import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  LIST_BRANDS,
  SLUG_CHECK,
  CREATE_BRAND,
  DETAIL_BRAND,
  UPDATE_BRAND,
  UPDATE_STATUS_BRANDS
} from "./action-type";

const initialState = ({
  isLoading: false,
  counter: 0,
  statusSlug: null,
});

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null
      };
    case LIST_BRANDS:
      return {
        ...state,
        ...action.payload,
      };
    case SLUG_CHECK:
      return {
        ...state,
        ...action.payload,
      };
    case CREATE_BRAND:
      return {
        ...state,
        ...action.payload,
      };
    case DETAIL_BRAND:
      return {
        ...state,
        ...action.payload,
      };
    case UPDATE_BRAND:
      const { updateBrand } = action.payload
      delete action.payload.detailBrand;
      return {
        ...state,
        ...action.payload,
        detailBrand: updateBrand
      };
    case UPDATE_STATUS_BRANDS:
      return {
        ...state,
        ...action.payload,
      };

    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer
};
