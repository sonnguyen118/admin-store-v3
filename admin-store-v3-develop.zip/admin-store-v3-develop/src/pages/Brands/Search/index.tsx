import React, { useState, useMemo } from "react";
import { Row, Col, Input, Button, Popover, Form, Tag, Dropdown, Menu } from "antd";
import { FilterOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import { Selector } from "components";
import "./styled.scss"
import { Mocks } from "utils";
import { DownOutlined } from "@ant-design/icons";

const filterOptions = [
  {
    label: "Trạng thái kích hoạt",
    value: "withIsActive"
  },
  {
    label: "Trạng thái hiển thị",
    value: "withIsShow"
  },
]

export default function Filter(props) {
  const { setFilter, filter, onChangePage, selectedItems, onVisible } = props
  const [form] = Form.useForm();
  const [filterVisible, setFilterVisible] = useState(false);
  const [searchValue, setSearchValue] = useState("");
  const inputDebounce = useDebounce(searchValue, 300);
  const [listFilter, setListFilter] = useState([])
  const [filterType, setFilterType] = useState("withIsActive")

  function onSetupForm() {
    form.setFieldsValue({
      filterType: "withIsActive",
      filterValue: true
    });
  }


  const handleVisibleChange = (visible) => {
    setFilterVisible(visible);
  };


  const onChangeSearchValue = (e) => {
    setSearchValue(e.target.value);
  };

  const onFilter = (filterType, filterValue) => {
    switch (filterType) {
      case "withIsActive":
        setFilter(prevState => ({
          ...prevState,
          isActive: filterValue,
        }))
        return;
      case "withIsShow":
        setFilter(prevState => ({
          ...prevState,
          isShow: filterValue,
        }))
        return;
      default:
        break;
    }
  }

  const checkListFilter = (filterType, filterValue) => {
    const arr = [...listFilter];
    const resultItem = listFilter.findIndex(item => item.value === filterType)
    if (resultItem === -1) {
      arr.push({
        value: filterType,
        label: Mocks.BRANDS.getLabelFilter(filterType, filterValue)
      })
      setListFilter(arr)
    } else {
      listFilter[resultItem].label = Mocks.BRANDS.getLabelFilter(filterType, filterValue)
      setListFilter(arr)
    }
    return (
      form.setFieldsValue({
        filterType: filterType,
        filterValue: filterValue
      }),
      onFilter(filterType, filterValue),
      onChangePage(1)
    );
  }

  const onFinish = (values) => {
    checkListFilter(values.filterType, values.filterValue)
  }

  const onChangeTypeFilter = (e) => {
    setFilterType(e)
  }

  const getOptionFilter = (filterType) => {
    switch (filterType) {
      case "withIsActive":
        return Mocks.BRANDS.ActiveStatus
      case "withIsShow":
        return Mocks.BRANDS.ShowStatus
      default:
        break;
    }
  }

  const handleRemoveFilter = (e, item) => {
    e.preventDefault();
    setListFilter(listFilter.filter(node => node.value != item.value))
    if (item.value === 'withIsActive') {
      delete filter.isActive;
      setFilter({ ...filter });
      onChangePage(1);
    }
    if (item.value === 'withIsShow') {
      delete filter.isShow;
      setFilter({ ...filter });
      onChangePage(1);
    }
  }


  const content = (
    <Form
      form={form}
      onFinish={onFinish}
    >
      <p>Hiển thị tất cả thương hiệu theo</p>
      <Form.Item
        name="filterType"
        style={{ marginBottom: 0 }}
      >
        <Selector onChange={onChangeTypeFilter} options={filterOptions} />
      </Form.Item>
      <div style={{ margin: "10px 0" }}>Là</div>
      <Form.Item
        name="filterValue"
      >
        <Selector options={getOptionFilter(filterType)} />
      </Form.Item>
      <Form.Item>
        <Button style={{ marginRight: 10 }}>Huỷ</Button>
        <Button htmlType="submit" type="primary">Thêm điều kiện lọc</Button>
      </Form.Item>
    </Form>
  );

  function handleMenuClick({ key }) {
    switch (key) {
      case "isActiveBrands":
        onVisible(true, false);
        return;
      case "isShowBrands":
        onVisible(false, true);
        return;
      default:
        break;
    }
  }

  const menu = (
    <Menu onClick={handleMenuClick}>
      <Menu.Item key="isActiveBrands">
        Thay đổi trạng thái kích hoạt
      </Menu.Item>
      <Menu.Item key="isShowBrands">
        Thay đổi trạng thái hiển thị
      </Menu.Item>
    </Menu>
  );

  useMemo(() => {
    if (filterType === "withIsActive") {
      form.setFieldsValue({
        filterType: "withIsActive",
        filterValue: Mocks.BRANDS.ActiveStatus[0].value
      });
    }
    if (filterType === "withIsShow") {
      form.setFieldsValue({
        filterType: "withIsShow",
        filterValue: Mocks.BRANDS.ShowStatus[0].value
      });
    }
  }, [filterType])

  useMemo(() => {
    if (inputDebounce) {
      setFilter(prevState => ({
        ...prevState,
        s: searchValue
      }));
      onChangePage(1);
      return
    }
  }, [inputDebounce])


  useMemo(() => {
    if (searchValue === "" && filter.s) {
      delete filter.s;
      setFilter({ ...filter });
      onChangePage(1);
    }

  }, [searchValue, filter])


  useMemo(onSetupForm, []);


  return (
    <div className="search-wrapper">
      <Row gutter={24}>
        <Col span={6}>
          <Popover
            placement="bottom"
            title={"Thêm điều kiện lọc"}
            content={content}
            trigger="click"
            visible={filterVisible}
            onVisibleChange={handleVisibleChange}
          >
            <Button style={{ width: "100%" }} icon={<FilterOutlined />}>
              Thêm điều kiện lọc
            </Button>
          </Popover>
        </Col>
        <Col span={18}>
          <Input
            value={searchValue}
            onChange={onChangeSearchValue}
            allowClear
            placeholder={
              "Tìm kiếm theo tên thương hiệu"
            }
          />
        </Col>
      </Row>
      <Row style={{ marginTop: 15 }} gutter={24}>
        <Col span={24}>
          {listFilter.map((item, index) => {
            return (
              <Tag key={index} closable onClose={(e) => handleRemoveFilter(e, item)}>
                {item.label}
              </Tag>
            )
          })}
        </Col>
      </Row>
      {selectedItems.length ? (
        <div style={{ marginTop: 10 }}>
          <Dropdown overlay={menu} trigger={["click"]}>
            <Button>
              Chọn thao tác ({selectedItems.length} thương hiệu) <DownOutlined />
            </Button>
          </Dropdown>
        </div>
      ) : null}
    </div>
  );
}
