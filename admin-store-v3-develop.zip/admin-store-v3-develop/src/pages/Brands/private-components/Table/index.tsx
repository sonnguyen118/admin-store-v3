import React, { useEffect, useState } from 'react';
import { Table as SimpleTable, Typography, Tag } from "antd";
import { orEmpty, orNumber } from 'utils/Selector';

const { Link } = Typography

export default function Table(props) {
    const { brands, meta, onChangePage, selectedItems, setSelectedItems, onDeatilProductBrand } = props
    const [rows, setRows] = useState([]);
    const columns = [
        {
            title: "Hình ảnh",
            dataIndex: "icon",
            render: (value, record) => (
                <Link onClick={(e) => onDeatilProductBrand(e, record.id)} href={`/product-brands/update/${record.id}`}>
                    <img src={orEmpty("url", value) ? orEmpty("url", value) : "https://i.stack.imgur.com/y9DpT.jpg"} style={{ objectFit: "contain", width: 64, height: 64, borderRadius: 8 }} />
                </Link>

            ),
            width: "10%",
        },
        {
            title: "Tên thương hiệu",
            dataIndex: "name",
            render: (value, record) => (
                <Link onClick={(e) => onDeatilProductBrand(e, record.id)} href={`/product-brands/update/${record.id}`}>{value}</Link>
            )
        },
        {
            title: "Trạng thái hiển thị",
            dataIndex: "isShow",
            render: (value) => (value ? <Tag color="#108ee9">Hiển thị</Tag> : <Tag>Tạm ẩn</Tag>)
        },
        {
            title: "Trạng thái kích hoạt",
            dataIndex: "isActive",
            render: (value) => (value ? <Tag color="#108ee9">Đã kích hoạt</Tag> : <Tag>Chưa kích hoạt</Tag>)
        }
    ];

    function onUpdateData(): void {
        if (brands) {
            const r = [] as any;

            brands.forEach((node): void => {
                r.push({
                    key: node.id,
                    ...node
                });
            });
            setRows(r);
        }
    }

    const rowSelection = {
        selectedRowKeys: selectedItems.map((item) => orEmpty("key", item)),
        onSelect: (record, selected) => {
            if (selected) {
                const r = selectedItems.slice()
                r.push(record)
                setSelectedItems(r)
                return;
            } else {
                setSelectedItems(prevState => prevState.filter(item => item.id != record.id))
            }
        },
        onSelectAll: (selected, selectedRows, changeRows) => {
            if (selected) {
                const r = selectedItems.slice()
                setSelectedItems(r.concat(selectedRows).filter(item => item))
                return
            } else {
                const r = selectedItems.slice()
                const data = []
                r.forEach(e => {
                    const result = changeRows.find(item => item.key === e.key)
                    if (!result) {
                        data.push(e)
                        return
                    }
                })
                setSelectedItems(data)
            }
        },
    };

    function showTotal(total) {
        return `Tổng: ${total}`;
    }

    useEffect(onUpdateData, [brands]);

    return (
        <SimpleTable
            rowSelection={rowSelection}
            columns={columns}
            dataSource={rows}
            pagination={{
                defaultPageSize: 15,
                defaultCurrent: orNumber("page", meta),
                current: orNumber("page", meta),
                total: orNumber("total", meta),
                onChange: onChangePage,
                showSizeChanger: false,
                showTotal: showTotal
            }} />
    );
}
