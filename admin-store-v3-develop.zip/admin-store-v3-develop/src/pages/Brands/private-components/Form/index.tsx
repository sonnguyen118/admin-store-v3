import React, { useMemo, useState } from 'react';
import {
  Row,
  Col,
  Form as FormBase,
  Space,
  notification
} from "antd";
import Header from "./Header"
import General from "./General";
import UploadIcon from "./UploadIcon"
import UploadBanner from "./UploadBanner"
import OptimalSEO from './OptimalSEO';
import Setting from "./Setting"
import { orBoolean, orEmpty, orNull } from 'utils/Selector';
import { Mocks } from "utils"
import "./styled.scss"
export default function Form(props) {
  const { item, onSearchSlug, statusSlug, onSave, onCancelClick, setSlugStatusToNull } = props
  const [form] = FormBase.useForm();
  const [slug, setSlug] = useState("");
  const [icon, setIcon] = useState(null);
  const [banner, setBanner] = useState(null);
  const [isFinish, setIsFinish] = useState({
    status: false,
    data: {},
  });

  function onSetupForm() {
    if (item) {
      setSlug(orEmpty("slug", item));
      setIcon(orNull("icon", item));
      setBanner(orNull("banner", item))
      form.setFieldsValue({
        name: orEmpty("name", item),
        slug: orEmpty("slug", item),
        description: orEmpty("description", item),
        url: orEmpty("icon.url", item),
        isShow: orEmpty("isShow", item),
        pageSEO_title: orEmpty("pageSEO.title", item),
        pageSEO_keywords: orEmpty("pageSEO.keywords", item),
        pageSEO_description: orEmpty("pageSEO.description", item),
      });
      return;
    }
  }

  useMemo(onSetupForm, [item])

  function onFinish(values) {
    setIsFinish({
      status: true,
      data: Mocks.BRANDS.getBodyBrand(values),
    });
    if (orNull("id", item)) {
      if (
        !values.pageSEO_title &&
        !values.pageSEO_keywords &&
        !values.pageSEO_description
      ) {
        const newValues = {
          ...values,
          id: orEmpty("id", item),
          pageSEO_title: orEmpty("pageSEO.title", item),
          pageSEO_keywords: orEmpty("pageSEO.keywords", item),
          pageSEO_description: orEmpty("pageSEO.description", item),
          slug: orEmpty("slug", item),
        };
        onSave(Mocks.BRANDS.getBodyBrand({ ...newValues }));
        return;
      }
      onSave(
        Mocks.BRANDS.getBodyBrand({
          ...values,
          id: orEmpty("id", item),
          slug: orEmpty("slug", item),
        })
      );
      return;
    }
    if (statusSlug != null) {
      if (statusSlug) {
        onSave(Mocks.BRANDS.getBodyBrand(values))
      } else {
        notification["warning"]({
          message: "Không thể tạo mới thương hiệu",
          description:
            "Lỗi đường dẫn thương hiệu đã tồn tại, vui lòng kiểm tra và thử lại!",
        });
      }
      return;
    }
    onSearchSlug(slug);
  }

  useMemo(() => {
    if (statusSlug != null) {
      if (isFinish.status && statusSlug) {
        onSave(isFinish.data)
      } else if (isFinish.status && !statusSlug) {
        notification["warning"]({
          message: "Không thể tạo mới thương hiệu",
          description:
            "Lỗi đường dẫn thương hiệu đã tồn tại, vui lòng kiểm tra và thử lại!",
        });
      }
      return;
    }
  }, [statusSlug]);

  useMemo(() => {
    if (slug && statusSlug) {
      form.setFieldsValue({
        slug: slug,
      });
    }
  }, [slug, statusSlug]);

  useMemo(() => {
    if (icon) {
      form.setFieldsValue({
        icon: icon,

      });
    }
  }, [icon]);

  useMemo(() => {
    if (banner) {
      form.setFieldsValue({
        banner: banner
      });
    }
  }, [banner]);

  function onClickActive(isActive) {
    if (item) {
      const body = {
        id: orNull("id", item),
        isActive: isActive,
      };
      onSave(body);
    }
  }

  function onClickShow(isShow) {
    if (item) {
      const body = {
        id: orNull("id", item),
        isShow: isShow,
      };
      onSave(body);
    }
  }



  const renderHeaderAction = () => {
    return <Header onCancelClick={onCancelClick} item={item} onClickActive={onClickActive} onClickShow={onClickShow} />
  }

  function renderInfoGeneral() {
    return <General
      item={item}
      form={form}
      slug={slug}
      setSlug={setSlug}
      setIsFinish={setIsFinish}
      onSearchSlug={onSearchSlug}
      statusSlug={statusSlug}
      setSlugStatusToNull={setSlugStatusToNull}
    />
  }

  function renderUploadThumb() {
    return <UploadIcon image={icon} setImage={setIcon} />;
  }

  function renderUploadBanner() {
    return <UploadBanner image={banner} setImage={setBanner} />;
  }

  function renderOptimalSEO() {
    return <OptimalSEO
      item={item}
      id={orNull("id", item)}
      isActive={orNull("isActive", item)}
      slug={slug}
    />
  }

  function renderSetting() {
    return item && orBoolean("isActive", item) && <Setting item={item} />
  }

  return (
    <FormBase
      layout="vertical"
      form={form}
      onFinish={onFinish}
    >
      {renderHeaderAction()}
      <Row gutter={24}>
        <Col span={18}>
          <Space style={{ width: "100%" }} direction="vertical">
            {renderInfoGeneral()}
            {renderOptimalSEO()}
          </Space>
        </Col>
        <Col span={6}>
          <Space style={{ width: "100%" }} direction="vertical">
            {renderUploadThumb()}
            {renderUploadBanner()}
            {renderSetting()}
          </Space>
        </Col>
      </Row>
    </FormBase>
  );
}
