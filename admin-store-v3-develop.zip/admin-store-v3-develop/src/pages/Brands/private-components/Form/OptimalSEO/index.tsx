import { Card, Form as FormBase, Input, Typography } from "antd";
import { useEffect, useState } from "react";
import { orEmpty } from 'utils/Selector';
import env from "configs/env";
const { Title, Link } = Typography;
const { Item } = FormBase;

export default function OptimalSEO({ id, slug, isActive = false, item }) {

  const [isSEO, setIsSEO] = useState(false)

  useEffect(() => {
    if (!id) {
      setIsSEO(true)
      return
    }
    setIsSEO(false)
  }, [id])

  const renderPreviewSEO = () => {
    return (
      <div>
        <Link href={isActive ? `${env.base_url}/thuong-hieu/${slug}` : null} target="_blank">
          {env.base_url}/thuong-hieu/{slug}
        </Link>
        <Title style={{ margin: 0 }} level={3}>{orEmpty('pageSEO.title', item)}</Title>
        <p>{orEmpty('pageSEO.description', item)}</p>
      </div>
    )
  }

  return (
    <Card
      title="Tối ưu SEO"
      className="wrapper"
      extra={id ? <div onClick={() => setIsSEO(!isSEO)} style={{ color: "blue", cursor: "pointer" }}>Chỉnh sửa SEO</div> : null}
    >
      {!isSEO ? renderPreviewSEO() : null}
      {isSEO &&
        (
          <div>
            <p>
              Thiết lập các thẻ mô tả giúp khách hàng dễ dàng tìm thấy danh mục này
              trên công cụ tìm kiếm như Google
            </p>
            <Item
              name="pageSEO_title"
              label="Tiêu đề trang"
            >
              <Input placeholder="Tiêu đề trang" />
            </Item>
            <Item
              name="pageSEO_keywords"
              label="Keywords trang"
            >
              <Input placeholder="Keywords trang" />
            </Item>
            <Item
              name="pageSEO_description"
              label="Mô tả trang"
            >
              <Input.TextArea rows={7} placeholder="Mô tả trang" />
            </Item>
          </div>
        )
      }

    </Card>
  );
}
