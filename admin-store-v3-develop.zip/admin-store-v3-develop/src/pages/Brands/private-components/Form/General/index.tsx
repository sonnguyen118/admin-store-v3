import React, { useState } from 'react';
import {
    Typography,
    Card,
    Input,
    Form,
    message,
} from "antd";
import { CheckSlug, Editor } from "components";
import { orNull } from 'utils/Selector';
import { Helpers } from 'utils';
import env from "configs/env";
const { Item } = Form;

function General(props): JSX.Element {
    const { slug, setSlug, form, item, setIsFinish, onSearchSlug, statusSlug, setSlugStatusToNull } = props
    function onChangeSlug(e) {
        form.setFieldsValue({
            pageSEO_title: e.target.value,
            pageSEO_description: e.target.value,
        });
        if (!orNull("id", item)) {
            setSlugStatusToNull()
            setSlug(Helpers.getSlug(e.target.value));
            setIsFinish((prevState) => ({
                ...prevState,
                status: false,
            }));
            form.setFieldsValue({
                slug: Helpers.getSlug(e.target.value),
            });
            return;
        }
    }

    function handleOnSearchSlug() {
        if (!orNull("id", item) && slug != "") {
            onSearchSlug(slug)
            return;
        }
        message.warning("Vui lòng nhập tên thương hiệu hoặc đường dẫn để kiểm tra");
        return;
    }

    return (
        <Card title="Thông tin chung" className="space-general-wrapper">
            <Item
                name="name"
                label={
                    <span style={{ color: "#6c798f", fontWeight: "bold" }}>
                        Tên thương hiệu:
                    </span>
                }
                rules={[
                    { required: true, message: "Vui lòng nhập tên thương hiệu" },
                ]}
                required
            >
                <Input onChange={onChangeSlug} placeholder="Nhập tên thương hiệu" />
            </Item>
            <CheckSlug
                slug={slug}
                onChangeSlug={onChangeSlug}
                onSearchSlug={handleOnSearchSlug}
                addonSlug={`${env.base_url}/thuong-hieu`}
                statusSlug={statusSlug}
                idItem={orNull("id", item)}
                isActive={orNull("isActive", item)}
            />
            <Item
                name="description"
                label={<span style={{ color: "#6c798f", fontWeight: "bold" }}>Mô tả thương hiệu:</span>}
                required
                rules={[
                    { required: true, message: 'Vui lòng nhập mô tả thương hiệu' }
                ]}>
                <Editor />
            </Item>
        </Card>
    );
};

export default General;