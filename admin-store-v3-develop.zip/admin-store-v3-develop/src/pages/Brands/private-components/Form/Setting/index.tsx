import React, { useState } from 'react';
import { Card, Form } from "antd";
import { Selector } from "components";
import { Mocks } from 'utils';
const { Item } = Form;
function Setting(props): JSX.Element {
    const { item } = props
    return (
        <Card title="Cấu hình" className="space-general-wrapper">
            <Item label="Hiển thị" name="isShow">
                <Selector value={true} options={Mocks.BRANDS.ShowStatus} />
            </Item>
        </Card>
    );
};

export default Setting;