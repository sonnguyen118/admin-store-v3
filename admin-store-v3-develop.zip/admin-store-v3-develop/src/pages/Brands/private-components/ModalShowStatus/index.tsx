import React, { useState, useEffect } from "react";
import { Modal, Button, Form, Radio, Popconfirm } from 'antd';
import { Selector } from "components"

export default function ModalActiveStatus(props) {
    const [form] = Form.useForm();
    const { visible, onSubmit, handleCancel } = props

    const handleSubmit = (values) => {
        onSubmit(values)
        form.setFieldsValue({
            isShow: null,
        });
    }

    return (
        <Modal
            visible={visible}
            title="Thay đổi trạng thái hiển thị"
            onCancel={handleCancel}
            footer={[
                <Button key="back" onClick={handleCancel}>
                    Hủy
                </Button>,
                <Popconfirm placement="bottom" title={"Bạn xác nhận thay đổi trạng thái những thương hiệu đã chọn!"} onConfirm={form.submit} okText="Xác nhận" cancelText="Hủy">
                    <Button key="submit" type="primary">
                        Lưu
                    </Button>
                </Popconfirm>
            ]}
        >
            <Form
                layout="vertical"
                form={form}
                onFinish={handleSubmit}
            >
                <Form.Item
                    name="isShow"
                    style={{ textAlign: "center" }}
                    rules={[
                        { required: true, message: 'Vui lòng chọn trạng thái' }
                    ]}
                    required
                >
                    <Radio.Group>
                        <Radio value={true}>Hiển thị</Radio>
                        <Radio value={false}>Tạm ẩn</Radio>
                    </Radio.Group>
                </Form.Item>
            </Form>

        </Modal>
    );
}
