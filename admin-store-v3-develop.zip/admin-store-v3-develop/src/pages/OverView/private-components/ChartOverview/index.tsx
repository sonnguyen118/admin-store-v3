import { Card, Col, Row } from 'antd';
import { Chart } from "react-google-charts";
import { useCallback, useMemo } from 'react';


const ChartOverview = ({ generalDataByTime, generalData }) => {


    const CardEmpty = useCallback(() => {
        return (
            <Card bordered={true} style={styles.cardWrapper}>
                <div>Không có dữ liệu</div>
            </Card>
        )
    }, [])

    const renderLineChart = useCallback(() => {
        if (generalDataByTime.length) {
            return (
                <Card bordered={true} style={styles.cardWrapper}>
                    <Chart
                        width={'100%'}
                        height={'400px'}
                        chartType="LineChart"
                        loader={<div>Loading Chart</div>}
                        data={[
                            [{ type: 'date', label: 'Ngày' }, 'Doanh thu'],
                            ...generalDataByTime.map(item => ([
                                new Date(item._id), item.totalPrice
                            ]))
                        ]}
                        options={{
                            hAxis: {
                                title: 'Ngày',
                                format: 'M/d/yy',
                            },
                            vAxis: {
                                title: 'Doanh thu',
                            },
                        }}
                        rootProps={{ 'data-testid': '1' }}
                    />
                </Card>
            )
        }
        return <CardEmpty />
    }, [generalDataByTime, CardEmpty])

    // create color map
    var colors = {
        'WEB': '#007fad',
        'APP': '#e9a227',
        'FACEBOOK': '#d91e48',
        'ZALO': '#2BB673',
        "STAFF": '#657CD0',
        "PHONE": '#DA68A0',
        "POS": '#06C3C0',
        "LAZADA": '#777B80',
        "SHOPEE": '#7C6D70',
        "TIKI": '#7C0850',
        "GOOGLESHOP": '#F75870',
        "LANDINGPAGE": '#ff0000'
    };

    // build slices
    let slices = [];
    useMemo(() => {
        for (var i = 0; i < generalData.length; i++) {
            slices.push({
                color: colors[generalData[i]._id]
            });
        }
    }, [generalData, slices])

    const renderPieChart = useCallback(() => {
        if (generalData.length) {
            return (
                <Card bordered={true} style={styles.cardWrapper}>
                    <Chart
                        width={'100%'}
                        height={'400px'}
                        chartType="PieChart"
                        loader={<div>Loading Chart</div>}
                        data={[
                            ['Source', 'Total Price'],
                            ...generalData.map(item => ([
                                item._id, item.totalPrice
                            ]))
                        ]}
                        options={{
                            slices: slices,
                            legend: {
                                // position: 'labeled',
                                position: "bottom",
                                alignment: "center",
                                textStyle: {
                                    color: "233238",
                                    fontSize: 14
                                }
                            },
                            tooltip: {
                                showColorCode: true
                            },
                            chartArea: {
                                left: 0,
                                top: 0,
                                width: "100%",
                                height: "70%"
                            },
                        }}
                        rootProps={{ 'data-testid': '4' }}
                    />
                </Card>
            )
        }
        return <CardEmpty />
    }, [generalData, CardEmpty, slices])

    return (
        <Row gutter={16}>
            <Col span={16}>
                {renderLineChart()}
            </Col>
            <Col span={8}>
                {renderPieChart()}
            </Col>
        </Row>
    );

}

export default ChartOverview;

const styles = {
    cardWrapper: {
        width: '100%',
        padding: 0
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: "center"
    }
}