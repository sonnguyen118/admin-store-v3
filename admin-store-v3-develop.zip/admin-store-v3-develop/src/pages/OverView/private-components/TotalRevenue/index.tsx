import { Card, Col, Row, Typography } from 'antd';
import { Helpers } from 'utils';
import { orNumber } from 'utils/Selector';

const { Title } = Typography

const TotalRevenue = ({ generalData }) => {
    return (
        <Row gutter={16}>
            <Col span={8}>
                <Card title="Tổng doanh thu đơn đã chốt" bordered={true} style={styles.cardWrapper}>
                    <div style={styles.center}>
                        <Title level={1} type="success" >
                            {Helpers.currencyFormatVND(
                                generalData.reduce(
                                    (acc, item) => acc + orNumber("totalPrice", item),
                                    0
                                ))}
                        </Title>
                    </div>
                </Card>
            </Col>
            <Col span={8}>
                <Card title="Tổng số lượng đơn đã chốt" bordered={true} style={styles.cardWrapper}>
                    <div style={styles.center}>
                        <Title level={1} type="success" >
                            {generalData.reduce(
                                (acc, item) => acc + orNumber("totalOrder", item),
                                0
                            )}
                        </Title>
                    </div>
                </Card>
            </Col>
            <Col span={8}>
                <Card title="Tổng giá trị upsale" bordered={true} style={styles.cardWrapper}>
                    <div style={styles.center}>
                        <Title level={1} type="success" >
                            {Helpers.currencyFormatVND(
                                generalData.reduce(
                                    (acc, item) => acc + orNumber("totalUpsaleValue", item),
                                    0
                                ))}
                        </Title>
                    </div>
                </Card>
            </Col>
        </Row>
    );

}

export default TotalRevenue;

const styles = {
    cardWrapper: {
        width: '100%'
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: "center"
    }
}