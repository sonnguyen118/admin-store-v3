import { Card, Col, Row, Typography, List, Skeleton } from 'antd';
import { orEmpty, orNumber } from 'utils/Selector';

const { Link } = Typography

const TopSellProducts = ({ topSellProducts }) => {
    return (
        <Row gutter={16}>
            <Col span={16}>
                <Card title="Top sản phẩm bán chạy" bordered={true} style={styles.cardWrapper}>
                    <List
                        className="demo-loadmore-list"
                        itemLayout="horizontal"
                        dataSource={topSellProducts}
                        renderItem={item => (
                            <List.Item>
                                <Skeleton title={false} loading={topSellProducts.length === 0}>
                                    <List.Item.Meta
                                        title={<Link href={`/products/update/${orEmpty("_id", item)}`} target={"blank"}>{orEmpty("productName", item)}</Link>}
                                    />
                                    <div>{orNumber("totalQuantity", item)} sản phẩm</div>
                                </Skeleton>
                            </List.Item>
                        )}
                    />
                </Card>
            </Col>
        </Row>
    );
}

export default TopSellProducts;

const styles = {
    cardWrapper: {
        width: '100%',
        padding: 0
    },
    center: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: "center"
    }
}