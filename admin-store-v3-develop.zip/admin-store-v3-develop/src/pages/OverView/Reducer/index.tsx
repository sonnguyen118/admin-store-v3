import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  SET_GENERAL_DATA,
  SET_TOP_SELL_PRODUCTS,
  SET_GENERAL_DATA_BY_TIME,
  SET_LIST_ORDER_SOURCE,
} from "./action-type";

const initialState = {
  isLoading: false,
  counter: 0,
};

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload,
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null,
      };
    case SET_GENERAL_DATA:
      return {
        ...state,
        ...action.payload,
      };
    case SET_TOP_SELL_PRODUCTS:
      return {
        ...state,
        ...action.payload,
      };
    case SET_GENERAL_DATA_BY_TIME:
      return {
        ...state,
        ...action.payload,
      };
    case SET_LIST_ORDER_SOURCE:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer,
};
