import { Overview as OverviewAPI, Common as CommonAPI } from "api";
import { orArray, orBoolean } from "utils/Selector";
import {
  IncrementLoading,
  DecrementLoading,
  setTopSellProducts,
  setGeneralData,
  setGeneralDataByTime,
  setListOrderSource,
} from "./action-type";

export const onGetTopSellProducts = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OverviewAPI.getTopSellProducts(params);
    const { data } = response;
    if (orBoolean("meta.success", data)) {
      return dispatch(
        setGeneralData({
          topSellProducts: orArray("data", data),
        })
      );
    }
  } catch (error) {
    return dispatch(
      setGeneralData({
        topSellProducts: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};

export const onGetGeneralData = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OverviewAPI.getGeneralData(params);
    const { data } = response;
    if (orBoolean("meta.success", data)) {
      return dispatch(
        setGeneralData({
          generalData: orArray("data", data),
        })
      );
    }
  } catch (error) {
    return dispatch(
      setGeneralData({
        generalData: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};

export const onGetGeneralDataByTime = async (params, dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await OverviewAPI.getGeneralDataByTime(params);
    const { data } = response;
    if (orBoolean("meta.success", data)) {
      return dispatch(
        setGeneralDataByTime({
          generalDataByTime: orArray("data", data),
        })
      );
    }
  } catch (error) {
    return dispatch(
      setGeneralDataByTime({
        generalDataByTime: [],
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error",
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};

export const onGetListOrderSource = async (dispatch) => {
  dispatch(IncrementLoading);
  try {
    const response = await CommonAPI.getListOrderSource();
    const { data } = response;
    return dispatch(
      setListOrderSource({
        listOrderSource: orArray("data", data),
      })
    );
  } catch (error) {
    return dispatch(
      setListOrderSource({
        listOrderSource: [],
      })
    );
  } finally {
    dispatch(DecrementLoading);
  }
};
