export const INCREMENT_LOADING = "overview/INCREMENT_LOADING";
export const DECREMENT_LOADING = "overview/DECREMENT_LOADING";
export const SET_TOP_SELL_PRODUCTS = "overview/SET_TOP_SELL_PRODUCTS";
export const SET_GENERAL_DATA = "overview/SET_GENERAL_DATA";
export const SET_GENERAL_DATA_BY_TIME = "overview/SET_GENERAL_DATA_BY_TIME";
export const SET_LIST_ORDER_SOURCE = "overview/SET_LIST_ORDER_SOURCE";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING,
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING,
};

export const setTopSellProducts = (payload) => {
  return {
    payload,
    type: SET_TOP_SELL_PRODUCTS,
  };
};

export const setGeneralData = (payload) => {
  return {
    payload,
    type: SET_GENERAL_DATA,
  };
};

export const setGeneralDataByTime = (payload) => {
  return {
    payload,
    type: SET_GENERAL_DATA_BY_TIME,
  };
};

export const setListOrderSource = (payload) => {
  return {
    payload,
    type: SET_LIST_ORDER_SOURCE,
  };
};
