import { DatePicker, Space, Button } from "antd";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Selector } from "components";
import { RedoOutlined } from "@ant-design/icons";
import { useHistory } from "react-router-dom";
import queryString from "query-string";
import { Mocks } from "utils";
import moment from "moment";
import { withReducer } from "hoc";
import overviewReducer from "./Reducer";
import { orArray, orEmpty } from "utils/Selector";
import {
  TotalRevenue,
  ChartOverview,
  TopSellProducts,
} from "./private-components";

const { RangePicker } = DatePicker;

const OverView = (props) => {
  const { action, state, dispatch } = props;
  const history = useHistory();

  const query: any = useMemo(() => {
    const data: any = queryString.parse(history.location.search);
    return {
      fromDate: !data.fromDate
        ? moment().subtract(6, "d").format("YYYY-MM-DD")
        : data.fromDate,
      toDate: !data.toDate ? moment().format("YYYY-MM-DD") : data.toDate,
      source: !data.source ? "All" : data.source,
    };
  }, [history.location.search]);

  const generalData = useMemo(() => {
    return orArray("overviewReducer.generalData", state);
  }, [state.overviewReducer]);

  const topSellProducts = useMemo(() => {
    return orArray("overviewReducer.topSellProducts", state);
  }, [state.overviewReducer]);

  const generalDataByTime = useMemo(() => {
    return orArray("overviewReducer.generalDataByTime", state);
  }, [state.overviewReducer]);

  const listOrderSourceOption = useMemo(() => {
    const list = orArray("overviewReducer.listOrderSource", state).map(
      (item) => ({ value: item, label: item })
    );
    return [
      {
        label: "Tất cả các kênh bán hàng",
        value: "All",
      },
      ...list,
    ];
  }, [state.overviewReducer]);

  const [filter, setFilter] = useState(null);
  const [initialState, setInitialState] = useState(true);

  function onGetListOrderSource() {
    action.overviewReducer.onGetListOrderSource(dispatch.overviewReducer);
  }

  useEffect(() => {
    onGetListOrderSource();
  }, []);

  useMemo(() => {
    if (query) {
      setFilter((prevState) => ({
        ...prevState,
        fromDate: query.fromDate,
        toDate: query.toDate,
      }));
    }
    if (query.source != "All") {
      setFilter((prevState) => ({
        ...prevState,
        source: query.source,
      }));
    } else {
      if (orEmpty("source", filter)) {
        delete filter.source;
        setFilter(filter);
      }
    }
    setInitialState(true);
  }, [query]);

  useMemo(() => {
    if (initialState && filter) {
      action.overviewReducer.onGetGeneralData(filter, dispatch.overviewReducer);
      action.overviewReducer.onGetGeneralDataByTime(
        { ...filter, frame: "1d" },
        dispatch.overviewReducer
      );
      action.overviewReducer.onGetTopSellProducts(
        { ...filter, limit: 10 },
        dispatch.overviewReducer
      );
      return setInitialState(false);
    }
  }, [initialState, filter]);

  function onChangeDate(_, dateString) {
    history.push({
      pathname: "/",
      search: queryString.stringify({
        ...query,
        fromDate: dateString[0],
        toDate: dateString[1],
      }),
    });
  }

  function onChangeSource(value) {
    history.push({
      pathname: "/",
      search: queryString.stringify({ ...query, source: value }),
    });
  }

  const renderFilter = useCallback(() => {
    return (
      <div>
        <Space direction="horizontal" size={12}>
          <RangePicker
            onChange={onChangeDate}
            value={[moment(query.fromDate), moment(query.toDate)]}
          />
          <div style={styles.sourceSelector}>
            <Selector
              mode={null}
              options={listOrderSourceOption}
              placeholder={"Lựa chọn kênh bán hàng"}
              onChange={onChangeSource}
              value={query.source}
            />
          </div>
          <Button
            onClick={() => setInitialState(true)}
            type="default"
            icon={<RedoOutlined />}
            size="middle"
          />
        </Space>
      </div>
    );
  }, [query, listOrderSourceOption]);

  const renderTotalRevenue = useCallback(() => {
    return <TotalRevenue generalData={generalData} />;
  }, [generalData]);

  const renderChartOverview = useCallback(() => {
    return (
      <ChartOverview
        generalDataByTime={generalDataByTime}
        generalData={generalData}
      />
    );
  }, [generalDataByTime, generalData]);

  const renderTopSellProduct = useCallback(() => {
    return <TopSellProducts topSellProducts={topSellProducts} />;
  }, [topSellProducts]);

  return (
    <div>
      <Space direction="vertical" size={12} style={styles.cardWrapper}>
        {renderFilter()}
        {renderTotalRevenue()}
        {renderChartOverview()}
        {renderTopSellProduct()}
      </Space>
    </div>
  );
};

export default withReducer({
  key: "overviewReducer",
  ...overviewReducer,
})(OverView);

const styles = {
  cardWrapper: {
    width: "100%",
  },
  center: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  sourceSelector: {
    width: 200,
  },
};
