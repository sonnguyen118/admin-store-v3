import { useCallback, useMemo } from 'react';
import { Table, Typography } from 'antd';
import { orEmpty } from 'utils/Selector';
import moment from 'moment';
import { Helpers } from 'utils';

const { Text } = Typography

const TableFulfillmentOrder = ({ fulfillmentOrders, fulfillmentOrdersMeta, onChangePage }) => {

    const columns = useMemo(() => {
        return [
            {
                key: "fulfillmentCode",
                title: "Mã vận đơn",
                dataIndex: "fulfillmentCode",
                width: 150,
                fixed: 'left',
            },
            {
                key: "orderCode",
                title: "Mã đơn hàng",
                dataIndex: "orderCode",
                width: 150,
            },
            {
                key: "fulfillmentCompany",
                title: "Nhà vận chuyển",
                dataIndex: "fulfillmentCompany",
                render: (value) => <div>{orEmpty("name", value)}</div>,
                width: 150,
            },
            {
                key: "createdAt",
                title: "Ngày tạo vận đơn",
                dataIndex: "createdAt",
                render: (value) => <div>{moment(value).format("DD/MM/YYYY")}</div>,
                width: 150,
            },
            {
                key: "codAmount",
                title: "Tiền COD",
                dataIndex: "codAmount",
                render: (value) => <div>{Helpers.currencyFormatVND(value)}</div>,
                width: 150,
                align: 'right',
            },
            {
                key: "totalPriceNVC",
                title: "Tổng phí trả NVC",
                dataIndex: "totalPriceNVC",
                render: (value) => <div>{value ? Helpers.currencyFormatVND(value) : null}</div>,
                width: 150,
                align: 'right',
            },
            {
                key: "codNVC",
                title: "NVC Thu hộ",
                dataIndex: "codNVC",
                render: (value) => <div>{value ? Helpers.currencyFormatVND(value) : null}</div>,
                width: 150,
                align: 'right',
            },
            {
                key: "collationDate",
                title: "Ngày đối soát",
                dataIndex: "collationDate",
                render: (value) => <div>{value ? moment(value).format("DD/MM/YYYY") : null}</div>,
                width: 150,
            },
            {
                key: "debt",
                title: "Công nợ",
                dataIndex: "debt",
                render: (value) => <div>{value || value === 0 ? Helpers.currencyFormatVND(value) : null}</div>,
                width: 150,
                align: 'right',
            },
            {
                key: "isCollated",
                title: "Trạng thái đối soát",
                dataIndex: "isCollated",
                render: (value) => <div>{value ? <Text strong>Đã đối soát</Text> : <Text strong type="warning">Chưa đối soát</Text>}</div>,
                width: 150,
                fixed: 'right',
            },
        ]
    }, [fulfillmentOrders])

    const showTotal = (total) => {
        return `Tổng: ${total}`;
    }

    const renderTable = useCallback(() => {
        return (
            <Table
                //@ts-ignore
                columns={columns}
                dataSource={fulfillmentOrders}
                scroll={{ x: 1500 }}
                pagination={{
                    defaultPageSize: fulfillmentOrdersMeta.pageSize,
                    defaultCurrent: fulfillmentOrdersMeta.page,
                    current: fulfillmentOrdersMeta.page,
                    showSizeChanger: false,
                    total: fulfillmentOrdersMeta.total,
                    onChange: (page) => onChangePage(page),
                    showTotal: showTotal
                }}
            />
        )
    }, [columns, fulfillmentOrders, fulfillmentOrdersMeta])

    return (
        <div>
            {renderTable()}
        </div>
    );
}
export default TableFulfillmentOrder