import { Table as TableAntd, Button, Progress, Typography, Tag, Modal } from 'antd';
import { useCallback, useMemo, useState } from 'react';
import { Collation as CollationAPI } from 'api'
import { orArray, orBoolean, orEmpty } from 'utils/Selector';
import { LoadingOutlined, CloseCircleTwoTone, CheckCircleTwoTone, SyncOutlined, CheckCircleOutlined } from '@ant-design/icons';
import ButtonExportFileError from "../ButtonExportFileError"
import moment from 'moment';
import { Helpers } from 'utils';

const { Text } = Typography

const Table = ({ items, fileInfo }) => {
    const [fulfillmentOrder, setFulfillmentOrder] = useState([])
    const [isEndCollation, setIsEndCollation] = useState(false)

    useMemo(() => {
        const arr = items.map((item, index) => ({
            index: index + 1,
            isStatus: null,
            errorMessage: "",
            dataError: [],
            ...item
        }))
        setFulfillmentOrder(arr)
    }, [items])

    async function onCollateData() {
        for (let index = 0; index < fulfillmentOrder.length; index++) {
            const params = {
                fulfillmentCode: fulfillmentOrder[index].mavandon,
                totalPriceNVC: fulfillmentOrder[index].tongphitranvc,
                codNVC: fulfillmentOrder[index].nvcthuho,
                collationDate: moment(fulfillmentOrder[index].ngaythanhtoan, "DD/MM/YYYY").format("YYYY-MM-DD"),
            }
            try {
                const arr = [...fulfillmentOrder]
                arr[index].isStatus = 'loading'
                setFulfillmentOrder(arr)
                const response = await CollationAPI.onCollateData(params)
                const { data } = response
                if (orBoolean("meta.success", data)) {
                    arr[index].isStatus = 'success'
                    setFulfillmentOrder(arr)
                } else {
                    arr[index].isStatus = 'false'
                    arr[index].errorMessage = orEmpty("meta.internalMessage", data)
                    arr[index].dataError = orArray("data", data)
                    setFulfillmentOrder(arr)
                }
            } catch (error) {
                console.log(error)
                const arr = [...fulfillmentOrder]
                arr[index].isStatus = 'false'
                arr[index].errorMessage = "Lỗi hệ thống"
                setFulfillmentOrder(arr)
            }
            const arr = [...fulfillmentOrder]
            if (fulfillmentOrder.length - 1 === index) {
                return (
                    setFulfillmentOrder(arr),
                    setIsEndCollation(true)
                )
            }
        }
    }

    const renderIndex = (index, record) => {
        if (record.isStatus) {
            switch (record.isStatus) {
                case 'loading':
                    return <div><LoadingOutlined /> {index}</div>
                case 'success':
                    return <div><CheckCircleTwoTone twoToneColor="#52c41a" /> {index}</div>
                case 'false':
                    return <div><CloseCircleTwoTone twoToneColor="#fb1239" /> {index}</div>
                default:
                    return index;
            }
        }
        return index
    }

    const renderMessage = (value, array) => {
        if (value && array.length) {
            return (
                <div style={{ display: "flex", flexDirection: "column" }}>
                    <div>{value}:</div>
                    {array.map((item) => {
                        return <div>- {item}</div>
                    })}
                </div>
            )
        }
        if (value && !array.length) {
            return value
        }
        return null
    }

    const columns = [
        {
            key: 'index',
            title: "STT",
            dataIndex: "index",
            width: 80,
            fixed: 'left',
            render: (text: number, record) => renderIndex(text, record),
        },
        {
            key: 'mavandon',
            title: "Mã vận đơn",
            dataIndex: "mavandon",
            width: 150,
            fixed: 'left',
        },
        {
            key: 'nhavanchuyen',
            title: "Nhà vận chuyển",
            dataIndex: "nhavanchuyen",
            width: 150,
        },
        {
            key: 'tongphitranvc',
            title: "Tổng phí trả NVC",
            dataIndex: "tongphitranvc",
            width: 100,
            align: 'right',
            render: (text: number) => Helpers.currencyFormatVND(text),
        },
        {
            key: 'nvcthuho',
            title: "NVC thu hộ",
            dataIndex: "nvcthuho",
            width: 100,
            align: 'right',
            render: (text: number) => Helpers.currencyFormatVND(text),
        },
        {
            key: 'ngaythanhtoan',
            title: "Ngày thanh toán",
            dataIndex: "ngaythanhtoan",
            width: 140,
        },
        {
            key: 'errorMessage',
            title: "",
            dataIndex: "errorMessage",
            width: 300,
            render: (text: string, record) => renderMessage(text, record.dataError)
        },
    ]

    const percent = useMemo(() => {
        const listItemUpload = fulfillmentOrder.filter(item => item.isStatus)
        return Math.round(listItemUpload.length / fulfillmentOrder.length * 100)

    }, [fulfillmentOrder])

    const renderTable = useCallback(() => {
        //@ts-ignore
        return <TableAntd columns={columns} dataSource={fulfillmentOrder} scroll={{ x: 1500 }} />
    }, [fulfillmentOrder, columns])

    function onSubmitCollation() {
        onCollateData()
    }

    const renderButtonImportLoading = useCallback(() => {
        if (percent > 0 && percent < 100) {
            return (
                <div>
                    <Tag icon={<SyncOutlined spin />} color="processing">
                        <Text strong> Đang tiến hành đối soát vui lòng đợi trong giây lát...</Text>
                    </Tag>
                </div>
            )
        }
        return null
    }, [percent])

    const renderButtonImportComplated = useCallback(() => {
        if (percent === 100) {
            return (
                <div>
                    {fulfillmentOrder.filter(item => item.isStatus === 'false').length ? <ButtonExportFileError items={fulfillmentOrder.filter(item => item.isStatus === 'false')} /> : null}
                </div>
            )
        }
        return null
    }, [percent, fulfillmentOrder])

    const renderButtonCollation = useCallback(() => {
        return (
            <div style={styles.button}>
                <div>
                    <Text strong>{fileInfo.name}</Text>
                </div>
                <div>
                    {percent === 0 ? <Button onClick={onSubmitCollation} type="primary">Xác nhận đối soát</Button> : null}
                    {renderButtonImportLoading()}
                    {renderButtonImportComplated()}
                </div>
            </div>
        )
    }, [fulfillmentOrder, percent])

    const renderProgress = useCallback(() => {
        if (percent) {
            return <Progress percent={percent} />
        }
        return null
    }, [percent])

    useMemo(() => {
        const dataCollationFalse = fulfillmentOrder.filter(item => item.isStatus === 'false')
        if (isEndCollation) {
            if (dataCollationFalse.length) {
                Modal.info({
                    title: 'Đối soát hoàn thành',
                    content: (
                        <div>
                            Một số đơn hàng đối soát không thành công
                            <ButtonExportFileError items={fulfillmentOrder.filter(item => item.isStatus === 'false')} />
                        </div>
                    ),
                    onOk() { },
                });
                return
            }
            if (dataCollationFalse.length === 0) {
                Modal.success({
                    content: 'Đối soát thành công...cảm ơn và hẹn gặp lại!',
                });
                return
            }
        }

    }, [isEndCollation, fulfillmentOrder])

    return (
        <div style={styles.tableWrapper}>
            {renderProgress()}
            {renderButtonCollation()}
            {renderTable()}
        </div>
    );
}
export default Table

const styles = {
    tableWrapper: {
        marginTop: 10
    },
    button: {
        display: "flex",
        justifyContent: "space-between",
        margin: "10px 0"
    },
    wrapperMessage: {
        display: "flex",
        flexDirection: "column"
    }
}