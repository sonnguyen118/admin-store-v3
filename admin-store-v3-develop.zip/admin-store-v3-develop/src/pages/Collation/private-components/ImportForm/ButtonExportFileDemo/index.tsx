import { Button, Tooltip } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { CSVLink } from "react-csv";

const ButtonExportFileDemo = () => {
    const header = ["Ma van don", "Nha van chuyen", "Tong phi tra NVC", "NVC thu ho", "Ngay thanh toan"]
    const data = ['ZHXEU', 'Giao hàng nhanh', 42900, 12000, '30/12/2021']

    return (
        <CSVLink data={[header, data]} filename={`file đối soát mẫu.csv`}>
            <Tooltip placement="top" title={"Tải xuống file đối soát mẫu"}>
                <Button style={styles.button} icon={<DownloadOutlined />} type="primary">
                    Tải xuống file mẫu
                </Button>
            </Tooltip>
        </CSVLink>
    );
}
export default ButtonExportFileDemo

const styles = {
    button: {
        marginLeft: 10
    }
}