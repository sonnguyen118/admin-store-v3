import CSVReader from 'react-csv-reader'
import { InboxOutlined } from '@ant-design/icons';
import { Helpers } from 'utils';
const ButtonUpload = ({handleForce}) => {

    const papaparseOptions = {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        transformHeader: header => Helpers.getKey(header.toLowerCase())
    };

    return (
        <label
                className="d-flex justify-content-center align-items-center btn"
                style={{ height: 'fit-content' }}
            >
                <div className="ant-upload ant-upload-drag">
                    <span className="ant-upload ant-upload-btn">
                        <div className="ant-upload-drag-container">
                            <p className="ant-upload-drag-icon">
                                <InboxOutlined />
                            </p>
                            <p className="ant-upload-text">Chọn hoặc kéo thả file CSV cần đối soát</p>
                        </div>
                    </span>
                </div>
                <CSVReader
                    inputId='CSVReader'
                    inputStyle={{ display: 'none' }}
                    onFileLoaded={handleForce}
                    parserOptions={papaparseOptions}
                />
            </label>
    );
}
export default ButtonUpload