import { Button } from 'antd';
import { useCallback, useState } from 'react';
import ButtonUpload from "./ButtonUpload"
import Table from "./Table"
import { useHistory } from "react-router-dom";
import ButtonExportFileDemo from './ButtonExportFileDemo';

const ImportForm = () => {
    const history = useHistory()
    const [items, setItems] = useState([])
    const [fileInfo, setFileInfo] = useState(null)

    const handleForce = (data, fileInfo) => {
        setItems(data)
        setFileInfo(fileInfo)
    };

    function onGoBack() {
        history.goBack()
    }

    const renderHeader = useCallback(() => {
        return (
            <div style={styles.buttonWrapper}>
                <Button onClick={onGoBack} type="default">
                    Quay lại
                </Button>
                <ButtonExportFileDemo />
            </div>
        )
    }, [])

    const renderButtonUpload = useCallback(() => {
        return <ButtonUpload handleForce={handleForce} />
    }, [])

    const renderTableOrder = useCallback(() => {
        if (items.length && fileInfo) {
            return <Table items={items} fileInfo={fileInfo} />
        }
        return null
    }, [items, fileInfo])

    return (
        <div>
            {renderHeader()}
            {renderButtonUpload()}
            {renderTableOrder()}
        </div>
    );
}
export default ImportForm

const styles = {
    buttonWrapper: {
        marginBottom: 10,
        display: "flex",
        justifyContent: "flex-end",
    }
}