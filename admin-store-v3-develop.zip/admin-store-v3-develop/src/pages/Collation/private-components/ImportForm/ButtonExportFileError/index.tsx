import { Tag, Tooltip } from 'antd';

import { DownloadOutlined } from '@ant-design/icons';
import { CSVLink } from "react-csv";
import { useMemo } from 'react';
import moment from 'moment';


const ButtonExportFileError = ({ items }) => {
    const header = ["Mã vận đơn", "Nhà vận chuyển", "Tổng phí trả NVC", "NVC thu hộ", "Ngày thanh toán", "Lý do lỗi"]

    const data = useMemo(() => {
        return items.map((item) => ([
            item.mavandon,
            item.nhavanchuyen,
            item.tongphitranvc,
            item.nvcthuho,
            item.ngaythanhtoan,
            item.errorMessage
        ]))
    }, [items])

    return (
        <CSVLink data={[header, ...data]} filename={`đơn hàng đối soát lỗi - ${moment().format("DD-MM-YYYY")}.csv`}>
            <Tooltip placement="top" title={"Tải xuống những đơn đối soát chưa thành công"}>
                <Tag icon={<DownloadOutlined />} color="#55acee">
                    Tải xuống
                </Tag>
            </Tooltip>
        </CSVLink>
    );
}
export default ButtonExportFileError