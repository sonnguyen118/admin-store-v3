import { useCallback } from "react";
import { ImportForm } from "../../../private-components"
const Import = () => {

    const renderImportForm = useCallback(() => {
        return <ImportForm />
    }, [])
    
    return (
        <div>
            {renderImportForm()}
        </div>
    );
}
export default Import