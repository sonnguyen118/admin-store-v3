import collationReducer from "../Reducer";
import { withReducer } from "hoc";
import { useCallback, useMemo, useState } from "react";
import { useHistory } from "react-router-dom";
import queryString from "query-string";
import { TableFulfillmentOrder } from "../private-components"
import { orArray } from "utils/Selector";
import Search from "../Search"

function clean(obj) {
    for (var propName in obj) {
        if (obj[propName] === null || obj[propName] === undefined) {
            delete obj[propName];
        }
    }
    return obj
}

const List = (props) => {
    const { dispatch, action, state } = props
    const history = useHistory()
    const [filter, setFilter] = useState(null)

    const query: any = useMemo(() => {
        const data: any = queryString.parse(history.location.search);
        return {
            page: data.page ? parseInt(data.page as string) : 1,
            pageSize: data.pageSize ? parseInt(data.pageSize as string) : 15,
            s: data.s ? data.s : null,
            inventory: data.inventory ? data.inventory : null,
            fulfillmentCompany: data.fulfillmentCompany ? data.fulfillmentCompany : null,
            isCOD: data.isCOD ? data.isCOD : null,
            isCollated: data.isCollated ? data.isCollated : null,
            after: data.after ? data.after : null,
            before: data.before ? data.before : null,
        }
    }, [history.location.search]);

    const fulfillmentOrders = useMemo(() => {
        return orArray("collationReducer.fulfillmentOrders", state)
    }, [state.collationReducer])

    const fulfillmentOrdersMeta = useMemo(() => {
        return orArray("collationReducer.fulfillmentOrdersMeta", state)
    }, [state.collationReducer])

    const fullfillmentCompanies = useMemo(() => {
        return orArray("collationReducer.fullfillmentCompanies", state)
    }, [state.collationReducer])

    const inventories = useMemo(() => {
        return orArray("collationReducer.inventories", state)
    }, [state.collationReducer])

    useMemo(() => {
        if (query) {
            setFilter({
                ...clean(query),
                isNotStatus: "CANCELLED"
            })
        }
    }, [query])

    useMemo(() => {
        if (filter) {
            action.collationReducer.getListFulfillmentOrder(
                filter,
                dispatch.collationReducer
            );
        }
    }, [filter])

    const onGetListFulfillmentCompany = () => {
        action.collationReducer.onGetListFulfillmentCompany(
            {},
            dispatch.collationReducer
        );
    }

    const onGetListInventory = () => {
        action.collationReducer.onGetListInventory(
            { isSalonInventories: true },
            dispatch.collationReducer
        );
    }

    useMemo(() => {
        onGetListFulfillmentCompany()
        onGetListInventory()
    }, [])

    function onChangePage(page) {
        history.push({
            pathname: "collation",
            search: queryString.stringify({ ...query, page })
        })
    }

    const renderTable = useCallback(() => {
        return (
            <TableFulfillmentOrder
                fulfillmentOrders={fulfillmentOrders}
                fulfillmentOrdersMeta={fulfillmentOrdersMeta}
                onChangePage={onChangePage}
            />
        )
    }, [fulfillmentOrders, fulfillmentOrdersMeta])

    function onSearch(params) {
        const filterValue = { ...query, ...params }
        delete filterValue.isNotStatus
        if (!params.inventory) {
            delete filterValue.inventory
        }
        if (!params.fulfillmentCompany) {
            delete filterValue.fulfillmentCompany
        }
        if (params.isCOD === null) {
            delete filterValue.isCOD
        }
        if (params.isCollated === null) {
            delete filterValue.isCollated
        }
        if (!params.after && !params.before) {
            delete filterValue.after
            delete filterValue.before
        }
        history.push({
            pathname: "collation",
            search: queryString.stringify({ ...filterValue })
        })
    }


    const renderSearch = useCallback(() => {
        return (
            <Search
                onSearch={onSearch}
                filter={filter}
                fullfillmentCompanies={fullfillmentCompanies}
                inventories={inventories}
            />
        )
    }, [filter, fullfillmentCompanies, inventories])


    return (
        <div>
            {renderSearch()}
            {renderTable()}
        </div>
    );
}

export default withReducer({
    key: "collationReducer",
    ...collationReducer
})(List)