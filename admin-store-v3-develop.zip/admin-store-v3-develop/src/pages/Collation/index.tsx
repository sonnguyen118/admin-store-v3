import { Typography, Row, Col, Button } from "antd";
import { PlusCircleOutlined } from "@ant-design/icons";
import { useHistory } from "react-router-dom";
import List from "./List"
import { useCallback } from "react";
const { Title } = Typography;

const Collation = () => {
    const history = useHistory()

    function onImportFile() {
        history.push("/collation/import");
    }

    const renderHeader = useCallback(() => {
        return (
            <Row>
                <Col span={8}>
                    <Title level={2}>Đối soát</Title>
                </Col>
                <Col span={8} offset={8}>
                    <div style={styles.buttonWrapper}>
                        <Button onClick={onImportFile} type="primary" icon={<PlusCircleOutlined />}>
                            Đối soát
                        </Button>
                    </div>
                </Col>
            </Row>
        )
    }, [])

    const renderBody = useCallback(() => {
        return <List />
    }, [])

    return (
        <div>
            {renderHeader()}
            {renderBody()}
        </div>
    );
}
export default Collation

const styles = {
    buttonWrapper: {
        display: "flex",
        justifyContent: "flex-end",
    }
}