import { Row, Col, Popover, Button, Input, Form, Tag } from "antd";
import { useCallback, useState } from "react";
import { FilterOutlined } from "@ant-design/icons";
import { Helpers } from "utils";
import FormSearch from "./FormSearch"
import ListFilterTag from "./ListFilterTag"

const Search = ({ onSearch, filter, fullfillmentCompanies, inventories }) => {
    const [listFilter, setListFilter] = useState([]);

    const renderFormSearch = useCallback(() => {
        return (
            <FormSearch
                onSearch={onSearch}
                filter={filter}
                fullfillmentCompanies={fullfillmentCompanies}
                inventories={inventories}
                listFilter={listFilter}
                setListFilter={setListFilter}
            />
        )
    }, [filter, listFilter, fullfillmentCompanies, inventories])

    const renderListFilterTag = useCallback(() => {
        if (listFilter.length) {
            return (
                <ListFilterTag filter={filter} listFilter={listFilter} setListFilter={setListFilter} onSearch={onSearch} />
            )
        }
        return null
    }, [listFilter])


    return (
        <div style={styles.wrapper}>
            {renderFormSearch()}
            {renderListFilterTag()}
        </div>
    );

}


export default Search;

const styles = {
    wrapper: {
        width: '100%',
        background: '#fff',
        marginBottom: '15px',
        padding: ' 15px',
    }
}