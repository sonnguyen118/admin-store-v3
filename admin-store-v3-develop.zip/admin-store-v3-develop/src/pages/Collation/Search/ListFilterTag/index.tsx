import { Row, Col, Tag } from "antd";
import { useCallback } from "react";
import { Helpers } from "utils";

const ListFilterTag = ({ filter, listFilter, setListFilter, onSearch }) => {

    function handleRemoveFilter(e, item) {
        const defaultFilter = { ...filter }
        e.preventDefault();
        setListFilter(listFilter.filter((node) => node.value != item.value));
        if (item.value === "withInventory") {
            defaultFilter.inventory = null
            onSearch(defaultFilter)
            return;
        }
        if (item.value === "withTransporter") {
            defaultFilter.fulfillmentCompany = null
            onSearch(defaultFilter)
            return;
        }
        if (item.value === "withCODStatus") {
            defaultFilter.isCOD = null
            onSearch(defaultFilter)
            return;
        }
        if (item.value === "withIsCollation") {
            defaultFilter.isCollated = null
            onSearch(defaultFilter)
            return;
        }
        if (item.value === "withDateTime") {
            defaultFilter.after = null
            defaultFilter.before = null
            onSearch(defaultFilter)
            return;
        }
    }

    const renderListFilterTag = useCallback(() => {
        if (listFilter.length) {
            return (
                <Row style={{ margin: "15px 0" }} gutter={24}>
                    <Col span={24}>
                        {Helpers.getUnique(listFilter, "value").map((item, index) => {
                            return (
                                <Tag
                                    key={index}
                                    closable
                                    onClose={(e) => handleRemoveFilter(e, item)}
                                >
                                    {item.label}
                                </Tag>
                            );
                        })}
                    </Col>
                </Row>
            )
        }
        return null
    }, [listFilter])


    return (
        <div >
            {renderListFilterTag()}
        </div>
    );

}


export default ListFilterTag;