import { Row, Col, Popover, Button, Input, Form, DatePicker } from "antd";
import { useCallback, useMemo, useState } from "react";
import { FilterOutlined } from "@ant-design/icons";
import useDebounce from "hook/useDebounce";
import form from "antd/lib/form";
import { Selector } from "components";
import { Mocks } from "utils";
import { orNull } from "utils/Selector";
import moment from "moment";

const { RangePicker } = DatePicker

const FormSearch = ({ onSearch, filter, fullfillmentCompanies, inventories, listFilter, setListFilter }) => {
    const [form] = Form.useForm();
    const [searchValue, setSearchValue] = useState("");
    const [filterVisible, setFilterVisible] = useState(false);
    const inputDebounce = useDebounce(searchValue, 300);
    const [filterType, setFilterType] = useState("withInventory");

    useMemo(() => {
        const defaultFilter = { ...filter }
        if (inputDebounce) {
            defaultFilter.s = searchValue
            onSearch(defaultFilter)
            return;
        }
    }, [searchValue, inputDebounce]);


    const listFulFillmentCompanyOption = useMemo(() => {
        return fullfillmentCompanies.map(item => ({ label: item.name, value: item.id }));
    }, [fullfillmentCompanies])

    const listInventoryOption = useMemo(() => {
        return inventories.map(item => ({ label: item.name, value: item.id }));
    }, [inventories])

    useMemo(() => {
        const arr = [...listFilter];
        if (filter.s) {
            setSearchValue(filter.s)
        }
        if (filter.inventory && listInventoryOption.length) {
            arr.push({
                value: "withInventory",
                label: Mocks.COLLATION.getLabelFilter("withInventory", orNull("inventory", filter), null, listFulFillmentCompanyOption, listInventoryOption)
            })
            setListFilter(arr)
        }
        if (filter.fulfillmentCompany && listFulFillmentCompanyOption.length) {

            arr.push({
                value: "withTransporter",
                label: Mocks.COLLATION.getLabelFilter("withTransporter", orNull("fulfillmentCompany", filter), null, listFulFillmentCompanyOption, listInventoryOption)
            })
            setListFilter(arr)
        }
        if (filter.isCOD || filter.isCOD === 0) {
            arr.push({
                value: "withCODStatus",
                label: Mocks.COLLATION.getLabelFilter("withCODStatus", filter.isCOD)
            })
            setListFilter(arr)
        }
        if (filter.isCollated || filter.isCollated === 0) {
            arr.push({
                value: "withIsCollation",
                label: Mocks.COLLATION.getLabelFilter("withIsCollation", orNull("isCollated", filter))
            })
            setListFilter(arr)
        }
        if (filter.after && filter.before) {
            arr.push({
                value: "withDateTime",
                label: `Ngày tạo từ ngày ${moment(orNull("after", filter)).format("DD-MM-YYYY")} đến ngày ${moment(orNull("before", filter)).subtract(1, "days").format("DD-MM-YYYY")}`
            })
            setListFilter(arr)
        }
    }, [filter, listFulFillmentCompanyOption, listInventoryOption])


    function onFilter(filterType, filterValue, filterDate) {
        const defaultFilter = { ...filter }
        switch (filterType) {
            case "withInventory":
                defaultFilter.inventory = filterValue
                onSearch(defaultFilter)
                return;
            case 'withTransporter':
                defaultFilter.fulfillmentCompany = filterValue
                onSearch(defaultFilter)
                return;
            case 'withCODStatus':
                defaultFilter.isCOD = filterValue
                onSearch(defaultFilter)
                return;
            case 'withIsCollation':
                defaultFilter.isCollated = filterValue
                onSearch(defaultFilter)
                return;
            case 'withDateTime':
                defaultFilter.after = filterDate[0].format("YYYY-MM-DD")
                defaultFilter.before = moment(filterDate[1]).add(1, "days").format("YYYY-MM-DD")
                onSearch(defaultFilter)
                return;
            default:
                return;
        }
    }


    function checkListFilter(filterType, filterValue, filterDate) {
        setFilterVisible(false)
        const arr = [...listFilter];
        const resultItem = listFilter.findIndex(item => item.value === filterType)
        if (resultItem === -1) {
            arr.push({
                value: filterType,
                label: Mocks.COLLATION.getLabelFilter(filterType, filterValue || filterValue === 0 && filterValue, filterDate, listFulFillmentCompanyOption, listInventoryOption)
            })
            setListFilter(arr)
        } else {
            listFilter[resultItem].label = Mocks.COLLATION.getLabelFilter(filterType, filterValue || filterValue === 0 && filterValue, filterDate, listFulFillmentCompanyOption, listInventoryOption)
            setListFilter(arr)
        }
        return (
            form.setFieldsValue({
                filterType: filterType,
                filterValue: filterValue,
                filterDate: filterDate
            }),
            onFilter(filterType, filterValue, filterDate)
        );
    }

    function onFinish(values) {
        checkListFilter(values.filterType, values.filterValue, values.filterDate)
    };

    useMemo(() => {
        form.setFieldsValue({
            filterType: "withInventory",
            filterValue: []
        });
    }, [])

    useMemo(() => {
        switch (form.getFieldValue("filterType")) {
            case 'withInventory':
                form.setFieldsValue({
                    filterType: "withInventory",
                    filterValue: filter.inventory ? filter.inventory : []
                });
                return;
            case 'withTransporter':
                form.setFieldsValue({
                    filterType: "withTransporter",
                    filterValue: filter.fulfillmentCompany ? filter.fulfillmentCompany : []
                });
                return;
            case 'withCODStatus':
                form.setFieldsValue({
                    filterType: "withCODStatus",
                    filterValue: filter.isCOD || filter.isCOD == 0 ? parseInt(filter.isCOD as string) : null
                });
                return;
            case 'withIsCollation':
                form.setFieldsValue({
                    filterType: "withIsCollation",
                    filterValue: filter.isCollated || filter.isCollated == 0 ? parseInt(filter.isCollated as string) : null
                });
                return;
            case "withDateTime":
                form.setFieldsValue({
                    filterType: "withDateTime",
                    filterDate: orNull("before", filter) && orNull("after", filter) ? [moment(orNull("after", filter)), moment(orNull("before", filter)).subtract(1, "days")] : null
                });
                return
            default:
                return;
        }

    }, [form.getFieldValue("filterType"), filter])

    function getOptionFilter(filterType) {
        switch (filterType) {
            case "withCODStatus":
                return Mocks.COLLATION.CODStatus;
            case "withTransporter":
                return listFulFillmentCompanyOption
            case "withInventory":
                return listInventoryOption
            case 'withIsCollation':
                return Mocks.COLLATION.CollationStatus
            default:
                return;
        }
    };

    const content = (
        <Form
            form={form}
            onFinish={onFinish}
            style={{ width: 300, maxWidth: 300 }}
        >
            <p>Hiển thị tất cả sản phẩm theo</p>
            <Form.Item name="filterType" style={{ marginBottom: 0 }}>
                <Selector onChange={(e) => setFilterType(e)} options={Mocks.COLLATION.filterOptions} />
            </Form.Item>
            <div style={{ margin: "10px 0" }}>Là</div>
            {filterType === "withDateTime" ? (
                <Form.Item
                    name="filterDate"
                    rules={[{ required: true, message: "Vui lòng lựa chọn thời gian" }]}
                    required
                >
                    <RangePicker />
                </Form.Item>
            ) : (
                <Form.Item name="filterValue" rules={[{ required: true, message: 'Vui lòng chọn thông tin để lọc' }]}>
                    <Selector
                        mode={Mocks.COLLATION.optionMultiple.includes(filterType) ? "multiple" : null}
                        options={getOptionFilter(filterType)}
                        placeholder="Chọn điều kiện lọc"
                    />
                </Form.Item>
            )}

            <Form.Item style={{ display: "flex", justifyContent: "space-between" }}>
                <Button onClick={() => setFilterVisible(false)} style={{ marginRight: 10 }}>
                    Huỷ
                </Button>
                <Button htmlType="submit" type="primary">
                    Thêm điều kiện lọc
                </Button>
            </Form.Item>
        </Form>
    );

    const renderFormSearch = useCallback(() => {
        return (
            <Row gutter={24}>
                <Col span={6}>
                    <Popover
                        placement="bottom"
                        title={"Thêm điều kiện lọc"}
                        content={content}
                        trigger="click"
                        visible={filterVisible}
                        onVisibleChange={(visible) => setFilterVisible(visible)}
                    >
                        <Button style={{ width: "100%" }} icon={<FilterOutlined />}>
                            Thêm điều kiện lọc
                        </Button>
                    </Popover>
                </Col>
                <Col span={18}>
                    <Input
                        value={searchValue}
                        onChange={(e) => setSearchValue(e.target.value)}
                        allowClear
                        placeholder={
                            "Tìm kiếm theo mã vận đơn, mã vận chuyển, mã đơn hàng ..."
                        }
                    />
                </Col>
            </Row>
        )
    }, [searchValue, filterVisible, filterType, listFulFillmentCompanyOption, listInventoryOption])

    return (
        <div>
            {renderFormSearch()}
        </div>
    );

}


export default FormSearch;
