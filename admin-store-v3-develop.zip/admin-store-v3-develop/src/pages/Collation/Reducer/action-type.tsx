export const INCREMENT_LOADING = "collation/INCREMENT_LOADING";
export const DECREMENT_LOADING = "collation/DECREMENT_LOADING";
export const SET_LIST_FULFILLMENT_ORDER = "collation/SET_LIST_FULFILLMENT_ORDER";
export const SET_LIST_FULFILLMENT_COMPANY = "collation/SET_LIST_FULFILLMENT_COMPANY";
export const SET_LIST_INVENTORY = "collation/SET_LIST_INVENTORY";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setListFulfillmentOrder = payload => {
  return {
    payload,
    type: SET_LIST_FULFILLMENT_ORDER
  };
};

export const setListFulfillmentCompany = payload => {
  return {
    payload,
    type: SET_LIST_FULFILLMENT_COMPANY
  };
};

export const setListInventory = payload => {
  return {
    payload,
    type: SET_LIST_INVENTORY
  };
};



