import * as action from "./action";
import {
  INCREMENT_LOADING,
  DECREMENT_LOADING,
  SET_LIST_FULFILLMENT_ORDER,
  SET_LIST_INVENTORY,
  SET_LIST_FULFILLMENT_COMPANY
} from "./action-type";

const initialState = ({
  isLoading: false,
  counter: 0,
});

const reducer = (state, action) => {
  switch (action.type) {
    case INCREMENT_LOADING:
      return {
        ...state,
        counter: state.counter + action.payload
      };
    case DECREMENT_LOADING:
      return {
        ...state,
        counter:
          state.counter - action.payload < 0
            ? 0
            : state.counter - action.payload,
        type: null,
        actionName: null,
        message: null
      };
    case SET_LIST_FULFILLMENT_ORDER:
      return {
        ...state,
        ...action.payload,
      };
    case SET_LIST_INVENTORY:
      return {
        ...state,
        ...action.payload,
      };
    case SET_LIST_FULFILLMENT_COMPANY:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return state;
  }
};

export default {
  action,
  initialState,
  reducer
};
