
import {
    Collation as CollationAPI,
    FullfillmentOrders as FullfillmentOrdersAPI
} from "api";
import {
    IncrementLoading,
    DecrementLoading,
    setListFulfillmentOrder,
    setListFulfillmentCompany,
    setListInventory
} from "./action-type";

export const getListFulfillmentOrder = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await CollationAPI.getListFulfillmentOrder(params)
        const { data, status } = response;
        if (status === 200) {
            const meta = {
                page: data.data.page,
                pageSize: data.data.pageSize,
                total: data.data.total,
            }
            dispatch(
                setListFulfillmentOrder({
                    fulfillmentOrders: data.data.datas,
                    fulfillmentOrdersMeta: meta
                })
            )
            dispatch(DecrementLoading);
            return;
        }
    } catch (error) {
        setListFulfillmentOrder({
            fulfillmentOrders: [],
            fulfillmentOrdersMeta: null,
            message: "Đã xảy ra lỗi vui lòng quay lại sau",
            type: "error"
        })
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const onGetListFulfillmentCompany = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await FullfillmentOrdersAPI.getListFulfillmentCompany(params);
        const { data, status } = response;
        if (status === 200) {
            dispatch(
                setListFulfillmentCompany({
                    fullfillmentCompanies: data.data,
                })
            )
            dispatch(DecrementLoading);
            return;
        }
    } catch (error) {
        dispatch(
            setListFulfillmentCompany({
                fullfillmentCompanies: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error"
            })
        )
    } finally {
        return dispatch(DecrementLoading);
    }
};

export const onGetListInventory = async (params, dispatch) => {
    dispatch(IncrementLoading);
    try {
        const response = await FullfillmentOrdersAPI.getListInventory(params);
        const { data, status } = response;
        if (status === 200) {
            dispatch(
                setListInventory({
                    inventories: data.data,
                })
            )
            dispatch(DecrementLoading);
            return;
        }
    } catch (error) {
        dispatch(
            setListInventory({
                inventories: [],
                message: "Đã xảy ra lỗi vui lòng quay lại sau",
                type: "error"
            })
        )
    } finally {
        return dispatch(DecrementLoading);
    }
};