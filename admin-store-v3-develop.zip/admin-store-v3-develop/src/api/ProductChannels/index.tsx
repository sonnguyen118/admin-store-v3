import { RequestManager } from "utils";

const getListProductChannels = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-channels",
    params,
  );
};

export default {
    getListProductChannels
};
