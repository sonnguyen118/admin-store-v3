import { RequestManager, Helpers } from "utils";

const getListOrder = (params?: any) => {
  return RequestManager.v1.withAuthorize.get("/admin/orders", params);
};

const getListOrderSeller = (params?: any) => {
  return RequestManager.v1.withAuthorize.get("/admin/orders/seller", params);
};

const createOrder = (body) => {
  return RequestManager.v1.withAuthorize.post("/admin/orders", body);
};

const assigneeSeller = (orderId, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${orderId}/seller`,
    body
  );
};

const assigneeSellerMutipleOrder = (body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/bulk-sellers`,
    body
  );
};

const forwardSellerMultipleOrder = (body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/bulk-forward-sellers`,
    body
  );
};

const managerTagsMutipleOrder = (body) => {
  return RequestManager.v1.withAuthorize.put(`/admin/orders/bulk-tags`, body);
};

const updateOrderNoteAndTags = (orderId, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${orderId}/note-tags`,
    body
  );
};

const detailOrder = (id) => {
  return RequestManager.v1.withAuthorize.get(`/admin/orders/${id}`);
};

const detailReorder = (id) => {
  return RequestManager.v1.withAuthorize.get(`/admin/orders/${id}/reorder`);
};

const sellerAcceptProcess = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/orders/${id}/accept-process`
  );
};

const sellerRejectProcess = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/orders/${id}/reject-process`
  );
};

const sellerProcessResult = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders/${id}/process-results`,
    body
  );
};

const cancelOrder = (id, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${id}/cancel`,
    body
  );
};

const updateOrder = (id, body) => {
  return RequestManager.v1.withAuthorize.put(`/admin/orders/${id}`, body);
};

const getOrderLogs = (id) => {
  return RequestManager.v1.withAuthorize.get(`/admin/orders/${id}/logs`);
};

const createOrderLogs = (id, body) => {
  return RequestManager.v1.withAuthorize.post(`/admin/orders/${id}/logs`, body);
};

const confirmPayment = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/orders/${id}/confirm-payment`
  );
};

const confirmPaymentFail = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/orders/${id}/confirm-payment-fail`
  );
};

const sellerProcessStep = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/seller-process/step`,
    params
  );
};

const getShippingFee = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/web/common/shipping-fee`,
    params
  );
};

const getShippingFeeOption = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/common/shipping-fee-option`,
    params
  );
};

const updateShippingFee = (id, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${id}/shipping-fee`,
    body
  );
};

const forwardSeller = (orderId, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${orderId}/forward-seller`,
    body
  );
};
const forwardConfirm = (orderId, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${orderId}/forward-confirm`,
    body
  );
};

const getListCampaign = (params?: any) => {
  return RequestManager.campaign.withAuthorize.post(
    `/api/validate-campaign/getCampaignStoreV1`,
    params
  );
};

const getListCampaignNew = (params?: any) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/campaign/valid-campaigns`,
    params
  );
};

const getDetailCampaignNew = (campaignId) => {
  return RequestManager.v1.withAuthorize.get(`/admin/campaign/${campaignId}`);
};

const checkCampaign = (params?: any) => {
  return RequestManager.campaign.withAuthorize.post(
    `/api/validate-campaign/check-campaign-use-store`,
    params
  );
};

const getMemberProduct = (params?: any) => {
  return RequestManager.campaign.withAuthorize.get(
    `/api/validate-campaign/getMemberProductByIdStore`,
    params
  );
};

const putCampaignOrder = (orderId, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/orders/${orderId}/campaigns`,
    body
  );
};

const getCampaignOrder = (customerId, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders/${customerId}/campaign-orders`,
    body
  );
};

const getCampaignVoucherCode = (params?: any) => {
  return RequestManager.campaign.withAuthorize.post(
    `/api/validate-campaign/validateVoucherStoreV2`,
    params
  );
};

const getCurrentCampaign = (params?: any) => {
  return RequestManager.campaign.withAuthorize.post(
    `/api/validate-campaign/getCurrentCampaignStore`,
    params
  );
};

const getCurrentCampaignNew = (params?: any) => {
  return RequestManager.v1.withAuthorize.post(`/admin/campaign/many`, params);
};

const calculateCampaignDiscount = (params: any) => {
  const { id, ...ortherParams } = params;
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders/${id}/calculate-discount-campaigns`,
    ortherParams
  );
};

const getWaitingProduct = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/orders/waiting-product",
    params
  );
};

const getWaitingProductFetching = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/orders/waiting-product-fetching",
    params
  );
};

export default {
  getListOrder,
  getListOrderSeller,
  createOrder,
  assigneeSeller,
  assigneeSellerMutipleOrder,
  forwardSellerMultipleOrder,
  managerTagsMutipleOrder,
  updateOrderNoteAndTags,
  detailOrder,
  sellerAcceptProcess,
  sellerRejectProcess,
  sellerProcessResult,
  cancelOrder,
  updateOrder,
  getOrderLogs,
  createOrderLogs,
  confirmPayment,
  sellerProcessStep,
  getShippingFee,
  forwardSeller,
  forwardConfirm,
  getShippingFeeOption,
  updateShippingFee,
  getListCampaign,
  checkCampaign,
  putCampaignOrder,
  getCampaignOrder,
  getMemberProduct,
  getCampaignVoucherCode,
  getCurrentCampaign,
  detailReorder,
  calculateCampaignDiscount,
  confirmPaymentFail,
  getWaitingProduct,
  getWaitingProductFetching,
  getListCampaignNew,
  getDetailCampaignNew,
  getCurrentCampaignNew,
};
