import { RequestManager } from "utils";

const getListOrderSource = () => {
  return RequestManager.v1.withAuthorize.get("/web/common/list-order-source");
};

export default {
  getListOrderSource,
};
