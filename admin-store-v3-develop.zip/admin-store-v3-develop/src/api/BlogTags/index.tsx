import { RequestManager } from "utils";

const getListBlogTags = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/blog-tags",
        params,
    );
};

const createBlogTag = (body) => {
    return RequestManager.v1.withAuthorize.post(
        "/admin/blog-tags",
        body,
    );
};


export default {
    getListBlogTags,
    createBlogTag
};
