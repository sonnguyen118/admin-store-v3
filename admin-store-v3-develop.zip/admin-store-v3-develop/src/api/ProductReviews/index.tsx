import { RequestManager } from "utils";

const listProductReviews = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/product-ratings",
        params,
    );
};

const productReviewDetail = (id) => {
    return RequestManager.v1.withAuthorize.get(
        `/admin/product-ratings/${id}`,
    );
};

const isActiveProductReview = (body) => {
    const { id, ...ortherParams } = body;
    return RequestManager.v1.withAuthorize.get(
        `/admin/product-ratings/${id}/publish`,
        ortherParams,
    );
};

const deleteProductReview = (id) => {
    return RequestManager.v1.withAuthorize.delete(
        `/admin/product-ratings/${id}`
    );
};

export default {
    listProductReviews,
    productReviewDetail,
    isActiveProductReview,
    deleteProductReview
};
