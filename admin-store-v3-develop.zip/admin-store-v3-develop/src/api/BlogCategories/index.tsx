import { RequestManager } from "utils";

const getListBlogCategoriesParent = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/blog-categories/parent",
    params,
  );
};

const getListBlogCategories = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/blog-categories",
    params,
  );
};

const slugCheckBlogCategory = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/blog-categories/slug-check`,
    params,
  );
};

const createBlogCategory = (params) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/blog-categories",
    params,
  );
};

const detailBlogCategory = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/blog-categories/${id}`,
  );
};

const updateBlogCategory = (id, params) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/blog-categories/${id}`,
    params,
  );
};

const updateStatusBlogCategories = (params) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/blog-categories/bulk-field-status`,
    params,
  );
};

const updatIsActiveBlogCategory = (id, params) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/blog-categories/${id}/active`,
    params,
  );
};



export default {
    getListBlogCategories,
    slugCheckBlogCategory,
    createBlogCategory,
    detailBlogCategory,
    updateBlogCategory,
    updateStatusBlogCategories,
    getListBlogCategoriesParent,
    updatIsActiveBlogCategory
};
