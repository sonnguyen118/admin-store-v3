import { RequestManager, Helpers } from "utils";

const getListProvince = (params?: any) => {
    return RequestManager.v1.withoutAuthorize.get(
        "/web/address/provinces",
        params,
    );
};

const getListDistrict = (params?: any) => {
    return RequestManager.v1.withoutAuthorize.get(
        "/web/address/districts",
        params,
    );
};

const getListWards = (params?: any) => {
    return RequestManager.v1.withoutAuthorize.get(
        "/web/address/wards",
        params,
    );
};


export default {
    getListProvince,
    getListDistrict,
    getListWards
};
