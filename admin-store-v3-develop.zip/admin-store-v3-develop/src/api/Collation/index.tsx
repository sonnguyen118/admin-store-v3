import { RequestManager } from "utils";

const onCollateData = (params?: any) => {
    const { fulfillmentCode, ...othersParams } = params;
    return RequestManager.v1.withAuthorize.post(
        `/admin/fulfillment-orders/collate-data/${fulfillmentCode}`,
        othersParams,
    );
};

const getListFulfillmentOrder = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/fulfillment-orders",
        params,
    );
};


export default {
    onCollateData,
    getListFulfillmentOrder
};
