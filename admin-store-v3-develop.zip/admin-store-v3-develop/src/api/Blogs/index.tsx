import { RequestManager } from "utils";

const getListProductBlogs = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/blogs",
    params,
  );
};

const slugCheck = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/blogs/slug-check`,
    params,
  );
};

const createBlog = (params) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/blogs",
    params,
  );
};

const detailBlog = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/blogs/${id}`,
  );
};

const updateBlog = (id, params) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/blogs/${id}`,
    params,
  );
};

const updateStatusBlog = (params) => {
  const { id, ...ortherParams } = params
  return RequestManager.v1.withAuthorize.put(
    `/admin/blogs/update-status/${id}`,
    ortherParams,
  );
};

const listUsers = (params) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/users/user-blog`,
    params,
  );
};


export default {
  getListProductBlogs,
  slugCheck,
  createBlog,
  detailBlog,
  updateBlog,
  updateStatusBlog,
  listUsers

};
