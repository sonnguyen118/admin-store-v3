import { RequestManager } from "utils";

const listJob = (params?: any) => {
  return RequestManager.v1.withAuthorize.get("/admin/jobs", params);
};

const retryJob = (id?: any) => {
  return RequestManager.v1.withAuthorize.post(`/admin/jobs/${id}/retry`);
};

export default {
  listJob,
  retryJob
};
