import { RequestManager } from "utils";

const getTopSellProducts = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/reports/top-sell-products",
        params,
    );
};

const getGeneralData = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/reports/general-data",
        params,
    );
};

const getGeneralDataByTime = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/reports/general-data-by-time",
        params,
    );
};



export default {
    getTopSellProducts,
    getGeneralData,
    getGeneralDataByTime,
};
