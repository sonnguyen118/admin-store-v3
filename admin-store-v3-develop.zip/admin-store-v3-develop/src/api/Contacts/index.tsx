import { RequestManager } from 'utils';

const getListContacts = (params?: any) => {
	return RequestManager.v1.withAuthorize.get('/admin/contacts', params);
};

const detailContact = (id) => {
	return RequestManager.v1.withAuthorize.get(`/admin/contacts/${id}`);
};

const updateContact = (params) => {
	const { id, query, ...body } = params;
	return RequestManager.v1.withAuthorize.put(`/admin/contacts/${id}/${query}`, body);
};

const updateStatusContacts = (body) => {
	return RequestManager.v1.withAuthorize.post(`/admin/contacts/bulk-field-status`, body);
};

export default {
	getListContacts,
	detailContact,
	updateContact,
	updateStatusContacts,
};
