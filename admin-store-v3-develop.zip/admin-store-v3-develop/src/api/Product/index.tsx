import { RequestManager, Helpers } from "utils";

const extDetection = file => {
  const originX = file.original.name
    .split(".")
    .pop();
  return originX || 'png';
};

const uploadSingle = (file, settings?: any) => {
  const formData = new FormData();
  const ext = extDetection(file);

  if (file.resize instanceof Blob) {
    formData.append("images", file.resize, Helpers.randomFilename(ext));
  } else {
    formData.append("images", file.original);
  }

  return RequestManager.v1.uploadFile.postFile(
    "/admin/common/upload-images",
    formData,
    settings
  );
};

const getListProduct = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/products/p",
    params,
  );
};

const getCreateProduct = (body) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/products",
    body,
  );
};

const deleteProduct = (id) => {
  return RequestManager.v1.withAuthorize.delete(
    `/admin/products/${id}`
  );
};

const getDetailProduct = (body) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/products/${body}`,
  );
};

const updateProduct = (body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/products/${body.id}`,
    body,
  );
};

const slugCheck = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/products/slug-check`,
    params,
  );
};

const activeProduct = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/products/${id}/active`,
  );
};

const deactiveProduct = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/products/${id}/deactive`,
  );
};

const getDetailVariant = (pid, vid) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/products/${pid}/variants/${vid}`,
  );
};

const createVariant = (pid, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/products/${pid}/variants`,
    body,
  );
};

const updateVariant = (pid, vid, body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/products/${pid}/variants/${vid}`,
    body,
  );
};

const getRelatedProducts = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/products/${id}/related-products`
  );
};

const updateRelatedProducts = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/products/${id}/related-products`,
    body,
  );
};

const updateOutOfStockVariant = (body) => {
  const { productId, variantId, ...params } = body
  return RequestManager.v1.withAuthorize.put(
    `/admin/products/${productId}/variants-out-of-stock/${variantId}`,
    params,
  );
};

export default {
  uploadSingle,
  getListProduct,
  getCreateProduct,
  deleteProduct,
  getDetailProduct,
  updateProduct,
  slugCheck,
  activeProduct,
  deactiveProduct,
  getDetailVariant,
  createVariant,
  updateVariant,
  getRelatedProducts,
  updateRelatedProducts,
  updateOutOfStockVariant
};
