import { RequestManager } from "utils";

const getListTransportOrder = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/fulfillment-orders",
        params,
    );
};

const detailTransportOrder = (id) => {
    return RequestManager.v1.withAuthorize.get(
        `/admin/fulfillment-orders/${id}`,
    );
};

const updateTransportOrder = (id, body) => {
    return RequestManager.v1.withAuthorize.put(
        `/admin/fulfillment-orders/${id}/status`,
        body
    );
};

const updateTransportOrderData = (id, body) => {
    return RequestManager.v1.withAuthorize.put(
        `/admin/fulfillment-orders/${id}/data`,
        body
    );
};

const onReceiptCod = (id) => {
    return RequestManager.v1.withAuthorize.get(
        `/admin/fulfillment-orders/${id}/cod-receipt`,
    );
};

const getListLog = (id) => {
    return RequestManager.v1.withAuthorize.get(
        `/admin/fulfillment-orders/${id}/logs`,
    );
};

const createLog = (id, body) => {
    return RequestManager.v1.withAuthorize.post(
        `/admin/fulfillment-orders/${id}/logs`,
        body
    );
};

const confirmPrintItems = (body) => {
    return RequestManager.v1.withAuthorize.post(
        `/admin/fulfillment-orders/printed`,
        body
    );
};



export default {
    getListTransportOrder,
    detailTransportOrder,
    updateTransportOrder,
    updateTransportOrderData,
    onReceiptCod,
    getListLog,
    createLog,
    confirmPrintItems
};
