import { RequestManager, Helpers } from "utils";

const getListOrderTags = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/order-tags",
        params,
    );
};

const createOrderTag = (body) => {
    return RequestManager.v1.withAuthorize.post(
        "/admin/order-tags",
        body,
    );
};


export default {
    getListOrderTags,
    createOrderTag
};
