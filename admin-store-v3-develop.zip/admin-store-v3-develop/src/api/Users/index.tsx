import { RequestManager } from "utils";

const getUser = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/users/mine",
        params,
    );
};

const getListSeller = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/users/seller",
        params,
    );
};

const getCustomer = (params?: any) => {
    return RequestManager.customerInsight.withAuthorize.get(
        "/api/customer/check-registered-for-staff",
        params,
    );
};

const searchCustomer = (params?: any) => {
    return RequestManager.customerInsight.withAuthorize.get(
        "/api/customer/find-customer-for-staff",
        params,
    );
};

const customerAddress = (params?: any) => {
    return RequestManager.v1.withAuthorize.get(
        "/admin/customer-address",
        params,
    );
};


export default {
    getUser,
    getListSeller,
    getCustomer,
    searchCustomer,
    customerAddress
};
