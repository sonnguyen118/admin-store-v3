import { RequestManager } from "utils";

const getListInventoryOrder = (params?: any) => {
  return RequestManager.v1.withAuthorize.get("/admin/orders/inventory", params);
};

const detailOrder = (id) => {
  return RequestManager.v1.withAuthorize.get(`/admin/orders/${id}`);
};

const updateOrder = (id, body) => {
  return RequestManager.v1.withAuthorize.put(`/admin/orders/${id}`, body);
};

const getOrderLogs = (id) => {
  return RequestManager.v1.withAuthorize.get(`/admin/orders/${id}/logs`);
};

const createOrderLogs = (id, body) => {
  return RequestManager.v1.withAuthorize.post(`/admin/orders/${id}/logs`, body);
};

const getListFulfillmentCompany = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/fulfillment-companies`,
    params
  );
};

const getListInventory = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(`/admin/inventories`, params);
};

const getListInventorySelecter = (orderCode: string, params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/inventories/${orderCode}`,
    params
  );
};

const createOrderTransport = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders/${id}/fulfillment-orders`,
    body
  );
};

const reorderTransport = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders/${id}/reorder-fulfillment`,
    body
  );
};

const getCompanyServices = (body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/fulfillment-orders/company-services`,
    body
  );
};

const shippingFeeCalculate = (body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/fulfillment-orders/shipping-fee-calculate`,
    body
  );
};

const listFulFillmentOrderExport = (params) => {
  return RequestManager.v1.withAuthorize.get(`/admin/orders-export`, params);
};

const exportOrder = (body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders-export/exports`,
    body
  );
};

const createOrderCompensation = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/fulfillment-orders/${id}/compensation-or-refund`,
    body
  );
};

const createOrderTransportCompensation = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/orders/${id}/compensation-or-refund`,
    body
  );
};

export default {
  getListInventoryOrder,
  getListInventory,
  getListInventorySelecter,
  detailOrder,
  getOrderLogs,
  createOrderLogs,
  updateOrder,
  getListFulfillmentCompany,
  createOrderTransport,
  reorderTransport,
  shippingFeeCalculate,
  getCompanyServices,
  listFulFillmentOrderExport,
  exportOrder,
  createOrderCompensation,
  createOrderTransportCompensation,
};
