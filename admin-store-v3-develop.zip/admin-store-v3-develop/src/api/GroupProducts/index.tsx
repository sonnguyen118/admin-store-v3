import { RequestManager, Helpers } from "utils";

const extDetection = file => {
  const originX = file.original.name
    .split(".")
    .pop();
  return originX || 'png';
};

const uploadSingle = (file, settings?: any) => {
  const formData = new FormData();
  const ext = extDetection(file);

  if (file.resize instanceof Blob) {
    formData.append("images", file.resize, Helpers.randomFilename(ext));
  } else {
    formData.append("images", file.original);
  }

  return RequestManager.v1.uploadFile.postFile(
    "/admin/common/upload-images",
    formData,
    settings
  );
};

const getListGroupProduct = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-groups",
    params,
  );
};

const slugCheck = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-groups/slug-check`,
    params,
  );
};

const onCreateGroupProduct = (body) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/product-groups",
    body,
  );
};

const getDetailGroupProduct = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-groups/${id}`,
  );
};

const updateGroupProduct = (body) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/product-groups/${body.id}`,
    body,
  );
};

const getListProductGroup = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-groups/${id}/products`,
  );
};

const actionItemProductGroup = (id, body) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/product-groups/${id}/products`,
    body
  );
};

export default {
  uploadSingle,
  getListGroupProduct,
  slugCheck,
  onCreateGroupProduct,
  getDetailGroupProduct,
  updateGroupProduct,
  getListProductGroup,
  actionItemProductGroup
};
