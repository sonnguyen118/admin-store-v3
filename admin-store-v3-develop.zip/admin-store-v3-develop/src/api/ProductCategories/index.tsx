import { RequestManager } from "utils";

const getListProductCategoriesParent = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-categories/parent",
    params,
  );
};

const getListProductCategories = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-categories",
    params,
  );
};

const getListSubCategories = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-categories/parent",
    params,
  );
};

const slugCheck = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-categories/slug-check`,
    params,
  );
};

const createCategory = (params) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/product-categories",
    params,
  );
};

const detailCategory = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-categories/${id}`,
  );
};

const updateCategory = (id, params) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/product-categories/${id}`,
    params,
  );
};

const updateStatusCategories = (params) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/product-categories/bulk-field-status`,
    params,
  );
};

const updatIsActiveCategory = (id, params) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/product-categories/${id}/active`,
    params,
  );
};



export default {
    getListProductCategories,
    getListSubCategories,
    slugCheck,
    createCategory,
    detailCategory,
    updateCategory,
    updateStatusCategories,
    getListProductCategoriesParent,
    updatIsActiveCategory
};
