import { RequestManager } from "utils";

const getListProductBrands = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-brands",
    params,
  );
};

const slugCheck = (params?: any) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-brands/slug-check`,
    params,
  );
};

const createBrand = (params) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/product-brands",
    params,
  );
};

const detailBrand = (id) => {
  return RequestManager.v1.withAuthorize.get(
    `/admin/product-brands/${id}`,
  );
};

const updateBrand = (id, params) => {
  return RequestManager.v1.withAuthorize.put(
    `/admin/product-brands/${id}`,
    params,
  );
};

const updateStatusBrands = (params) => {
  return RequestManager.v1.withAuthorize.post(
    `/admin/product-brands/bulk-field-status`,
    params,
  );
};
export default {
  getListProductBrands,
  slugCheck,
  createBrand,
  detailBrand,
  updateBrand,
  updateStatusBrands
};
