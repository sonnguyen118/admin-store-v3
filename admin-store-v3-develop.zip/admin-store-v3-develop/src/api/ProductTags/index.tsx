import { RequestManager } from "utils";

const getListProductTags = (params?:any) => {
  return RequestManager.v1.withAuthorize.get(
    "/admin/product-tags",
    params,
  );
};

const getCreateProductTag = (body) => {
  return RequestManager.v1.withAuthorize.post(
    "/admin/product-tags",
    body,
  );
};

export default {
    getListProductTags,
    getCreateProductTag
};
