import React, { Suspense } from "react";
import { Switch, Route } from "react-router-dom";
import { withRouter } from 'react-router'
import Loading from "../components/DashboardLayout/Loading";
import { PrivateRoute } from "components";
import Page404 from "../pages/Errors/404";
import Page403 from "../pages/Errors/403";
import Page500 from "../pages/Errors/500";

const OverView = React.lazy(() => import("../pages/OverView"));

const Products = React.lazy(() => import("../pages/Products"));
const CreateProducts = React.lazy(() => import("../pages/Products/List/Manipulation/Create"));
const UpdateProducts = React.lazy(() => import("../pages/Products/List/Manipulation/Update"));
const RelatedProducts = React.lazy(() => import("../pages/Products/List/Manipulation/RelatedProducts"));

const Variants = React.lazy(() => import("../pages/Products/Variants"));

const ProductReviews = React.lazy(() => import("../pages/ProductReviews"));
const ProductReviewDetail = React.lazy(() => import("../pages/ProductReviews/List/Manipulation/Detail"));

const Blogs = React.lazy(() => import("../pages/Blogs"));
const CreateBlogs = React.lazy(() => import("../pages/Blogs/List/Manipulation/Create"));
const UpdateBlogs = React.lazy(() => import("../pages/Blogs/List/Manipulation/Update"));

const BlogCategories = React.lazy(() => import("../pages/BlogCategories"));
const CreateBlogCategories = React.lazy(() => import("../pages/BlogCategories/List/Manipulation/Create"));
const UpdateBlogCategories = React.lazy(() => import("../pages/BlogCategories/List/Manipulation/Update"));

const Brands = React.lazy(() => import("../pages/Brands"));
const CreateBrands = React.lazy(() => import("../pages/Brands/List/Manipulation/Create"));
const UpdateBrands = React.lazy(() => import("../pages/Brands/List/Manipulation/Update"));

const Categories = React.lazy(() => import("../pages/Categories"));
const CreateCategory = React.lazy(() => import("../pages/Categories/List/Manipulation/Create"));
const UpdateCategory = React.lazy(() => import("../pages/Categories/List/Manipulation/Update"));

const Groups = React.lazy(() => import("../pages/Groups"));
const CreateGroup = React.lazy(() => import("../pages/Groups/List/Manipulation/Create"));
const UpdateGroup = React.lazy(() => import("../pages/Groups/List/Manipulation/Update"));
const ListProduct = React.lazy(() => import("../pages/Groups/List/Manipulation/ListProduct"));

const AdminOrders = React.lazy(() => import("../pages/Orders/Admin"));
const AdminCreateOrder = React.lazy(() => import("../pages/Orders/Admin/List/Manipulation/Create"));
const AdminOrderDetail = React.lazy(() => import("../pages/Orders/Admin/List/Manipulation/Detail"));
const AdminReOrder = React.lazy(() => import("../pages/Orders/Admin/List/Manipulation/ReOrder"));
const AdminOrderComPensationRefund = React.lazy(() => import("../pages/Orders/Admin/List/Manipulation/CompensationRefund"))

const SellerOrders = React.lazy(() => import("../pages/Orders/Seller"));
const SellerCreateOrder = React.lazy(() => import("../pages/Orders/Seller/List/Manipulation/Create"));
const SellerOrderDetail = React.lazy(() => import("../pages/Orders/Seller/List/Manipulation/Detail"));
const SellerReOrder = React.lazy(() => import("../pages/Orders/Seller/List/Manipulation/ReOrder"));

const BillLaddings = React.lazy(() => import("../pages/BillLaddings"));
const BillLaddingDetail = React.lazy(() => import("../pages/BillLaddings/List/Manipulation/Detail"));
const TransportReorder = React.lazy(() => import("../pages/BillLaddings/List/Manipulation/Reorder"));

const Transports = React.lazy(() => import("../pages/Transports"));
const TransportDetail = React.lazy(() => import("../pages/Transports/List/Manipulation/Detail"));
const CompensationTransport = React.lazy(() => import("../pages/Transports/List/Manipulation/Compensation"))

const DeliveryOrder = React.lazy(() => import("../pages/DeliveryOrder"));
const DeliveryOrderJob = React.lazy(() => import("../pages/DeliveryOrder/Job"));

const Contact = React.lazy(() => import("../pages/CustomerContacts"));
const ContactDetail = React.lazy(() => import("../pages/CustomerContacts/List/Manipulation/Update"));

const Collation = React.lazy(() => import("../pages/Collation"));
const CollationImport = React.lazy(() => import("../pages/Collation/List/Manipulation/Import"));

const Customers = React.lazy(() => import("../pages/Customers"));


function MainRouter(props) {
  return (
    <div>
      <Suspense fallback={<Loading />}>
        <Switch>
          <PrivateRoute exact path={"/"} component={OverView} {...props} />

          <PrivateRoute exact path={"/products"} component={Products} {...props} />
          <PrivateRoute exact path={"/products/create"} component={CreateProducts} {...props} />
          <PrivateRoute exact path={"/products/update/:id"} component={UpdateProducts} {...props} />
          <PrivateRoute exact path={"/products/:id/variants/create"} component={Variants} {...props} />
          <PrivateRoute exact path={"/products/update/:id/variants/:vid"} component={Variants} {...props} />
          <PrivateRoute exact path={"/products/:id/related-products"} component={RelatedProducts} {...props} />

          <PrivateRoute exact path={"/product-reviews"} component={ProductReviews} {...props} />
          <PrivateRoute exact path={"/product-reviews/:id"} component={ProductReviewDetail} {...props} />

          <PrivateRoute exact path={"/blogs"} component={Blogs} {...props} />
          <PrivateRoute exact path={"/blogs/create"} component={CreateBlogs} {...props} />
          <PrivateRoute exact path={"/blogs/update/:id"} component={UpdateBlogs} {...props} />

          <PrivateRoute exact path={"/product-brands"} component={Brands} {...props} />
          <PrivateRoute exact path={"/product-brands/create"} component={CreateBrands} {...props} />
          <PrivateRoute exact path={"/product-brands/update/:id"} component={UpdateBrands} {...props} />

          <PrivateRoute exact path={"/product-categories"} component={Categories} {...props} />
          <PrivateRoute exact path={"/product-categories/create"} component={CreateCategory} {...props} />
          <PrivateRoute exact path={"/product-categories/update/:id"} component={UpdateCategory} {...props} />

          <PrivateRoute exact path={"/product-groups"} component={Groups} {...props} />
          <PrivateRoute exact path={"/product-groups/create"} component={CreateGroup} {...props} />
          <PrivateRoute exact path={"/product-groups/update/:id"} component={UpdateGroup} {...props} />
          <PrivateRoute exact path={"/product-groups/:id/products"} component={ListProduct} {...props} />

          <PrivateRoute exact path={"/orders"} component={AdminOrders} {...props} />
          <PrivateRoute exact path={"/orders/create"} component={AdminCreateOrder} {...props} />
          <PrivateRoute exact path={"/orders/detail/:id"} component={AdminOrderDetail} {...props} />
          <PrivateRoute exact path={"/orders/:id/reorder"} component={AdminReOrder} {...props} />
          <PrivateRoute exact path={"/orders/:id/create/:type"} component={AdminOrderComPensationRefund} {...props} />

          <PrivateRoute exact path={"/orders-seller"} component={SellerOrders} {...props} />
          <PrivateRoute exact path={"/orders-seller/create"} component={SellerCreateOrder} {...props} />
          <PrivateRoute exact path={"/orders-seller/detail/:id"} component={SellerOrderDetail} {...props} />
          <PrivateRoute exact path={"/orders-seller/:id/reorder"} component={SellerReOrder} {...props} />

          <PrivateRoute exact path={"/bill-laddings"} component={BillLaddings} {...props} />
          <PrivateRoute exact path={"/bill-laddings/order/:id"} component={BillLaddingDetail} {...props} />

          <PrivateRoute exact path={"/transports"} component={Transports} {...props} />
          <PrivateRoute exact path={"/transports/detail/:id"} component={TransportDetail} {...props} />
          <PrivateRoute exact path={"/transports/:id/reorder-fulfillment"} component={TransportReorder} {...props} />
          <PrivateRoute exact path={"/transports/:id/create/:type"} component={CompensationTransport} {...props} />

          <PrivateRoute exact path={"/delivery-order"} component={DeliveryOrder} {...props} />
          <PrivateRoute exact path={"/delivery-order/job"} component={DeliveryOrderJob} {...props} />
          

          <PrivateRoute exact path={"/blog-categories"} component={BlogCategories} {...props} />
          <PrivateRoute exact path={"/blog-categories/create"} component={CreateBlogCategories} {...props} />
          <PrivateRoute exact path={"/blog-categories/update/:id"} component={UpdateBlogCategories} {...props} />

          <PrivateRoute exact path={"/collation"} component={Collation} {...props} />
          <PrivateRoute exact path={"/collation/import"} component={CollationImport} {...props} />

          <PrivateRoute exact path={"/customers"} component={Customers} {...props} />

          <PrivateRoute exact path={"/customer-contacts"} component={Contact} {...props} />
          <PrivateRoute exact path={"/customer-contacts/update/:id"} component={ContactDetail} {...props} />

          <PrivateRoute path="/403" component={Page403} {...props} />
          <PrivateRoute path="/500" component={Page500} {...props} />

          <PrivateRoute path="*" component={Page404} {...props} />
        </Switch>
      </Suspense>
    </div>
  );
}

export default withRouter(MainRouter)