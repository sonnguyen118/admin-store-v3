export const INCREMENT_LOADING = "user/INCREMENT_LOADING";
export const DECREMENT_LOADING = "user/DECREMENT_LOADING";
export const GET_USER = "user/GET_USER";

export const IncrementLoading = {
  payload: 1,
  type: INCREMENT_LOADING
};

export const DecrementLoading = {
  payload: 1,
  type: DECREMENT_LOADING
};

export const setUser = payload => {
  return {
    payload,
    type: GET_USER
  };
};









