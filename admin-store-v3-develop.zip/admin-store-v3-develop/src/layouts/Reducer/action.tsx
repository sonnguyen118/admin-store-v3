import {
  Users as UsersAPI
} from "api";
import {
  IncrementLoading,
  DecrementLoading,
  setUser
} from "./action-type";

export const onGetUser = async (params, dispatch) => {
  try {
    const response = await UsersAPI.getUser(params);
    const { data, status } = response;
    if (status === 200) {
      dispatch(
        setUser({
          user: data.data
        })
      )
      return;
    }
  } catch (error) {
    dispatch(
      setUser({
        user: null,
        message: "Đã xảy ra lỗi vui lòng quay lại sau",
        type: "error"
      })
    )
  }
};