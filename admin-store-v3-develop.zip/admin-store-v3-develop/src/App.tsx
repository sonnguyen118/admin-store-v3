import React, { useEffect, useState } from "react";
import "./App.scss";
import request from "utils/RequestManager/RequestGlobalConfig";
import config from "configs/env";
import MainDashboard from "./pages";
import { SSO } from "@30shine/sso-erp";

const sso = new SSO(process.env.REACT_APP_ENV || "test");

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const fetchCredentials = async () => {
    try {
      // @ts-ignore
      // const credentials = {
      //     AccessToken: "eyJraWQiOiJydEd1c1hpbWZ6OFN6SEhGek04cTRtMkh2eDZTazU3MHpzM0NXQTVPTWtRPSIsImFsZyI6IlJTMjU2In0.eyJzdWIiOiJmMmEzYzIwOS03Yzg1LTQ3NWEtYTliNy1hMzM1YTk0MzQ5ZjAiLCJldmVudF9pZCI6ImM0NjJjNzI0LTg5YzYtNDU5YS1iZmU0LTgxMjU2YzFmN2Q4NCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE2NjA2MzYzNDEsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC5hcC1zb3V0aGVhc3QtMS5hbWF6b25hd3MuY29tXC9hcC1zb3V0aGVhc3QtMV80SDJ3d0NYeFUiLCJleHAiOjE2NjA2Mzk5NDAsImlhdCI6MTY2MDYzNjM0MSwianRpIjoiZDJjMTYxMWUtN2I0Ni00ODc5LTk1NDYtNDg3NGJkMDNjMjkxIiwiY2xpZW50X2lkIjoiNnNsamxycW1waGprNWgwaGhoaXBja241MDkiLCJ1c2VybmFtZSI6InZ1Lm5ndXllbiJ9.FQ6wORPlHqeGydrdACjwd3aoMAlZd0Du6XbfzXClAV3NS7_B4eqOeq6Wm6G1NfJU52b7x-crV28wJ25zKa4PdvX8mX0bpAd2a5eDE1rR782b5Iu26NCUzgx_Ch_F7jb5neEzeEb5w5PUQQvYGmSmYp6t2u-oI5syoFKXJdxVGgzKaZdEeoh9e6MQFrQuwsaWkUsQDyQrRQgVS4F0FP3HSPWW7MRSQgT0u4tE6RRfLiIxpkqvGLeVCn7tUxeM5s3vjjATZhihUNVxaj3tH4nkCrP7UMoPxjxFSgjrjvCfV7zGmpP7l9l1sZcGr8jUxGSKaqVOIwjK2HFVfhKgWyQo1g"
      // }
      // localStorage.setItem("AccessToken", credentials.AccessToken);
      const credentials = await sso.ssoLogin();
      // Update credentials
      localStorage.setItem("AccessToken", credentials.AccessToken);
      localStorage.setItem("RefreshToken", credentials.RefreshToken);
      localStorage.setItem("IdToken", credentials.IdToken);

      if (credentials) {
        request.defaults.headers.common["Authorization"] =
          "Bearer " + credentials.AccessToken;
        request.interceptors.response.use(
          (response) => {
            return response;
          },
          async (error) => {
            console.log(error);
            const originalRequest = error.config;
            if (error.response.status === 401) {
              let data = await sso.refreshToken();
              localStorage.setItem("AccessToken", data.AccessToken);
              originalRequest.headers = {
                Authorization: "Bearer " + data.AccessToken,
              };
              return request(originalRequest);
            }

            return Promise.reject(error);
          }
        );

        setIsAuthenticated(true);
      }
    } catch (e) {
      console.log(e);
    }
  };

  useEffect(() => {
    fetchCredentials();
  }, []);

  return <div className="App">{isAuthenticated && <MainDashboard />}</div>;
}

export default App;
