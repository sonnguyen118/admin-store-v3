
const withToken = Component => props => {
  const token = localStorage.getItem("AccessToken");
  return <Component {...props} token={token} />;
};

export default withToken;
