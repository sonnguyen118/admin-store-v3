import { compose as withCompose } from "ramda";

export default withCompose;
